## Projet Web

> Sommaire

- [Liste des Commandes](#commandes)
  - [FrontEnd](#commandes-frontend)
  - [BackEnd](#commandes-backend)
- [Projet](#projet)
  - [Sujets](#sujets)
  - [Ressources](#ressources)
- [Base de Données](#base-de-données)
  - [Collections](#collections)
    - [Tickets](#tickets)
    - [Clients](#clients)
    - [Developers](#developers)
    - [Projects](#projects)
    - [Comments](#comments)
  - [Interfaces](#interfaces)
    - [Users](#users)
- [Fonctionnement](#fonctionnement)
- [Etape par étape](#etape-par-etape)
  - [Arrivée sur le site](#arrivée-sur-le-site)
  - [Accueil](#accueil)
  - [Projets](#projets)
    - [Création d'un Projet](#création-dun-projet)
    - [Modification d'un Projet](#modification-dun-projet)
    - [Backlog d'un Projet](#backlog-dun-projet)
    - [Tickets d'un Projet](#tickets-dun-projet)
  - [Tickets](#tickets)
    - [Création d'un Ticket](#création-dun-ticket)
    - [Modification d'un Ticket](#modification-dun-ticket)
    - [Commentaires d'un Ticket](#commentaires-dun-ticket)
  - [Statistiques](#statistiques)
  - [Profil](#profil)
- [Membres du Groupe](#membres-du-groupe)
- [Notes](#notes)

## Commandes

### Commandes FrontEnd

- `npm install vue`: Installe le package Vue.js
- `npm install vuex`: Installe le package Vuex
- `npm install bootstrap`: Installe le package bootstrap
- `npm run serve`: Permet de lancer le serveur sur le port 8080

Rappel : les commandes doivent être exécutées dans le dossier `FrontEnd\src`.

### Commandes BackEnd

- `npm install cors`: Installe le package Cors
- `npm install express`: Installe le package Express
- `npm install mongoose`: Installe le package Mongoose
- `npm install nodemon`: Installe le package Nodemon
- `npm install dotenv`: Installe le package dotenv
- `npx nodemon app.js`: Lance l'application Node.js App

Rappel : les commandes doivent être exécutées dans le dossier `BackEnd\src`.

## Projet

### Sujets

- [Application pour une Société d'Assurance Auto](./Ressources/sujet1.pdf)
- [Gestion de Matériel](./Ressources/sujet2.pdf)
- [Gestion de Tickets d'Incidents](./Ressources/sujet3.pdf)
- [Site Internet - Boutique Electronique](./Ressources/sujet4.pdf)
- [Gestion électronique de documents GED](./Ressources/sujet5.pdf)
- [Gestion de Tâches](./Ressources/sujet6.pdf)

Le sujet choisi pour ce projet est la [Gestion de Tickets d'Incidents](./Ressources/sujet3.pdf).

### Ressources

- [API Reference](http://vuejs.org/api/)
- [Postman Documentation](https://learning.postman.com/docs/introduction/overview/)

## Base de Données

La Base de Données utilisée a été faite depuis MongoDB.
Pour accéder à la base de données, il faut avoir inscrit son adresse IP dans la liste des adresses IP autorisées dans le cluster MongoDB.
Un diagramme de classe a été créé pour représenter les différentes collections de la base de données, celui-ci est le suivant: [cliquez ici](./Ressources/class%20diagram.pdf).

### Collections

Dans MongoDB, on n'utilise pas de tables, mais des collections, celles-ci sont les suivantes.

#### Tickets

La collection "Tickets" de notre application Web comprend les paramètres suivants :

- `_id` : **Number** - Identifiant unique du ticket.
- `title` : **String** - Titre du ticket.
- `description` : **String** - Description détaillée du ticket.
- `status` : **String** - Statut actuel du ticket (par exemple, ouvert, en cours, fermé).
- `priority` : **String** - Priorité du ticket (par exemple, faible, moyenne, haute).
- `dateCreation` : **Date** - Date de création du ticket.
- `endDate` : **Date** - Date de clôture prévue du ticket.
- `creator` : **ObjectId** - Référence à l'utilisateur qui a créé le ticket.
- `assignee` : **ObjectId** - Référence au développeur assigné au ticket.
- `project` : **ObjectId** - Référence au projet associé au ticket.

#### Clients

La collection "Clients" de notre application Web comprend les paramètres suivants :

- `_id` : **ObjectId** - Identifiant unique du client.
- `name` : **String** - Prénom du client.
- `surname` : **String** - Nom du client.
- `email` : **String** - Adresse e-mail du client.
- `companyName` : **String** - Nom de la société du client.

Cette collection fait référence à la collection "Users" pour les utilisateurs qui sont des clients.

#### Developers

La collection "Developers" de notre application Web comprend les paramètres suivants :

- `_id` : **ObjectId** - Identifiant unique du développeur.
- `name` : **String** - Prénom du développeur.
- `surname` : **String** - Nom du développeur.
- `email` : **String** - Adresse e-mail du développeur.
- `position` : **String** - Poste du développeur, par exemple, développeur front-end, développeur back-end.

Cette collection fait référence à la collection "Users" pour les utilisateurs qui sont des développeurs.

#### Projects

La collection "Projects" de notre application Web comprend les paramètres suivants :

- `_id` : **ObjectId** - Identifiant unique du projet.
- `name` : **String** - Nom du projet.
- `description` : **String** - Description détaillée du projet.

#### Comments

La collection "Comments" de notre application Web comprend les paramètres suivants :

- `_id` : **ObjectId** - Identifiant unique du commentaire.
- `text` : **String** - Texte du commentaire.
- `date` : **Date** - Date de création du commentaire.
- `author` : **ObjectId** - Référence à l'utilisateur qui a écrit le commentaire.
- `ticket` : **ObjectId** - Référence au ticket associé au commentaire.

### Interfaces

En JavaScript, contrairement à d'autres langages de programmation, il n'y a pas de classes pour définir des interfaces. De ce fait, tous les paramètres des interfaces sont reportés dans les collections implémentant ces interfaces.

#### Users

L'interface "Users" de notre application Web comprend les paramètres suivants :

- `_id` : **ObjectId** - Identifiant unique de l'utilisateur.
- `name` : **String** - Prénom de l'utilisateur.
- `surname` : **String** - Nom de l'utilisateur.
- `email` : **String** - Adresse e-mail de l'utilisateur.

Cette interface est implémentée par les collections "Clients" et "Developers".

## Fonctionnement

Le projet est divisé en deux parties, le Front-End et le Back-End.
- Le Front-End est réalisé en Vue.js et le Back-End en Node.js.
- Le Front-End est la partie visible de l'application, c'est-à-dire l'interface utilisateur. Le Back-End est la partie invisible de l'application, c'est-à-dire le serveur qui gère les requêtes de l'application.

Pour lancer l'application, il faut lancer le serveur Back-End et le serveur Front-End.

Pour lancer le serveur Back-End, il faut exécuter la commande suivante : `npx nodemon app.js`.
Pour lancer le serveur Front-End, il faut exécuter la commande suivante : `npm run serve`.

Pour accéder à l'application, il faut ouvrir un navigateur et taper l'URL suivante : `http://localhost:8080`.

## Etape par étape

### Arrivée sur le site

Lorsque l'utilisateur arrive sur le site, il est redirigé vers la page de connexion.
S'il n'a pas de compte, il peut s'inscrire en cliquant sur le cliquant sur "Create one here". S'il a déjà un compte, il peut se connecter en entrant son adresse e-mail et son mot de passe.

### Accueil

Une fois connecté, l'utilisateur est redirigé vers la page d'accueil. Il peut s'y rendre en cliquant sur "Home" depuis le header de la page ou sur le logo de l'application.
Depuis l'accueil, il peut accéder à ses projets, ses tickets, ses statistiques et son profil.
En dessous de ces liens, il y a les 5 derniers commentaires des projets auxquels l'utilisateur participe.

### Projets

Une fois connecté, l'utilisateur est redirigé vers la page "Mes Projets".
Sur cette page, il peut voir la liste des projets auxquels il participe.

#### Création d'un Projet

L'utilisateur peut créer un nouveau projet en cliquant sur "Create Project" depuis la page "Mes Projets". Il sera redirrigé vers une page où il pourra entrer le nom et la description du projet.
L'utilisateur sera automatiquement admin du projet.

#### Modification d'un Projet

L'utilisateur peut modifier un projet en cliquant sur le projet depuis la page "Mes Projets". Il ne peut modifier un projet que s'il est admin du projet.
Il peut modifier le nom et la description du projet ainsi que les utilisateurs qui participent au projet.

#### Backlog d'un Projet

L'utilisateur peut voir le backlog d'un projet en cliquant sur le projet depuis la page "Mes Projets".
Il verra ainsi la liste de l'ensemble des tickets du projet triés par status (BACKLOG, TODO, IN DEVELOPMENT, IN TESTS, DONE, CLOSED).
C'est le seul endroit où l'utilisateur peut voir les tickets du projet possédant le statut BACKLOG ou CLOSED.
Seul un admin du projet peut voir le backlog du projet.

#### Tickets d'un Projet

L'utilisateur peut voir les tickets d'un projet en cliquant sur le projet depuis la page "Mes Projets".
Il verra ainsi la liste de l'ensemble des tickets du projet séparés par statut (TODO, IN DEVELOPMENT, IN TESTS, DONE).
Il peut également créer un nouveau ticket en cliquant sur "Create Ticket".

### Tickets

L'utilisateur peut voir la liste des tickets auxquels il participe en cliquant sur "Mes Tickets" depuis le header de la page.
Il verra ainsi la liste des tickets séparés par statut (TODO, IN DEVELOPMENT, IN TESTS, DONE).
Il est aussi précisé la priorité du ticket, le nombre de jour restant avant la date de fin et le projet associé.

#### Création d'un Ticket

L'utilisateur peut créer un nouveau ticket en cliquant sur "Create Ticket" depuis la page "Mes Tickets" ou depuis la page d'un projet.
Il sera redirrigé vers une page où il pourra entrer le titre, la description, la priorité, la date de fin et l'assignation du ticket.
Il sera automatiquement le créateur du ticket.

#### Modification d'un Ticket

L'utilisateur peut modifier un ticket en cliquant sur le ticket depuis la page "Mes Tickets" ou depuis la page d'un projet.
Il peut modifier le titre, la description, le statut, la priorité, la date de fin et l'assignation du ticket.
(Pour modifier le statut, il faut cliquer sur le bouton "Set to x" une fois après avoir appuyé sur le ticket depuis la page du projet ou depuis la page "Mes Tickets".)
Seul un ticket avec le status BACKLOG peut être supprimé. Seul le développeur assigné peut modifier le status du ticket. Seul un admin du projet peut envoyer un ticket en BACKLOG ou le fermer.

#### Commentaires d'un Ticket

L'utilisateur peut voir les commentaires d'un ticket en cliquant sur le ticket depuis la page "Mes Tickets" ou depuis la page d'un projet.
Il peut ajouter un commentaire en écrivant le texte du commentaire et en cliquant sur "Add Comment".

Les informations sur les commentaires sont les suivantes :
- `Le texte du commentaire`
- `La date de création du commentaire`
- `L'auteur du commentaire`

### Statistiques

L'utilisateur peut voir les statistiques de son activité en cliquant sur "Statistics" depuis le header de la page.
Il verra ainsi diverses informations sur ses tickets et ses projets.

### Profil

L'utilisateur peut voir son profil en cliquant sur "Account" depuis le header de la page.
Il peut modifier son nom, son prénom et son mot de passe.
S'il est un développeur, il peut également modifier son poste. Sinon, il peut modifier son nom de société.
L'adresse mail ne peut pas être modifiée.

## Membres du Groupe

- `Rayan Capaldi Benamou` : **Full-Stack**
- `Ahmad Houhou` : **Front-End**
- `Baptiste Nevejans` : **Front-End**
- `Matthieu Brandao` : **Front-End**

## Notes

Une nouvelle version du projet en ligne est disponible sous le nom de [RambHub](https://rambhub.vercel.app), hébergé depuis Vercel et Render.
