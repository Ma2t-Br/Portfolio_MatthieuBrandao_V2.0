<template>
  <div class="create-account">
    <h1>Create an Account</h1>
    <br>
    <div class="form-container">
      <form @submit.prevent="createAccount">
        <div class="form-group">
          <label for="name">Name</label>
          <input type="text" id="name" v-model="newAccount.name" required>
          <label for="surname">Surname</label>
          <input type="text" id="name" v-model="newAccount.surname" required>
          <label for="role">Role</label>
          <div class="radio-group">
            <label class="radio-label">
              <input type="radio" id="dev" value="Developer" v-model="newAccount.role" required>
              <span class="radio-custom"></span>
              Developer
            </label>
            <label class="radio-label">
              <input type="radio" id="client" value="Client" v-model="newAccount.role" required>
              <span class="radio-custom"></span>
              Client
            </label>
          </div>
          <label for="position" v-if="newAccount.role === 'Developer'">Position</label>
          <input v-if="newAccount.role === 'Developer'" type="text" id="position" v-model="newAccount.position">
          <label for="company-name" v-if="newAccount.role === 'Client'">Company Name</label>
          <input v-if="newAccount.role === 'Client'" type="text" id="company-name" v-model="newAccount.companyName">
          <label for="email">Email</label>
          <input type="email" id="email" v-model="newAccount.email" required>
          <label for="password">Password</label>
          <input type="password" id="password" v-model="newAccount.password" required>
          <label for="confirm-password">Confirm Password</label>
          <input type="password" id="confirm-password" v-model="confirmPassword" required>
        </div>
        <button type="submit">Create Account</button>
      </form>
    </div>
  </div>
</template>

<script>
import { createDev, fetchDevByEmail } from '../APicalls/devCalls.js'
import { createClient, fetchClientByEmail } from '../APicalls/clientCalls.js'

export default {

  name: 'CreateAccount',
  data() {
    return {
      newAccount: {
        name: '',
        surname: '',
        email: '',
        password: '',
        role: 'Developer',
        companyName: '',
        position: ''
      },
      newDev: {},
      newClient: {},
      confirmPassword: ''
    }
  },
  methods: {
    async checkAccountExist(){
      if (this.newAccount.role === 'Developer') {
        const dev = (await fetchDevByEmail(this.newAccount.email)).result;
        if (dev)
          return true;
      } else {
        const client = (await fetchClientByEmail(this.newAccount.email)).result;
        if (client)
          return true;
      }
      return false;
    },
    async createAccount() {
      if (this.newAccount.password !== this.confirmPassword) {
        alert('Passwords do not match');
        return;
      }
      const accountExist = await this.checkAccountExist();
      if (accountExist){
        alert('Account already exists');
        return;
      }
      if (this.newAccount.role === 'Developer') {
        this.newDev = {
          name: this.newAccount.name,
          surname: this.newAccount.surname,
          email: this.newAccount.email,
          password: this.newAccount.password,
          position: this.newAccount.position
        }
        const result = await createDev(this.newDev);
        if (result.error){
          alert('Error creating account');
        } else{
          this.$router.push({ name: 'LoginAccount' });
        }
      } else {
        this.newClient = {
          name: this.newAccount.name,
          surname: this.newAccount.surname,
          email: this.newAccount.email,
          password: this.newAccount.password,
          companyName: this.newAccount.companyName
        }
        const result = await createClient(this.newClient);
        if (result.error){
          alert('Error creating account');
        } else{
          this.$router.push({ name: 'LoginAccount' });
        }
      }
      
      this.resetFields();
    },
    resetFields(){
      this.newAccount.name = '';
      this.newAccount.surname = '';
      this.newAccount.email = '';
      this.newAccount.password = '';
      this.newAccount.role = 'Developer';
      this.newAccount.companyName = '';
      this.newAccount.position = '';
      this.confirmPassword = '';
      this.newDev = {};
      this.newClient = {};
    }
  }
}
</script>

<style scoped>
.radio-group {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
}

.radio-label {
  position: relative;
  padding-left: 25px;
  cursor: pointer;
  font-size: 14px;
  user-select: none;
}

.radio-label input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
}

.radio-custom {
  position: absolute;
  top: 0;
  left: 0;
  height: 18px;
  width: 18px;
  background-color: #eee;
  border-radius: 50%;
}

.radio-label input:checked ~ .radio-custom {
  background-color: #2196F3;
}

.radio-custom:after {
  content: "";
  position: absolute;
  display: none;
}

.radio-label input:checked ~ .radio-custom:after {
  display: block;
}

.radio-custom:after {
  top: 6px;
  left: 6px;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: white;
}
.create-account {
  text-align: center;
}

.form-container {
  width: 300px;
  margin: 0 auto;
}

.form-group {
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 5px;
}

input[type="text"],
input[type="email"],
input[type="password"] {
  width: 100%;
  padding: 8px;
  border-radius: 5px;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  width: 100%;
  padding: 10px 20px;
  background-color: #42b983;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}
</style>
