<template>
  <div class="project-tickets">
    <h1 v-if="project">{{ project.name }}'s Tickets</h1>
    <button @click="createTicket" class="create-ticket">Create Ticket</button>
    <div class="columns">
      <div class="column todo">
        <h2>TODO</h2>
        <div v-for="ticket in filteredTickets('TODO')" :key="ticket._id" class="ticket" @click="toggleSubMenu(ticket._id)" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
          <div class="ticket-title">{{ ticket.title }}</div>
          <div class="ticket-owner">{{ ticket.owner }}</div>
          <div class="ticket-prority">{{ ticket.priority }}</div>
          <div class="days-left" v-if="daysLeft(ticket) > 0">{{ daysLeft(ticket) }} days left</div>
          <div class="days-left overdue" v-else>Overdue</div>
          <div v-if="ticket._id === activeSubMenu" class="submenu" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
            <button @click="viewTicket(ticket)">View Ticket</button>
            <button @click="setToInDev(ticket)" :disabled="user._id !== ticket.assignee">Set to In Development</button>
            <button @click="sendToBacklog(ticket)" :disabled="!hasSuperAccess">Send to the Backlog</button>
          </div>
        </div>
      </div>
      <div class="column in-development">
        <h2>IN DEVELOPMENT</h2>
        <div v-for="ticket in filteredTickets('IN DEVELOPMENT')" :key="ticket.id" class="ticket" @click="toggleSubMenu(ticket._id)" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
          <div class="ticket-title">{{ ticket.title }}</div>
          <div class="ticket-owner">{{ ticket.owner }}</div>
          <div v-if="ticket._id === activeSubMenu" class="submenu" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
            <button @click="viewTicket(ticket)">View Ticket</button>
            <button @click="setToInTests(ticket)" :disabled="user._id !== ticket.assignee">Set to In Tests</button>
            <button @click="setToTodo(ticket)" :disabled="user._id !== ticket.assignee">Set to Todo</button>
          </div>
          <div class="ticket-prority">{{ ticket.priority }}</div>
          <div class="days-left" v-if="daysLeft(ticket) > 0">{{ daysLeft(ticket) }} days left</div>
          <div class="days-left overdue" v-else>Overdue</div>
        </div>
      </div>
      <div class="column in-tests">
        <h2>IN TESTS</h2>
        <div v-for="ticket in filteredTickets('IN TESTS')" :key="ticket.id" class="ticket" @click="toggleSubMenu(ticket._id)" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
          <div class="ticket-title">{{ ticket.title }}</div>
          <div class="ticket-owner">{{ ticket.owner }}</div>
          <div v-if="ticket._id === activeSubMenu" class="submenu" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
            <button @click="viewTicket(ticket)">View Ticket</button>
            <button @click="setToDone(ticket)" :disabled="user._id !== ticket.assignee">Set to Done</button>
            <button @click="setToInDev(ticket)" :disabled="user._id !== ticket.assignee">Set to In Development</button>
          </div>
          <div class="ticket-prority">{{ ticket.priority }}</div>
          <div class="days-left" v-if="daysLeft(ticket) > 0">{{ daysLeft(ticket) }} days left</div>
          <div class="days-left overdue" v-else>Overdue</div>
        </div>
      </div>
      <div class="column done">
        <h2>DONE</h2>
        <div v-for="ticket in filteredTickets('DONE')" :key="ticket.id" class="ticket" @click="toggleSubMenu(ticket._id)" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
          <div class="ticket-title">{{ ticket.title }}</div>
          <div class="ticket-owner">{{ ticket.owner }}</div>
          <div v-if="ticket._id === activeSubMenu" class="submenu" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
            <button @click="viewTicket(ticket)">View Ticket</button>
            <button @click="setToInTests(ticket)" :disabled="user._id !== ticket.assignee">Set to In Tests</button>
            <button @click="setToClosed(ticket)" :disabled="!hasSuperAccess">Close the Ticket</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
  
<script>
  import { fetchProjectById } from '../APicalls/projectCalls.js';
  import { fetchTicketsByProjectId} from '../APicalls/ticketCalls.js';
  import { fetchDevById } from '../APicalls/devCalls.js';
  import { updateTicket } from '../APicalls/ticketCalls.js';
  import { fetchAccessesForUser } from '../APicalls/accessCalls.js';

  export default {
    name: 'OneProjectTickets',
    props: {
      id: {
        type: String,
        required: true
      }
    },
    data() {
      return {
        project: null,
        tickets: [],
        activeSubMenu: null,
        hasSuperAccess: false
      };
    },
    computed: {
      user() {
        return this.$store.state.user;
      },
      daysLeft() {
        return function(ticket) {
          const now = new Date();
          const endDate = new Date(ticket.endDate);
          if (endDate < now) {
            return 0;
          }
          const diffTime = Math.abs(endDate - now);
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          return diffDays;
        }
      }
    },
    methods: {
      keepSubMenuOpen() {
        // Do nothing to keep the submenu open
      },
      hideSubMenu() {
        this.activeSubMenu = null;
      },
      createTicket() {
        this.$router.push({ name: 'TicketCreation', params: { id: this.id } });
      },
      filteredTickets(status) {
        if (status === 'DONE') {
          return this.tickets ? this.tickets.filter(ticket => ticket.status === status) : [];
        } else {
          return this.tickets 
            ? this.tickets
                .filter(ticket => ticket.status === status)
                .sort((a, b) => this.daysLeft(a) - this.daysLeft(b))
            : [];
        }
      },
      toggleSubMenu(ticketId) {
        this.activeSubMenu = this.activeSubMenu === ticketId ? null : ticketId;
      },
      viewTicket(ticket) {
        this.$router.push({ name: 'TicketDetails', params: { ticketId: ticket._id , projectId: this.id } });
      },
      async sendToBacklog(ticket) {
        const updatedData = { ...ticket, status: 'BACKLOG' };
        await this.updateTicket(ticket._id, updatedData);
      },
      async setToTodo(ticket) {
        const updatedData = { ...ticket, status: 'TODO' };
        await this.updateTicket(ticket._id, updatedData);
      },
      async setToInDev(ticket) {
        const updatedData = { ...ticket, status: 'IN DEVELOPMENT' };
        await this.updateTicket(ticket._id, updatedData);
      },
      async setToInTests(ticket) {
        const updatedData = { ...ticket, status: 'IN TESTS' };
        await this.updateTicket(ticket._id, updatedData);
      },
      async setToDone(ticket) {
        const updatedData = { ...ticket, status: 'DONE' };
        await this.updateTicket(ticket._id, updatedData);
      },
      async setToClosed(ticket) {
        const updatedData = { ...ticket, status: 'CLOSED' };
        await this.updateTicket(ticket._id, updatedData);
      },
      async updateTicket(ticketID, ticketData) {
        try {
          const response = await updateTicket(ticketID, ticketData);
          if (response.error) {
            alert('Error updating ticket');
          } else {
            this.tickets = this.tickets.map(ticket => 
              ticket._id === ticketID 
                ? { ...response.result, owner: ticket.owner } 
                : ticket
            );
          }
        } catch (error) {
          console.error(error);
        }
      },
      async checkSuperAccess(projectId) {
        let accesses = (await fetchAccessesForUser(this.user._id)).result;
        for (let access of accesses) {
          if (access.project === projectId && access.user === this.user._id) {
            this.hasSuperAccess = access.super;
            console.log('User has super access to project', access.super);
            break;
          }
        }
      }
    },
    async created() {
      if (!this.user){
        this.$router.push({ name: 'LoginAccount' });
        return;
      }
      try {
        const projectResponse = await fetchProjectById(this.id);
        if (projectResponse) {
          this.project = projectResponse.result;
        }

        const ticketsResponse = await fetchTicketsByProjectId(this.id);
        if (ticketsResponse) {
          this.ticketsData = ticketsResponse.result;
        }

        for (let ticket of this.ticketsData) {
          const devData = await fetchDevById(ticket.assignee);
          if (devData && devData.result && devData.result.name && devData.result.surname) {
            ticket.owner = devData.result.name[0] + devData.result.surname[0];
          }
        }

        this.tickets = this.ticketsData;
        await this.checkSuperAccess(this.id);
      } catch (error) {
        console.error(error);
      }
    }
  } 
</script>
  
<style scoped>
  .project-tickets {
    padding: 20px;
  }

  .project-tickets h1 {
    margin-bottom: 50px;
  }

  .create-ticket {
    background-color: #4fa3ff;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin: 20px 0;
    margin-top: -70px;
    float: right;
  }

  .create-ticket:hover {
    transform: scale(1.05);
    background-color: #007bff;
  }

  .columns {
    display: flex;
    justify-content: space-around;
    margin-top: 20px;
  }

  .column {
    width: 20%;
    padding: 10px;
    border-radius: 5px;
  }

  .column h2 {
    text-align: center;
    padding: 10px;
    border-radius: 5px 5px 0 0;
  }

  .todo {
    background-color: #f8d7da;
  }

  .in-development {
    background-color: #fff3cd;
  }

  .in-tests {
    background-color: #d1c4e9;
  }

  .done {
    background-color: #d4edda;
  }

  .ticket {
    background-color: #e7f1ff;
    padding: 10px;
    margin: 10px 0;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    position: relative;
  }

  .ticket:hover {
    background-color: #cde0ff;
    transform: scale(1.05);
    z-index: 2;
  }

  .ticket-title {
    font-weight: bold;
  }

  .ticket-owner {
    background-color: #8c9eff;
    color: #fff;
    padding: 5px;
    border-radius: 50%;
    text-align: center;
    width: 30px;
    height: 30px;
    display: inline-block;
    line-height: 20px;
    margin-top: 10px;
  }

  .ticket-prority {
    color: #ff9c07;
    position: absolute;
    bottom: 10px;
    left: 10px;
  }

  .submenu {
    display: flex;
    flex-direction: column;
    margin-top: 10px;
    position: absolute;
    right: -100px;
    top: 0;
    width: 140px;
    background-color: #e7f1ff;
    border: 1px solid #ccc;
    border-radius: 5px;
    padding: 10px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    z-index: 1;
  }

  .submenu button {
    background-color: #d4e5ff;
    border: none;
    border-radius: 5px;
    color: #ffffff;
    font-size: 16px;
    margin-bottom: 10px;
    padding: 10px;
    text-align: center;
    cursor: pointer;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    transition: background-color 0.3s ease;
  }

  .submenu button:hover {
    transform: scale(1.05);
    background-color: #b0cfff;
  }

  .days-left {
    position: absolute;
    bottom: 10px;
    right: 10px;
    color: red;
    display: block;
  }

  .days-left.overdue {
    color: darkred;
    font-weight: bold;
  }

</style>  