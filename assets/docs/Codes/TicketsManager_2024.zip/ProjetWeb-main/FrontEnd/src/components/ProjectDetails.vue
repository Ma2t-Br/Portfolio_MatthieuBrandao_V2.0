<template>
    <div class="project-details" v-if="loading">
        Loading...
    </div>
    <div class="project-details" v-else>
        <h1 style="text-align: left; margin-bottom: 50px;">Project's Details</h1>
        <button @click="updateProject()" class="update-project">Update Project</button>
        <button @click="deleteProject()" class="delete-project">Delete Project</button>
        <br>
        <div class="form-container">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" id="name" v-model="project.name">
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" v-model="project.description"></textarea>
            </div>
        </div>
        <div class="user-management" v-if="!loading">
            <h2>User Management</h2>
            <br>
            <div v-if="users.length === 0">
                You are the only user with access to this project.
            </div>
            <div v-else v-for="user in users" :key="user._id" class="user">
                <div class="user-names">
                    <p>{{ user.name }}</p>
                    <p>{{ user.surname }}</p>
                </div>
                <div class="user-email">
                    <p>{{ user.email }}</p>
                </div>
                <div class="user-role">
                    <p>{{ user.role }}</p>
                    <p v-if="user.role === 'Client'" style="font-weight: bold;">({{ user.companyName }})</p>
                    <p v-else style="font-weight: bold;">({{ user.position }})</p>
                </div>
                <div class="user-super">
                    <p>{{ user.super }}</p>
                </div>
                <div class="user-buttons">
                    <button class="user-change-role" @click="toggleSuper(user._id)">{{ user.super === 'Admin' ? 'Make User' : 'Make Admin' }}</button>
                    <button class="user-revoke" @click="revokeAccess(user._id)">Revoke Access</button>
                </div>
            </div>
            <div class="user-add">
                <label for="newUserMail">Enter the mail adress of the user to add</label>
                <input type="text" id="newUserMail" v-model="newUserMail">
                <button @click="addUser()">Add User</button>
            </div>
        </div>
    </div>
</template>

<script>
    import { fetchProjectById, updateProject, deleteProject } from '../APicalls/projectCalls.js';
    import { fetchAccessesForProject, updateAccess, deleteAccess, createAccess } from '../APicalls/accessCalls.js';
    import { fetchDevById, fetchDevByEmail } from '../APicalls/devCalls.js'
    import { fetchClientById, fetchClientByEmail } from '../APicalls/clientCalls.js'
    import { fetchTicketsByProjectId, deleteTicket } from '../APicalls/ticketCalls.js'
    import { fetchCommentsByTicketId, deleteComment } from '../APicalls/commentCalls.js'

    export default {
        name: 'ProjectDetails',
        props: {
            id: {
                type: String,
                required: true
            }
        },
        data() {
            return {
                project: {
                    name: '',
                    description: ''
                },
                users: [],
                loading: true,
                newUserMail: '',
            };
        },
        computed: {
            user() {
                return this.$store.state.user;
            }
        },
        methods: {
            async updateProject() {
                try {
                    const updatedData = { ...this.project };
                    const response = await updateProject(this.id, updatedData);
                    if (response.error) {
                        alert('Error updating project');
                        return;
                    }
                    alert('Project updated successfully');
                }
                catch (error) {
                    console.error(error);
                    alert('Error updating project');
                }
            },

            async getUsersForProject() {
                this.accesses = (await fetchAccessesForProject(this.id)).result;
                for (let access of this.accesses) {
                    if (access.user === this.user._id) 
                        continue;

                    let userOfProject = (await fetchDevById(access.user)).result;
                    if (!userOfProject) {
                        userOfProject = (await fetchClientById(access.user)).result;
                        userOfProject.role = 'Client';
                    } else {
                        userOfProject.role = 'Developer';
                    }

                    if (access.super === true) {
                        userOfProject.super = 'Admin';
                        access.isSuper = true;
                    } else {
                        userOfProject.super = 'User';
                        access.isSuper = false;
                    }
                    this.users.push(userOfProject);
                }
            },
            async getTicketsForProject() {
                return (await fetchTicketsByProjectId(this.id)).result;
            },

            async getCommentsForTicket(ticketId) {
                return (await fetchCommentsByTicketId(ticketId)).result;
            },

            async toggleSuper(userId) {
                let accesses  = (await fetchAccessesForProject(this.id)).result;
                for (let access of accesses) {
                    if (access.user === userId && access.project === this.id) {
                        const updatedData = { ...access, isSuper: !access.super };
                        console.log("updatedData:", updatedData);
                        await updateAccess(access._id, updatedData);
                        this.users = [];
                        await this.getUsersForProject();
                    }
                }
            },
            async revokeAccess(userId){
                let accesses  = (await fetchAccessesForProject(this.id)).result;
                for (let access of accesses) {
                    if (access.user === userId && access.project === this.id) {
                        await deleteAccess(access._id);
                        this.users = [];
                        await this.getUsersForProject();
                    }
                }
            },
            async addUser() {
                let user = (await fetchDevByEmail(this.newUserMail)).result;
                if (!user) {
                    user = (await fetchClientByEmail(this.newUserMail)).result;
                    if (!user) {
                        alert('User not found');
                        return;
                    }
                }
                let access = {
                    user: user._id,
                    project: this.id,
                    isSuper: false
                };
                
                const result = await createAccess(access);
                if (result.error) {
                    alert('Error adding user');
                    this.newUserMail = '';
                    return;
                }
                this.newUserMail = '';
                this.users = [];
                await this.getUsersForProject();
            },
            async deleteProject() {
                if (confirm('Are you sure you want to delete this project?')) {
                    const tickets = await this.getTicketsForProject();
                    // Delete all tickets and comments for this project
                    if (tickets.length > 0) {
                        if (confirm('This project has tickets. Are you sure you want to delete this project and all its tickets?')) {
                            for (let ticket of tickets) {
                                const comments = await this.getCommentsForTicket(ticket._id);
                                console.log("Deleting comments for ticket:", ticket.title);
                                for (let comment of comments) {
                                    await deleteComment(comment._id);
                                }
                                console.log("Deleting ticket:", ticket.title);
                                await deleteTicket(ticket._id);
                            }
                        }
                        else{
                            return;
                        }  
                    }
                    // Delete the Accesses for this project
                    console.log("Deleting accesses for project:", this.project.name);
                    for (let user of this.users) {
                        await this.revokeAccess(user._id);
                    }
                    await this.revokeAccess(this.user._id);
                    // Delete the project
                    console.log("Deleting project:", this.project.name);
                    const response = await deleteProject(this.id);
                    if (response.error) {
                        alert('Error deleting project');
                        return;
                    }
                    alert('Project deleted successfully');
                    this.$router.push({ name: 'MyProjects' });
                }
            }
        },
        
        async created() {
            if (!this.user) {
                this.$router.push({ name: 'LoginAccount' });
                return;
            }
            this.project = (await fetchProjectById(this.id)).result;
            await this.getUsersForProject();
            this.loading = false;
        }
    }

</script>

<style scoped>
    .project-details {
        text-align: left;
        padding: 20px;
        position: relative;
    }

    .update-project, .delete-project {
        position: absolute;
        right: 20px;
        padding: 10px 20px;
        border-radius: 5px;
        border: none;
        cursor: pointer;
    }

    .update-project {
        background-color: #4fa3ff;
        color: #fff;
        top: 10px;
    }

    .update-project:hover {
        transform: scale(1.05);
        background-color: #007bff;
    }

    .delete-project {
        background-color: #ff4f4f;
        color: #fff;
        top: 60px; /* Adjust this value to position the button appropriately */
    }

    .delete-project:hover {
        transform: scale(1.05);
        background-color: #ff0000;
    }

    .form-container {
        justify-content: space-between;
        padding: 20px;
        background-color: #f9f9f9;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .form-group {
        margin-bottom: 20px;
        text-align: center;
    }

    label {
        display: block;
        margin-bottom: 5px;
    }

    input[type="text"],
    select,
    textarea {
        width: 100%;
        padding: 8px;
        border-radius: 5px;
        border: 1px solid #ccc;
        box-sizing: border-box;
    }

    .user-management {
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-top: 20px;
        background-color: #f9f9f9;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .user-add {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        width: 80%;
        margin: 20px auto;
        padding: 20px;
        background-color: #f9f9f9;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .user-add label {
        margin-bottom: 10px;
        font-weight: bold;
        text-align: center;
    }

    .user-add input[type="text"] {
        margin-bottom: 10px;
        padding: 10px;
        width: 100%;
        border-radius: 5px;
        border: 1px solid #ccc;
    }

    .user-add button {
        padding: 10px 20px;
        background-color: #4fa3ff;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .user-add button:hover {
        background-color: #007bff;
        transform: scale(1.05);
    }

    .user {
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;
        width: 80%;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        padding: 20px;
        background-color: #f9f9f9;
        border-radius: 5px;
    }

    .user-names {
        width: 20%;
        font-weight: bold;
    }

    .user-email {
        width: 20%;
    }

    .user-role {
        width: 20%;
    }

    .user-super {
        width: 20%;
    }

    .user-company {
        width: 20%;
    }

    .user-buttons {
        width: 20%;
    }

    .user-buttons button {
        margin: 0 10px;
        padding: 10px 20px;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .user-buttons button:hover {
        transform: scale(1.05);
    }

    .user-change-role {
        background-color: #4fa3ff;
    }

    .user-change-role:hover {
        background-color: #007bff;
    }

    .user-revoke {
        background-color: #ff4f4f;
    }

    .user-revoke:hover {
        background-color: #ff0000;
    }

</style>