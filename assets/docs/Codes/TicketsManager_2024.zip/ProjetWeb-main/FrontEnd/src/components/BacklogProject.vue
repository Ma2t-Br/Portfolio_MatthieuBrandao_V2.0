<template>
    <div class="project-backlog" v-if="loading">
        Loading...
    </div>
    <div class="project-backlog" v-else>
        <button @click="createTicket" class="create-ticket">Create Ticket</button>
        <div class="project-backlog-header">
            <h1>{{ project.name }}</h1>
            <p>{{ project.description }}</p>
        </div>
        <div class="project-backlog-tickets">
            <table class="tickets-Backlog" v-if="tickets.length > 0">
                <thead>
                    <tr>
                        <th>Ticket's Name</th>
                        <th>Status</th>
                        <th>End Date</th>
                        <th>Assignee</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="ticket in filteredTickets('BACKLOG')" :key="ticket._id" class="ticket">
                        <td>{{ ticket.title }}</td>
                        <td>{{ ticket.status }}</td>
                        <td>{{ ticket.displayedEndDate }}</td>
                        <td>{{ ticket.owner }}</td>
                        <td>
                            <button @click="viewTicket(ticket)">View Ticket</button>
                            <button @click="setToTodo(ticket)">Set to Todo</button>
                            <button @click="deleteTicket(ticket)" class="delete-ticket">Delete Ticket</button>
                        </td>
                    </tr>
                    <tr v-for="ticket in filteredTickets('TODO')" :key="ticket._id" class="ticket">
                        <td>{{ ticket.title }}</td>
                        <td>{{ ticket.status }}</td>
                        <td>{{ ticket.displayedEndDate }}</td>
                        <td>{{ ticket.owner }}</td>
                        <td>
                            <button @click="viewTicket(ticket)">View Ticket</button>
                            <button @click="setToInDev(ticket)">Set to In Development</button>
                            <button @click="sendToBacklog(ticket)">Send to the Backlog</button>
                        </td>
                    </tr>
                    <tr v-for="ticket in filteredTickets('IN DEVELOPMENT')" :key="ticket._id" class="ticket">
                        <td>{{ ticket.title }}</td>
                        <td>{{ ticket.status }}</td>
                        <td>{{ ticket.displayedEndDate }}</td>
                        <td>{{ ticket.owner }}</td>
                        <td>
                            <button @click="viewTicket(ticket)">View Ticket</button>
                            <button @click="setToInTests(ticket)">Set to In Tests</button>
                            <button @click="setToTodo(ticket)">Set to Todo</button>
                        </td>
                    </tr>
                    <tr v-for="ticket in filteredTickets('IN TESTS')" :key="ticket._id" class="ticket">
                        <td>{{ ticket.title }}</td>
                        <td>{{ ticket.status }}</td>
                        <td>{{ ticket.displayedEndDate }}</td>
                        <td>{{ ticket.owner }}</td>
                        <td>
                            <button @click="viewTicket(ticket)">View Ticket</button>
                            <button @click="setToDone(ticket)">Set to Done</button>
                            <button @click="setToInDev(ticket)">Set to In Development</button>
                        </td>
                    </tr>
                    <tr v-for="ticket in filteredTickets('DONE')" :key="ticket._id" class="ticket">
                        <td>{{ ticket.title }}</td>
                        <td>{{ ticket.status }}</td>
                        <td>{{ ticket.displayedEndDate }}</td>
                        <td>{{ ticket.owner }}</td>
                        <td>
                            <button @click="viewTicket(ticket)">View Ticket</button>
                            <button @click="setToInTests(ticket)">Set to In Tests</button>
                            <button @click="setToClosed(ticket)">Close Ticket</button>
                        </td>
                    </tr>
                    <tr v-for="ticket in filteredTickets('CLOSED')" :key="ticket._id" class="ticket">
                        <td>{{ ticket.title }}</td>
                        <td>{{ ticket.status }}</td>
                        <td>{{ ticket.displayedEndDate }}</td>
                        <td>{{ ticket.owner }}</td>
                        <td>
                            <button @click="viewTicket(ticket)">View Ticket</button>
                            <button @click="setToDone(ticket)">Set to Done</button>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div v-else>
                No tickets found
            </div>
        </div>
    </div>
</template>


<script>
    import { fetchProjectById } from '../APicalls/projectCalls.js';
    import { deleteTicket, fetchTicketsByProjectId, updateTicket} from '../APicalls/ticketCalls.js';
    import { fetchDevById } from '../APicalls/devCalls.js';
    import { fetchCommentsByTicketId, deleteComment } from '../APicalls/commentCalls.js';

    export default {
        name: 'BacklogProject',
        props: {
            id: {
                type: String,
                required: true
            }
        },
        data() {
            return {
                project: {
                    name: '',
                    description: ''
                },
                tickets: [],
                loading: true,
            };
        },
        computed: {
            user() {
                return this.$store.state.user;
            }
        },
        methods: {
            createTicket() {
                this.$router.push({ name: 'TicketCreation', params: { id: this.id } });
            },
            filteredTickets(status) {
                return this.tickets.filter(ticket => ticket.status === status).sort((a, b) => {
                    const aDate = new Date(a.endDate.split('/').reverse().join('-'));
                    const bDate = new Date(b.endDate.split('/').reverse().join('-'));
                    return aDate - bDate;
                });
            },
            async getProject() {
                this.project = (await fetchProjectById(this.id)).result;
            },
            async getTickets() {
                const ticketsResponse = await fetchTicketsByProjectId(this.id);
                if (ticketsResponse) {
                this.ticketsData = ticketsResponse.result;
                } else {
                    return;
                }

                for (let ticket of this.ticketsData) {
                    const devData = await fetchDevById(ticket.assignee);
                    if (devData && devData.result && devData.result.name && devData.result.surname) {
                        ticket.owner = devData.result.name + " " + devData.result.surname;
                    }
                    ticket.displayedEndDate = new Date(ticket.endDate).toLocaleDateString();
                }

                this.tickets = this.ticketsData;
            },
            viewTicket(ticket) {
                this.$router.push({ name: 'TicketDetails', params: { ticketId: ticket._id , projectId: this.id } });
            },
            async sendToBacklog(ticket) {
                const updatedData = { ...ticket, status: 'BACKLOG' };
                await this.updateTicket(ticket._id, updatedData);
            },
            async setToTodo(ticket) {
                const updatedData = { ...ticket, status: 'TODO' };
                await this.updateTicket(ticket._id, updatedData);
            },
            async setToInDev(ticket) {
                const updatedData = { ...ticket, status: 'IN DEVELOPMENT' };
                await this.updateTicket(ticket._id, updatedData);
            },
            async setToInTests(ticket) {
                const updatedData = { ...ticket, status: 'IN TESTS' };
                await this.updateTicket(ticket._id, updatedData);
            },
            async setToDone(ticket) {
                const updatedData = { ...ticket, status: 'DONE' };
                await this.updateTicket(ticket._id, updatedData);
            },
            async setToClosed(ticket) {
                const updatedData = { ...ticket, status: 'CLOSED' };
                await this.updateTicket(ticket._id, updatedData);
            },
            async updateTicket(ticketID, ticketData) {
                try {
                const response = await updateTicket(ticketID, ticketData);
                if (response.error) {
                    alert('Error updating ticket');
                } else {
                    this.tickets = this.tickets.map(ticket => 
                    ticket._id === ticketID 
                        ? { ...response.result, owner: ticket.owner, displayedEndDate: ticket.displayedEndDate} 
                        : ticket
                    );
                }
                } catch (error) {
                console.error(error);
                }
            },
            async getComments(ticketId) {
                return (await fetchCommentsByTicketId(ticketId)).result;
            },
            async deleteTicket(ticket){
                const comments = await this.getComments(ticket._id);
                console.log("Deleting comments for ticket ", ticket.title)
                for (let comment of comments) {
                    await deleteComment(comment._id);
                }
                console.log("Deleting ticket ", ticket.title)
                await deleteTicket(ticket._id);
                this.tickets = this.tickets.filter(t => t._id !== ticket._id);
            }
        },
        async created() {
            if (!this.user){
                this.$router.push({ name: 'LoginAccount' });
                return;
            }
            try{
                await this.getProject();
                await this.getTickets();
                this.loading = false;
            } catch (error) {
                console.error(error);
            }
        }
    }
</script>

<style scoped>
    .project-backlog {
        width: 100%;
        padding: 20px;
        box-sizing: border-box;
    }

    .project-backlog .delete-ticket {
        background-color: #ff4f4f;
    }

    .project-backlog .delete-ticket:hover {
        background-color: #ff0000;
    }

    .create-ticket {
        background-color: #4fa3ff;
        color: #fff;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        margin: 20px 0;
        float: right;
    }

    .create-ticket:hover {
        transform: scale(1.05);
        background-color: #007bff;
    }
    
    .project-backlog-header {
        margin-bottom: 20px;
    }

    .project-backlog-header h1 {
        margin: 0;
        padding: 0;
        font-size: 24px;
        color: #333;
    }

    .project-backlog-header p {
        margin: 0;
        padding: 0;
        font-size: 16px;
        color: #666;
    }

    .project-backlog-tickets {
        width: 100%;
    }

    .tickets-Backlog {
        width: 100%;
        border-collapse: collapse;
    }

    .tickets-Backlog th, .tickets-Backlog td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    .tickets-Backlog tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    .tickets-Backlog tr:hover {
        z-index: 1;
    }

    .tickets-Backlog td button {
        display: block;
        margin-bottom: 5px;
        padding: 10px 20px;
        background-color: #4fa3ff;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .tickets-Backlog td button:hover {
        transform: scale(1.05);
        background-color: #007bff;
    }
</style>