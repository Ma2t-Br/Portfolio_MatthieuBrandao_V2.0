<template>
  <div class="projects">
    <h1>My Projects</h1>
    <div v-if="!isLoaded">Loading...</div>
    <div v-else class="project-list">
      <div
        v-for="project in projects"
        :key="project._id"
        class="project-card"
        @click="showSubMenu(project._id)"
        @mouseleave="hideSubMenu"
      >
        <h2>{{ project.name }}</h2>
        <p>{{ project.description }}</p>
        <div v-if="project._id === activeSubMenu" class="submenu" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
          <button @click="viewProject(project)">View Project</button>
          <button @click="viewBacklog(project)" :disabled="!hasSuperAccess[project._id]">View Backlog</button>
          <button @click="editProject(project)" :disabled="!hasSuperAccess[project._id]">Edit Project</button>
        </div>
      </div>
      <div v-if="projects.length === 0">No projects found.</div>
    </div>
    <button @click="createProject">Create Project</button>
  </div>
</template>

<script>
  import { fetchAccessesForUser } from '../APicalls/accessCalls.js';
  import { fetchProjectById } from '../APicalls/projectCalls.js';

  export default {
    name: 'MyProjects',
    data() {
      return {
        projects: [],
        activeSubMenu: null,
        hasSuperAccess:{},
        isLoaded: false,
      }
    },
    computed: {
      user() {
        return this.$store.state.user;
      }
    },
    methods: {
      createProject() {
        this.$router.push({ name: 'CreateProject' });
      },
      showSubMenu(projectId) {
        this.activeSubMenu = projectId;
      },
      hideSubMenu() {
        this.activeSubMenu = null;
      },
      keepSubMenuOpen() {
        // Do nothing to keep the submenu open
      },
      viewProject(project) {
        this.$router.push({ name: 'OneProjectTickets', params: { id: project._id } });
      },
      viewBacklog(project) {
        this.$router.push({ name: 'BacklogProject', params: { id: project._id } });
      },
      editProject(project) {
        this.$router.push({ name: 'ProjectDetails', params: { id: project._id } });
      },
      async userHasSuperAccess(projectId) {
        let accesses = (await fetchAccessesForUser(this.user._id)).result;
        for (let access of accesses) {
          if (access.project === projectId && access.user === this.user._id) {
            console.log('User has super access to project', access.super);
            return access.super;
          }
        }
      },
      async checkSuperAccess(projectId) {
        let accesses = (await fetchAccessesForUser(this.user._id)).result;
        for (let access of accesses) {
          if (access.project === projectId && access.user === this.user._id) {
            this.hasSuperAccess[projectId] = access.super;
            break;
          }
        }
      },
    },
    async created() {
      if (!this.user) {
        this.$router.push({ name: 'LoginAccount' });
        return;
      }
      this.accesses = (await fetchAccessesForUser(this.user._id)).result;
      for (let access of this.accesses) {
        let project = (await fetchProjectById(access.project)).result;
        this.projects.push(project);
        this.checkSuperAccess(project._id);
      }
      this.isLoaded = true;
    }
  }
</script>

<style scoped>
  .projects {
    text-align: center;
  }
  .projects h1 {
    margin-bottom: 50px;
  }
  .project-list {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
  }
  .project-card {
    background-color: #b3e5fc;
    border-radius: 8px;
    padding: 20px;
    width: 250px;
    text-decoration: none;
    color: inherit;
    cursor: pointer;
    transition: transform 0.2s;
    position: relative;
    z-index: 1;
  }
  .project-card:hover {
    transform: scale(1.05);
    z-index: 2;
  }
  button {
    margin-top: 20px;
    padding: 10px 20px;
    background-color: #4fa3ff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }
  button:hover {
    transform: scale(1.05);
    background-color: #007bff;
  }
  .submenu {
    display: flex;
    flex-direction: column;
    margin-top: 10px;
    position: absolute;
    right: -100px;
    top: 0;
    width: 140px;
    background-color: #e7f1ff;
    border: 1px solid #ccc;
    border-radius: 5px;
    padding: 10px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    z-index: 1;
  }

  .submenu button {
    background-color: #d4e5ff;
    border: none;
    border-radius: 5px;
    color: #ffffff;
    font-size: 16px;
    margin-bottom: 10px;
    padding: 15px;
    text-align: center;
    cursor: pointer;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    transition: background-color 0.3s ease;
  }

  .submenu button:hover {
    transform: scale(1.05);
    background-color: #b0cfff;
  }
</style>