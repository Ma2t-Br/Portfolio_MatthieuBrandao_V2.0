<template>
  <div class="login-account">
    <h1>Login</h1>
    <form @submit.prevent="login" class="login-form">
      <div class="form-group">
        <label for="email">Email</label>
        <input type="text" id="email" v-model="authData.email" required>
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" id="password" v-model="authData.password" required>
      </div>
      <button type="submit">Login</button>
    </form>
    <br>
    <p>Don't have an account? <router-link to="/create-account">Create one here</router-link></p>
  </div>
</template>

<script>
  import { fetchDevByAuth } from '../APicalls/devCalls.js'
  import { fetchClientByAuth } from '../APicalls/clientCalls.js';

  export default {
    name: 'LoginAccount',
    data() {
      return {
        authData: {
          email: '',
          password: ''
        }
      };
    },
    methods: {
      async login() {
        let response = await fetchDevByAuth(this.authData.email, this.authData.password);
        this.user = response.result;
        if (this.user) {
          this.user.role = 'developer';
          this.$store.commit('setUser', this.user);
          this.$router.push({ name: 'HomePage' });
          return;
        }
        response = await fetchClientByAuth(this.authData.email, this.authData.password);
        this.user = response.result;
        if (this.user) {
          this.user.role = 'client';
          this.$store.commit('setUser', this.user);
          this.$router.push({ name: 'HomePage' });
          return;
        }
        alert('Invalid email or password');
        this.authData.email = '';
        this.authData.password = '';
        return;
      }
    }
  };
</script>

<style scoped>
  .login-account {
    text-align: center;
  }

  .login-form {
    max-width: 300px;
    margin: 0 auto;
  }

  .form-group {
    margin-bottom: 20px;
  }

  label {
    display: block;
    margin-bottom: 5px;
  }

  input[type="text"],
  input[type="password"] {
    width: 100%;
    padding: 8px;
    border-radius: 5px;
    border: 1px solid #ccc;
    box-sizing: border-box;
  }

  button {
    padding: 10px 20px;
    background-color: #42b983;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }

  button:hover {
    background-color: #3a9d72;
  }
</style>
