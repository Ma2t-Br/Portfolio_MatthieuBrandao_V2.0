<template>
    <div class="home">
        <h1 v-if="user">Welcome {{ user.name + ' ' + user.surname }}</h1>
        <div class="home-list">
            <router-link :to="{ name: 'MyProjects' }" class="home-card">
                <h2>My Projects</h2>
                <p>Access to your different projects and their tickets</p>
            </router-link>
            <router-link :to="{ name: 'AllProjectTickets' }" class="home-card">
                <h2>My Tickets</h2>
                <p>Access to all of your different tickets accross all projects</p>
            </router-link>
            <router-link :to="{ name: 'StatisticsUser' }" class="home-card">
                <h2>Statistics</h2>
                <p>Check your statistics on your projects and tickets</p>
            </router-link>
            <router-link :to="{ name: 'AccountUser' }" class="home-card">
                <h2>Account</h2>
                <p>Check your account and modify your informations</p>
            </router-link>
        </div>
        <div class="latestComments">
            <h2>Latest Comments</h2>
            <div v-if="isLoading">Loading...</div>
            <div v-else>
                <div v-if="comments.length === 0">
                    No comments yet
                </div>
                <div v-else v-for="comment in latestComments" :key="comment._id" class="comment">
                    <div class="comment-text">{{ comment.text }}</div>
                    <div class="comment-details">
                        <div class="comment-project">{{ comment.projectName }}</div>
                        <div class="comment-ticket">{{ comment.ticketName }}</div>
                        <div class="comment-author">{{ comment.authorName }}</div>
                        <div class="comment-date">{{ new Date(comment.date).toLocaleDateString() }}</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { fetchComments } from '../APicalls/commentCalls.js';
    import { fetchDevById } from '../APicalls/devCalls.js';
    import { fetchClientById } from '../APicalls/clientCalls.js';
    import { fetchProjectById } from '../APicalls/projectCalls.js';
    import { fetchTicketById } from '../APicalls/ticketCalls.js';
    import { fetchAccessesForUser } from '../APicalls/accessCalls.js';

    export default {
        name: 'HomePage',
        data() {
            return {
                comments: [],
                latestComments: [],
                isLoading: true
            }
        },
        computed: {
            user() {
                return this.$store.state.user;
            }
        },
        methods: {
            async hasAccess(projectId) {
                const accesses = (await fetchAccessesForUser(this.user._id)).result;
                for (let access of accesses) {
                    if (access.project === projectId) {
                        return true;
                    }
                }
                return false;
            },
            async getProjectId(ticketId) {
                const ticketData = await fetchTicketById(ticketId);
                if (ticketData.result) {
                    return ticketData.result.project;
                }
                return 'Unknown';
            },
            async getProjectName(projectId) {
                const projectData = await fetchProjectById(projectId);
                if (projectData.result) {
                    return projectData.result.name;
                }
                return 'Unknown';
            },
            async getTicketTitle(ticketId) {
                const ticketData = await fetchTicketById(ticketId);
                if (ticketData.result) {
                    return ticketData.result.title;
                }
                return 'Unknown';
            },
            async getUserName(userId){
                const devData = await fetchDevById(userId);
                if (devData.result) {
                    return `${devData.result.name} ${devData.result.surname}`;
                }

                const clientData = await fetchClientById(userId);
                if (clientData.result) {
                    return `${clientData.result.name} ${clientData.result.surname}`;
                }

                return 'Unknown';
            },
            async getComments() {
                let allComments = (await fetchComments()).result;
                for (let comment of allComments) {
                    const projectID = await this.getProjectId(comment.ticket);

                    if (!await this.hasAccess(projectID))
                        continue;

                    comment.projectName = await this.getProjectName(projectID);
                    comment.ticketName = await this.getTicketTitle(comment.ticket);
                    comment.authorName = await this.getUserName(comment.author);

                    const ticketData = (await fetchTicketById(comment.ticket)).result;
                    if (ticketData) {
                        if (ticketData.status === 'BACKLOG' || ticketData.status === 'CLOSED')
                            continue;
                        else
                            this.comments.push(comment);
                    }
                }
            },
            getLatestComments() {
                this.latestComments = this.comments.sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 10);
            },
        },
        async created() {
            if (!this.user) {
                this.$router.push({ name: 'LoginAccount' });
                return;
            }
            this.comments = [];
            await this.getComments();
            this.getLatestComments();
            this.isLoading = false;
        }
    }
</script>

<style>
    .home {
        text-align: center;
    }
    .home h1 {
        margin-bottom: 50px;
    }
    .home-list {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 20px;
        margin-bottom: 50px;
    }
    .home-card {
        background-color: #b3e5fc;
        border-radius: 8px;
        padding: 20px;
        width: 250px;
        text-decoration: none;
        color: inherit;
        cursor: pointer;
        transition: transform 0.2s;
        position: relative;
    }
    .home-card:hover {
        transform: scale(1.05);
        z-index: 1;
    }
    .latestComments {
        margin-top: 20px;
        background-color: #f9f9f9;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .comment {
        display: flex;
        justify-content: space-between;
        align-items: start;
        margin-top: 10px;
        margin-bottom: 10px;
        margin-left: auto;
        margin-right: auto;
        padding: 15px;
        border: 1px solid #ddd;
        border-radius: 5px;
        background-color: #fff;
        transition: background-color 0.3s;
        max-width: 50%;
    }
    .comment:hover {
        background-color: #f1f1f1;
    }
    .comment-text {
        font-size: 16px;
        flex-grow: 1;
        margin-right: 20px;
    }
    .comment-details {
        text-align: center;
    }
    .comment-project {
        font-size: 16px;
        font-weight: bold;
    }
    .comment-ticket {
        font-size: 14px;
        font-style: italic;
    }
    .comment-author {
        font-size: 14px;
    }
    .comment-date {
        font-size: 12px;
        color: #888;
        margin-top: 5px;
    }
</style>