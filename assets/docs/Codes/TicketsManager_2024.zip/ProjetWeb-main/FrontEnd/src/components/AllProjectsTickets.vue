<template>
  <div class="project-tickets" v-if="user">
    <div v-if="isLoading">Loading...</div>
    <div v-else>
      <h1>{{ user.role === 'client' ? 'All tickets by' : 'All Tickets for' }} {{ user.name + ' ' + user.surname }}</h1>
      <div class="columns">
        <div class="column todo">
          <h2>TODO</h2>
          <div v-for="ticket in filteredTickets('TODO')" :key="ticket._id" class="ticket" @click="toggleSubMenu(ticket._id)" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
            <div class="ticket-title">{{ ticket.title }}</div>
            <div class="ticket-project">{{ ticket.projectName }}</div>
            <div class="ticket-owner">{{ ticket.owner }}</div>
            <div v-if="ticket._id === activeSubMenu" class="submenu" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
              <button @click="viewTicket(ticket)">View Ticket</button>
              <button @click="setToInDev(ticket)">Set to In Development</button>
              <button @click="sendToBacklog(ticket)" :disabled="!hasSuperAccess[ticket.project]">Send to the Backlog</button>
            </div>
            <div class="ticket-prority">{{ ticket.priority }}</div>
            <div class="days-left" v-if="daysLeft(ticket) > 0">{{ daysLeft(ticket) }} days left</div>
            <div class="days-left overdue" v-else>Overdue</div>
          </div>
        </div>
        <div class="column in-development">
          <h2>IN DEVELOPMENT</h2>
          <div v-for="ticket in filteredTickets('IN DEVELOPMENT')" :key="ticket._id" class="ticket" @click="toggleSubMenu(ticket._id)" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
            <div class="ticket-title">{{ ticket.title }}</div>
            <div class="ticket-project">{{ ticket.projectName }}</div>
            <div class="ticket-owner">{{ ticket.owner }}</div>
            <div v-if="ticket._id === activeSubMenu" class="submenu" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
              <button @click="viewTicket(ticket)">View Ticket</button>
              <button @click="setToInTests(ticket)">Set to In Tests</button>
              <button @click="setToTodo(ticket)">Set to Todo</button>
            </div>
            <div class="ticket-prority">{{ ticket.priority }}</div>
            <div class="days-left" v-if="daysLeft(ticket) > 0">{{ daysLeft(ticket) }} days left</div>
            <div class="days-left overdue" v-else>Overdue</div>
          </div>
        </div>
        <div class="column in-tests">
          <h2>IN TESTS</h2>
          <div v-for="ticket in filteredTickets('IN TESTS')" :key="ticket._id" class="ticket" @click="toggleSubMenu(ticket._id)" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
            <div class="ticket-title">{{ ticket.title }}</div>
            <div class="ticket-project">{{ ticket.projectName }}</div>
            <div class="ticket-owner">{{ ticket.owner }}</div>
            <div v-if="ticket._id === activeSubMenu" class="submenu" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
              <button @click="viewTicket(ticket)">View Ticket</button>
              <button @click="setToDone(ticket)">Set to Done</button>
              <button @click="setToInDev(ticket)">Set to In Development</button>
            </div>
            <div class="ticket-prority">{{ ticket.priority }}</div>
            <div class="days-left" v-if="daysLeft(ticket) > 0">{{ daysLeft(ticket) }} days left</div>
            <div class="days-left overdue" v-else>Overdue</div>
          </div>
        </div>
        <div class="column done">
          <h2>DONE</h2>
          <div v-for="ticket in filteredTickets('DONE')" :key="ticket._id" class="ticket" @click="toggleSubMenu(ticket._id)" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
            <div class="ticket-title">{{ ticket.title }}</div>
            <div class="ticket-project">{{ ticket.projectName }}</div>
            <div class="ticket-owner">{{ ticket.owner }}</div>
            <div v-if="ticket._id === activeSubMenu" class="submenu" @mouseenter="keepSubMenuOpen" @mouseleave="hideSubMenu">
              <button @click="viewTicket(ticket)">View Ticket</button>
              <button @click="setToInTests(ticket)">Set to In Tests</button>
              <button @click="setToClosed(ticket)" :disabled="!hasSuperAccess[ticket.project]">Close the Ticket</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
  
<script>
  import { fetchAccessesForUser } from '../APicalls/accessCalls.js';
  import { fetchTicketsByProjectId } from '../APicalls/ticketCalls.js';
  import { fetchProjectById } from '../APicalls/projectCalls.js';
  import { fetchDevById } from '../APicalls/devCalls.js';
  import { updateTicket } from '../APicalls/ticketCalls.js';

  export default {
    name: 'AllProjectTickets',
    data() {
      return {
        tickets: [],
        isLoading: true,
        activeSubMenu: null,
        hasSuperAccess: {}
      };
    },
    computed: {
      user() {
        return this.$store.state.user;
      },
      daysLeft() {
        return function(ticket) {
          const now = new Date();
          const endDate = new Date(ticket.endDate);
          if (endDate < now) {
            return 0;
          }
          const diffTime = Math.abs(endDate - now);
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          return diffDays;
        }
      }
    },
    methods: {
      keepSubMenuOpen() {
        // Do nothing to keep the submenu open
      },
      hideSubMenu() {
        this.activeSubMenu = null;
      },
      filteredTickets(status) {
        if (status === 'DONE') {
          return this.tickets
            ? this.tickets
              .filter(ticket => ticket.status === status && (ticket.assignee === this.user._id || ticket.creator === this.user._id))
            : [];
        } else {
          return this.tickets 
            ? this.tickets
              .filter(ticket => ticket.status === status && (ticket.assignee === this.user._id || ticket.creator === this.user._id))
              .sort((a, b) => this.daysLeft(a) - this.daysLeft(b))
            : [];
        }
      },
      async processTicket(ticket, project) {
        ticket.projectName = project.name;
        if (ticket.assignee === this.user._id) {
          ticket.owner = this.user.name[0] + this.user.surname[0];
        } else {
          const dev = (await fetchDevById(ticket.assignee)).result;
          ticket.owner = dev.name[0] + dev.surname[0];
        }
        return ticket;
      },
      toggleSubMenu(ticketId) {
        this.activeSubMenu = this.activeSubMenu === ticketId ? null : ticketId;
      },
      viewTicket(ticket) {
        this.$router.push({ name: 'TicketDetails', params: { ticketId: ticket._id , projectId: ticket.project } });
      },
      async sendToBacklog(ticket) {
        const updatedData = { ...ticket, status: 'BACKLOG' };
        await this.updateTicket(ticket._id, updatedData);
      },
      async setToTodo(ticket) {
        const updatedData = { ...ticket, status: 'TODO' };
        await this.updateTicket(ticket._id, updatedData);
      },
      async setToInDev(ticket) {
        const updatedData = { ...ticket, status: 'IN DEVELOPMENT' };
        await this.updateTicket(ticket._id, updatedData);
      },
      async setToInTests(ticket) {
        const updatedData = { ...ticket, status: 'IN TESTS' };
        await this.updateTicket(ticket._id, updatedData);
      },
      async setToDone(ticket) {
        const updatedData = { ...ticket, status: 'DONE' };
        await this.updateTicket(ticket._id, updatedData);
      },
      async setToClosed(ticket) {
        const updatedData = { ...ticket, status: 'CLOSED' };
        await this.updateTicket(ticket._id, updatedData);
      },
      async updateTicket(ticketID, ticketData) {
        try {
          
          const updatedTicket = await updateTicket(ticketID, ticketData);
          const project = (await fetchProjectById(updatedTicket.result.project)).result;
          const processedTicket = await this.processTicket(updatedTicket.result, project);
          const index = this.tickets.findIndex(t => t._id === ticketID);
          this.tickets.splice(index, 1, processedTicket);
          this.activeSubMenu = null;
        } catch (error) {
          console.error(error);
        }
      },
      async checkSuperAccess(projectId) {
        let accesses = (await fetchAccessesForUser(this.user._id)).result;
        for (let access of accesses) {
          if (access.project === projectId && access.user === this.user._id) {
            this.hasSuperAccess[projectId] = access.super;
            break;
          }
        }
      },
    },
    async created() {
      if (!this.user) {
        this.$router.push({ name: 'LoginAccount' });
        return;
      }
      try {
        this.isLoading = true;

        // Fetch all projects the user has access to
        const accesses = (await fetchAccessesForUser(this.user._id)).result;

        // Fetch tickets for all projects in parallel
        const ticketsPromises = accesses.map(access => fetchTicketsByProjectId(access.project));
        const ticketsResults = await Promise.all(ticketsPromises);

        // Process tickets
        for (let i = 0; i < ticketsResults.length; i++) {
          const ticketsData = ticketsResults[i].result;
          const project = (await fetchProjectById(accesses[i].project)).result;

          for (let ticket of ticketsData) {
            if (this.user.role === 'client' && ticket.creator === this.user._id) {
              const processedTicket = await this.processTicket(ticket, project);
              this.tickets.push(processedTicket);
            }
            if (this.user.role === 'developer') {
              if (ticket.assignee === this.user._id) {
                const processedTicket = await this.processTicket(ticket, project);
                this.tickets.push(processedTicket);
              }
            }
          }

          // Check if user has super access to the projects
          this.checkSuperAccess(accesses[i].project);
        }
      } catch (error) {
        console.error(error);
      } finally {
        this.isLoading = false;
      }
    },
  }
</script>
  
<style scoped>
  .project-tickets {
    padding: 20px;
  }
  
  .project-tickets h1 {
    margin-bottom: 50px;
  }

  .columns {
    display: flex;
    justify-content: space-around;
    margin-top: 20px;
  }
  
  .column {
    width: 20%;
    padding: 10px;
    border-radius: 5px;
  }
  
  .column h2 {
    text-align: center;
    padding: 10px;
    border-radius: 5px 5px 0 0;
  }
  
  .todo {
    background-color: #f8d7da;
  }
  
  .in-development {
    background-color: #fff3cd;
  }
  
  .in-tests {
    background-color: #d1c4e9;
  }
  
  .done {
    background-color: #d4edda;
  }
  
  .ticket {
    background-color: #e7f1ff;
    padding: 10px;
    margin: 10px 0;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    position: relative;
    transition: background-color 0.3s ease;
  }

  .ticket:hover {
    background-color: #cde0ff;
    transform: scale(1.05);
    z-index: 2;
  }
  
  .ticket-title {
    font-weight: bold;
  }

  .ticket-project {
    font-style: italic;
  }
  
  .ticket-owner {
    background-color: #8c9eff;
    color: #fff;
    padding: 5px;
    border-radius: 50%;
    text-align: center;
    width: 30px;
    height: 30px;
    display: inline-block;
    line-height: 20px;
    margin-top: 10px;
  }

  .ticket-prority {
    color: #ff9c07;
    position: absolute;
    bottom: 10px;
    left: 10px;
  }

  .submenu {
    display: flex;
    flex-direction: column;
    margin-top: 10px;
    position: absolute;
    right: -100px;
    top: 0;
    width: 140px;
    background-color: #e7f1ff;
    border: 1px solid #ccc;
    border-radius: 5px;
    padding: 10px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    z-index: 1;
  }

  .submenu button {
    background-color: #d4e5ff;
    border: none;
    border-radius: 5px;
    color: #ffffff;
    font-size: 16px;
    margin-bottom: 10px;
    padding: 10px;
    text-align: center;
    cursor: pointer;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    transition: background-color 0.3s ease;
  }

  .submenu button:hover {
    transform: scale(1.05);
    background-color: #b0cfff;
  }

  .days-left {
    position: absolute;
    bottom: 10px;
    right: 10px;
    color: red;
  }

  .days-left.overdue {
    color: darkred;
    font-weight: bold;
  }
</style>