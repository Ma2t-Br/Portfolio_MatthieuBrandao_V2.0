<template>
    <div class="account" v-if="user">
        <h1>Account Information</h1>
        <div class="account-info">
            <div class="account-field">
                <label for="name">Name:</label>
                <input type="text" id="name" v-model="updatedName" />
            </div>
            <div class="account-field">
                <label for="surname">Surname:</label>
                <input type="text" id="surname" v-model="updatedSurname" />
            </div>
            <div class="account-field">
                <label for="email">Email:</label>
                <p>{{ user.email }}</p>
            </div>
            <div class="account-field">
                <label v-if="this.user.role === 'developer'" for="position">Position:</label>
                <input v-if="this.user.role === 'developer'" type="text" id="position" v-model="updatedPosition" />
                <label v-if="this.user.role === 'client'" for="company">Company:</label>
                <input v-if="this.user.role === 'client'" type="text" id="company" v-model="updatedCompanyName" />

            </div>
        </div>
        <button @click="updateUserDetails">Save Changes</button>
        <br>
        <div class="change-password">
            <h2>Change Password</h2>
            <form @submit.prevent="changePassword">
                <div class="form-field">
                    <label for="currentPassword">Current Password:</label>
                    <input type="password" id="currentPassword" v-model="currentPassword" required />
                </div>
                <div class="form-field">
                    <label for="newPassword">New Password:</label>
                    <input type="password" id="newPassword" v-model="newPassword" required />
                </div>
                <div class="form-field">
                    <label for="confirmPassword">Confirm New Password:</label>
                    <input type="password" id="confirmPassword" v-model="confirmPassword" required />
                </div>
                <br>
                <button type="submit">Change Password</button>
            </form>
        </div>
    </div>
</template>

<script>
import { updateClient } from '../APicalls/clientCalls.js';
import { updateDev } from '../APicalls/devCalls.js';

export default {
    name: 'AccountUser',
    data() {
        return {
            currentPassword: '',
            newPassword: '',
            confirmPassword: '',
            updatedName: this.$store.state.user.name,
            updatedSurname: this.$store.state.user.surname,
            updatedPosition: '',
            updatedCompanyName: '',
        };
    },
    computed: {
        user() {
            return this.$store.state.user;
        }
    },
    methods: {
        async changePassword() {
            if (this.newPassword !== this.confirmPassword) {
                alert("New passwords do not match.");
                return;
            }
            if (this.newPassword === this.user.password){
                alert("New password cannot be the same as the old password.");
                return;
            }
            if (this.currentPassword !== this.user.password){
                alert("Current password is incorrect.");
                return;
            }
            try {
                const updatedData = {
                    ...this.user,
                    password: this.newPassword
                };
                if (this.user.role === 'developer'){
                    await updateDev(this.user._id, updatedData);
                } else {
                    await updateClient(this.user._id, updatedData);
                }
                this.user.password = this.newPassword;
                this.$store.commit('setUser', this.user);
                alert("Password changed successfully.");
                this.currentPassword = '';
                this.newPassword = '';
                this.confirmPassword = '';
            } catch (error) {
                alert("Error changing password: " + error.message);
            }
        },
        async updateUserDetails() {
            try {
                if (this.user.role === 'developer'){
                    let updatedData = {
                        ...this.user,
                        name: this.updatedName,
                        surname: this.updatedSurname,
                        position: this.updatedPosition
                    };
                    await updateDev(this.user._id, updatedData);
                    this.user.position = this.updatedPosition;
                } else {
                    let updatedData = {
                        ...this.user,
                        name: this.updatedName,
                        surname: this.updatedSurname,
                        companyName: this.updatedCompanyName
                    };
                    await updateClient(this.user._id, updatedData);
                    this.user.companyName = this.updatedCompanyName;
                }
                this.user.name = this.updatedName;
                this.user.surname = this.updatedSurname;
                this.$store.commit('setUser', this.user);
                alert("User details updated successfully.");
            } catch (error) {
                alert("Error updating user details: " + error.message);
            }
        }
    },
    async created() {
        if (!this.user) {
            this.$router.push({ name: 'LoginAccount' });
            return;
        }
        if (this.user.role === 'developer'){
            this.updatedPosition = this.user.position;
        } else {
            this.updatedCompanyName = this.user.companyName;
        }
    }
}
</script>

<style scoped>
    .account {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        text-align: center;
        padding: 20px;
    }

    .account h1, .account h2 {
        margin-bottom: 20px;
    }

    .account-info {
        margin-bottom: 40px;
        width: 100%;
        max-width: 400px;
    }

    .account-field {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 10px 0;
    }

    .account-field label {
        min-width: 100px;
        text-align: left;
        margin-right: 10px;
    }

    .account-field input {
        width: 100%;
        padding: 8px;
        box-sizing: border-box;
    }

    .change-password form {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .change-password button {
        text-align: center;
    }

    .form-field {
        margin-bottom: 20px;
    }

    label {
        display: block;
        margin-bottom: 5px;
    }

    input {
        width: 100%;
        padding: 8px;
        box-sizing: border-box;
    }

    button {
        padding: 10px 20px;
        background-color: #4fa3ff;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    button:hover {
        transform: scale(1.05);
        background-color: #007bff;
    }
</style>
