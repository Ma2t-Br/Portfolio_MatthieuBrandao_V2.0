<template>
  <header>
    <div class="header-content">
      <img src="./RambHub.png" alt="RambHub" @click="goHome()">
      <nav>
        <ul v-if="user">
          <li><router-link to="/home">Home</router-link></li>
          <li><router-link to="/projects">Projects</router-link></li>
          <li><router-link to="/all-project-tickets">Tickets</router-link></li>
          <li><router-link to="/statistics">Statistics</router-link></li>
          <li><router-link to="/account">Account</router-link></li>
        </ul>
      </nav>
      <button v-if="user" class="logout-button" @click="logout">Log Out</button>
    </div>
  </header>
</template>

<script>

export default {
  name: 'AppHeader',
  computed: {
    user() {
      return this.$store.state.user;
    }
  },
  methods: {
    logout() {
      this.$router.push({name: 'LoginAccount'});
      console.log('Logging out user');
      this.$store.commit('resetUser');
    },
    goHome() {
      if (this.$store.state.user){
        this.$router.push({name: 'HomePage'});
        return;
      }
      this.$router.push({name: 'LoginAccount'});
    }
  }
}

</script>

<style scoped>
header {
  background-color: white;
  border-bottom: 1px solid #d3d3d3;
  padding: 10px 0;
}
.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;
}
.header-content img {
  width: 100px;
  height: 100px;
}
.site-name {
  font-size: 1.5em;
  color: #2c3e50;
}
nav ul {
  list-style: none;
  display: flex;
  gap: 20px;
}
nav a {
  color: #2c3e50;
  text-decoration: none;
}
.logout-button {
  background-color: #007bff;
  color: white;
  border: none;
  padding: 10px 20px;
  cursor: pointer;
  border-radius: 5px;
}
.logout-button:hover {
  background-color: #0056b3;
}
</style>
