<template>
    <div class="statistics" v-if="this.user">
        <h1>Statistics</h1>
        <div class="statistics-list">
            <div class="statistics-card">
                <h2>Projects</h2>
                <p>Number of project you have access to: {{ projects.length }}</p>
                <p>Number of project you have admin access to: {{ projectsAdminAccessCount }}</p>
                <p>Percentage of tickets closed by the teams</p>
                <div class="progress">
                    <div class="progress-bar" role="progressbar" :style="{ width: percentClosedTicketsAllProjects + '%' }" :aria-valuenow="percentClosedTicketsAllProjects" aria-valuemin="0" aria-valuemax="100">
                        <span>{{ percentClosedTicketsAllProjects }}%</span>
                    </div>
                </div>
            </div>
            <div class="statistics-card">
                <h2>Tickets</h2>
                <p>Number of tickets you have created: {{ createdTicketsCount }}</p>
                <p v-if="this.user.role === 'developer'">Number of tickets you are assigned to: {{ assignedTicketsCount }}</p>
                <p v-if="this.user.role === 'developer'">Number of opened tickets you are assigned to: {{ assignedTicketsOpenedCount }}</p>
                <p v-if="this.user.role === 'developer'">Number of assigned tickets closed: {{ assignedTicketsClosedCount }}</p>
                <p>Number of comments written: {{ commentsCount }}</p>
                <p v-if="this.user.role === 'developer'">Percentage of opened tickets with a 'High' priority:</p>
                <div class="progress" v-if="this.user.role === 'developer'">
                    <div class="progress-bar-error" role="progressbar" :style="{ width: percentHighPriority + '%' }" :aria-valuenow="percentHighPriority" aria-valuemin="0" aria-valuemax="100">
                        <span>{{ percentHighPriority }}%</span>
                    </div>
                </div>
                <br v-if="this.user.role === 'developer'">
                <p v-if="this.user.role === 'developer'">Percentage of opened tickets that are currently overdue</p>
                <div class="progress" v-if="this.user.role === 'developer'">
                    <div class="progress-bar-error" role="progressbar" :style="{ width: percentOverdueTickets + '%' }" :aria-valuenow="percentOverdueTickets" aria-valuemin="0" aria-valuemax="100">
                        <span>{{ percentOverdueTickets }}%</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { fetchAccessesForUser } from '../APicalls/accessCalls.js';
    import { fetchTickets } from '../APicalls/ticketCalls.js';
    import { fetchTicketsByProjectId } from '../APicalls/ticketCalls.js';
    import { fetchComments } from '../APicalls/commentCalls.js';

    export default{
        name: 'StatisticsUser',
        data(){
            return{
                projects: [],
                projectsAdminAccessCount: 0,
                createdTicketsCount: 0,
                assignedTicketsCount: 0,
                assignedTicketsOpenedCount: 0,
                assignedTicketsClosedCount: 0,
                commentsCount: 0,
                percentHighPriority: 0,
                percentClosedTicketsAllProjects: 0,
                percentOverdueTickets: 0,
            }
        },
        computed: {
            user(){
                return this.$store.state.user;
            }
        },
        methods: {
            async getProjets(){
                this.accesses = (await fetchAccessesForUser(this.user._id)).result;
                for (let access of this.accesses){
                    this.projects.push(access.project);
                }
            },
            async countProjectsAdminAccess(){
                let count = 0;
                this.accesses = (await fetchAccessesForUser(this.user._id)).result;
                for (let access of this.accesses){
                    if (access.super === true){
                        count++;
                    }
                }
                return count;
            },
            async countCreatedTickets(){
                let count = 0;
                let tickets = (await fetchTickets()).result;
                for (let ticket of tickets){
                    if (ticket.creator === this.user._id){
                        count++;
                    }
                }
                return count;
            },
            async countAssignedTickets(){
                let count = 0;
                let tickets = (await fetchTickets()).result;
                for (let ticket of tickets){
                    if (ticket.assignee === this.user._id){
                        count++;
                    }
                }
                return count;
            },
            async countTicketsClosed(){
                let count = 0;
                let tickets = (await fetchTickets()).result;
                for (let ticket of tickets){
                    if (ticket.assignee === this.user._id && ticket.status === 'CLOSED'){
                        count++;
                    }
                }
                return count;
            },
            async countTicketsNotDone(){
                let count = 0;
                let tickets = (await fetchTickets()).result;
                for (let ticket of tickets){
                    if (ticket.assignee === this.user._id && ticket.status !== 'DONE' && ticket.status !== 'BACKLOG' && ticket.status !== 'CLOSED'){
                        count++;
                    }
                }
                return count;
            },
            async countComments(){
                let count = 0;
                let comments = (await fetchComments()).result;
                for (let comment of comments){
                    if (comment.author === this.user._id){
                        count++;
                    }
                }
                return count;
            },
            async countPercentHighPriority(){
                let count = 0;
                let tickets = (await fetchTickets()).result;
                for (let ticket of tickets){
                    if (ticket.assignee === this.user._id && ticket.priority === 'High' && ticket.status !== 'DONE' && ticket.status !== 'BACKLOG' && ticket.status !== 'CLOSED'){
                        count++;
                    }
                }
                let percent = (count / await this.countTicketsNotDone()) * 100;
                if (isNaN(percent))
                    return 0;
                
                return percent.toFixed(2);
            },
            async countpercentClosedTicketsAllProjects(){
                let count = 0;
                let ticketCount = 0;
                let tickets = [];
                this.accesses = (await fetchAccessesForUser(this.user._id)).result;
                for (let access of this.accesses){
                    tickets = (await fetchTicketsByProjectId(access.project)).result;
                    for (let ticket of tickets){
                        if (ticket.status === 'CLOSED'){
                            count++;
                        }
                        ticketCount++;
                    }
                }
                let percent = (count / ticketCount) * 100;
                return percent.toFixed(2);
            },
            async countPercentOverdueTickets(){
                let count = 0;
                let tickets = (await fetchTickets()).result;
                for (let ticket of tickets){
                    if (ticket.assignee === this.user._id && ticket.status !== 'DONE' && ticket.status !== 'CLOSED'){
                        const now = new Date();
                        const endDate = new Date(ticket.endDate);
                        if (endDate < now){
                            count++;
                        }
                    }
                }
                let percent = (count / this.assignedTicketsOpenedCount) * 100;
                if (isNaN(percent))
                    return 0;
                return percent.toFixed(2);
            }

        },
        async created(){
            if (!this.user){
                this.$router.push({ name: 'LoginAccount' });
                return;
            }
            await this.getProjets();
            this.projectsAdminAccessCount = await this.countProjectsAdminAccess();
            this.createdTicketsCount = await this.countCreatedTickets();
            this.assignedTicketsCount = await this.countAssignedTickets();
            this.assignedTicketsOpenedCount = await this.countTicketsNotDone();
            this.assignedTicketsClosedCount = await this.countTicketsClosed();
            this.commentsCount = await this.countComments();
            this.percentHighPriority = await this.countPercentHighPriority();
            this.percentClosedTicketsAllProjects = await this.countpercentClosedTicketsAllProjects();
            this.percentOverdueTickets = await this.countPercentOverdueTickets();
        }
    }
</script>

<style scoped>
    .statistics{
        text-align: center;
    }
    .statistics h1{
        margin-bottom: 50px;
    }
    .statistics-list{
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 20px;
    }
    .statistics-card{
        background-color: #b3e5fc;
        border-radius: 8px;
        padding: 20px;
        width: 80%;
        max-width: 800px;
        text-decoration: none;
        color: inherit;
        cursor: pointer;
        transition: transform 0.2s;
    }
    .statistics-card h2{
        margin-bottom: 20px;
    }
    .statistics-card:hover{
        transform: scale(1.05);
    }
    .progress{
        margin-top: 10px;
        height: 20px;
        background-color: #f8f9fa;
        border-radius: 5px;
        overflow: hidden;
    }
    .progress-bar{
        height: 100%;
        background-color: #42b983;
    }
    .progress-bar-error{
        height: 100%;
        background-color: #b94242;
    }
</style>