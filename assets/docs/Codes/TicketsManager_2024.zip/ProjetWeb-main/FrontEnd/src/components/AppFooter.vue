<template>
  <footer>
    <div class="footer-content">
      <strong>RambHub</strong>
      <div class="social-icons">
        <a href="https://www.facebook.com">
          <img src="@/assets/facebook.png" alt="Facebook" />
        </a>
        <a href="#https://www.twitter.com">
          <img src="@/assets/x.png" alt="Twitter" />
        </a>
        <a href="https://www.youtube.com">
          <img src="@/assets/youtube.png" alt="YouTube" />
        </a>
        <a href="https://www.instagram.com">
          <img src="@/assets/instagram.png" alt="Instagram" />
        </a>
      </div>
    </div>
  </footer>
</template>

<script>
/* eslint-disable vue/multi-word-component-names */
export default {
  name: 'Footer'
}
/* eslint-enable vue/multi-word-component-names */
</script>

<style scoped>
footer {
  background-color: white;
  border-top: 1px solid #d3d3d3;
  color: #2c3e50;
  padding: 20px 0;
  position: fixed;
  width: 100%;
  bottom: 0;
}
.footer-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;
}
.social-icons a {
  margin: 0 10px;
}
.social-icons img {
  width: 24px; /* Adjust the size as needed */
  height: 24px; /* Adjust the size as needed */
}
</style>
