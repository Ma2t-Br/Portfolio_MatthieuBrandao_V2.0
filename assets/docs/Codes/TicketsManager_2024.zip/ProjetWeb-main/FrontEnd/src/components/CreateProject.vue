<template>
    <div class="create-project">
        <h1>Create a Project</h1>
        <br>
        <div class="form-container">
            <form @submit.prevent="createProject">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" v-model="project.name" required>
                    <label for="description">Description</label>
                    <textarea id="description" v-model="project.description" required></textarea>
                </div>
                <button type="submit">Create Project</button>
            </form>
        </div>
    </div>
</template>

<script>
    import { createProject } from '../APicalls/projectCalls.js';
    import { createAccess } from '../APicalls/accessCalls';

    export default {
        name: 'CreateProject',
        data() {
            return {
                project: {
                    name: '',
                    description: '',
                }
            }
        },
        methods: {
            async createProject() {
                try{
                    console.log('Creating project', this.project.name);
                    const response = await createProject(this.project);
                    if(response.error){
                        alert('Error creating project', response.error);
                    }
                    else{
                        const project = response.result;
                        let firstAccess = {
                            project: project._id,
                            user: this.$store.state.user._id,
                            isSuper: true
                        };
                        const responseAccess = await createAccess(firstAccess);
                        console.log('Creating access', responseAccess.result);
                        if(responseAccess.error){
                            alert('Error creating access to the project', responseAccess.error);
                            this.project = {
                                name: '',
                                description: '',
                            };
                        }
                        else{
                            this.$router.push({ name: 'MyProjects' });
                        }
                    }
                }
                catch(error){
                    alert('Error creating project', error);
                }
            }
        }
    }
</script>

<style scoped>
    .create-project {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .form-container {
        width: 50%;
    }

    form {
        display: flex;
        flex-direction: column;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        margin-bottom: 1rem;
    }

    label {
        font-weight: bold;
        margin-bottom: 0.5rem;
    }

    input, textarea {
        padding: 0.5rem;
        margin-top: 0.5rem;
        margin-bottom: 0.5rem;
        border: 1px solid #ccc;
        border-radius: 0.25rem;
    }

    button {
        padding: 0.5rem;
        margin-top: 1rem;
        border: none;
        border-radius: 0.25rem;
        background-color: #4fa3ff;
        color: white;
        cursor: pointer;
    }

    button:hover {
        background-color: #007bff;
    }
</style>