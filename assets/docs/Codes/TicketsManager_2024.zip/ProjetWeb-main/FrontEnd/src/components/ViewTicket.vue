<template>
    <div class="ticket-creation" v-if="loading">
        Loading...
    </div>
    <div class="ticket-creation" v-else>
        <h1 style="text-align: left; margin-bottom: 20px;">Ticket's Details</h1>
        <button @click="submitTicket" style="float: right; margin-top: -50px;">Update Ticket</button>
        <div class="form-container">
            <div class="form-section-left">
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" id="title" v-model="ticket.title" required>
                </div>
                <div class="form-group" style="flex-grow: 1;">
                    <label for="description">Description</label>
                    <textarea id="text" v-model="ticket.description" style="height: 185px;" required></textarea>
                </div>
            </div>
            <div class="form-section-right" style="margin-left: 20px;">
                <div class="form-group">
                    <label for="assignee">Assignee</label>
                    <select id="assignee" v-model="ticket.assignee">
                    <option v-for="dev in devs" :key="dev._id" :value="dev._id">{{ dev.name }} {{ dev.surname }}</option>
                    </select>
                </div>
                <!-- <div class="form-group">
                    <label for="ccs">CCs</label>
                    <input type="text" id="ccs" v-model="ticket.ccs">
                </div> -->
                <!-- <div class="form-group">
                    <label for="tags">Tags</label>
                    <input type="text" id="tags" v-model="ticket.tags">
                </div> -->
                <div class="form-group">
                    <label for="type">Type</label>
                    <select id="type" v-model="ticket.type">
                    <option value="Bug">Bug</option>
                    <option value="Feature">Feature</option>
                    <option value="Task">Task</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="priority">Priority</label>
                    <select id="priority" v-model="ticket.priority">
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="endDate">End Date</label>
                    <input type="date" id="endDate" v-model="ticket.endDate">
                </div>
            </div>
        </div>
        <div class="comments-section" v-if="!loading">
            <div class="form-group">
                <label for="text">Add a Comment:</label>
                <textarea id="commentText" v-model="newComment.text" style="height: 100px; margin-bottom: 10px;"></textarea>
            </div>
            <button @click="addComment" style="margin-bottom: 20px;">Submit Comment</button>
            <br>
            <h2>Comments section</h2>
            <div v-if="comments.length === 0">
                This is empty
            </div>
            <div v-else v-for="comment in comments" :key="comment._id" class="comment">
                <div class="comment-text">{{ comment.text }}</div>
                <div class="comment-details">
                    <div class="comment-author">{{ comment.authorName }}</div>
                    <div class="comment-date">{{ new Date(comment.date).toLocaleDateString() }}</div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { fetchAccessesForProject } from '../APicalls/accessCalls.js';
    import { fetchDevById } from '../APicalls/devCalls.js';
    import { fetchClientById } from '../APicalls/clientCalls.js';
    import { updateTicket } from '../APicalls/ticketCalls.js';
    import { fetchTicketById } from '../APicalls/ticketCalls.js';
    import { createComment } from '../APicalls/commentCalls.js';
    import { fetchCommentsByTicketId } from '../APicalls/commentCalls.js';

    export default {
        name: 'TicketDetails',
        props: {
            projectId: {
                type: String,
                required: true
            },
            ticketId: {
                type: String,
                required: true
            }
        },
        data() {
            return {
                ticket: null,
                devs: [],
                loading: true,
                comments: [],
                newComment: {}
            }
        },
        computed: {
            user() {
                return this.$store.state.user;
            }
        },
        methods: {
            async submitTicket() {
                // Check if all fields are filled
                if (!this.ticket.title || !this.ticket.description || !this.ticket.assignee || !this.ticket.type || !this.ticket.priority || !this.ticket.endDate) {
                    alert('Please fill all fields');
                    return;
                }
                await this.updateTicket(this.ticket._id, this.ticket);
                alert('Ticket updated successfully');
            },
            async updateTicket(ticketID, ticketData) {
                try {
                    const response = await updateTicket(ticketID, ticketData);
                    if (response.error) {
                        alert('Error updating ticket');
                    } else {
                        this.tickets = this.tickets.map(ticket => 
                        ticket._id === ticketID 
                            ? { ...response.result, owner: ticket.owner } 
                            : ticket
                        );
                    }
                } catch (error) {
                    console.error(error);
                }
            },
            async getDevs(){
                let accesses = (await fetchAccessesForProject(this.$route.params.projectId));
                this.accesses = accesses.result;
                for (let access of this.accesses) {
                    const devData = await fetchDevById(access.user);
                    if (devData.result) {
                    this.devs.push(devData.result);
                    }
                }
                this.devs.sort((a, b) => a.name.localeCompare(b.name));
            },
            async getUserName(userId){
                const devData = await fetchDevById(userId);
                if (devData.result) {
                    return `${devData.result.name} ${devData.result.surname}`;
                }

                const clientData = await fetchClientById(userId);
                if (clientData.result) {
                    return `${clientData.result.name} ${clientData.result.surname}`;
                }

                return 'Unknown';
            },
            async getTicket(){
                const ticketData = await fetchTicketById(this.$route.params.ticketId);
                if (ticketData.result) {
                    this.ticket = ticketData.result;
                    let endDate = new Date(this.ticket.endDate);
                    let year = endDate.getFullYear();
                    let month = ('0' + (endDate.getMonth() + 1)).slice(-2);
                    let day = ('0' + endDate.getDate()).slice(-2);
                    this.ticket.endDate = `${year}-${month}-${day}`;
                } else {
                    alert('Error fetching ticket');
                    this.$router.push({ name: 'MyProjects'});
                }
            },
            async getComments(){
                const commentsData = await fetchCommentsByTicketId(this.ticketId);
                if (commentsData.result) {
                    this.comments = commentsData.result;
                    for (let comment of this.comments) {
                        comment.authorName = await this.getUserName(comment.author);
                    }
                    this.comments.sort((a, b) => new Date(b.date) - new Date(a.date));
                } else {
                    alert('Error fetching comments');
                }
            },
            async addComment(){
                if (!this.newComment || this.newComment.text === '') {
                    alert('Please fill the comment field');
                    return;
                }
                this.newComment.date = new Date();
                this.newComment.author = this.user._id;
                this.newComment.ticket = this.ticketId;

                // Create the comment
                const result = await createComment(this.newComment);
                if (result.error) {
                    alert('Error creating comment');
                } else {
                    this.newComment = {};
                    await this.getComments();
                }
            }
        },
        async created() {
            if (!this.user) {
                this.$router.push({ name: 'LoginAccount' });
                return;
            }
            await this.getDevs();
            await this.getTicket();
            await this.getComments();
            this.loading = false;
        }
    }
</script>

<style scoped>
    .ticket-creation {
        text-align: center;
    }

    .form-container {
        display: flex;
        justify-content: space-between;
        padding: 20px;
        background-color: #f9f9f9;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .form-section-left {
        flex: 1;
    }

    .form-section-right {
        flex: 1;
    }

    .form-group {
        margin-bottom: 20px;
    }

    label {
        display: block;
        margin-bottom: 5px;
    }

    select#assignee option {
        font-size: 18px;
        padding: 20px 0;
    }

    input[type="text"],
    select,
    textarea {
        width: 100%;
        padding: 8px;
        border-radius: 5px;
        border: 1px solid #ccc;
        box-sizing: border-box;
    }

    textarea#text {
        resize: vertical;
    }

    button {
        padding: 10px 20px;
        background-color: #4fa3ff;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    button:hover {
        transform: scale(1.05);
        background-color: #007bff;
    }

    .comments-section {
        margin-top: 20px;
        background-color: #f9f9f9;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .comment {
        display: flex;
        justify-content: space-between;
        align-items: start;
        margin-top: 10px;
        margin-bottom: 10px;
        margin-left: auto;
        margin-right: auto;
        padding: 15px;
        border: 1px solid #ddd;
        border-radius: 5px;
        background-color: #fff;
        transition: background-color 0.3s;
        max-width: 50%;
    }

    .comment:hover {
        background-color: #f1f1f1;
    }

    .comment-text {
        font-size: 16px;
        flex-grow: 1;
        margin-right: 20px;
    }

    .comment-details {
        text-align: right;
    }

    .comment-author {
        font-size: 14px;
        font-style: italic;
        color: #555;
    }

    .comment-date {
        font-size: 12px;
        color: #888;
        margin-top: 5px;
    }

</style>