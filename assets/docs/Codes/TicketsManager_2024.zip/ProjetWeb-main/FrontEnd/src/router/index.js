import { createRouter, createWebHistory } from 'vue-router';
import CreateTicket from '../components/CreateTicket.vue';
import MyProjects from '../components/MyProjects.vue';
import OneProjectTickets from '../components/OneProjectTickets.vue';
import AllProjectTickets from '../components/AllProjectsTickets.vue';
import CreateAccount from '../components/CreateAccount.vue';
import LoginAccount from '../components/LoginAccount.vue';
import ViewTicket from '../components/ViewTicket.vue';
import Statistics from '../components/Statistics.vue';
import ProjectDetails from '../components/ProjectDetails.vue';
import HomePage from '../components/HomePage.vue';
import BacklogProject from '../components/BacklogProject.vue';
import CreateProject from '../components/CreateProject.vue';
import AccountUser from '../components/AccountUser.vue';

const routes = [
  { path: '/projects', name: 'MyProjects', component: MyProjects },
  { path: '/projects/:id', name: 'OneProjectTickets', component: OneProjectTickets, props: true},
  { path: '/projects/:id/backlog', name: 'BacklogProject', component: BacklogProject, props: true},
  { path: '/projects/:id/ticket-creation', name: 'TicketCreation', component: CreateTicket, props: true},
  { path: '/projects/:id/details', name: 'ProjectDetails', component: ProjectDetails, props: true},
  { path: '/create-project', name: 'CreateProject', component: CreateProject},
  { path: '/all-project-tickets', name: 'AllProjectTickets', component: AllProjectTickets },
  { path: '/projects/:projectId/tickets/:ticketId' , name: 'TicketDetails', component: ViewTicket, props: true},
  { path: '/create-account', name:'CreateAccount', component: CreateAccount },
  { path: '/statistics', name: 'StatisticsUser', component: Statistics },
  { path: '/', name: 'LoginAccount', component: LoginAccount },
  { path: '/home', name: 'HomePage', component: HomePage },
  {path: '/account',name: 'AccountUser', component: AccountUser}
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
