const API_BASE_URL = 'http://localhost:3000/api';

export const fetchClients = async () => {
    try {
        const response = await fetch(`${API_BASE_URL}/clients`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const fetchClientById = async (id) => {
    try {
        const response = await fetch(`${API_BASE_URL}/clients/${id}`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const fetchClientByAuth = async (email, password) => {
    try {
        const response = await fetch(`${API_BASE_URL}/clients/auth`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const fetchClientByEmail = async (email) => {
    try {
        const response = await fetch(`${API_BASE_URL}/clients/email/${email}`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const createClient = async (clientData) => {
    try {
        const response = await fetch(`${API_BASE_URL}/clients`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(clientData),
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const updateClient = async (id, updatedData) => {
    try {
        const response = await fetch(`${API_BASE_URL}/clients/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updatedData),
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const deleteClient = async (id) => {
    try {
        const response = await fetch(`${API_BASE_URL}/clients/${id}`, {
            method: 'DELETE',
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};