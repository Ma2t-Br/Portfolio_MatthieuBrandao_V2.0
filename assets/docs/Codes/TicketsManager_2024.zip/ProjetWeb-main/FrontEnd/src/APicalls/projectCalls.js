const API_BASE_URL = 'http://localhost:3000/api';

export const fetchProjects = async () => {
    try {
        const response = await fetch(`${API_BASE_URL}/projects`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const fetchProjectById = async (id) => {
    try {
        const response = await fetch(`${API_BASE_URL}/projects/${id}`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const createProject = async (projectData) => {
    try {
        const response = await fetch(`${API_BASE_URL}/projects`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(projectData),
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const updateProject = async (id, updatedData) => {
    try {
        const response = await fetch(`${API_BASE_URL}/projects/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updatedData),
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const deleteProject = async (id) => {
    try {
        const response = await fetch(`${API_BASE_URL}/projects/${id}`, {
            method: 'DELETE',
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};