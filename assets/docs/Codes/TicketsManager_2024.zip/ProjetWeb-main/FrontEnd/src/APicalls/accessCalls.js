const API_BASE_URL = 'http://localhost:3000/api';

export const fetchAccesses = async () => {
    try {
        const response = await fetch(`${API_BASE_URL}/accesses`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const fetchAccessById = async (id) => {
    try {
        const response = await fetch(`${API_BASE_URL}/accesses/${id}`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const fetchAccessesForUser = async (userId) => {
    try {
        const response = await fetch(`${API_BASE_URL}/accesses/user/${userId}`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const fetchAccessesForProject = async (projectId) => {
    try {
        const response = await fetch(`${API_BASE_URL}/accesses/project/${projectId}`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const createAccess = async (accessData) => {
    try {
        const response = await fetch(`${API_BASE_URL}/accesses`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(accessData),
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const updateAccess = async (id, updatedData) => {
    try {
        const response = await fetch(`${API_BASE_URL}/accesses/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updatedData),
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const deleteAccess = async (id) => {
    try {
        const response = await fetch(`${API_BASE_URL}/accesses/${id}`, {
            method: 'DELETE',
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};