const API_BASE_URL = 'http://localhost:3000/api';

export const fetchTickets = async () => {
    try {
        const response = await fetch(`${API_BASE_URL}/tickets`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const fetchTicketById = async (id) => {
    try {
        const response = await fetch(`${API_BASE_URL}/tickets/${id}`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const fetchTicketsByProjectId = async (projectId) => {
    try {
        const response = await fetch(`${API_BASE_URL}/tickets/project/${projectId}`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const createTicket = async (ticketData) => {
    try {
        const response = await fetch(`${API_BASE_URL}/tickets`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(ticketData),
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const updateTicket = async (id, updatedData) => {
    try {
        const response = await fetch(`${API_BASE_URL}/tickets/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updatedData),
        });
        const result = await response.json();
        return result;
    } catch (error) {
        console.error('Error:', error);
    }
};

export const deleteTicket = async (id) => {
    try {
        const response = await fetch(`${API_BASE_URL}/tickets/${id}`, {
            method: 'DELETE',
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};