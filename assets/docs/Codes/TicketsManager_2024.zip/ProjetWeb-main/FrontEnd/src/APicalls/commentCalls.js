const API_BASE_URL = 'http://localhost:3000/api';

export const fetchComments = async () => {
    try {
        const response = await fetch(`${API_BASE_URL}/comments`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const fetchCommentById = async (id) => {
    try {
        const response = await fetch(`${API_BASE_URL}/comments/${id}`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const fetchCommentsByTicketId = async (ticketId) => {
    try {
        const response = await fetch(`${API_BASE_URL}/comments/ticket/${ticketId}`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const createComment = async (commentData) => {
    try {
        const response = await fetch(`${API_BASE_URL}/comments`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(commentData),
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const updateComment = async (id, updatedData) => {
    try {
        const response = await fetch(`${API_BASE_URL}/comments/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updatedData),
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const deleteComment = async (id) => {
    try {
        const response = await fetch(`${API_BASE_URL}/comments/${id}`, {
            method: 'DELETE',
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};