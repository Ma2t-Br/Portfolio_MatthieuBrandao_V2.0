const API_BASE_URL = 'http://localhost:3000/api';

export const fetchDev = async () => {
    try {
        const response = await fetch(`${API_BASE_URL}/developers`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const fetchDevById = async (id) => {
    try {
        const response = await fetch(`${API_BASE_URL}/developers/${id}`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const fetchDevByAuth = async (email, password) => {
    try {
        const response = await fetch(`${API_BASE_URL}/developers/auth`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const fetchDevByEmail = async (email) => {
    try {
        const response = await fetch(`${API_BASE_URL}/developers/email/${email}`);
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const createDev = async (devData) => {
    try {
        const response = await fetch(`${API_BASE_URL}/developers`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(devData),
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const updateDev = async (id, updatedData) => {
    try {
        const response = await fetch(`${API_BASE_URL}/developers/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updatedData),
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};

export const deleteDev = async (id) => {
    try {
        const response = await fetch(`${API_BASE_URL}/developers/${id}`, {
            method: 'DELETE',
        });
        return await response.json();
    } catch (error) {
        return console.error('Error:', error);
    }
};