# Module SQL utilisé dans ce code : mysql connector (driver de mysql fait par Oracle pour python)
# installation : python -m pip install mysql-connector-python
# Module Discord utilisé dansce code : discord.py
# installation : python -m pip install discord.py

import mysql.connector
import discord
import time
import asyncio
from email.message import EmailMessage
import ssl
import smtplib

email_sender = "eyetask.dev.team@gmail.com"
email_password = "klsszxwlsixmnevy"

# Connexion à la BDD
BDD = mysql.connector.connect(host="localhost", user="root", password="root", database="projet_transverse_v2")

cursor = BDD.cursor()


def fetch_hour_reminders():
    # Récupération des rappels à faire dans l'heure
    cursor.execute("SELECT u.EMail_User, u.Surname_User, u.Discord_Tag, r.Date_Reminder, r.Hour_Reminder, "
                   "t.Task_name, t.Task_Description, t.Day_Deadline, t.Hour_Deadline FROM utilisateur AS u "
                   "JOIN envoyer AS e ON u.EMail_User=e.EMail_User "
                   "JOIN rappel AS r ON r.Id_Reminder=e.Id_Reminder "
                   "JOIN tâche AS t ON t.Id_Task=r.Id_Task "
                   "WHERE hour(Hour_Reminder) = hour(NOW()) AND Date_Reminder=CURRENT_DATE")

    handle_list = []

    # Création d'une liste de dictionnaires contenant les rappels à effectuer dans l'heure
    # nb : les objets en datetime.date sont des objets du module de base datetime
    for i in cursor:
        handle_list.append({"Mail": i[0], "Prénom": i[1], "Discord": i[2], "Date_Rappel": i[3],
                            "Heure_Rappel": str(i[4].seconds//3600) + "h" + str((i[4].seconds//60) % 60),
                            "Nom_Tâche": i[5], "Description_Tâche": i[6], "Jour_Deadline_Tâche": i[7],
                            "Heure_Deadline_Tâche": str(i[8].seconds//3600) + "h" + str((i[8].seconds//60) % 60)})

    return handle_list

# ###### LE BOT ENSUITE ###### #
# Penser à prendre en compte que l'utilisateur peut ne pas renseigner son discord (Discord=None dans handle list)


with open("token.txt", "r") as f:
    TOKEN = f.read()


intents = discord.Intents.default()
intents.members = True
client = discord.Client(intents=intents)


async def send_reminders(handle_list):
    for reminder in handle_list:
        hour, minute = map(int, reminder["Heure_Rappel"].split('h'))
        if int(time.strftime('%H')) == hour and int(time.strftime('%M')) == minute:
            email_receiver = reminder["Mail"]
            subject = "Rappel de tâche"
            body = f"Bonjour {reminder['Prénom']} 👋\nIl est temps de commencer à {reminder['Nom_Tâche']}, vous avez jusqu'au {reminder['Jour_Deadline_Tâche']} à {reminder['Heure_Deadline_Tâche']}\n\n {reminder['Description_Tâche']}"
            em = EmailMessage()
            em['From'] = email_sender
            em['To'] = email_receiver
            em['Subject'] = subject
            em.set_content(body)
            context = ssl.create_default_context()

            with smtplib.SMTP_SSL('smtp.gmail.com', 465, context=context) as smtp:
                smtp.login(email_sender, email_password)
                smtp.sendmail(email_sender, email_receiver, em.as_string())

            if reminder['Discord'] is not None:
                target = None
                try:
                    target = client.fetch_user(int(reminder["Discord"]))
                except:
                    pass
                if target is None:
                    print(f"{reminder['Discord']}, Verifie ton Discord et que tu sois sur le serveur https://discord.gg/AAYwgkBZ25")
                else:
                    await target.send(f"**Bonjour {reminder['Prénom']} 👋**\nIl est temps de commencer à `{reminder['Nom_Tâche']}`, vous avez jusqu'au *{reminder['Jour_Deadline_Tâche']}* à *{reminder['Heure_Deadline_Tâche']}*")
                    handle_list.pop(0)


async def bg_task():
    while 1:
        while int(time.strftime("%M")) != 0:
            print("\nattends")
            while int(time.strftime("%S")) != 0:
                await asyncio.sleep(0.5)
            print("requete des rappels")
            handle_list = fetch_hour_reminders()
            print("envoie les rappels")
            await send_reminders(handle_list)
            print("on re attend")
            while int(time.strftime("%S")) == 0:
                await asyncio.sleep(0.5)


@client.event
async def on_ready():
    print(f"Logged in as {client.user.name}")
    await client.change_presence(activity=discord.Activity(type=3, name="tes tâches"))
    await bg_task()


client.run(TOKEN)
