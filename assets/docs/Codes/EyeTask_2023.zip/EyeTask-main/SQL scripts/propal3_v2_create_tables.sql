CREATE TABLE Utilisateur(
   EMail_User VARCHAR(100),
   Surname_User VARCHAR(50) NOT NULL,
   Name_User VARCHAR(50) NOT NULL,
   Phone_Number_User VARCHAR(10) NOT NULL,
   Pwd_Hash VARCHAR(100) NOT NULL,
   Inscription_Date DATE,
   Discord_Tag VARCHAR(50),
   PRIMARY KEY(EMail_User)
);

CREATE TABLE Projet(
   Id_Project INT NOT NULL AUTO_INCREMENT,
   Creation_Date DATE,
   Project_Name VARCHAR(50) NOT NULL,
   Project_Description VARCHAR(500),
   PRIMARY KEY(Id_Project)
);

CREATE TABLE Tâche(
   Id_Task INT NOT NULL AUTO_INCREMENT,
   Task_name VARCHAR(50) NOT NULL,
   Task_Description VARCHAR(500),
   Day_Deadline DATE NOT NULL,
   Hour_Deadline TIME,
   PRIMARY KEY(Id_Task)
);

CREATE TABLE Rappel(
   Id_Reminder INT NOT NULL AUTO_INCREMENT,
   Date_Reminder DATE NOT NULL,
   Hour_Reminder TIME,
   Id_Task INT NOT NULL,
   PRIMARY KEY(Id_Reminder),
   FOREIGN KEY(Id_Task) REFERENCES Tâche(Id_Task)
);

CREATE TABLE Equipe(
   Id_Team INT NOT NULL AUTO_INCREMENT,
   Team_Name VARCHAR(50) NOT NULL,
   Team_Description VARCHAR(500),
   Id_Project INT NOT NULL,
   PRIMARY KEY(Id_Team),
   FOREIGN KEY(Id_Project) REFERENCES Projet(Id_Project)
);

CREATE TABLE REJOINDRE_P(
   EMail_User VARCHAR(100),
   Id_Project INT,
   Join_Date DATE,
   Is_Admin INT NOT NULL,
   Discord_Reminder INT,
   Mail_Reminder INT,
   PRIMARY KEY(EMail_User, Id_Project),
   FOREIGN KEY(EMail_User) REFERENCES Utilisateur(EMail_User),
   FOREIGN KEY(Id_Project) REFERENCES Projet(Id_Project)
);

CREATE TABLE ENVOYER(
   EMail_User VARCHAR(100),
   Id_Reminder INT,
   PRIMARY KEY(EMail_User, Id_Reminder),
   FOREIGN KEY(EMail_User) REFERENCES Utilisateur(EMail_User),
   FOREIGN KEY(Id_Reminder) REFERENCES Rappel(Id_Reminder)
);

CREATE TABLE REJOINDRE_G(
   EMail_User VARCHAR(100),
   Id_Team INT,
   PRIMARY KEY(EMail_User, Id_Team),
   FOREIGN KEY(EMail_User) REFERENCES Utilisateur(EMail_User),
   FOREIGN KEY(Id_Team) REFERENCES Equipe(Id_Team)
);

CREATE TABLE ASSOCIER_G(
   Id_Task INT,
   Id_Team INT,
   PRIMARY KEY(Id_Task, Id_Team),
   FOREIGN KEY(Id_Task) REFERENCES Tâche(Id_Task),
   FOREIGN KEY(Id_Team) REFERENCES Equipe(Id_Team)
);


















