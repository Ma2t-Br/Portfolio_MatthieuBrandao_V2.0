CREATE TABLE Utilisateur(
                            Email_User VARCHAR(100) NOT NULL,
                            Surname_User VARCHAR(50) NOT NULL,
                            Name_User VARCHAR(50) NOT NULL,
                            Phone_Number_User BIGINT NOT NULL,
                            Pwd_Hash VARCHAR(100) NOT NULL,
                            Inscription_Date DATE,
                            Discord_Tag VARCHAR(50),
                            PRIMARY KEY(Email_User)
);

CREATE TABLE Projet(
                       Id_Project INT,
                       Creation_Date VARCHAR(50),
                       Project_Name VARCHAR(50),
                       Project_Description VARCHAR(500),
                       PRIMARY KEY(Id_Project)
);

CREATE TABLE Tâche(
                      Id_Task INT,
                      Task_name VARCHAR(50),
                      Task_Description VARCHAR(500),
                      Day_Deadline DATE,
                      Hour_Deadline TIME,
                      PRIMARY KEY(Id_Task)
);

CREATE TABLE RAPPEL(
                       Id_Reminder INT,
                       Date_Reminder DATE,
                       Hour_Reminder TIME,
                       Id_Task INT NOT NULL,
                       PRIMARY KEY(Id_Reminder),
                       FOREIGN KEY(Id_Task) REFERENCES Tâche(Id_Task)
);

CREATE TABLE Equipe(
                       Id_Team INT,
                       Team_Name VARCHAR(50),
                       Team_Description VARCHAR(500),
                       Id_Project INT NOT NULL,
                       PRIMARY KEY(Id_Team),
                       FOREIGN KEY(Id_Project) REFERENCES Projet(Id_Project)
);

CREATE TABLE REJOINDRE_P(
                            Email_User VARCHAR(100) NOT NULL,
                            Id_Project INT,
                            Join_Date DATE,
                            Is_Admin INT,
                            Discord_Reminder INT,
                            Mail_Reminder INT,
                            PRIMARY KEY(Email_User, Id_Project),
                            FOREIGN KEY(Email_User) REFERENCES Utilisateur(Email_User),
                            FOREIGN KEY(Id_Project) REFERENCES Projet(Id_Project)
);

CREATE TABLE ENVOYER(
                        Email_User VARCHAR(100) NOT NULL,
                        Id_Reminder INT,
                        PRIMARY KEY(Email_User, Id_Reminder),
                        FOREIGN KEY(Email_User) REFERENCES Utilisateur(Email_User),
                        FOREIGN KEY(Id_Reminder) REFERENCES RAPPEL(Id_Reminder)
);

CREATE TABLE REJOINDRE_G(
                            Email_User VARCHAR(100) NOT NULL,
                            Id_Team INT,
                            PRIMARY KEY(Email_User, Id_Team),
                            FOREIGN KEY(Email_User) REFERENCES Utilisateur(Email_User),
                            FOREIGN KEY(Id_Team) REFERENCES Equipe(Id_Team)
);

CREATE TABLE ASSOCIER_G(
                           Id_Task INT,
                           Id_Team INT,
                           PRIMARY KEY(Id_Task, Id_Team),
                           FOREIGN KEY(Id_Task) REFERENCES Tâche(Id_Task),
                           FOREIGN KEY(Id_Team) REFERENCES Equipe(Id_Team)
);
