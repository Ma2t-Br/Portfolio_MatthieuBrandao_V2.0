<?php
include "request_functions.php";
session_start();

if(isset($_POST["task_name"]) and isset($_POST["project_ID"]) and isset($_POST["url"]) and isset($_POST["team_ID"])
    and isset($_POST["date"]) and isset($_POST["hour"]) and isset($_POST["task_description"]))
{
    $BDD = get_BDD();

    $task = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["task_name"]));
    $project = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["project_ID"]));
    $team = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["team_ID"]));
    $url = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["url"]));
    $date = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["date"]));
    $hour = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["hour"]));
    $task_desc = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["task_description"]));

    // echo $date, $hour, $task, $project, $url;
    // echo $team." ".$hour." ".$date." ".$project." ".$url;

    if($task != "")
    {
        if($task_desc!="") {
            $request = "INSERT INTO `tâche` (`Task_name`, `Task_Description`, `Day_Deadline`, `Hour_Deadline`) VALUES ('" . $task . "', '".$task_desc."', '" . $date . "', '" . $hour . "')";
        }
        else {
            $request = "INSERT INTO `tâche` (`Task_name`, `Task_Description`, `Day_Deadline`, `Hour_Deadline`) VALUES ('" . $task . "', 'Non renseignée', '" . $date . "', '" . $hour . "')";
        }
        // echo $request;

        $request_execution = mysqli_query($BDD, $request);

        $request = "INSERT INTO `associer_g` (`Id_Task`, `Id_Team`) VALUES (LAST_INSERT_ID(), '".$team."')";

        // echo $request;

        $request_execution = mysqli_query($BDD, $request);

        // On se déconnecte de la BDD
        mysqli_close($BDD);

        header("Location: ".$_POST["url"]);

    }
    else
    {
        // afficher l'erreur
        header("Location: ".$_POST["url"]);
    }

}
else
{
    echo "une erreur est survenue";
}