<?php
include "request_functions.php";
session_start();

if(isset($_POST["team_name"]) and isset($_POST["project"]) and isset($_POST["team_description"]))
{
    $BDD = get_BDD();

    $team = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["team_name"]));
    $project = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["project"]));
    $team_desc = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["team_description"]));

    if($team != "")
    {
        // on crée le groupe
        if($team_desc!="") {
            $request = "INSERT INTO `equipe` (`Team_Name`, `Team_Description`, `Id_Project`) VALUES ('" . $team . "', '" . $team_desc . "', '" . $project . "')";
        }
        else {
            $request = "INSERT INTO `equipe` (`Team_Name`, `Team_Description`, `Id_Project`) VALUES ('" . $team . "', 'Non renseignée', '" . $project . "')";
        }

        $request_execution = mysqli_query($BDD, $request);
        mysqli_close($BDD);

        header("Location: ".$_POST["url"]);
    }
    else
    {
        // afficher l'erreur
        header("Location: ".$_POST["url"]);
    }

}
else
{
    echo "une erreur est survenue";
}