<?php
include "request_functions.php";

session_start();

if(isset($_POST["task_ID"])) {
    // connexion à la BDD
    $BDD = get_BDD();

    // on supprime les liens utilisateur - groupe
    $request = "DELETE FROM associer_g WHERE Id_Task=" . $_POST["task_ID"];
    $request_execution = mysqli_query($BDD, $request);

    $request = "DELETE e FROM envoyer e JOIN rappel r on e.Id_Reminder = r.Id_Reminder WHERE Id_Task=" . $_POST["task_ID"];
    $request_execution = mysqli_query($BDD, $request);

    $request = "DELETE FROM rappel WHERE Id_Task=" . $_POST["task_ID"];
    $request_execution = mysqli_query($BDD, $request);

    $request = "DELETE FROM tâche WHERE Id_Task=" . $_POST["task_ID"];
    $request_execution = mysqli_query($BDD, $request);

    // On se déconnecte de la BDD
    mysqli_close($BDD);

    // on redirige l'utilisateur
    header("Location: ".$_POST["url"]);

}
else
{
    // ID_p n'est pas définie
    echo "Une erreur est survenue";
}