<?php
session_start();
include "request_functions.php";

if(isset($_POST["name"]) && isset($_POST["surname"]) && isset($_POST["phone"]) && isset($_POST["discord_tag"])) {

    $BDD = get_BDD();

    $mail = $_SESSION["email"];
    $name = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["name"]));
    $surname = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["surname"]));
    $phone = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["phone"]));
    $discord = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["discord_tag"]));

    $request = "UPDATE `utilisateur` SET `Surname_User` = '".$surname."', `Name_User` = '".$name."', 
                `Phone_Number_User` = '".$phone."', `Discord_Tag` = '".$discord."' 
                WHERE `utilisateur`.`EMail_User` = '".$mail."'";
    $request_execution = mysqli_query($BDD, $request);

    echo $request;

    if($request_execution)
    {
        // Le compte a été modifié, on redirige l'utilisateur
        header("Location: ../info_user.php");
        echo"$request_execution";
    }
    else
    {
        // Echec lors de la modification du compte
        echo "Erreur: " . $request . "<br>" . mysqli_error($BDD);
    }
}







// UPDATE `utilisateur` SET `Surname_User` = 'aa', `Name_User` = 'mm', `Phone_Number_User` = '2222222221', `Discord_Tag` = 'ma#6942' WHERE `utilisateur`.`EMail_User` = 'ma.ma@gmail.com'