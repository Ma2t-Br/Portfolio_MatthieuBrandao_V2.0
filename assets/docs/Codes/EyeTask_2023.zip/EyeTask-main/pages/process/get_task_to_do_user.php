<?php


// include "request_functions.php";

$BDD = get_BDD();

$request = "SELECT t.Task_name, t.Hour_Deadline, t.Day_Deadline, p.Project_Name, e.Team_Name, t.Id_Task FROM tâche AS t
                    JOIN associer_g AS ag ON t.Id_Task = ag.Id_Task
                    JOIN rejoindre_g AS rg ON ag.Id_Team = rg.Id_Team
                    JOIN equipe AS e ON ag.Id_Team = e.Id_Team
                    JOIN projet AS p ON e.Id_Project = p.Id_Project
                    WHERE EMail_User='".$_SESSION["email"]."' AND t.Day_Deadline >= CURRENT_DATE";

$request_execution = mysqli_query($BDD, $request);

while ($row = mysqli_fetch_array($request_execution, MYSQLI_ASSOC)) {
    echo "
    <div class='task'>".
        $row["Day_Deadline"]."-".$row["Hour_Deadline"].
        "<br>Projet ".$row["Project_Name"]. " Equipe ".$row["Team_Name"]."<br>".
        $row["Task_name"].
        "<form action='view_task.php' method='post'>
            <input type='hidden' name='id_task' value='".$row["Id_Task"]."'>
            <input type='submit' value='Détails' class='button_details'>
        </form>"
    ."</div>
    ";
}

session_abort();