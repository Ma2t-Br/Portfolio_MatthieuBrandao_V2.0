<?php
include "request_functions.php";
session_start();


if(isset($_GET["ID_p"]) and isset($_GET["email"]))
{
    // connexion à la BDD
    $BDD = get_BDD();

    // on supprime le lien utilisateur - groupe
    $request = "DELETE FROM rejoindre_p WHERE Id_Project=" . $_GET["ID_p"] . " AND EMail_User='" . $_GET["email"] . "'";
    $request_execution = mysqli_query($BDD, $request);

    // On se déconnecte de la BDD
    mysqli_close($BDD);

    header("Location: ".$_POST["url"]);
}
else
{
    // ID_p n'est pas définie
    echo $_GET["ID_p"];
    echo $_GET["email"];
    echo "Une erreur est survenue";
}

// il faudra ajouter la suppression de l'utilisateur dans les groupes qu'il a rejoints quand ils seront codés

// il faudra aussi s'assurer qu'il reste un admin dans le projet si l'utilisateur quittant le projet est admin