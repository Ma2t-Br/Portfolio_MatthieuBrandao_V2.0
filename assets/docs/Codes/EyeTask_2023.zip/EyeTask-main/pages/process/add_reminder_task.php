<?php
include "request_functions.php";
session_start();

if(isset($_POST["task"]) and isset($_POST["date"]) and isset($_POST["hour"]))
{
    $BDD = get_BDD();

    $task = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["task"]));
    $date = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["date"]));
    $hour = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["hour"]));
    $mail = $_SESSION["email"];

    if (isset($_POST["bool_discord"])) $bool_discord = 1;
    else $bool_discord = 0;

    if (isset($_POST["bool_mail"])) $bool_mail = 1;
    else $bool_mail = 0;


    if($task != "" and $date != "" and $hour != "")
    {
        $request = "INSERT INTO `rappel` (`Date_Reminder`, `Hour_Reminder`, `Id_Task`, `Mail_bool`, `Discord_bool`) 
                    VALUES ('".$date."', '".$hour."', '".$task."', '".$bool_mail."', '".$bool_discord."')";

        $request_execution = mysqli_query($BDD, $request);

        $request = "INSERT INTO `envoyer` (`EMail_User`, `Id_Reminder`) VALUES ('".$mail."', LAST_INSERT_ID())";

        $request_execution = mysqli_query($BDD, $request);

        // On se déconnecte de la BDD
        mysqli_close($BDD);

        header("Location: ../planify_reminder.php");

    }
    else
    {
        // afficher l'erreur
        header("Location: ../planify_reminder.php");
    }

}
else
{
    echo "une erreur est survenue";
}
