<?php
include "request_functions.php";

session_start();

if(isset($_GET["ID_p"]))
{
    // connexion à la BDD
    $BDD = get_BDD();

    // on supprime les liens utilisateur - groupe
    $request = "DELETE FROM rejoindre_p WHERE Id_Project=" . $_GET["ID_p"];
    $request_execution = mysqli_query($BDD, $request);

    // on supprime le projet
    $request = "DELETE FROM projet WHERE Id_Project=" . $_GET["ID_p"];
    $request_execution = mysqli_query($BDD, $request);

    // On se déconnecte de la BDD
    mysqli_close($BDD);

    // on redirige l'utilisateur
    header("Location: ../projects.php");

}
else
{
    // ID_p n'est pas définie
    echo "Une erreur est survenue";
}