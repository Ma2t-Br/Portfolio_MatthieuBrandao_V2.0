<?php

function get_project_members($project)
{
    if(isset($project) and $project != "")
    {
        // connexion à la BDD
        $BDD = get_BDD();

        // on récupère tous les utilisateurs du projet
        $request = "SELECT u.EMail_User, u.Name_User, u.Surname_User FROM utilisateur as u
                    JOIN rejoindre_p AS r ON u.EMail_User = r.EMail_User
                    WHERE r.Id_Project=" . $project;

        $request_execution = mysqli_query($BDD, $request);

        echo "<div class='box' id='personne'>";
        while ($row = mysqli_fetch_array($request_execution, MYSQLI_ASSOC))
        {
            echo "<strong>Mail :</strong> ".$row["EMail_User"]." <strong>Nom :</strong> ".$row["Name_User"]." <strong>Prénom :</strong> ".$row["Surname_User"]."
            <form method='post' style='display: inline' action='process/leave_project.php?ID_p=".$project."&email=".$row["EMail_User"]."'>
                <input type='hidden' name=url value='".$_SERVER["REQUEST_URI"]."'>
                <input type='submit' class='button' value='exclure'>
            </form><br>";
        }
        echo "</div>";
    }
    else
    {
        echo "<div class='box' id='personne'>erreur lors de la récupération des membres du projet</div>";
    }
}