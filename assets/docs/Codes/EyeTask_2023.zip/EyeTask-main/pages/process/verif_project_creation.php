<?php
include "request_functions.php";
session_start();

if(isset($_POST["project_name"]) and isset($_POST["project_description"]))
{
    // connexion à la BDD
    $BDD = get_BDD();

    // sécurité pour éviter les injections SQL et la faille XSS
    $p_name = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["project_name"]));
    $p_desc = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["project_description"]));

    if($p_name != "")
    {
        // on crée le projet et on complète la table rejoindre_p

        if($p_desc!="") {
            $request = "INSERT INTO `projet` (`Creation_Date`, `Project_Name`, `Project_Description`) VALUES ('" . date("Y/m/d") . "', '" . $p_name . "', '" . $p_desc . "')";
        }
        else {
            $request = "INSERT INTO `projet` (`Creation_Date`, `Project_Name`, `Project_Description`) VALUES ('" . date("Y/m/d") . "', '".$p_name."', 'Non renseignée')";
        }

        $request_execution = mysqli_query($BDD, $request);
        $request = "INSERT INTO `rejoindre_p` (`EMail_User`, `Id_Project`, `Join_Date`, `Is_Admin`) 
                    VALUES ('".$_SESSION["email"]."', LAST_INSERT_ID(), '".date("Y/m/d")."', '1')";
        $request_execution = mysqli_query($BDD, $request);

        // On se déconnecte de la BDD
        mysqli_close($BDD);

        if($request_execution) {
            // Réussite, tout a bien été créé
            header("Location: ../projects.php?created=1");
        }
        else
        {
            // Echec lors de la création du projet
            echo "Erreur: " . $request . "<br>" . mysqli_error($BDD);
        }
    }
    else
    {
        // Le nom du projet n'a pas été renseigné
        header("Location: ../projects.php?error=1");
    }
}
else
{
    // Erreur, le nom du projet vaut NULL
    header("Location: ../projects.php");
}
