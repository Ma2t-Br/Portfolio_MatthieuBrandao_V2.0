<?php
include "request_functions.php";
session_start();

if(isset($_POST["email_to_add"]) and isset($_POST["project"]))
{
    $BDD = get_BDD();

    $email = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["email_to_add"]));
    $project = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["project"]));


    if(filter_var($email, FILTER_VALIDATE_EMAIL) && $email != "")
    {
        // on vérifie que l'utilisateur à ajouter existe
        $request = "SELECT count(*) FROM utilisateur WHERE EMail_User='".$email."'";
        $request_execution = mysqli_query($BDD, $request);
        $answer = mysqli_fetch_array($request_execution);
        mysqli_free_result($request_execution);

        if($answer["count(*)"] == 1)
        {
            // l'utilisateur existe bien
            $request = "INSERT INTO `rejoindre_p` (`EMail_User`, `Id_Project`, `Join_Date`, `Is_Admin`, `Discord_Reminder`, `Mail_Reminder`) 
                        VALUES ('".$email."',".$project.", '".date("Y/m/d")."', '0', '0', '0')";
            $request_execution = mysqli_query($BDD, $request);

            // On se déconnecte de la BDD
            mysqli_close($BDD);

            header("Location: ".$_POST["url"]);
        }
        else
        {
            // l'utilisateur n'existe pas
            header("Location: ".$_POST["url"]);
        }
    }
    else
    {
        // afficher l'erreur
        header("Location: ".$_POST["url"]);
    }

}
else
{
    echo "une erreur est survenue";
}