<?php
include "request_functions.php";
session_start();


if(isset($_GET["ID_t"]) and isset($_GET["email"]))
{
    // connexion à la BDD
    $BDD = get_BDD();

    // on supprime le lien utilisateur - groupe
    $request = "DELETE FROM rejoindre_g WHERE Id_Team=" . $_GET["ID_t"] . " AND EMail_User='" . $_GET["email"] . "'";
    $request_execution = mysqli_query($BDD, $request);

    // On se déconnecte de la BDD
    mysqli_close($BDD);

    header("Location: ".$_SERVER['HTTP_REFERER']);
}
else
{
    // ID_p n'est pas définie
    echo $_GET["ID_p"];
    echo $_GET["email"];
    echo "Une erreur est survenue";
}

// il faudra ajouter la suppression des rappels liés à l'équipe pour l'utilisateur quand ça sera codé