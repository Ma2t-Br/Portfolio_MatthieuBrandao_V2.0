<?php
include "request_functions.php";
session_start();

if(isset($_POST["name"]) && isset($_POST["surname"]) && isset($_POST["email"])
    && isset($_POST["phone"]) && isset($_POST["password"]) && isset($_POST["password_confirm"])) {

    // connexion à la BDD
    $BDD = get_BDD();

    // sécurité pour éviter les injections SQL et la faille XSS
    $name = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["name"]));
    $surname = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["surname"]));
    $email = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["email"]));
    $phone = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["phone"]));
    $password = crypt(mysqli_real_escape_string($BDD, htmlspecialchars($_POST["password"])), '$2a$07$usesomesillystringforsalt$');
    $password_confirm = crypt(mysqli_real_escape_string($BDD, htmlspecialchars($_POST["password_confirm"])), '$2a$07$usesomesillystringforsalt$');
    $discord = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["tag_discord"]));


    if($password == $password_confirm)
    {
        if(filter_var($email, FILTER_VALIDATE_EMAIL) && $email != "")
        {
            if($name != "" && $surname != "")
            {
                if($phone != "")
                {
                    // Tout est valide, on peut créer le compte
                    if($discord=="") {
                        $request = "INSERT INTO utilisateur values('%s', '%s', '%s', '%s','%s', '%s', %s)";
                        $request = sprintf($request, $email, $surname, $name, $phone, $password, date("Y/m/d"), "NULL");
                    }
                    else {
                        $request = "INSERT INTO utilisateur values('%s', '%s', '%s', '%s','%s', '%s', '%s')";
                        $request = sprintf($request, $email, $surname, $name, $phone, $password, date("Y/m/d"), $discord);
                    }

                    $request_execution = mysqli_query($BDD, $request);

                    if($request_execution)
                    {
                        // Le compte a été créé, on redirige l'utilisateur
                        header("Location: ../create_account.php?created=1");
                        echo"$request_execution";
                    }
                    else
                    {
                        // Echec lors de la création du compte
                        echo "Erreur: " . $request . "<br>" . mysqli_error($BDD);
                    }
                }
                else
                {
                    // Le numéro de téléphone n'a pas été saisi
                    header("Location: ../create_account.php?error=6");
                }
            }
            else
            {
                // Le nom ou le prénom ou les 2 n'ont pas été saisis
                header("Location: ../create_account.php?error=5");
            }
        }
        elseif($email != "")
        {
            // L'email saisi n'est pas un mail
            header("Location: ../create_account.php?error=3");
        }
        else
        {
            // Aucun mail n'a été saisi
            header("Location: ../create_account.php?error=4");
        }
    }
    elseif($password != "")
    {
        // Mauvais MDP de confirmation
        header("Location: ../create_account.php?error=1");
    }
    else
    {
        // Aucun MDP n'a été saisi
        header("Location: ../create_account.php?error=2");
    }

    // On se déconnecte de la BDD
    mysqli_close($BDD);
}
else
{
    // Un des attributs est NULL
    header("Location: ../create_account.php");
}