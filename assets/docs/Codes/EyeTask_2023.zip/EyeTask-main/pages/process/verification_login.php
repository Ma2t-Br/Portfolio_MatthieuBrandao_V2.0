
<?php
include "request_functions.php";
session_start();

if(isset($_POST["email"]) && isset($_POST["password"]))
{
    // connexion à la BDD
    $BDD = get_BDD();

    // sécurité pour éviter les injections SQL et la faille XSS
    $email = mysqli_real_escape_string($BDD, htmlspecialchars($_POST["email"]));
    $password = crypt(mysqli_real_escape_string($BDD, htmlspecialchars($_POST["password"])), '$2a$07$usesomesillystringforsalt$');

    if(filter_var($email, FILTER_VALIDATE_EMAIL) && $email != "" && $password != "")
    {
        $request = "SELECT count(*) FROM utilisateur where EMail_User = '" .$email. "' and Pwd_Hash = '" .$password. "' " ;
        $request_execution = mysqli_query($BDD, $request);
        $answer = mysqli_fetch_array($request_execution);
        mysqli_free_result($request_execution);

        if($answer["count(*)"] == 1)
        {
            // Connexion réussie → email et password corrects
            // On va donc ouvrir une session et rediriger l'utilisateur sur sa page
            $_SESSION["email"] = $email;

            $request = "SELECT Surname_User, Name_User FROM utilisateur where EMail_User = '" .$email. "'" ;
            $request_execution = mysqli_query($BDD, $request);
            $answer = mysqli_fetch_array($request_execution);

            $_SESSION["name_user"] = $answer["Surname_User"] . " " . $answer["Name_User"];

            echo $_SESSION["name_user"];

            header("Location: ../main_page.php");
        }
        else
        {
            // email incorrect ou password incorrect
            header("Location: ../login.php?error=2");
        }

    }
    else
    {
        // email non valide ou password vide ou email vide
        header("Location: ../login.php?error=1");
    }

    // On se déconnecte de la BDD
    mysqli_close($BDD);
}
else
{
    // email NULL ou password NULL
    header("Location: ../login.php");
}
