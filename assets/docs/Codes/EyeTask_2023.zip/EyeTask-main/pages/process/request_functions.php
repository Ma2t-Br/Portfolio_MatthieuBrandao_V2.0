<?php

function get_BDD() {
    // connexion à la BDD
    $BDD_host = "localhost";
    $BDD_username = "root";
    $BDD_password = "root";
    $BDD_name = "projet_transverse_v3";

    $BDD = mysqli_connect($BDD_host, $BDD_username, $BDD_password, $BDD_name)
    or die("Connexion à la base de données impossible.");

    return $BDD;
}

function request($BDD, $request) {
    return mysqli_query($BDD, $request);
}