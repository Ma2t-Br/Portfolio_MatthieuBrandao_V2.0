<?php

function list_teams($ID_p)
{
    // connexion à la BDD
    $BDD = get_BDD();

    // On récupère toutes les équipes du projet
    $request = "SELECT Id_Team, Team_Name, e.Id_Project FROM equipe as e
                JOIN projet as p ON e.Id_Project = p.Id_Project
                WHERE p.Id_Project=" . $ID_p;

    $request_execution = mysqli_query($BDD, $request);

    $cpt = 0;
    while ($row = mysqli_fetch_array($request_execution, MYSQLI_ASSOC)) {
        $cpt++;
        echo $row["Team_Name"] . "<form action='view_team.php?project=" . $row["Id_Project"] . "&team_id=" . $row["Id_Team"] . "' method='post' style='display: inline'>
                                        <input type='hidden' name=url value='".$_SERVER["REQUEST_URI"]."'>
                                        <input type='submit' value='voir' class='button'>
                                   </form><br>";
    }

    if ($cpt == 0) {
        echo "Vous n'avez rejoint aucune équipe dans ce projet";
    }
}