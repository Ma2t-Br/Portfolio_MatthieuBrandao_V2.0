<?php
include "request_functions.php";
session_start();

// connexion à la BDD
$BDD = get_BDD();

// On récupère tous les projets de l'utilisateur
$request = "SELECT p.Project_Name, p.Id_Project FROM projet AS p 
            JOIN rejoindre_p AS r ON r.Id_Project = p.Id_Project 
            JOIN utilisateur AS u ON r.EMail_User = u.EMail_User
            WHERE r.EMail_User='" . $_SESSION["email"] . "' ";

$request_execution = mysqli_query($BDD, $request);

$cpt=0;

echo "<div class='box' id='personne'>";

while ($row = mysqli_fetch_array($request_execution, MYSQLI_ASSOC)) {
    $cpt++;
    echo $row["Project_Name"]."<form action='view_project.php?project=".$row["Id_Project"]."' method='post' style='display: inline'>
                                    <input type='submit' value='voir' class='button'>
                               </form><br>";
}

if($cpt == 0) {
    echo "Vous n'avez rejoint aucun projet";
}

echo "</div>";