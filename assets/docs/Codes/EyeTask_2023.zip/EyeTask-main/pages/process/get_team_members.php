<?php
function get_team_members($team)
{
    if(isset($team) and $team != "")
    {
        // connexion à la BDD
        $BDD = get_BDD();

        // on récupère tous les membres de l'équipe
        $request = "SELECT u.EMail_User, u.Name_User, u.Surname_User FROM utilisateur as u
                    JOIN rejoindre_g AS r ON u.EMail_User = r.EMail_User
                    JOIN equipe AS e ON r.Id_Team = e.Id_Team
                    WHERE r.Id_Team=" . $team;

        $request_execution = mysqli_query($BDD, $request);

        $cpt=0;

        echo "<div class='box' id='personne'>";

        while ($row = mysqli_fetch_array($request_execution, MYSQLI_ASSOC))
        {
            $cpt++;
            echo "<strong>Mail :</strong> ".$row["EMail_User"]." <strong>Nom :</strong> ".$row["Name_User"]." <strong>Prénom :</strong> ".$row["Surname_User"]."
            <form method='post' style='display: inline' action='process/leave_team.php?ID_t=".$team."&email=".$row["EMail_User"]."'>
                <input type='hidden' name=url value='".$_SERVER["REQUEST_URI"]."'>
                <input type='submit' value='exclure' class='button'>
            </form><br>";
        }
        if($cpt==0)
        {
            echo "Cette équipe ne possède aucun membre";
        }

        echo "</div>";
    }
    else
    {
        echo "erreur lors de la récupération des membres de l'équipe";
    }
}