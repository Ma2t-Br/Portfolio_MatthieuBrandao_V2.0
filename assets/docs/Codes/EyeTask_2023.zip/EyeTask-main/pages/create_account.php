<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="stylesheets/style_create_account.css">
    <title>Créer un compte</title>
    <link rel="icon" type="image/png" href="../Sources/logo_eyetask.png"/>
</head>

<body>
<div id="content_signin">
    <h1>Créer un compte</h1>
    <div>
        <form action="login.php" style="display: inline">
            <input id="button" type="submit" value="J&#39;ai déjà un compte">
        </form>
        <form action="" style="display: inline">
            <input id="selected-button" type="button" value="Créer un compte">
        </form>
    </div>
    <form action="process/verif_account_creation.php" method="post">
        <label>
            <input id="input" type="text" placeholder="Nom" name="name" required>
        </label>
        <br>
        <label>
            <input id="input" type="text" placeholder="Prénom" name="surname" required>
        </label>
        <br>
        <label>
            <input id="input" type="email" placeholder="E-mail" name="email" required>
        </label>
        <br>
        <label>
            <input id="input" type="tel" placeholder="Téléphone" name="phone" required>
        </label>
        <br>
        <label>
            <input id="input" type="password" placeholder="Mot de passe" name="password" required>
        </label>
        <br>
        <label>
            <input id="input" type="password" placeholder="Confirmer le mot de passe" name="password_confirm" required>
        </label>
        <br>
        <label>
            <input id="input" type="text" placeholder="ID Discord (optionnel)" name="tag_discord">
        </label>
        <br>
        <input id="signin-button" type="submit" value="Inscription">
    </form>


    <!-- Erreurs -->
    <?php
    if(isset($_GET["error"]))
    {
        if($_GET["error"] == 1)
        {
            echo "<p class='error'>Mauvais mot de passe de confirmation !</p>";
        }
        elseif($_GET["error"] == 2)
        {
            echo "<p class='error'>Veuillez saisir un mot de passe</p>";
        }
        elseif($_GET["error"] == 3)
        {
            echo "<p class='error'>Email invalide</p>";
        }
        elseif($_GET["error"] == 4)
        {
            echo "<p class='error'>Veuillez saisir un email</p>";
        }
        elseif($_GET["error"] == 5)
        {
            echo "<p class='error'>Veuillez saisir nom et votre prénom</p>";
        }
        elseif($_GET["error"] == 6)
        {
            echo "<p class='error'>Veuillez saisir votre numéro de téléphone</p>";
        }
    }
    ?>

    <!-- Compte créé -->
    <?php
    if(isset($_GET["created"]))
    {
        if($_GET["created"] == 1)
        {
            echo "<br><strong>Votre compte a bien été créé !</strong><br>";
        }
    }
    ?>
</div>
</body>
</html>