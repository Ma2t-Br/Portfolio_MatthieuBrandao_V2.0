<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="stylesheets/style_planify_reminder.css">
    <link rel="stylesheet" href="stylesheets/style_header.css">
    <title>Planifier un rappel</title>
    <link rel="icon" type="image/png" href="../Sources/logo_eyetask.png"/>
</head>

<body>
<?php include("header.php") ?>

<div id='encad'>
    <div class='af' id='new'>
        <form action="process/add_reminder_task.php" method="post">
            <h1>Plannifier un rappel</h1>
            <label>Tâche :<select name="task" class="input">
            <?php
                session_start();
                include "process/request_functions.php";

                $BDD = get_BDD();

                $request = "SELECT t.Task_name, t.Id_Task, e.Team_Name, p.Project_Name FROM tâche AS t
                            JOIN associer_g AS ag ON t.Id_Task = ag.Id_Task
                            JOIN rejoindre_g AS rg ON ag.Id_Team = rg.Id_Team
                            JOIN equipe AS e ON ag.Id_Team = e.Id_Team
                            JOIN projet AS p ON e.Id_Project = p.Id_Project
                            WHERE EMail_User='".$_SESSION["email"]."' AND t.Day_Deadline>=CURRENT_DATE";

                $request_execution = mysqli_query($BDD, $request);

                while ($row = mysqli_fetch_array($request_execution, MYSQLI_ASSOC)) {
                    echo "<option value='".$row["Id_Task"]."'>".$row["Task_name"]." - projet ".$row["Project_Name"]." équipe ".$row["Team_Name"]."</option>";
                }
            ?>
            </select></label>
            <br><label>Date du rappel :<input type="date" class="input" name="date"></label>
            <br><label>Heure du rappel :<input type="time" class="input" name="hour"></label>
            <br><label>Discord : <input type="checkbox" name="bool_discord"></label>
            <label>Mail : <input type="checkbox" name="bool_mail"></label>
            <br><input type="submit" value="Valider" class="button">
        </form>
    </div>
</div>

</body>
</html>