<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Infos utilisateur</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="stylesheets/style_info_user.css">
    <link rel="stylesheet" href="stylesheets/style_header.css">
    <link rel="icon" type="image/png" href="../Sources/logo_eyetask.png"/>
</head>

<body>
<?php include("header.php") ?>

<div id="encad">
    <div class="af">
        <h1>Informations personnelles</h1>
        <?php
        include "process/request_functions.php";
        session_start();

        if($_SESSION["email"] != "")
        {
            $email = $_SESSION["email"];

            // connexion à la BDD
            $BDD = get_BDD();

            // requête des informations de l'utilisateur
            $request = "SELECT * FROM utilisateur where EMail_User = '" .$email. "' ";
            $request_execution = mysqli_query($BDD, $request);
            $answer = mysqli_fetch_array($request_execution);

            echo "<p><strong>Nom : </strong>".$answer["Name_User"]."</p>";
            echo "<p><strong>Prénom : </strong>".$answer["Surname_User"]."</p>";
            echo "<p><strong>Mail : </strong>".$answer["EMail_User"]."</p>";
            echo "<p><strong>Numéro de téléphone : </strong>".$answer["Phone_Number_User"]."</p>";
            echo "<p><strong>Tag Discord : </strong>".$answer["Discord_Tag"]."</p>";
            echo "<p><strong>Date d'inscription : </strong>".$answer["Inscription_Date"]."</p>";

            echo "
                <form action='modify_info_user.php' method='post'>
                    <input type='submit' value='Modifier mes informations' class='button'>
                </form>
            ";
        }
        ?>
    </div>
</div>
</body>
</html>
