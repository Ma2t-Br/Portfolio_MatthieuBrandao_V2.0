<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Page principale</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="stylesheets/style_main_page.css">
    <link rel="stylesheet" href="stylesheets/style_header.css">
    <link rel="icon" type="image/png" href="../Sources/logo_eyetask.png"/>

    <script src='../API/fullcalendar-6.1.5/dist/index.global.js'></script>

    <?php
    include "process/request_functions.php";
    session_start();

    echo "
        <script>

            document.addEventListener('DOMContentLoaded', function() {
                var calendarEl = document.getElementById('calendar');

                var calendar = new FullCalendar.Calendar(calendarEl, {
                    headerToolbar: {
                        left: 'prevYear,prev,next,nextYear today',
                        center: 'title',
                        right: 'dayGridMonth,dayGridWeek,dayGridDay'
                    },
                    titleFormat: {
                        month: 'long',
                        year: 'numeric',
                    },
                    navLinks: true,
                    editable: false,
                    dayMaxEvents: true,
                    events: [";

    $BDD = get_BDD();

    $request = "SELECT t.Task_name, t.Task_Description, t.Day_Deadline, t.Hour_Deadline FROM tâche AS t
                    JOIN associer_g AS ag ON t.Id_Task = ag.Id_Task
                    JOIN rejoindre_g AS rg ON ag.Id_Team = rg.Id_Team
                    WHERE EMail_User='".$_SESSION["email"]."'";

    $request_execution = mysqli_query($BDD, $request);

    while ($row = mysqli_fetch_array($request_execution, MYSQLI_ASSOC)) {
        echo "{ 
                    title: '".$row["Task_name"]."',
                    start: '".$row["Day_Deadline"]."T".$row["Hour_Deadline"]."'
                },";
    }
    echo"]
                });

                calendar.render();
            });
    </script>";
    session_abort();
    ?>
</head>

<body>
<?php include("header.php") ?>

<div class="calendar">
    <div id='calendar'></div>
</div>

<div class="taskManagment">
    <div class="etat">
        <h1 class="tache">Tâches en cours</h1>
    </div>

    <?php
        include("process/get_task_to_do_user.php");
    ?>
</div>


<div id="container">
    <table>
        <tr>
            <td><img src="../Sources/icons8-plus-512.svg" class="icon"></td>
            <td class="hide">Ajouter une tache</td>

        </tr>
        <tr>
            <td><img src="../Sources/icons8-synchroniser.svg" class="icon"></td>
            <td class="hide">Synchroniser votre agenda</td>

        </tr>
        <tr>
            <td><img src="../Sources/icons8-mallette.svg" class="icon"></td>
            <td class="hide">Lister mes projets</td>

        </tr>
        <tr>
            <td><img src="../Sources/icons8-info.svg" class="icon"></td>
            <td class="hide">infos et aides</td>

        </tr>
        <tr>
            <td><img src="../Sources/icons8-partager.svg" class="icon"></td>
            <td class="hide">Partager mes projets</td>

        </tr>
        <tr>
            <td><img src="../Sources/icons8-services.svg" class="icon"></td>
            <td class="hide">Paramètres avancés</td>

        </tr>
    </table>
</div>
</body>
</html>
