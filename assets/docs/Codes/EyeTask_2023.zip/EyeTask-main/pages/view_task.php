<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="stylesheets/style_view_task.css">
    <link rel="stylesheet" href="stylesheets/style_header.css">
    <title>Voir une tâche</title>
    <link rel="icon" type="image/png" href="../Sources/logo_eyetask.png"/>
</head>

<body>

<?php include("header.php") ?>

<div id="encad">
    <?php
    session_start();
    include "process/request_functions.php";

    if(isset($_POST["id_task"])) {
        $BDD = get_BDD();

        $request = "SELECT * FROM tâche AS t WHERE Id_Task=" . $_POST["id_task"];
        $request_execution = mysqli_query($BDD, $request);

        $row = mysqli_fetch_array($request_execution, MYSQLI_ASSOC);

        echo "<div class='af'>";

        echo "
            <h1>Tâche : ".$row["Task_name"]."</h1>
            <p><strong>Deadline :</strong> Le ".$row["Day_Deadline"]." à ".$row["Hour_Deadline"]."</p>
            <p><strong>Description :</strong><br>".$row["Task_Description"]."</p>
        ";

        echo "</div>";
    }
    else {
        echo "Une erreur est survenue :(";
    }
    ?>
</div>

</body>
</html>
