<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="stylesheets/style_view_project.css">
    <link rel="stylesheet" href="stylesheets/style_header.css">
    <title>Page principale</title>
    <link rel="icon" type="image/png" href="../Sources/logo_eyetask.png"/>
</head>

<body>
<?php include("header.php") ?>

<?php
echo "<div id='encad'>";
if(isset($_GET["project"]))
{
    include "process/request_functions.php";
    session_start();

    $BDD=get_BDD();

    // On va vérifier que l'utilisateur est bien membre du projet
    $request="SELECT count(*) FROM projet AS p 
                    JOIN rejoindre_p AS r ON r.Id_Project = p.Id_Project 
                    JOIN utilisateur AS u ON r.EMail_User = u.EMail_User
                    WHERE p.Id_Project=".$_GET["project"]." AND u.Email_User='".$_SESSION["email"]."'";

    $request_execution = mysqli_query($BDD, $request);
    $answer = mysqli_fetch_array($request_execution);

    if($answer["count(*)"] == 1)  // l'utilisateur est bien membre du projet
    {
        // On récupère et on affiche les informatation générales du pojet
        $request="SELECT * FROM projet where Id_Project=".$_GET["project"];
        $request_execution = mysqli_query($BDD, $request);
        $answer = mysqli_fetch_array($request_execution);
        $p_name = $answer["Project_Name"];
        $p_date = $answer["Creation_Date"];
        $p_desc = $answer["Project_Description"];

        echo "<div class='af' id='info'>";

        echo "<h1>".$p_name."</h1><br>
                        <div><strong>Date de création :</strong>".$p_date."<br>
                        <p><strong>Description :</strong><br>".(($p_desc=="")?"Aucune description n'a été écrite pour ce projet":$p_desc)."</p></div>";
        echo "</div>";

        // on va chercher si l'utilisateur est administrateur du projet ou non
        $request="SELECT count(*) FROM projet AS p 
                    JOIN rejoindre_p AS r ON r.Id_Project = p.Id_Project 
                    JOIN utilisateur AS u ON r.EMail_User = u.EMail_User
                    WHERE p.Id_Project=".$_GET["project"]." AND u.Email_User='".$_SESSION["email"]."' AND r.Is_Admin=1";

        $request_execution = mysqli_query($BDD, $request);
        $answer = mysqli_fetch_array($request_execution);

        if($answer["count(*)"] == 1)
        {

            echo"<div class='af'>";

            // l'utilisateur est administrateur du projet
            echo "<h2>Vous êtes administrateur du projet.</h2>";

            // on permet de supprimer le projet
            echo "<br><form action='process/delete_project.php?ID_p=".$_GET["project"]."' method='post'><input type='submit' class='button' id='sup' value='Supprimer le projet'></form>";

            echo "</div>";
            echo"<div class='af'>";

            // on affiche la liste des membres de projet pour les administrateurs
            echo "<h1>Membres du projet</h1>";
            include "process/get_project_members.php";
            get_project_members($_GET["project"]);

            echo "</div>";
            echo "<div class='af' id='new'>";

            // on affiche le formulaire pour ajouter une personne au projet
            echo "
                    <h1>Ajouter une personne au projet</h1>
                    <form action='process/add_people_project.php' method='post'>
                        <label>Mail de la personne à ajouter :</label>
                        <input type='email' placeholder='Email' name='email_to_add' class='input' required>
                        <input type='hidden' name=project value='".$_GET["project"]."'>
                        <input type='hidden' name=url value='".$_SERVER["REQUEST_URI"]."'>
                        <input type='submit' value='ajouter' class='button'>
                    </form>";

            echo "</div>";
            echo "<div class='af' id='new'>";

            // on affiche le formulaire pour créer une équipe
            echo "
                    <h1>Ajouter une équipe au projet</h1>
                    <form action='process/add_team_project.php' method='post'>
                        <label>Nom de l'équipe à créer :</label>
                        <input type='text' placeholder='Nom de léquipe' name='team_name' class='input' required><br>
                        <label>Description de l'équipe (optionnel) :<br>
                            <textarea name='team_description' placeholder='Description de léquipe' class='input' cols='60' rows='6'></textarea>
                        </label><br>
                        <input type='hidden' name=project value='".$_GET["project"]."'>
                        <input type='hidden' name=url value='".$_SERVER["REQUEST_URI"]."'>
                        <input type='submit' value='créer' class='button'>
                    </form>";

            echo "</div>";

            //-----------------------------------------------------------------------------
            // Ajout de tâche à une équipe
            //-----------------------------------------------------------------------------
            // on récupère la liste des équipes du projet
            $request="SELECT Id_Team, Team_Name FROM equipe WHERE Id_Project=".$_GET["project"];
            $request_execution = mysqli_query($BDD, $request);

            echo "<div class='af' id='new'>";

            // on affiche le formulaire pour plannifier une tâche
            echo "
                    <h1>Ajouter une tâche à une équipe du projet</h1>
                    <form action='process/add_task_team.php' method='post'>
                        <label>Nom de la tâche :
                        <input type='text' placeholder='Nom de la tâche' name='task_name' class='input' required></label>
                        <input type='hidden' name=project_ID value='".$_GET["project"]."'>
                        <input type='hidden' name=url value='".$_SERVER["REQUEST_URI"]."'>
                        <label>Date : <input type='date' name='date' class='input' required></label>
                        <label>Heure : <input type='time' name='hour' class='input' required></label>
                        <br>
                        <label>Description de la tâche (optionnel) :<br>
                            <textarea name='task_description' placeholder='Descirption de la tâche' class='input' rows='6' cols='60'></textarea>
                        </label>
                        
                        <br><label>Equipe : </label><select name='team_ID' class='input'>";

            while ($row = mysqli_fetch_array($request_execution, MYSQLI_ASSOC)) {
                echo "<option value='".$row["Id_Team"]."'>".$row["Team_Name"]."</option>";
            }

            echo"</select><br><input type='submit' value='créer' class='button'></form>";

            echo "</div>";


            // récupération de la liste des tâches du projet
            $request="SELECT t.Id_Task, t.Task_name FROM Tâche t 
                        JOIN associer_g ag on t.Id_Task = ag.Id_Task
                        JOIN equipe e on ag.Id_Team = e.Id_Team
                        JOIN projet p on e.Id_Project = p.Id_Project
                        WHERE p.Id_Project=".$_GET["project"];

            $request_execution = mysqli_query($BDD, $request);

            // on affiche le formulaire pour supprimer une tâche

            echo "<div class='af' id='new'>";

            echo "
                <h1>Supprimer une tâche</h1>
                <form action='process/delete_task_project.php' method='post'>
                    <select name='task_ID'>";

            while ($row = mysqli_fetch_array($request_execution, MYSQLI_ASSOC)) {
                echo "<option value='".$row["Id_Task"]."'>".$row["Task_name"]."</option>";
            }

            echo"
                    </select>
                    <input type='hidden' name=url value='".$_SERVER["REQUEST_URI"]."'>
                    <input type='submit' value='Supprimer' class='button'>
                </form>
            ";

            echo "</div>";

        }
        else
        {
            echo "<div class='af'>";

            // l'utilisateur n'est pas administrateur du projet
            echo "<h2>Vous n'êtes pas administrateur du projet</h2>";

            echo "</div>";
            echo "<div class='af' id='new'>";

            // on permet de quitter le projet
            echo "<form action='process/leave_project.php?ID_p=".$_GET["project"]."&email=".$_SESSION["email"]."' method='post'>
                            <input type='hidden' name=url value='../projects.php'>
                            <input type='submit' value='Quitter le projet' class='button'>
                        </form>";

            echo "</div>";

        }

        echo "<div class='af'>";

        // on liste les équipes du projet
        include "process/get_teams.php";
        echo "<h1>Equipes du projet</h1>";
        echo "<div class='box' id='team'>";
        list_teams($_GET["project"]);
        echo "</div>";
        echo "</div>";
    }
    else
    {
        echo "<div class='af'>";

        // L'utilisateur n'est pas membre du projet
        echo"<h1>vous n'avez pas la permission de consulter ce projet !</h1>";

        echo "</div>";
    }
}
else
{
    echo "<div class='af'>";
    // L'ID du projet n'est pas définie
    echo "<h1>Une erreur est survenue.</h1>";
    echo "</div>";
}
echo "</div>";
?>
</body>
</html>