
<div id="main_container">
    <div id="img_container">
        <a href="main_page.php"><img src="../Sources/logo_eyetask.png" alt="Page principale" class="logo"></a>
    </div>

    <div id="bandeau_container">
        <ul class="bandeau">
            <li class="bandeau_items"><a href="main_page.php" class="bandeau_link">Accueil</a></li>
            <li class="bandeau_items"><a href="projects.php" class="bandeau_link">Mes projets</a></li>
            <li class="bandeau_items"><a href="info_user.php" class="bandeau_link">Mes informations</a></li>
            <li class="bandeau_items"><a href="planify_reminder.php" class="bandeau_link">Planifier un rappel</a></li>
            <li class="bandeau_items"><a href="login.php" class="bandeau_link">Se déconnecter</a></li>
        </ul>
    </div>

    <div id="user_container">
        <ul id="list_user">
            <li><a href="https://discord.gg/AAYwgkBZ25"><img src="../Sources/icons8-éclair-96.png" class="eclair" alt="Notifications"></a></li>
            <li id="user_name"><a class="login" href="info_user.php">
                <?php
                    session_start();
                    echo $_SESSION["name_user"];
                    session_abort();
                ?>
            </a></li>
        </ul>
    </div>
</div>
