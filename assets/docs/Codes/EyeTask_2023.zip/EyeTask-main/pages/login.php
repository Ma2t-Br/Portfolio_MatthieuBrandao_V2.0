<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="stylesheets/style_login.css">
    <title>Connexion</title>
    <link rel="icon" type="image/png" href="../Sources/logo_eyetask.png"/>
</head>

<body>
<div id="content_login">
    <h1>Connexion</h1>

    <div>
        <form action="" style="display: inline">
            <input id="selected-button" type="button" value="J'ai déjà un compte">
        </form>
        <form action="create_account.php" style="display: inline">
            <input id="button" type="submit" value="Créer un compte">
        </form>
    </div>

    <form action="process/verification_login.php" method="post">

        <input id="input" type="email" placeholder="E-mail" name="email" required>
        <br>
        <input id="input" type="password" placeholder="Mot de passe" name="password" required>
        <br>
        <input id="connexion-button" type="submit" value="Connexion">

        <!-- Erreurs -->
        <?php
        if(isset($_GET["error"]))
        {
            if($_GET["error"] == 2)
            {
                echo "<p class='error'>Email ou mot de passe incorrect</p>";
            }
            elseif($_GET["error"] == 1)
            {
                echo "<p class='error'>Email non valide ou mot de passe / email non saisi</p>";
            }
        }
        ?>
    </form>
</div>
</body>
</html>