<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="stylesheets/style_projects.css">
        <link rel="stylesheet" href="stylesheets/style_header.css">
        <title>Projets</title>
        <link rel="icon" type="image/png" href="../Sources/logo_eyetask.png"/>
    </head>

    <body>
    <!-- Header -->
    <?php include("header.php") ?>
    <div id='encad'>
        <!-- Affichage de la liste des projets de l'utilisateur  -->
        <div class='af'>
            <h1>Mes projets</h1>
            <?php include("process/get_projects.php") ?>
        </div>

        <!-- Créer un projet -->
        <div class='af' id='new'>
            <h1>Créer un projet</h1>
            <form action="process/verif_project_creation.php" method="post">
                <label>
                    Nom du projet :
                    <input type="text" placeholder="Nom du projet" name="project_name" class="input" required>
                </label><br>
                <label>Descritpion du projet (optionnel):<br>
                    <textarea placeholder="Description du projet" name="project_description" class="input" cols="60" rows="6"></textarea>
                </label>
                <br>
                <input type="submit" value="créer le projet" class="button">
            </form>

        <!--Erreur ou succès -->
        <?php
        if(isset($_GET["created"]))
        {
            if($_GET["created"] == 1)
            {
                echo "<br><strong>Le projet a bien été créé !</strong><br>";
            }
        }
        if(isset($_GET["error"]))
        {
            if($_GET["error"] == 1)
            {
                echo "<p class='error'>Veuillez saisir un nom pour votre projet !</p>";
            }
        }
        ?>
        </div>
    </div>

    </body>
</html>