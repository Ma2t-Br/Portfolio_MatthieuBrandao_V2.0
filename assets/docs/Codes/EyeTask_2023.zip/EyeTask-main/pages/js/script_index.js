function buttonA_clickHandler(event) {
    document.getElementById('hidden-div').hidden = false;
}