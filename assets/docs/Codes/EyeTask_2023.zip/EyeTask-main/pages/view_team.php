<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="stylesheets/style_view_project.css">
        <link rel="stylesheet" href="stylesheets/style_header.css">
        <title>Vue équipe</title>
        <link rel="icon" type="image/png" href="../Sources/logo_eyetask.png"/>
    </head>

    <body>
    <?php include("header.php") ?>
    <div id="encad">
        <?php
        include "process/request_functions.php";
        session_start();

        $team_ID = $_GET["team_id"];
        $project_ID = $_GET["project"];

        // on récupère les informations de l'équipe
        $BDD=get_BDD();
        $request="SELECT Team_Name, Team_Description FROM equipe WHERE Id_Team=".$team_ID;
        $request_execution = mysqli_query($BDD, $request);
        $answer = mysqli_fetch_array($request_execution);

        echo "<div class='af'>";
        echo "<h1>".$answer["Team_Name"]."</h1>
                <strong>Description :</strong><br>".$answer["Team_Description"];
        echo "</div>";

        echo "<div class='af' id='new'>";
        echo "<h1>Membres de l'équipe :</h1>";
        include "process/get_team_members.php";
        get_team_members($team_ID);
        echo "</div>";
        ?>

        <div class="af">
            <h1>Ajouter un membre à l'équipe</h1>
            <?php
                // on récupère la liste des mails des membres du projet
                $request="SELECT EMail_User FROM rejoindre_p WHERE Id_Project=".$project_ID;
                $request_execution = mysqli_query($BDD, $request);

                // ajouter un menu déroulant proposant tous les membres du projet qu'on peut ajouter
                echo "<form method='post' action='process/add_people_team.php'><select name='email' class='input'>";

                while ($row = mysqli_fetch_array($request_execution, MYSQLI_ASSOC)) {
                    echo "<option value='".$row["EMail_User"]."'>".$row["EMail_User"]."</option>";
                }
                echo "</select><input type='hidden' name='project_ID' value='".$project_ID."'>
                                <input type='hidden' name='team_ID' value='".$team_ID."'>
                                <input type='hidden' name=url value='".$_SERVER["REQUEST_URI"]."'>
                                <input type='submit' value='ajouter' class='input'></form>";
            ?>
        </div>
    </div>
    </body>
</html>