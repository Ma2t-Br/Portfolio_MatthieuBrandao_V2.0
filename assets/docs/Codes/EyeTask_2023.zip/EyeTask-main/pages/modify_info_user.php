<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Modifier utilisateur</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="stylesheets/style_modidy_info_user.css">
    <link rel="stylesheet" href="stylesheets/style_header.css">
    <link rel="icon" type="image/png" href="../Sources/logo_eyetask.png"/>
</head>

<body>
<?php include("header.php") ?>
<div id="encad">
    <?php
    session_start();
    include "process/request_functions.php";

    $BDD = get_BDD();

    $email = $_SESSION["email"];

    $request = "SELECT * FROM utilisateur where EMail_User = '" .$email. "' ";
    $request_execution = mysqli_query($BDD, $request);
    $answer = mysqli_fetch_array($request_execution);

    echo "<div id='new' class='af'>";

    echo "
    <form action='process/update_user.php' method='post'>
        <h1>Modifier mes informations</h1>
        <label>Mail : <input type='email' name='mail' class='input' value='".$answer["EMail_User"]."' disabled></label><br>
        <label>Nom : <input type='text' name='name' class='input' value='".$answer["Name_User"]."'></label><br>
        <label>Prénom : <input type='text' name='surname' class='input' value='".$answer["Surname_User"]."'></label><br>
        <label>Numéro de téléphone : <input type='tel' name='phone' class='input' value='".$answer["Phone_Number_User"]."'></label><br>
        <label>Tag Discord : <input type='text' name='discord_tag' class='input' value='".$answer["Discord_Tag"]."'></label><br>
        <input type='submit' value='Valider' class='button'>
    </form>";

    echo "</div>";
    ?>
</div>
</body>
</html>

