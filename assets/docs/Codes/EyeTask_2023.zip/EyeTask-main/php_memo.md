<h1> Mémo PHP </h1>
(créé après la lecture du cours d'openclassrooms : 
https://openclassrooms.com/fr/courses/918836-concevez-votre-site-web-avec-php-et-mysql/912352-exploitez-toute-la-puissance-des-fonctions-php)

<h2>Généralités</h2>

<pre>
Pour intégrer du code PHP dans une page, on utilise la balise<![CDATA[ <?php (on met le code ici)  ?>]]>

Chaque instruction doit se terminer par un ";".
Pour afficher du texte, on utilise "echo".

Exemple :
echo "bonjour";

A SAVOIR : echo permet "d'afficher" des balises HTML. On peut donc utiliser PHP pour générer une page entière.
C'est le principe même de PHP, qui permet de créer des pages dynamiques.

Le PHP suit la convention du camelCase.

Pour intégrer un code PHP provenant d'un autre fichier dans notre page, on utilise :
<![CDATA[<?php include('fichier.php'); ?>]]>
On peut par exemple placer cette balise dans un code HTML pour implémenter une partie dynamique.

--> Cela permet de séparer sa page en plusieurs parties claires :
on peut notamment créer "footer.php" et "header.php" pour ranger la tête et le pied de page.
Cela permet aussi de les réutiliser dans toutes nos pages sans avoir à le copier coller à chaque fois.

On peut arrêter l'exécution d'un code PHP avec return;
Cela permet de créer des points d'arrêt en cas d'erreur ou de condition non respectée.
</pre>

<h2>Types</h2>
<pre>
En termes de type, on a :
- int
- string
- float
- bool
- NULL
</pre>

<h2>Variables</h2>
<pre>
Pour déclarer une variable, pas besoin de spécifier son type.

Un peu comme dans le shell Linux, pour faire référence à une variable, on utilise le $.
Pour faire utiliser la variable "nom" par exemple, on écrira $nom.

Exemple :
$nom = 2;
echo $nom;

On peut utiliser la post-incrémentation :
$var++

Pour supprimer une variable, on utilise la fonction unset().
</pre>

<h2>Opérateurs</h2>
<pre>
On a accès aux opérateurs suivants :
-, +, /, *, %

Pour la comparaison, on a :
==, <, >, <=, >=, !=
</pre>

<h2>Conditions</h2>
<pre>
Les conditions s'écrivent de la manière suivante :

if(condition){
    code;
}
elseif(condition){
    code;
}
else{
    code;
}

Pour les conditions multiples, on utilisera :
&& pour le AND
|| pour le OR
! pour le NOT
</pre>

<h2>Switch</h2>
<pre>
On peut également utiliser le switch :

switch(variable)
{
    case 0:
        code;
        break;
    case 1:
        code;
        break;
    default:
        code;
}
</pre>


<h2>Tableaux numérotés</h2>
<pre>
Il existe des tableaux en PHP.
Un des types de tableaux, les tableaux numérotés, possède un fonctionnement similaire à celui des tableaux en Python :

$tableau = ["oui", "non", 2];

Pour accéder aux valeurs : 
$tableau[0] --> "oui"
</pre>

<h2>While</h2>
<pre>
La boucle while est aussi disponible :

while(condition){
    code;
}
</pre>

<h2>Boucle for</h2>
<pre>
On a aussi la boucle for :

for ($i = 0; $i <= 2; $i++)
{
    code;
}
</pre>

<h2>Intégration de la boucle for dans la balise PHP</h2>
<pre>
On peut intégrer la boucle for à la balise PHP pour exécuter un code un certain nombre de fois :

<![CDATA[
<?php for ($lines = 0; $lines <= 1; $lines++): ?>
    code;
<?php endfor; ?>
]]>
</pre>

<h2>Tableaux associatifs</h2>
<pre>
Un autre type de tableaux en PHP est les tableaux associatifs.
Leur syntaxe est la suivante :

$tableau = [
    "oui" => "non",
    ...
    "bonjour" => "Au revoir"
];

Pour accéder aux données de ces tableaux, on utilise les clés :
tableau["oui"] donnera "non".
C'est un fonctionnement similaire à celui des dictionnaires en Python.
</pre>

<h2>La boucle foreach</h2>
<pre>
Il existe une boucle permettant de parcourir les tableaux par valeur :

foreach ($tableau as $element) {
    code;
}

C'est un fonctionnement similaire à "for element in tableau" en Python.

Foreach permet de parcourir les tableaux numérotés et associatifs.
Pour les tableaux associatifs, la boucle ci dessus permet de parcourir les clés.
Si on veut parcourir les clés ET leurs attributs, on utilise la boucle suivante :

foreach($tableau as $cle => $attribut){
    code;
}
</pre>

<h2>Afficher un tableau</h2>
<pre>
Pour afficher un tableau on utilisera la fonction print_r :

print_r($recipes);

L'affichage sera assez sale, on pourra rajouter un echo pour afficher une balise HTML de champ "pre".
</pre>

<h2>Recherche dans les tableaux</h2>
<pre>
Il y a des fonctions pour faire de la recherche rapide dans les tableaux :
- in_array("oui", $tab) renverra un booléen indiquant si la valeur "oui" est dans le tableau "tab"
- array_key_exists("clé", $tab) renverra un booléen indiquant si la valeur "clé" est une clé du tableau "tab"
- array_search('oui', $tab) renverra la position de la valeur "oui" dans le tableau "tab"
</pre>

<h2>Des fonctions super pratiques</h2>
<pre>
Pour des détails sur le fonctionnement exacts des fonctions listées ici, consultez la documentation en ligne.
Seulement les fonctions potentiellement utiles au projet seront listées ici.

- str_replace() pour rechercher et remplacer des mots dans un string
- move_uploaded_file() pour envoyer un fichier sur un serveur
- imagecreate() pour créer des images miniatures (thumbnails)
- mail() pour envoyer un mail avec PHP
- crypt() pour crypter les mots de passe
- date() pour renvoyer la date et l'heure
- strlen() pour obtenir la taille d'un string
- sprintf() pour formater les chaînes de caractères
- fopen() pour créer / ouvrir un fichier
- isset() pour vérifier si une variable existe
- empty() pour vérifier si une variable est vide
- filter_var() pour filtrer des variables, et notamment des EMAIL
- htmlspecialchars() pour supprimer tout code donné dans un input (pour éviter les injections javascript)
        --> à utiliser à la réception de chaque input de l'utilisateur pour sécuriser la page
        --> en réalité, cette fonction remplace les "<" et ">" des balises pour que ce ne soit plus des balises
- strip_tags() enlève entièrement les balises HTML des inputs qu'on lui donne.
- header() permet de rediriger vers une autre page en incorporant des éléments dans l'URL (pratique pour transmettre une erreur)
</pre>

<h2>Créer une fonction</h2>
<pre>
Pour définir une fonction en PHP, on utilise la syntaxe suivante :

function nomFonction(type $var) : typeRetourné
{
    code;
    return qqch;
}

nb : si la fonction retourne un tableau ou a un tableau en entrée, on utilise le mot clé "array".
</pre>

<h2>Récupérer les données d'un formulaire</h2>
<pre>
Lorsqu'un formulaire de type GET est envoyé vers du code PHP, il place toutes les informations dans la variable superglobale "$_GET".
En fait, "$_GET" est un tableau associatif.

Exemple : 
Si le formulaire contenant l'information "identifiant" et que sa valeur est à "michel".
On a alors $_GET["identifiant"] == "michel".

Si le formulaire est de type POST, les informations seront placées dans la variable superglobale "$_POST", qui a la même structure.

Comme les formulaires sont traficables depuis la barre d'adresse, on va devoir s'assurer que toute nos variables sont bien là.

Rappel : la forme d'un formulaire est https://www.monsite.com/fichier.php?nom=michel&prenom=eude dans la barre d'adresse.

Pour ça, on a la fonction isset() qui nous permet de vérifier si une variable existe :
isset($_GET['email']) permet de vérifier si l'email est bien défini.

On peut aussi contrôler la validité des informations récupérées avant de faire une action avec les données récupérées.
Par exemple, on peut s'assurer que l'attribut "email" est bien un mail et pas une simple chaine de caractères.

A chaque réception de formulaire, on doit systématiquement utiliser la fonction htmlspecialchars() ou strip_tags().
Elle permet de supprimer tout code dans les inputs de l'utilisateur, et donc de sécuriser un peu plus le site.
En effet, si on ne la met pas, l'utilisateur peut utiliser des balises script pour injecter du code javascript dans la page.
A partir de là, il peut faire beaucoup de choses dangereuses.
</pre>

<h2>Liens avec MySQL</h2>
<pre>
Pour ouvrir une session MySql, on utilise le modèle suivant :
$BDD = mysqli_connect($BDD_host, $BDD_username, $BDD_password,$BDD_name)

On peut ajouter un "or die("connexion impossible")" pour gérer les cas de problèmes de connexion à la base de données.

Pour écrire une requête SQL, il faut d'abord la stocker sous forme de string dans une variable.
On écrit la requête comme on l'aurait écrite dans un fichier .sql, il faut juste formater le string pour y insérer nos variables.

Une fois la requête écrite, on l'envoie ainsi :
$request_execution = mysqli_query($BDD, $request);
Le résultat est stocké dans la variable request_execution.

Pour pouvoir exploiter le résultat, on transforme la réponse en tableau associatif :
$answer = mysqli_fetch_array($request_execution);
Ce tableau aura à peu près la même forme que le résultat d'un SELECT en SQL.

Quand on a terminé nos requêtes, on ferme la session MySQL avec :
mysqli_close($BDD);
</pre>

<h2>Créer une session</h2>
<pre>
On place "session_start();" juste après la balise php, cela nous ouvre une session.

On peut aussi utiliser la variable superglobale $_SESSION :
$_SESSION["user"] = $user;

On peut ensuite rediriger l'utilisateur vers sa page avec la fonction header :
header("Location: main_page.php");
Attention à bien respecter les espaces dans la commande ci dessus, cela peut mener à une erreur 500 s'ils ne sont pas respectés.
</pre>

<h2></h2>
<pre>

</pre>