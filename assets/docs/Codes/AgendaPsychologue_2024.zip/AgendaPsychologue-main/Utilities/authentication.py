from logging import root

from Connector.Connector import MySQLConnector
from Interface import user_menu
from Utilities import textPrinter


def is_in_database(username, password):
    # Vérifier si l'utilisateur est dans la base de données
    query = f"SELECT Psychologue FROM User WHERE NuméroDeSécuriéSocial = '{username}' AND UserPassword = '{password}'"

    connector = MySQLConnector()
    connector.connect()

    result = connector.execute_query(query)
    if (len(result) > 0):
        textPrinter.log_message("Vous êtes connecté")
        return result
    else:
        textPrinter.log_message("Mauvais identifiants")
        connector.close()

    return None