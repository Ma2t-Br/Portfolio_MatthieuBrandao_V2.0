from Connector.Connector import MySQLConnector
from Objects import Patient, Reservation, Agenda, Profession

class DataBaseInitializer:
    def __init__(self, connector):
        self.connector = connector
        return self.init_patients_from_dataBase(),\
            self.init_reservations_from_dataBase(), \
            self.init_agendas_from_dataBase(), \
            self.init_professions_from_dataBase()

    def init_patients_from_dataBase(self):
        patients_from_dataBase = []

        patients = self.connector.execute_query('SELECT * FROM patient')
        if len(patients) > 0:
            for patient in patients:
                patients_from_dataBase.append(
                    Patient.Patient(patient[1], patient[2], patient[3], patient[4], patient[5], patient[6], patient[7],
                                    patient[0], patient[8]))
        return patients_from_dataBase

    def init_reservations_from_dataBase(self):
        reservations_from_dataBase = []

        reservations = self.connector.execute_query('SELECT * FROM réservation')
        if len(reservations) > 0:
            for reservation in reservations:
                reservations_from_dataBase.append(
                    Reservation.Reservation(reservation[0], reservation[1], reservation[2], reservation[3], reservation[4], reservation[5],
                                             reservation[6], reservation[7]))
        return reservations_from_dataBase

    def init_agendas_from_dataBase(self):
        agendas_from_dataBase = []

        agendas = self.connector.execute_query('SELECT * FROM agenda')
        if len(agendas) > 0:
            for agenda in agendas:
                agendas_from_dataBase.append(
                    Agenda.Agenda(agenda[0]))
        return agendas_from_dataBase

    def init_professions_from_dataBase(self):
        professions_from_dataBase = []

        professions = self.connector.execute_query('SELECT * FROM profession')
        if len(professions) > 0:
            for profession in professions:
                professions_from_dataBase.append(
                    Profession.Profession(profession[1], profession[0]))
        return professions_from_dataBase
