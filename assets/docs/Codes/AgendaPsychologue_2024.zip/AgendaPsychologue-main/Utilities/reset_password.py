import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from Connector.Connector import MySQLConnector

def is_in_database(username):
    # Vérifier si l'utilisateur est dans la base de données
    query = f"SELECT a.Email FROM Patient p a NATURAL JOIN User u WHERE p.NuméroDeSécuriéSocial = '{username}'"

    connector = MySQLConnector()
    connector.connect()

    result = connector.execute_query(query)
    connector.close()

    return result

def send_reset_password(email):
    sender_email = "your-email@gmail.com"
    password = "<PASSWORD>"
    # Create the email object
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = email
    message["Subject"] = "New Password Reset!"


    # Body of the email
    body = "Hello, you can reset your password with this link"
    message.attach(MIMEText(body, "plain"))

    # SMTP server initialization
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()  # Secure the connection
    server.login(sender_email, password)

    # Send the email
    server.sendmail(sender_email, email, message.as_string())
    server.quit()