from Objects.Patient import Patient
from Utilities import textPrinter
from Connector.Connector import MySQLConnector
import traceback  # Importez le module traceback pour obtenir des informations sur les exceptions

class PsychologueActions:
    def __init__(self, connector: MySQLConnector):
        self.connector = connector

    def view_all_appointments(self):
        query = f"SELECT * FROM Réservation"

        try:
            result = self.connector.execute_query(query)
            if result:
                return textPrinter.print_reservation_list(result)
            else:
                return textPrinter.log_message("Vous n'avez pas de rendez-vous")
        except Exception as e:
            print(f"Erreur lors de l'exécution de la requête : {e}")
            print(traceback.format_exc())  # Imprimez la trace complète de l'exception
            return textPrinter.log_message("Une erreur s'est produite lors de la récupération des rendez-vous")

    def add_patient(self, patient: Patient):
        query = f"INSERT INTO Patient (NuméroDeSécuriéSocial, Prénom, Nom, Email, DatePremiereConsultation, Adresse, DateDeNaissance, Source, Classification) " \
                f"VALUES ({patient.numeroDeSecuriteSociale}, '{patient.prenom}', '{patient.nom}', '{patient.email}', CURRENT_DATE, '{patient.adresse}', '{patient.dateDeNaissance}', '{patient.source}', '{patient.classification}')"

        try:
            self.connector.execute_query(query)
            return textPrinter.log_message("Patient ajouté")
        except Exception as e:
            print(f"Erreur lors de l'exécution de la requête : {e}")
            print(traceback.format_exc())  # Imprimez la trace complète de l'exception
            return textPrinter.log_message("Une erreur s'est produite lors de l'ajout du patient")

    def is_in_database(self, numeroDeSecuriteSociale: str, password: str):
        # Vérifier si l'utilisateur est dans la base de données
        query = f"SELECT Psychologue FROM User WHERE NuméroDeSécuriéSocial = '{numeroDeSecuriteSociale}' AND UserPassword = '{password}'"

        result = self.connector.execute_query(query)

        if len(result) > 0:
            textPrinter.log_message("Vous êtes connecté")
            return result[0][0]
        else:
            textPrinter.log_message("Mauvais identifiants")

    def is_in_database_add(self, patient: Patient):
        # Vérifier si l'utilisateur est dans la base de données
        query = f"SELECT * FROM User WHERE NuméroDeSécuriéSocial = '{patient.numeroDeSecuriteSociale}'"

        result = self.connector.execute_query(query)
        if len(result) > 0:
            textPrinter.log_message("Vous êtes connecté")
            return True
        else:
            textPrinter.log_message("Mauvais identifiants")

        return False

