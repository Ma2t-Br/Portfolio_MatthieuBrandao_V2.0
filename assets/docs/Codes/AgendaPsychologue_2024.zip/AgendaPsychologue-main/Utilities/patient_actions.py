import traceback

from Connector.Connector import MySQLConnector
from Utilities import textPrinter


class PatientActions:
    def __init__(self, connector: MySQLConnector):
        self.connector = connector

    def view_patient_account(self, numeroDeSecuriteSociale: str):
        query = f"SELECT * FROM Patient WHERE NuméroDeSécuriéSocial = '{numeroDeSecuriteSociale}'"

        result = self.connector.execute_query(query)
        return textPrinter.print_patient(result[0])

    def view_one_patient_appointments(self, numeroDeSecuriteSociale):
        query = f"SELECT * FROM Réservation WHERE NuméroDeSécuriéSocial = '{numeroDeSecuriteSociale}'"

        try:
            result = self.connector.execute_query(query)
            if result:
                return textPrinter.print_reservation_list(result)
            else:
                return textPrinter.log_message("Vous n'avez pas de rendez-vous")
        except Exception as e:
            print(f"Erreur lors de l'exécution de la requête : {e}")
            print(traceback.format_exc())  # Imprimez la trace complète de l'exception
            return textPrinter.log_message("Une erreur s'est produite lors de la récupération des rendez-vous")
