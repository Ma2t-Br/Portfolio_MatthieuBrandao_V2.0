def open_session_message():
    print("::" * 50)
    print("\tBienvenue sur &coute!")
    print("\n\tInstructions :\n\t\tVous retrouvez ici un outil de gestion de rendez-vous pour le cabinet &coute.\n\t\tCette console affichera les informations dont vous aurez besoin\n\t\tUn menu de fonctionnalités s'affiche aussi en même temps que cette fenêtre pour vous connecter et accéder aux informations")
    print("::" * 50)


def print_title(title):
    print("\n\n" + "-"*50)
    print(" "*10 + title)
    print("-"*50)


def log_message(message):
    print("LOG -- " + message)
    return message

def print_patient(patient):
    # create a string to print the patient
    patient_string = "ID: " + str(patient[0]) + "\n"
    patient_string += "Nom: " + patient[1] + "\n"
    patient_string += "Prénom: " + patient[2] + "\n"
    patient_string += "Email: " + patient[3] + "\n"
    patient_string += "Date de naissance: " + str(patient[4]) + "\n"
    patient_string += "Adresse: " + patient[5] + "\n"
    patient_string += "Date de création: " + str(patient[6]) + "\n"
    patient_string += "Référence: " + patient[7] + "\n"
    patient_string += "Type: " + patient[8] + "\n"
    print(patient_string)
    return patient_string

def print_reservation(reservation):
    # create a string to print the reservation
    reservation_string = "ID: " + str(reservation[0]) + "\n"
    reservation_string += "Numéro de sécurité sociale: " + reservation[1] + "\n"
    reservation_string += "ID psychologue: " + str(reservation[2]) + "\n"
    reservation_string += "Date: " + str(reservation[3]) + "\n"
    reservation_string += "Durée: " + str(reservation[4]) + "\n"
    reservation_string += "Motif: " + reservation[5] + "\n"
    reservation_string += "Date de création: " + str(reservation[6]) + "\n"
    print(reservation_string)
    return reservation_string

def print_reservation_list(reservation_list):
    for reservation in reservation_list:
        print_reservation(reservation)
        print("-"*50)
    return reservation_list