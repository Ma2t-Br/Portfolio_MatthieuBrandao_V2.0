CREATE TABLE Patient(
   NuméroDeSécuriéSocial INT,
   Prénom VARCHAR(50) NOT NULL,
   Nom VARCHAR(50) NOT NULL,
   Email VARCHAR(100) NOT NULL,
   DatePremiereConsultation DATE,
   Adresse VARCHAR(50) NOT NULL,
   DateDeNaissance DATE NOT NULL,
   Source VARCHAR(50) NOT NULL,
   Classification VARCHAR(50) NOT NULL,
   PRIMARY KEY(NuméroDeSécuriéSocial)
);

CREATE TABLE Profession(
   DateProfession DATE,
   NomProfession VARCHAR(50) NOT NULL,
   PRIMARY KEY(DateProfession)
);

CREATE TABLE Agenda(
   DataHeure DATETIME,
   PRIMARY KEY(DataHeure)
);

CREATE TABLE ProfessionActuelle(
   NuméroDeSécuriéSocial INT,
   DateProfession DATE,
   PRIMARY KEY(NuméroDeSécuriéSocial, DateProfession),
   FOREIGN KEY(NuméroDeSécuriéSocial) REFERENCES Patient(NuméroDeSécuriéSocial),
   FOREIGN KEY(DateProfession) REFERENCES Profession(DateProfession)
);

CREATE TABLE Réservation(
   NuméroDeSécuriéSocial INT,
   DataHeure DATETIME,
   Durée INT NOT NULL,
   Prix DECIMAL(10,2) NOT NULL,
   ModedeReglement VARCHAR(50) NOT NULL,
   IndicateurAnxiété SMALLINT,
   DateCreationRDV DATE NOT NULL,
   Retard BOOLEAN NOT NULL,
   PRIMARY KEY(NuméroDeSécuriéSocial, DataHeure),
   FOREIGN KEY(NuméroDeSécuriéSocial) REFERENCES Patient(NuméroDeSécuriéSocial),
   FOREIGN KEY(DataHeure) REFERENCES Agenda(DataHeure)
);

CREATE TABLE User(
   NuméroDeSécuriéSocial INT NOT NULL,
   UserPassword VARCHAR(50) NOT NULL,
   Psychologue BOOLEAN NOT NULL,
   PRIMARY KEY(NuméroDeSécuriéSocial)
);