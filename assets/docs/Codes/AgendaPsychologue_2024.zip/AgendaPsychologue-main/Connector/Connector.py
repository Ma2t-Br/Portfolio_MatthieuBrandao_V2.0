import mysql.connector
import configparser
import os

class MySQLConnector:
    # Lire le fichier de configuration
    config = configparser.ConfigParser()
    config.read(os.path.join(os.path.dirname(__file__), '..', 'Settings', 'databaseConnection.properties'))

    def __init__(self):
        self.host = self.config.get('database', 'host')
        self.user = self.config.get('database', 'user')
        self.password = self.config.get('database', 'password')
        self.database = self.config.get('database', 'name')
        self.port = self.config.get('database', 'port')
        self.conn = None
        self.cursor = None

    def connect(self):
        # Paramètres de connexion à la base de données
        config = {
            'host': self.host,
            'user': self.user,
            'password': self.password,
            'database': self.database,
            'port': self.port  # Utilisation du port spécifié dans le fichier de configuration
        }

        # Créer une connexion à la base de données
        self.conn = mysql.connector.connect(**config)
        self.cursor = self.conn.cursor()

    def close(self):
        # Fermer le curseur et la connexion
        if self.cursor:
            self.cursor.close()
        if self.conn:
            self.conn.close()

    def execute_query(self, query):
        # Exécuter une requête SQL
        if not self.cursor:
            raise Exception("La connexion n'a pas été établie. Veuillez appeler la méthode connect() d'abord.")
        self.cursor.execute(query)
        return self.cursor.fetchall()
