class Profession:
    def __init__(self, nom_profession, date_profession):
        self.nom_profession = nom_profession
        self.date_profession = date_profession

    def getDateProfession(self):
        return self.date_profession

    def getNomProfession(self):
        return self.nom_profession

    def setNomProfession(self, nom_professsion):
        self.nom_profession = nom_professsion

    def setDateProfession(self, date_profession):
        self.date_profession = date_profession
