
class Reservation:
    def __init__(self, patient_numero_de_securite_social, date, duree, prix, mode_de_paiement, indicateur_anxiete, date_creation_rdv,
                 retard, agenda):
        self.patient_numero_de_securite_social = patient_numero_de_securite_social
        self.date = date
        self.duree = duree
        self.prix = prix
        self.mode_de_paiement = mode_de_paiement
        self.indicateur_anxiete = indicateur_anxiete
        self.date_creation_rdv = date_creation_rdv
        self.retard = retard
        self.agenda = agenda

    def get_reservations_by_date(self, current_date):

        return [reservation for reservation in self.agenda.reservations if reservation.date >= current_date]

