
class Patient:

    def __init__(self, prenom, nom, email, adresse, dateDeNaissance, source,
                 numeroDeSecuriteSociale, classification, dateDernierConsultation=None):
        self.prenom = prenom
        self.nom = nom
        self.email = email
        self.dateDernierConsultation = dateDernierConsultation
        self.adresse = adresse
        self.dateDeNaissance = dateDeNaissance
        self.source = source
        self.numeroDeSecuriteSociale = numeroDeSecuriteSociale
        self.classification = classification




