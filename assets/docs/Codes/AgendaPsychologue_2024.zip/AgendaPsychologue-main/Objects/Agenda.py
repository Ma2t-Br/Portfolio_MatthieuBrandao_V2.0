class Agenda:
    def __init__(self):
        self.reservations = []

    def add_reservation(self, reservation):
        # Check for overlapping reservations
        for existing_reservation in self.reservations:
            if (existing_reservation.start_time < reservation.end_time and
                    existing_reservation.end_time > reservation.start_time):
                raise ValueError('reservation times overlap.')
        self.reservations.append(reservation)

    def cancel_reservation(self, reservation):
        try:
            self.reservations.remove(reservation)
        except ValueError:
            raise ValueError('reservation not found.')

    def list_reservations(self, date=None):
        if date:
            # List reservations for a specific date
            return [reservation for reservation in self.reservations if reservation.start_time.date() == date]
        else:
            # List all reservations
            return list(self.reservations)




