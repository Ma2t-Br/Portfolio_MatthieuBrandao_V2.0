import tkinter as tk

from Connector.Connector import MySQLConnector
from Interface import user_menu
from Interface import psychologue_menu
from Utilities import textPrinter
from Utilities.patient_actions import PatientActions
from Utilities.psychologue_actions import PsychologueActions

global background_color
background_color = "lightgrey"

def connection_interface(psychologue_actions: PsychologueActions, patient_actions: PatientActions):
    textPrinter.print_title("Connection à votre compte")

    def on_button_click_connect():
        numero_secu_sociale, password = numero_secu_input.get(), password_input.get()
        TypeofUser = psychologue_actions.is_in_database(numeroDeSecuriteSociale=numero_secu_sociale, password=password)
        if TypeofUser == 0:
            print("Patient")
            root.destroy()
            user_menu.user_menu_interface(numero_secu_sociale)
        elif TypeofUser == 1:
            print("Psychologue")
            root.destroy()
            psychologue_menu.psychologue_menu_interface(psychologue_actions, patient_actions, numero_secu_sociale)
        else:
            print("Erreur de connexion")
            # TODO: Afficher un message d'erreur

    def on_button_click_request_account():
        print("Request an account")

    def on_button_click_reset_password():
        print("Reset password")

    root = tk.Tk()
    root.title("&coute")
    root.geometry("200x300")
    root.configure(bg=background_color)

    # Labels
    label = tk.Label(root, text="&coute", font=("Helvetica", 16), bg=background_color)
    identifier = tk.Label(root, text="Numero de sécurité sociale")
    password = tk.Label(root, text="Mot de passe")

    # Buttons
    button_width = 20  # Définir la largeur des boutons ici

    numero_secu_input = tk.Entry(root, justify="center")
    password_input = tk.Entry(root, show="*", justify="center")
    connect_button = tk.Button(root, text="Se connecter", command=on_button_click_connect, width=button_width)
    request_account_button = tk.Button(root, text="Demander un compte", command=on_button_click_request_account, width=button_width)
    close_button = tk.Button(root, text="Fermer", command=root.destroy, bg="red", width=button_width)
    forgot_password_button = tk.Button(root, text="Mot de passe oublié", command=on_button_click_reset_password, width=button_width)

    # Disposition
    label.pack(pady=(0, 50))
    identifier.pack()
    numero_secu_input.pack()
    password.pack()
    password_input.pack()
    connect_button.pack(pady=(20, 0))
    request_account_button.pack()
    forgot_password_button.pack()
    close_button.pack()

    root.mainloop()
