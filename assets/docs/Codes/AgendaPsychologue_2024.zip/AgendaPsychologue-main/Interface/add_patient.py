import tkinter as tk
from tkinter import Text

from tkcalendar import DateEntry

from Objects.Patient import Patient
from Utilities import textPrinter
from Utilities.psychologue_actions import PsychologueActions

global background_color
background_color = "lightgrey"


def add_patient_interface(psychologue_actions: PsychologueActions):
    textPrinter.print_title("Ajout d'un patient")

    def on_button_click_add_patient():
        patient = Patient(prenom=surname_input.get(), nom=name_input.get(), email=email_input.get(),
                          dateDeNaissance=birth_input.get(), adresse=address_input.get(), source=source_input.get(),
                          classification=classification_input.get(), numeroDeSecuriteSociale=identifier_input.get())

        if psychologue_actions.is_in_database_add(patient):
            textPrinter.log_message("Patient déjà existant")
            message_text.config(state=tk.NORMAL)
            message_text.insert(tk.END, "Patient déjà existant\n")
            message_text.config(state=tk.DISABLED)
        else:
            psychologue_actions.add_patient(patient)
            textPrinter.log_message("Patient ajouté")
            message_text.config(state=tk.NORMAL)
            message_text.insert(tk.END, "Patient ajouté avec succès!\n")
            message_text.config(state=tk.DISABLED)

    root = tk.Tk()
    root.title("&coute")  # Titre corrigé
    root.geometry("400x500")  # Ajustement de la taille
    root.configure(bg=background_color)

    # Labels
    label = tk.Label(root, text="Ajout d'un patient", font=("Helvetica", 16), bg=background_color)
    identifier = tk.Label(root, text="Numéro de sécurité sociale")
    surname = tk.Label(root, text="Prénom")
    name = tk.Label(root, text="Nom")
    email = tk.Label(root, text="Email")
    address = tk.Label(root, text="Adresse")
    birth = tk.Label(root, text="Date de naissance")
    source = tk.Label(root, text="Source")
    classification = tk.Label(root, text="Classification")

    # Entrées
    identifier_input = tk.Entry(root, justify="center")
    name_input = tk.Entry(root, justify="center")
    surname_input = tk.Entry(root, justify="center")
    email_input = tk.Entry(root, justify="center")
    address_input = tk.Entry(root, justify="center")
    source_input = tk.Entry(root, justify="center")
    classification_input = tk.Entry(root, justify="center")

    # Calendrier pour la date de naissance
    birth_input = DateEntry(root, justify="center", date_pattern='yyyy-mm-dd')

    # Boutons
    add_patient_button = tk.Button(root, text="Ajouter le patient", command=on_button_click_add_patient)
    close_button = tk.Button(root, text="Fermer", command=root.destroy, bg="red")

    # Texte pour afficher un message
    message_text = Text(root, height=2, width=30, state=tk.DISABLED)

    # Disposition
    label.grid(row=0, column=0, columnspan=2, pady=(0, 20))
    identifier.grid(row=1, column=0, sticky="w")
    identifier_input.grid(row=1, column=1)
    name.grid(row=2, column=0, sticky="w")
    name_input.grid(row=2, column=1)
    surname.grid(row=3, column=0, sticky="w")
    surname_input.grid(row=3, column=1)
    birth.grid(row=4, column=0, sticky="w")
    birth_input.grid(row=4, column=1)
    email.grid(row=5, column=0, sticky="w")
    email_input.grid(row=5, column=1)
    address.grid(row=6, column=0, sticky="w")
    address_input.grid(row=6, column=1)
    source.grid(row=7, column=0, sticky="w")
    source_input.grid(row=7, column=1)
    classification.grid(row=8, column=0, sticky="w")
    classification_input.grid(row=8, column=1)
    add_patient_button.grid(row=9, column=0, columnspan=2, pady=(20, 0))
    message_text.grid(row=10, column=0, columnspan=2)
    close_button.grid(row=11, column=0, columnspan=2)

    root.mainloop()
