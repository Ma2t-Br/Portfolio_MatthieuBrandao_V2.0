import tkinter as tk
from Utilities import textPrinter, patient_actions, psychologue_actions
from Interface import new_appointment, add_patient
from Utilities.patient_actions import PatientActions
from Utilities.psychologue_actions import PsychologueActions

global background_color
background_color = "light blue"


def psychologue_menu_interface(psychologue_actions: PsychologueActions, patient_actions: PatientActions, numero_secu_sociale):

    textPrinter.print_title("Accès au menu principal")

    def on_button_click_view_account_offpatient():
        textPrinter.print_title("Visualisation du compte du patient")
        patient_actions.view_patient_account(numero_secu_sociale)

    def on_button_click_addpatient():
        textPrinter.print_title("Ajout d'un patient")
        add_patient.add_patient_interface(psychologue_actions)

    def on_button_click_view_appointments():
        textPrinter.print_title("Visualisation des rendez-vous")
        psychologue_actions.view_all_appointments()

    def on_button_click_add_appointments():
        new_appointment.new_appointment_interface(id)

    root = tk.Tk()
    root.title("&coute")
    root.geometry("200x300")
    root.configure(bg=background_color)

    # Labels
    label = tk.Label(root, text="Interface Psychologue", font=("Helvetica", 16), bg=background_color, height=5)

    # Buttons
    button_width = 20  # Largeur des boutons
    view_add_patient_button = tk.Button(root, text="Ajouter un patient", command=on_button_click_addpatient, width=button_width)
    view_account_button = tk.Button(root, text="Voir mes informations", command=on_button_click_view_account_offpatient, width=button_width)
    view_appointments_button = tk.Button(root, text="Voir mes rendez-vous", command=on_button_click_view_appointments, width=button_width)
    request_appointments_button = tk.Button(root, text="Demander un rendez-vous", command=on_button_click_add_appointments, width=button_width)
    close_button = tk.Button(root, text="Fermer", command=root.destroy, bg="red", width=button_width)

    # Disposition
    label.pack()
    view_add_patient_button.pack()
    view_account_button.pack()
    view_appointments_button.pack()
    request_appointments_button.pack()
    close_button.pack()

    root.mainloop()
