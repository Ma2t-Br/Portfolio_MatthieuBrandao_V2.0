import tkinter as tk
from Utilities import textPrinter, patient_actions
from Interface import new_appointment

global background_color
background_color = "light blue"

def user_menu_interface(id):
    textPrinter.print_title("Accès au menu principal")

    def on_button_click_view_info():
        toggle_info_display()

    def toggle_info_display():
        global info_displayed

        if info_displayed:
            info_label.config(text="")
            info_displayed = False
        else:
            infos = patient.view_patient_account(id)
            info_label.config(text=infos)
            info_displayed = True

    def on_button_click_view_appointments():
        toggle_appointments_display()

    def toggle_appointments_display():
        global appointments_displayed

        if appointments_displayed:
            appointments_label.config(text="")
            appointments_displayed = False
        else:
            appointments = patient.view_patient_appointments(id)
            appointments_label.config(text=appointments)
            appointments_displayed = True

    def on_button_click_request_appointments():
        new_appointment.new_appointment_interface(id)
        # renvoie un mail au psychologue pour lui demander un rendez-vous

    root = tk.Tk()
    root.title("&coute")
    root.geometry("200x300")
    root.configure(bg=background_color)

    # Labels
    label = tk.Label(root, text="Interface Patient", font=("Helvetica", 16), bg=background_color, height=5)

    # Buttons
    button_width = 20  # Définir la largeur des boutons ici
    button_bg = "light blue"  # Définir la couleur de fond des boutons ici
    button_highlight_color = "light blue"  # Couleur de surbrillance pour correspondre à la couleur de fond
    view_account_button = tk.Button(root, text="Voir mes informations", command=on_button_click_view_info,
                                    width=button_width, bg=button_bg, highlightthickness=0)
    info_label = tk.Label(root, text="", bg=background_color)
    view_appointments_button = tk.Button(root, text="Voir mes rendez-vous", command=on_button_click_view_appointments,
                                         width=button_width, bg=button_bg, highlightthickness=0)
    appointments_label = tk.Label(root, text="", bg=background_color)
    request_appointments_button = tk.Button(root, text="Demander un rendez-vous",
                                            command=on_button_click_request_appointments, width=button_width,
                                            bg=button_bg, highlightthickness=0)
    close_button = tk.Button(root, text="Fermer", command=root.destroy, bg="red", width=button_width,
                             highlightthickness=0)

    # Disposition
    label.pack()
    view_account_button.pack()
    info_label.pack()
    view_appointments_button.pack()
    appointments_label.pack()
    request_appointments_button.pack()
    close_button.pack()

    root.mainloop()

info_displayed = False
appointments_displayed = False
