import tkinter as tk
from Utilities import textPrinter
from tkcalendar import DateEntry

global background_color
background_color = "light blue"

def new_appointment_interface(id):
    textPrinter.print_title("Prise de rendez-vous")

    def on_button_click_request_appointments():
        print("Demander un rendez-vous")

    root = tk.Tk()
    root.title("&coute")
    root.geometry("500x500")
    root.configure(bg=background_color)

    # Labels
    label = tk.Label(root, text="&coute", font=("Helvetica", 16), bg=background_color, height=5)
    dateTime = tk.Label(root, text="Quand ?")
    nbHours = tk.Label(root, text="Combien de temps ?")

    # Buttons
    button_width = 20  # Définir la largeur des boutons ici
    forUser_input = tk.Checkbutton(root, text="Je prends ce rendez-vous pour moi")
    date_input = DateEntry(root, date_pattern="dd/mm/yyyy")
    choices = ["1", "2", "3"]
    selected_choice = tk.StringVar(root)
    selected_choice.set(choices[0])
    option_menu = tk.OptionMenu(root, selected_choice, *choices)
    request_button = tk.Button(root, text="Demander un rendez-vous", command=on_button_click_request_appointments, width=button_width)
    close_button = tk.Button(root, text="Annuler", command=root.destroy, bg="red", width=button_width)

    # Disposition
    label.pack(pady=(0,50))
    forUser_input.pack()
    dateTime.pack()
    date_input.pack()
    nbHours.pack()
    option_menu.pack()
    request_button.pack(pady=(0,50))
    close_button.pack()

    root.mainloop()
