import tkinter as tk
import random
from Utilities import initialization, textPrinter

def setting_interface():
    def on_button_click_pull_from_dataBase():
        textPrinter.print_title("Pull from dataBase")

        init_return = {}
        init_return["Patients"], init_return["Réservations"], init_return["Agendas"], init_return["Professions"] = initialization.init_dataBase()
        for data in init_return:
            print(data, ":", len(init_return[data]))

    # For fun
    def on_mouse_enter(event):
        x, y = root.winfo_pointerxy()
        close_button.place(y=random.randint(0, 100), x=80)

    root = tk.Tk()
    root.title("Settings")
    root.geometry("200x300")
    root.configure(bg="light grey")
    root.positionfrom()

    # Labels
    label = tk.Label(root, text="Paramètres")

    # Buttons
    button_width = 20  # Définir la largeur des boutons ici

    init_button = tk.Button(root, text="Pull from dataBase", command=on_button_click_pull_from_dataBase, width=button_width)
    close_button = tk.Button(root, text="Close", command=root.destroy, bg="red", width=button_width)
    close_button.bind("<Enter>", on_mouse_enter)  # for fun

    # Disposition
    label.pack()
    init_button.pack()
    close_button.pack()

    root.mainloop()
