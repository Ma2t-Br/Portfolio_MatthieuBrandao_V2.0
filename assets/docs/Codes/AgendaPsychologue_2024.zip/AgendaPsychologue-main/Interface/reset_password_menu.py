import tkinter as tk
from Interface import user_menu
<<<<<<< HEAD
from Utilities import textPrinter, authentication, reset_password
=======
from Utilities import textPrinter, authentication_class
>>>>>>> 903d72807df37f5fbca9d36f7ed54f6bd37b416a

global background_color
background_color = "white"

def resetpassword_interface():
    textPrinter.print_title("Réinitilisation votre mot de passe")
    def on_button_click_send_a_reset(identity):
        id = identity.get()
        userEmail = reset_password.is_in_database(id)


    root = tk.Tk()
    root.title("&coute")
    root.geometry("200x300")
    root.configure(bg=background_color)

    # Labels
    label = tk.Label(root, text="&coute", font=("Helvetica", 16), bg=background_color)
    identifier = tk.Label(root, text="Numero de sécurité sociale")
    password = tk.Label(root, text="Mot de passe")

    # Buttons
    identifier_input = tk.Entry(root, justify="center")
    password_input = tk.Entry(root, show="*", justify="center")
    connect_button = tk.Button(root, text="Se connecter", command=on_button_click_connect)
    request_account_button = tk.Button(root, text="Demander un compte", command=on_button_click_request_account)
    close_button = tk.Button(root, text="Fermer", command=root.destroy, bg="red")
    forgot_password_button = tk.Button(root, text="Mot de passe oublié", command=on_button_click_reset_password)

    # Disposition
    label.pack(pady=(0,50))
    identifier.pack()
    identifier_input.pack()
    password.pack()
    password_input.pack()
    connect_button.pack(pady=(20,0))
    request_account_button.pack()
    forgot_password_button.pack()
    close_button.pack()

    root.mainloop()
