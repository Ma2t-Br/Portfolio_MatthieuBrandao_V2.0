import tkinter as tk

from Interface import settings
from Interface.connection_interface import connection_interface
from Utilities.patient_actions import PatientActions
from Utilities.psychologue_actions import PsychologueActions

global background_color
background_color = "light blue"

def start_interface(mysql_connector):
    psychologue_actions = PsychologueActions(mysql_connector)
    patient_actions = PatientActions(mysql_connector)

    def on_button_click_settings():
        settings.setting_interface()

    def on_button_click_connect():
        root.destroy()

        connection_interface(psychologue_actions, patient_actions)

    root = tk.Tk()

    label = tk.Label(root, text="&coute", font=("Helvetica", 16), bg=background_color, height=5)
    label.pack()

    root.title("&coute")
    root.geometry("200x300")
    root.configure(bg=background_color)

    button_width = 20

    init_button_connect = tk.Button(root, text="Se connecter", command=on_button_click_connect, width=button_width)
    init_button_connect.pack()

    # init_button_settings = tk.Button(root, text="Paramètres", command=on_button_click_settings, width=button_width)
    # init_button_settings.pack()

    close_button = tk.Button(root, text="Fermer", command=root.destroy, bg="red", width=button_width)
    close_button.pack()

    root.mainloop()
