from Connector.Connector import MySQLConnector
from Interface import start
from Utilities import textPrinter

def main():
    mysql_connector = MySQLConnector()
    mysql_connector.connect()

    textPrinter.open_session_message()
    start.start_interface(mysql_connector)
    mysql_connector.close()


if __name__ == "__main__":
    main()