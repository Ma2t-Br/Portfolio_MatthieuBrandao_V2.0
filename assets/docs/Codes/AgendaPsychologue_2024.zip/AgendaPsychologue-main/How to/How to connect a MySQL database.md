# Connecteur Python à une base de données MySQL en local

Pour créer un connecteur Python à une base de données MySQL en local, vous pouvez utiliser la bibliothèque `mysql-connector-python`. Voici les étapes à suivre :

## 1. Installation de mysql-connector-python

Assurez-vous d'installer la bibliothèque `mysql-connector-python` en exécutant la commande suivante :

```bash
pip install mysql-connector-python
```

## 2. Importation du connecteur

Importez le connecteur dans votre script Python :

```python
import mysql.connector
```

## 3. Connexion à la base de données

Créez une connexion à votre base de données en spécifiant les paramètres de connexion :

```python
# Paramètres de connexion à la base de données
config = {
    'host': 'localhost',
    'user': 'votre_utilisateur',
    'password': 'votre_mot_de_passe',
    'database': 'votre_base_de_donnees'
}

# Créer une connexion à la base de données
conn = mysql.connector.connect(**config)
```

4. Création d'un curseur

Créez un curseur pour exécuter des requêtes SQL :

```python
cursor = conn.cursor()
```

## 5. Exécution de requêtes SQL

Vous pouvez maintenant exécuter des requêtes SQL à l'aide du curseur. Par exemple, pour sélectionner des données :

```python
cursor.execute("SELECT * FROM votre_table")
rows = cursor.fetchall()

for row in rows:
    print(row)
```

## 6. Fermeture de la connexion

N'oubliez pas de fermer la connexion une fois que vous avez terminé d'utiliser la base de données :

```python
cursor.close()
conn.close()
```
Assurez-vous que votre serveur MySQL est en cours d'exécution localement et que vous avez les autorisations nécessaires pour vous connecter à la base de données avec les informations fournies.