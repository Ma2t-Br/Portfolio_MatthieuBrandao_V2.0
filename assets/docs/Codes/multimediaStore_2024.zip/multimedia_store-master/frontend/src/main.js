import { createApp } from 'vue';
import { createRouter, createWebHistory } from 'vue-router';
import App from './App.vue';

import LoginComponent from '@/components/LoginComponent.vue';
import ProfileComponent from "@/components/ProfileComponent.vue";
import HomeComponent from "@/components/HomeComponent.vue";
import ProductsByCategory from "@/components/ProductsByCategory.vue";
import ProductComponent from "@/components/ProductComponent.vue";
import ManageUsersComponent from "@/components/ManageUsersComponent.vue";
import ManageProductsComponent from "@/components/ManageProductsComponent.vue";
import CreateProductComponent from "@/components/CreateProductComponent.vue";
import SellProductComponent from "@/components/SellProductComponent.vue";
import CustomerOrdersComponent from "@/components/CustomerOrdersComponent.vue";
import CreateAccountComponent from "@/components/CreateAccountComponent.vue";
import SellOrdersComponent from "@/components/SellOrdersComponent.vue";
import { library } from '@fortawesome/fontawesome-svg-core';
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome';
import "./assets/style/reset.css"
import { faCamera, faHome, faSignInAlt, faSignOutAlt, faUsers, faCogs, faUser, faShoppingCart,faThumbsUp, faThumbsDown } from '@fortawesome/free-solid-svg-icons';
import ContactUsComponent from "@/components/ContactUsComponent.vue";
library.add(faCamera, faHome, faSignInAlt, faSignOutAlt, faUsers, faCogs, faUser, faShoppingCart,faThumbsUp, faThumbsDown);

const routes = [
    { path: '/', component: HomeComponent, name: "home"},
    { path: '/login', component: LoginComponent, name: "login"},
    { path: '/category/:category', component: ProductsByCategory, name: "products-by-category"},
    { path: '/products/:productReference', component: ProductComponent, name: "product"},
    { path: '/manage-users', component: ManageUsersComponent, name: "manage-users"},
    { path: '/manage-products', component: ManageProductsComponent, name: "manage-products"},
    { path: '/create-account', component: CreateAccountComponent, name: "create-account"},
    { path: '/create-product', component: CreateProductComponent, name: "create-product"},
    { path: '/profile', component: ProfileComponent, name: "profile"},
    { path: '/sell-product', component: SellProductComponent, name: "sell-product"},
    { path: '/my-orders', component: CustomerOrdersComponent, name: "my-orders"},
    { path: '/my-sells', component: SellOrdersComponent, name: "my-sells"},
    { path: '/contact-us', component: ContactUsComponent, name: "contact-us"}
];

const router = createRouter({
    history: createWebHistory(),
    routes,
});

const app = createApp(App);
app.use(router);
app.component('font-awesome-icon', FontAwesomeIcon);
app.mount('#app');


