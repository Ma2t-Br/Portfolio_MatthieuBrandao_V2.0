<template>
  <div id="app">
    <HeaderComponent />
    <NavbarComponent />
    <router-view />
    <FooterComponent />
  </div>
</template>

<script>
import HeaderComponent from './components/HeaderComponent.vue';
import NavbarComponent from './components/NavbarComponent.vue';
import FooterComponent from './components/FooterComponent.vue';

export default {
  name: 'App',
  components: {
    HeaderComponent,
    NavbarComponent,
    FooterComponent,
  },
  methods: {
    getIsAdminFromCookies() {
      const cookieString = document.cookie;
      const cookies = cookieString.split(';');
      for (let cookie of cookies) {
        const [name, value] = cookie.trim().split('=');
        if (name === 'client_role') {
          return value === 'ADMIN';
        }
      }
      return false;
    },
    getIsLoggedInFromCookies() {
      const cookieString = document.cookie;
      const cookies = cookieString.split(';');
      for (let cookie of cookies) {
        const name = cookie.trim().split('=')[0];
        if (name === 'client_email') {
          return true;
        }
      }
      return false;
    },
    getCustomerEmailFromCookies() {
      const cookieString = document.cookie;
      const cookies = cookieString.split(';');
      for (let cookie of cookies) {
        const [name, value] = cookie.trim().split('=');
        if (name === 'client_email') {
          return value;
        }
      }
      return '';
    },
   },
};
</script>

<style>
#app {
  font-family: Arial, sans-serif;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

th {
  background-color: #f2f2f2;
}
</style>
