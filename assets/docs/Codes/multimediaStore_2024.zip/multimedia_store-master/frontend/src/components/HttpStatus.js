const HttpStatus = {
    NOT_FOUND: 404,
    FORBIDDEN: 403,
    FOUND: 302,
    OK: 200,
    CREATED: 201,
    INTERNAL_SERVER_ERROR: 500,
};

export default HttpStatus;
