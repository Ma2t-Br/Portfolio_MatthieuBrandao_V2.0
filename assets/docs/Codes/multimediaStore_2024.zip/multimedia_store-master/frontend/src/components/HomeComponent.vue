<script>
import MessageComponent from "@/components/MessageComponent.vue";
import { BASE_URL } from "@/components/ApiConfig";

export default {
  components: { MessageComponent },
  data() {
    return {
      categories: [],
      errorMessage: '',
      successMessage: ''
    };
  },
  created() {
    this.fetchCategories();
  },
  methods: {
    async fetchCategories() {
      try {
        const response = await fetch(`${BASE_URL}/products/allCategories`);
        this.categories = await response.json();
      } catch (error) {
        this.errorMessage = error.message;
        this.successMessage = '';
      }
    },
    goToCategory(category) {
      this.$router.push({ name: 'products-by-category', params: { category: category } });
    },
    getRandomCategoryImage(categoryName) {
      return `https://source.unsplash.com/random/200x150/?${categoryName}`;
    }
  }
};
</script>

<template>
  <div>
    <h2>Categories</h2>
    <ul class="container" v-if="categories.length > 0">
      <li class="item" v-for="category in categories" :key="category" @click="goToCategory(category)">
        <img :src="getRandomCategoryImage(category)" alt="Image of the category">
        <div class="item-content">
        </div>
        <p>{{ category }}</p>
      </li>
    </ul>
    <p v-else>No categories available at the moment...</p>
    <message-component v-if="errorMessage" :message="errorMessage" :isError="true"/>
    <message-component v-if="successMessage" :message="successMessage" :isSuccess="true"/>
  </div>
</template>

<style scoped>
div {
  width: 100%;
  min-height: 50vh;
  display: block;
}

.container {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 10px;
  padding: 30px;
}

.item {
  position: relative;
  background-color: #f9f9f9;
  border: 1px solid #ddd;
  overflow: hidden;
  height: auto;
}

.item img {
  width: 100%;
  height: auto;
  object-fit: cover;
}

.item-content {
  position: absolute;
  bottom: 0;
  width: 100%;
  background: rgba(0, 0, 0, 0.5);
  color: white;
  padding: 10px;
  text-align: center;
  z-index: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
}

.item p {
  margin: 0;
}

.item:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0,0,0,0.3);
}

@media (max-width: 600px) {
  .container {
    grid-template-columns: 1fr;
  }
}

</style>



