<script>
import MessageComponent from "@/components/MessageComponent.vue";
import HttpStatus from "@/components/HttpStatus";
import { BASE_URL } from "@/components/ApiConfig";

export default {
  components: { MessageComponent },
  data() {
    return {
      sellOrders: [],
      customerEmail: '',
      errorMessage: '',
    };
  },
  created() {
    this.customerEmail = this.$root.getCustomerEmailFromCookies();
    this.fetchSellOrders();
  },
  methods: {
    async fetchSellOrders() {
      try {
        const response = await fetch(`${BASE_URL}/sell-orders/customer/${this.customerEmail}`);
        if (response.status === HttpStatus.OK) {
          this.sellOrders = await response.json();
          this.errorMessage = "";
        } else {
          this.errorMessage = "Failed to fetch sell orders.";
        }
      } catch (error) {
        this.errorMessage = error.message;
      }
    },
  },
};
</script>

<template>
  <div>
    <h2>Sell Orders</h2>
    <table>
      <thead>
      <tr>
        <th>Company Name</th>
        <th>Product Name</th>
        <th>Quantity Sold</th>
        <th>Money Earned</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="order in sellOrders" :key="order.id">
        <td>{{ order.company.companyName }}</td>
        <td>{{ order.productName }}</td>
        <td>{{ order.soldQuantity }}</td>
        <td>{{ order.totalPrice }} $</td>
      </tr>
      </tbody>
    </table>
    <message-component v-if="errorMessage" :message="errorMessage" :isError="true" />
  </div>
</template>

<style scoped>

</style>
