<script>
import MessageComponent from "@/components/MessageComponent.vue";
import HttpStatus from "@/components/HttpStatus";
import {BASE_URL} from "@/components/ApiConfig";
import '../assets/style/manage.css';


export default {
  components: { MessageComponent },
  data() {
    return {
      products: [],
      successMessage: '',
      errorMessage: ''
    };
  },
  created() {
    this.fetchProducts();
  },
  methods: {
    async fetchProducts() {
      try {
        const response = await fetch(`${BASE_URL}/products/all`);
        const data = await response.json();
        this.products = data.map(product => ({
          productReference: product.productReference,
          company: product.company,
          categoryName: product.categoryName,
          productName: product.productName,
          stockQuantity: product.stockQuantity,
          price: product.price
        }));
      } catch (error) {
        console.error('Error fetching products:', error);
      }
    },
    async deleteProduct(productReference) {
      try {
        const response = await fetch(`${BASE_URL}/products/${productReference}`, { method: 'DELETE' });
        if (response.status === HttpStatus.NOT_FOUND || response.status === HttpStatus.FORBIDDEN) {
          this.errorMessage = await response.text();
          this.successMessage = '';
        } else if (response.ok) {
          this.products = this.products.filter(product => product.productReference !== productReference);
          this.successMessage = await response.text();
          this.errorMessage = '';
        }
      } catch (error) {
        console.error('Error deleting product:', error);
        this.errorMessage = 'Failed to delete product.';
      }
    },
    async addStockQuantity(productReference) {
      let quantityToAdd = prompt('Enter quantity to add:');
      if (!quantityToAdd || isNaN(quantityToAdd) || !Number.isInteger(parseFloat(quantityToAdd)) || parseFloat(quantityToAdd) <= 0) {
        alert('Please enter a valid integer greater than 0.');
        return;
      }
      quantityToAdd = parseInt(quantityToAdd);
      try {
        const response = await fetch(`${BASE_URL}/products/${productReference}/increase-stock-quantity?quantity=${quantityToAdd}`, { method: 'PATCH' });
        if (response.status === HttpStatus.NOT_FOUND) {
          this.errorMessage = await response.text();
          this.successMessage = '';
        } else if (response.status === HttpStatus.OK) {
          const index = this.products.findIndex(product => product.productReference === productReference);
          if (index !== -1) {
            this.products[index].stockQuantity += quantityToAdd;
          }
          this.successMessage = await response.text();
          this.errorMessage = '';
        }
      } catch (error) {
        console.error('Error adding stock quantity:', error);
        this.successMessage = '';
        this.errorMessage = 'Failed to update stock quantity.';
      }
    },
    async updatePrice(productReference) {
      let newPrice = prompt('Enter a new price:');
      if (!newPrice || isNaN(newPrice) || parseFloat(newPrice) <= 0) {
        alert('Please enter a valid price greater than 0.');
        return;
      }
      newPrice = parseFloat(newPrice).toFixed(2);
      try {
        const response = await fetch(`${BASE_URL}/products/${productReference}/update-price?price=${newPrice}`, { method: 'PATCH' });
        if (response.status === HttpStatus.NOT_FOUND) {
          this.errorMessage = await response.text();
          this.successMessage = '';
        } else if (response.status === HttpStatus.OK) {
          const index = this.products.findIndex(product => product.productReference === productReference);
          if (index !== -1) {
            this.products[index].price = newPrice;
          }
          this.successMessage = await response.text();
          this.errorMessage = '';
        }
      } catch (error) {
        console.error('Error updating price:', error);
        this.successMessage = '';
        this.errorMessage = 'Failed to update price.';
      }
    },
    redirectToCreateProduct() {
      this.$router.push({ name: 'create-product'});
    }
  }
};
</script>

<template>
  <div>
    <h2>Product Dashboard</h2>
    <table>
      <thead>
      <tr>
        <th>Product Reference</th>
        <th>Company</th>
        <th>Category</th>
        <th>Product Name</th>
        <th>Stock Quantity</th>
        <th>Price</th>
        <th>Actions</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="product in products" :key="product.productReference">
        <td>{{ product.productReference }}</td>
        <td>{{ product.company.companyName }}</td>
        <td>{{ product.categoryName }}</td>
        <td>{{ product.productName }}</td>
        <td>{{ product.stockQuantity }}</td>
        <td>{{ product.price }}</td>
        <td>
          <button @click="deleteProduct(product.productReference)">
            <font-awesome-icon icon="trash-alt" /> Delete
          </button>
          <button @click="addStockQuantity(product.productReference)">
            <!--TODO Doesn't work!-->
            <font-awesome-icon icon="plus" /> Add Stock
          </button>
          <button @click="updatePrice(product.productReference)">
            <!--TODO Doesn't work!-->
            <font-awesome-icon icon="pen" /> Update Price
          </button>
        </td>
      </tr>
      </tbody>
      <button @click="redirectToCreateProduct">
        <!--TODO Doesn't work!-->
        <font-awesome-icon icon="plus"/> Create A New Product
      </button>
    </table>
    <message-component v-if="successMessage" :message="successMessage" :isSuccess="true" />
    <message-component v-if="errorMessage" :message="errorMessage" :isError="true" />
  </div>
</template>


<style scoped>
button {
  margin-right: 10px;
  padding: 5px 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: white;
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #f0f0f0;
}

font-awesome-icon {
  margin-right: 5px;
}
</style>

