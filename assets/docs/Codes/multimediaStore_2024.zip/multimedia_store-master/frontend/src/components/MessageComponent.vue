<script>
export default {
  props: {
    message: String,
    isError: {
      type: Boolean,
      default: false
    },
    isSuccess: {
      type: Boolean,
      default: false
    }
  }
}
</script>

<template>
  <div v-if="message" :class="{ 'error': isError, 'success': isSuccess }">
    {{ message }}
  </div>
</template>

<style scoped>
.error {
  color: red;
}

.success {
  color: green;
}
</style>
