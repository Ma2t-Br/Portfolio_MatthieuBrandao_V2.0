<script>
export default {
  name: 'FooterComponent',
};
</script>

<template>
  <footer class="fixed-footer">
    <div>
      <h3>Information</h3>
      <ul>
        <li><a href="/">Home</a></li>
        <li><a href="/contact-us">Contact Us</a></li>
      </ul>
    </div>
    <div>
      <h3>About Us</h3>
      <p>MultimediaStore</p>
      <p>30-32 Av. de la République Villejuif 94800</p>
      <p>01 88 28 90 00</p>
      <p>multimediastore.efrei@outlook.fr</p>
    </div>
    <div>
      <h3>Follow Us</h3>
      <ul>
        <li><a href="https://www.facebook.com/EfreiParis/">Facebook</a></li>
        <li><a href="https://twitter.com/Efrei_Paris">Twitter (X)</a></li>
        <li><a href="https://www.instagram.com/efrei_paris/">Instagram</a></li>
      </ul>
    </div>
  </footer>
</template>

<style scoped>
.fixed-footer {
  bottom: 0;
  background-color: #333;
  color: #fff;
  padding: 20px;
  display: flex;
  justify-content: space-between;
}

.fixed-footer div {
  flex: 1;
  margin-right: 20px;
}

.fixed-footer h3 {
  font-size: 18px;
  margin-bottom: 10px;
}

.fixed-footer ul {
  list-style: none;
  padding: 0;
}

.fixed-footer ul li {
  margin-bottom: 5px;
}

.fixed-footer ul li a {
  color: #fff;
  text-decoration: none;
}

.fixed-footer form {
  display: flex;
  margin-top: 10px;
}

.fixed-footer input[type="email"] {
  width: 200px;
  padding: 5px;
}

.fixed-footer button {
  padding: 5px 10px;
  background-color: #fff;
  color: #333;
  border: none;
  cursor: pointer;
}
</style>
