<script>
import MessageComponent from "@/components/MessageComponent.vue";
import {BASE_URL} from "@/components/ApiConfig";

export default {
  components: {
    MessageComponent
  },
  data() {
    return {
      categoryName: '',
      products: [],
      successMessage: '',
      errorMessage: ''
    };
  },
  created() {
    this.categoryName = this.$route.params.category;
    this.fetchProductsByCategory();
  },
  methods: {
    async fetchProductsByCategory() {
      try {
        const response = await fetch(`${BASE_URL}/products/${this.categoryName}/all`);

        this.products = await response.json();
      } catch (error) {
        this.errorMessage = error.message;
      }
    },
    getRandomProductImage(productName) {
      return `https://source.unsplash.com/random/250x100/?${productName}`;
    },
    redirectToProduct(productReference) {
      this.$router.push({ name: 'product', params: { productReference: productReference } });
    }
  }
};

</script>

<template>
  <div class="category-container">
    <h2>{{ categoryName }}</h2>
    <div class="product-grid" v-if="products.length > 0">
      <div v-for="product in products" :key="product.productReference" class="product-card" @click="redirectToProduct(product.productReference)">
        <div class="product-info">
          <img :src="getRandomProductImage(product.productName)" alt="Image of the category">
          <h3>{{ product.productName }}</h3>
          <p>Stock Quantity: {{ product.stockQuantity }}</p>
          <p>Price: {{ product.price }} $</p>
        </div>
      </div>
    </div>
    <p v-else>No products available for this category.</p>
    <message-component v-if="errorMessage" :message="errorMessage" :isError="true" />
    <message-component v-if="successMessage" :message="successMessage" :isSuccess="true" />
  </div>
</template>

<style scoped>
.category-container {
  max-width: 1200px;
  margin: auto;
  padding: 20px;
}

.product-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 20px;
}

.product-card {
  background-size: cover;
  height: 300px;
  color: white;
  display: flex;
  align-items: flex-end;
  transition: transform 0.3s ease;
  background: rgba(0, 0, 0, 0.5) center;
  padding: 10px;
  border-radius: 10px;
}

.product-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0,0,0,0.3);
}

</style>
