<script>
import MessageComponent from "@/components/MessageComponent.vue";
import HttpStatus from "@/components/HttpStatus";
import { BASE_URL } from "@/components/ApiConfig";

export default {
  components: { MessageComponent },
  data() {
    return {
      customerOrders: [],
      customerEmail: '',
      errorMessage: '',
    };
  },
  created() {
    this.customerEmail = this.$root.getCustomerEmailFromCookies();
    this.fetchCustomerOrders();
  },
  methods: {
    async fetchCustomerOrders() {
      try {
        const response = await fetch(`${BASE_URL}/customer-orders/customer/${this.customerEmail}`);
        if (response.status === HttpStatus.OK) {
          this.customerOrders = await response.json();
          this.errorMessage = "";
        } else {
          this.errorMessage = "Failed to fetch customer orders.";
        }
      } catch (error) {
        this.errorMessage = error.message;
      }
    },
  },
};
</script>

<template>
  <div>
    <h2>Customer Orders</h2>
    <table>
      <thead>
      <tr>
        <th>Product Reference</th>
        <th>Product Name</th>
        <th>Company Name</th>
        <th>Ordered Quantity</th>
        <th>Order Status</th>
        <th>Total Payed</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="order in customerOrders" :key="order.id">
        <td>{{ order.product.productReference }}</td>
        <td>{{ order.product.productName }}</td>
        <td>{{ order.product.company.companyName }}</td>
        <td>{{ order.orderedQuantity }}</td>
        <td>{{ order.orderStatus }}</td>
        <td>{{ order.totalPayed}} $</td>
      </tr>
      </tbody>
    </table>
    <message-component v-if="errorMessage" :message="errorMessage" :isError="true" />
  </div>
</template>



<style scoped>

</style>
