const port = 5000;
const host = "http://localhost"
const project = "multimediastore"

export const BASE_URL = `${host}:${port}/${project}`;
