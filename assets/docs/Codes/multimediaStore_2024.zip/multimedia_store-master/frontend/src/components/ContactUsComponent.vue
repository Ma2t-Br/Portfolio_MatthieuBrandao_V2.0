<script>
import MessageComponent from "@/components/MessageComponent.vue";
import HttpStatus from "@/components/HttpStatus";
import {BASE_URL} from "@/components/ApiConfig";

export default {
  components: {MessageComponent},
  data() {
    return {
      customerEmail: '',
      subject: '',
      text: '',
      errorMessage: '',
      successMessage: '',
    };
  },
  created() {
    this.customerEmail = this.$root.getCustomerEmailFromCookies();
  },
  methods: {
    async contactWebMaster() {
      try {
        const response = await fetch(`${BASE_URL}/clients/${this.customerEmail}/contact_web_master`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            subject: this.subject,
            text: this.text
          })
        });

        if (response.status === HttpStatus.CREATED) {
          this.resetForm();
          this.successMessage = await response.text();
          this.errorMessage = '';
        } else {
          this.successMessage = '';
          this.errorMessage = 'Email could not have been sent..';
        }

      } catch (error) {
        this.successMessage = '';
        this.errorMessage = error.message;
      }
    },
    resetForm() {
      this.subject = '';
      this.text = '';
    },
  }
};
</script>

<template>
  <div>
    <h2>Contact Web Master</h2>
    <form @submit.prevent="contactWebMaster">
      <label for="email">Email:</label>
      <input type="email" id="email" v-model="customerEmail" required>
      <label for="subject">Subject:</label>
      <input type="text" id="subject" v-model="subject" required>
      <label for="content">Content:</label>
      <textarea id="content" v-model="text" rows="10" required></textarea>
      <message-component v-if="successMessage" :message="successMessage" :isSuccess="true" />
      <message-component v-if="errorMessage" :message="errorMessage" :isError="true" />
      <button type="submit">Send Email</button>
    </form>
  </div>
</template>

<style scoped>
form {
  display: flex;
  flex-direction: column;
  max-width: 500px;
  padding: 20px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  margin: 20px auto auto;
}

label {
  margin-bottom: 8px;
  font-weight: bold;
  color: #333;
}

input[type="email"], input[type="text"], input[type="password"], input[type="file"], textarea{
  margin-bottom: 15px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 16px;
  resize: none;
}

button {
  padding: 10px 20px;
  margin-top: 10px;
  border: none;
  border-radius: 5px;
  background-color: #007BFF;
  color: white;
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #0056b3;
}

button[type="button"] {
  background-color: #6c757d;
}

button[type="button"]:hover {
  background-color: #545b62;
}
</style>
