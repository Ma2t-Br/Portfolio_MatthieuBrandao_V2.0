<script>
import MessageComponent from "@/components/MessageComponent.vue";
import HttpStatus from "@/components/HttpStatus";
import {BASE_URL} from "@/components/ApiConfig";

export default {
  components: { MessageComponent },
  data() {
    return {
      email: this.$root.getCustomerEmailFromCookies(),
      lastName: '',
      firstName: '',
      address: '',
      wallet: 0,
      avatar: null,
      oldPassword: '',
      newPassword: '',
      errorMessage: '',
      successMessage: ''
    };
  },
  created() {
    this.fetchUserProfile();
  },
  methods: {
    async fetchUserProfile() {
      try {
        const customerResponse = await fetch(`${BASE_URL}/customers/${this.email}`);
        const customerData = await customerResponse.json();
        this.lastName = customerData.lastName;
        this.firstName = customerData.firstName;
        this.address = customerData.address;
        this.wallet = customerData.wallet;

        const avatarResponse = await fetch(`${BASE_URL}/avatars/${customerData.avatar}`);
        const avatarData = await avatarResponse.blob();
        this.avatar = URL.createObjectURL(avatarData);

      } catch (error) {
        this.successMessage = '';
        this.errorMessage = error.message;
        console.log(error, error.message);
      }
    },
    async updateProfile() {
      try {
        const response = await fetch(`${BASE_URL}/customers/${this.email}?lastName=${this.lastName}&firstName=${this.firstName}&address=${this.address}`, {
          method: 'PATCH'
        });
        if (response.status === HttpStatus.NOT_FOUND) {
          this.errorMessage = await response.text();
          this.successMessage = '';
        } else {
          this.successMessage = await response.text();
          this.errorMessage = '';
        }
      } catch (error) {
        this.errorMessage = error.message;
        this.successMessage = '';
      }
    },
    async updatePassword() {
      try {
        const response = await fetch(`${BASE_URL}/clients/${this.email}?oldPassword=${this.oldPassword}&newPassword=${this.newPassword}`, {
          method: 'PATCH'
        });
        if (response.status === HttpStatus.NOT_FOUND) {
          this.errorMessage = await response.text();
          this.successMessage = '';
        } else {
          this.successMessage = await response.text();
          this.errorMessage = '';
        }
      } catch (error) {
        this.errorMessage = error.message;
        this.successMessage = '';
      }
    },
    async updateAvatar() {
      try {
        const avatarInput = this.$refs.avatar;
        if (!avatarInput || !avatarInput.files || avatarInput.files.length === 0) {
          this.errorMessage = 'Please select an avatar image';
          return;
        }

        const avatarFile = avatarInput.files[0];

        const allowedTypes = ['image/png', 'image/jpeg', 'image/jpg'];
        if (!allowedTypes.includes(avatarFile.type)) {
          this.errorMessage = 'Please select a valid image file (PNG, JPEG, JPG)';
          return;
        }

        const formData = new FormData();
        formData.append('avatar', avatarFile);

        const uploadResponse = await fetch(`${BASE_URL}/avatars/upload-avatar`, {
          method: 'POST',
          body: formData,
        });

        if (uploadResponse.status === HttpStatus.OK) {
          this.successMessage = 'Avatar uploaded successfully';
          this.errorMessage = '';
          this.avatar = await uploadResponse.text();
        } else {
          console.log('Failed to upload avatar');
        }

        const response = await fetch(`${BASE_URL}/customers/${this.email}?avatar=${this.avatar}`, {
          method: 'PATCH'
        });
        if (response.status === HttpStatus.NOT_FOUND) {
          this.errorMessage = await response.text();
          this.successMessage = '';
        } else {
          this.successMessage = await response.text();
          this.errorMessage = '';
        }
        this.$refs.avatar.value = '';

      } catch (error) {
        this.errorMessage = error.message;
      }
    },
  }
};
</script>

<template>
  <div>
    <h2>Your Profile</h2>
    <div v-if="avatar">
      <img :src="avatar" alt="Avatar" style="max-width: 200px; max-height: 200px;"/>
    </div>
    <form @submit.prevent="updateAvatar">
      <label for="avatar">New Avatar:</label>
      <input type="file" id="avatar" ref="avatar" accept="image/png, image/jpeg, image/jpg" required>
      <button type="submit">Save Avatar</button>
    </form>
    <div>
      <p>Your email: {{ email }}</p>
      <p>Your wallet: {{ wallet }} credits</p>
    </div>
    <form @submit.prevent="updateProfile">
      <div>
        <label for="lastName">Last Name:</label>
        <input type="text" id="lastName" v-model="lastName" required>
      </div>
      <div>
        <label for="firstName">First Name:</label>
        <input type="text" id="firstName" v-model="firstName" required>
      </div>
      <div>
        <label for="address">Address:</label>
        <input type="text" id="address" v-model="address" required>
      </div>
      <button type="submit">Save Changes</button>
    </form>
    <h2>Change Password</h2>
    <form @submit.prevent="updatePassword">
      <div>
        <label for="oldPassword">Old Password:</label>
        <input type="password" id="oldPassword" v-model="oldPassword" required>
      </div>
      <div>
        <label for="newPassword">New Password:</label>
        <input type="password" id="newPassword" v-model="newPassword" required>
      </div>
      <button type="submit">Change Password</button>
    </form>
    <message-component v-if="errorMessage" :message="errorMessage" :isError="true"/>
    <message-component v-if="successMessage" :message="successMessage" :isSuccess="true"/>
  </div>
</template>

<style scoped>

div {
  max-width: 800px;
  margin: auto;
  padding: 10px;
  background-color: #f9f9f9;

  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}


h2 {
  color: #333;
  text-align: center;
  margin-bottom: 20px;
}




label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
}

input[type="text"], input[type="password"], input[type="file"] {
  width: 100%;
  padding: 8px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  width: 100%;
  padding: 10px;
  background-color: #007BFF;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #0056b3;
}

img {
  display: block;
  max-width: 200px;
  max-height: 200px;
  margin: 10px auto;
  border-radius: 10px;
}

.message-component {
  padding: 10px;
  color: white;
  border-radius: 5px;
  text-align: center;
  margin-top: 20px;
}

.message-component.isError {
  background-color: #ff3860;
}

.message-component.isSuccess {
  background-color: #23d160;
}
</style>
