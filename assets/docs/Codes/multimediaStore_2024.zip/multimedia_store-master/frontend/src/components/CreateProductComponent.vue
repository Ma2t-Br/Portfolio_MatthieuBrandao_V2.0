<script>
import MessageComponent from "@/components/MessageComponent.vue";
import HttpStatus from "@/components/HttpStatus";
import {BASE_URL} from "@/components/ApiConfig";

export default {
  components: { MessageComponent },
  data() {
    return {
      companies: [],
      productReference: '',
      companyName: '',
      productName: '',
      categoryName: '',
      stockQuantity: 1,
      price: 0.01,
      errorMessage: '',
      successMessage: '',
    };
  },
  created() {
    this.fetchCompanies();
  },
  methods: {
    async fetchCompanies() {
      const response = await fetch (`${BASE_URL}/companies/all`);

      this.companies = await response.json();
    },
    async createProduct() {
      try {
        const companyResponse = await fetch (`${BASE_URL}/companies/${this.companyName}`)
        let company;
        if (companyResponse.status === HttpStatus.NOT_FOUND) {
          this.errorMessage = "Company '" + this.companyName + "' not found";
          this.successMessage = '';
          return;
        }
        else if (companyResponse.status === HttpStatus.OK) {
          company = await companyResponse.json();
        }

        const response = await fetch(`${BASE_URL}/products`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            productReference: this.productReference,
            company: company,
            productName: this.productName,
            categoryName: this.categoryName,
            stockQuantity: this.stockQuantity,
            price: this.price
          })
        });

        if (response.status === HttpStatus.FORBIDDEN){
          this.errorMessage = await response.text();
          this.successMessage = '';
        }
        else if (response.status === HttpStatus.CREATED) {
          this.resetForm();
          this.successMessage = await response.text();
          this.errorMessage = '';
        }

      } catch (error) {
        console.error('Error creating product:', error);
        this.successMessage = '';
        this.errorMessage = 'Failed to create product.';
      }
    },
    resetForm() {
      this.productReference = '';
      this.companyName = '';
      this.productName = '';
      this.categoryName = '';
      this.stockQuantity = 1;
      this.price = 0.01;
    },
  }
};
</script>

<template>
  <div>
    <h2>Create Product</h2>
    <form @submit.prevent="createProduct">
      <label for="productReference">Product Reference:</label>
      <input type="text" id="productReference" v-model="productReference" required>
      <label for="companyName">Company Name:</label>
      <select id="companyName" v-model="companyName" required>
        <option v-for="company in this.companies" :key="company.companyName">
          {{ company.companyName }}
        </option>
      </select>

      <label for="productName">Product Name:</label>
      <input type="text" id="productName" v-model="productName" required>
      <label for="categoryName">Category Name:</label>
      <input type="text" id="categoryName" v-model="categoryName" required>
      <label for="stockQuantity">Stock Quantity:</label>
      <input type="number" id="stockQuantity" v-model="stockQuantity" min="1" required>
      <label for="price">Price:</label>
      <input type="number" id="price" v-model="price" step="0.01" min="0.01" required>
      <button type="submit">Create Product</button>
    </form>
    <message-component v-if="successMessage" :message="successMessage" :isSuccess="true" />
    <message-component v-if="errorMessage" :message="errorMessage" :isError="true" />
  </div>
</template>

<style scoped>
form {
  display: flex;
  flex-direction: column;
  max-width: 500px;
  padding: 20px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  margin: 20px auto auto;
}

label {
  margin-bottom: 8px;
  font-weight: bold;
  color: #333;
}

input[type="text"], input[type="number"], select {
  margin-bottom: 15px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 16px;
}

button {
  padding: 10px 20px;
  margin-top: 10px;
  border: none;
  border-radius: 5px;
  background-color: #007BFF;
  color: white;
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #0056b3;
}

select {
  cursor: pointer;
}

option {
  padding: 5px;
}
</style>
