<script>
import {BASE_URL} from "@/components/ApiConfig";
import HttpStatus from "@/components/HttpStatus";

export default {
  props: {
    companyName: {
      type: String,
      default: ''
    },
    customerEmail: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      rating: 0,
      hoverIndex: null,
    };
  },
  created() {
    this.initializeRating();
  },
  methods: {
    rate(star) {
      this.rating = star;
      this.$emit('rated', star);
    },
    hover(star) {
      this.hoverIndex = star;
    },
    leave() {
      this.hoverIndex = null;
    },
    async initializeRating() {
      const response = await fetch(`${BASE_URL}/notes/company/${this.companyName}/customer/${this.customerEmail}`);

      if (response.status === HttpStatus.NOT_FOUND)
        this.rating = 0;
      else if (response.status === HttpStatus.OK) {
        const note = await response.json();
        this.rating = parseInt(note.noteValue);
      }

    }
  },
};
</script>

<template>
  <div class="star-rating">
    <p>Note given by you:</p>
    <i v-for="star in 10" :key="star"
       @click="rate(star)"
       @mouseover="hover(star)"
       @mouseleave="leave"
       class="star"
       :class="{ 'full': star <= (hoverIndex || rating), 'half': star === Math.ceil(rating) && rating % 1 > 0 }">
      &#9733;
    </i>
  </div>
</template>


<style scoped>
.star {
  cursor: pointer;
  color: gray;
}
.full {
  color: gold;
}
.half {
  color: lightgray;
}

</style>
