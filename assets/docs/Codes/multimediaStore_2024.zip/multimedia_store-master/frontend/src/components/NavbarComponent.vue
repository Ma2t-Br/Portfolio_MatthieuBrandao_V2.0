<template>
  <nav>
    <ul>
      <li>
        <router-link to="/" @click="handleIndicator($event, 'blue')" class="nav-item hover-underline-animation">
          <font-awesome-icon icon="home" /> Home
        </router-link>
      </li>
      <li v-if="loggedIn && !isAdmin" style="display: flex;">
        <router-link to="/sell-product" @click="handleIndicator($event, 'blue')" class="nav-item hover-underline-animation">Sell Products</router-link>
        <router-link to="/my-orders" @click="handleIndicator($event, 'blue')" class="nav-item hover-underline-animation">My Orders</router-link>
        <router-link to="/my-sells" @click="handleIndicator($event, 'blue')" class="nav-item hover-underline-animation">My Sells</router-link>
      </li>
      <li v-if="loggedIn && isAdmin" style="display: flex;">
        <router-link to="/manage-users" @click="handleIndicator($event, 'rebeccapurple')" class="nav-item hover-underline-animation">
          <font-awesome-icon icon="users" /> Manage Users
        </router-link>
        <router-link to="/manage-products" @click="handleIndicator($event, 'rebeccapurple')" class="nav-item hover-underline-animation">
          <font-awesome-icon icon="cogs" /> Manage Products
        </router-link>
      </li>
    </ul>
    <div class="right-items">
      <li class="" v-if="loggedIn && !isAdmin" style="display: flex;">
        <router-link to="/profile" class="nav-item">
          <div v-if="avatar" style="width: 50px; height: 50px; border-radius: 50%; overflow: hidden; transform: scale(1.2);">
            <img :src="avatar" alt="Avatar" style="width: 100%; height: 100%; object-fit: cover; border: 2px solid #000000; border-radius: 50%;">
          </div>
          <div v-else>
            <font-awesome-icon icon="user"/> Profile
          </div>
        </router-link>
      </li>
      <li>
        <router-link v-if="!loggedIn" to="/login" @click="handleIndicator($event, 'blue')" class="nav-item hover-underline-animation"><i class="fas fa-sign-in-alt"></i> Log in</router-link>
        <a v-else href="/" @click="logout" style="margin-left: 10px" class="nav-item hover-underline-animation">Sign out</a>
      </li>
    </div>
    <span class="nav-indicator"></span>
  </nav>
</template>




<script>
import {BASE_URL} from "@/components/ApiConfig";

export default {
  data() {
    return {
      isAdmin: false,
      loggedIn: false,
      avatar: null,
      email: this.$root.getCustomerEmailFromCookies(),
      borderColor: 'black'
    };
  },
  created() {
    this.initializeAvatar();
    this.isAdmin = this.$root.getIsAdminFromCookies();
    this.loggedIn = this.$root.getIsLoggedInFromCookies();
  },
  methods: {
    async initializeAvatar() {
      try {
        const customerResponse = await fetch(`${BASE_URL}/customers/${this.email}`);
        const customerData = await customerResponse.json();

        const avatarResponse = await fetch(`${BASE_URL}/avatars/${customerData.avatar}`);
        const avatarData = await avatarResponse.blob();
        this.avatar = URL.createObjectURL(avatarData);

      } catch (error) {
        this.successMessage = '';
        this.errorMessage = error.message;
        console.log(error, error.message);
      }
    },
    logout() {
      this.clearCookies();
      this.$emit('logout');
    },
    clearCookies() {
      document.cookie = 'client_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
      document.cookie = 'client_email=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
      document.cookie = 'client_role=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
    },
    handleIndicator(event, color) {
      // Sélectionne l'élément actuellement actif
      const previousActiveItem = document.querySelector('.nav-item.active');

      // Si un élément est déjà actif, enlever la classe et les styles
      if (previousActiveItem) {
        previousActiveItem.classList.remove('active');
        previousActiveItem.style.color = '';
        previousActiveItem.style.fontWeight = '';
      }

      // Ajoute la classe et les styles à l'élément cliqué
      const clickedItem = event.target.closest('.nav-item');
      clickedItem.classList.add('active');
      clickedItem.style.color = color; // Appliquer la couleur spécifiée
      clickedItem.style.fontWeight = 'bold'; // Appliquer le style gras

      // Met à jour l'indicateur de navigation
      const indicator = document.querySelector('.nav-indicator');
      const activeItemRect = clickedItem.getBoundingClientRect();
      indicator.style.width = `${activeItemRect.width}px`;
      indicator.style.transform = `translateX(${activeItemRect.left}px)`;
      indicator.style.backgroundColor = color;
    }

  }
};
</script>


<style scoped>
/* Ajout des classes CSS pour les éléments actifs */
.nav-item.active {
  color: blue;
  font-weight: bold;
}

/* CSS pour l'indicateur de navigation */
.nav-indicator {
  position: absolute;
  bottom: 0;
  left: 0;
  height: 3px;
  background-color: blue;
  transition: transform 0.3s ease-in-out;
  width: 2px;
}

/* CSS général */
* {
  box-sizing: border-box;
  text-decoration: none;
}
nav {
  background-color: #fff;
  padding: 0 30px;
  border-radius: 40px;
  box-shadow: 0 10px 40px rgba(159, 162, 177, .8);
  display: flex;
  position: relative;
  justify-content: space-between; /* Ensure space between left and right items */
}
nav ul {
  list-style-type: none;
  padding: 0;
  display: flex;
  align-items: center;
  margin: 0;
}
nav ul li {
  margin-right: 20px;
  display: flex;
  align-items: center;
}
nav ul li:last-child {
  margin-right: 0;
}
nav ul li a {
  text-decoration: none;
  color: #333;
  display: flex;
  align-items: center;
  margin-right: 10px;
}
.hover-underline-animation {
  display: inline-block;
  position: relative;
}
.hover-underline-animation::after {
  content: '';
  position: absolute;
  width: 100%;
  transform: scaleX(0);
  height: 3px; /* Increased height */
  bottom: -12px;
  left: 0;
  background-color: #0303ee; /* Changed color */
  transition: transform 0.3s ease-in-out; /* Adjusted transition */
}
.hover-underline-animation:hover::after {
  transform: scaleX(1);
}
.right-items {
  display: flex;
  align-items: center;
}


</style>