<script>
import MessageComponent from "@/components/MessageComponent.vue";
import HttpStatus from "@/components/HttpStatus";
import { BASE_URL } from "@/components/ApiConfig";

export default {
  components: {
    MessageComponent
  },
  data() {
    return {
      companies: [],
      customerEmail: '',
      companyName: '',
      productName: '',
      quantity: null,
      price: null,
      errorMessage: '',
      successMessage: ''
    };
  },
  created() {
    this.fetchCompanies();
    this.customerEmail = this.$root.getCustomerEmailFromCookies();
  },
  methods: {
    async fetchCompanies() {
      const response = await fetch (`${BASE_URL}/companies/all`);

      this.companies = await response.json();
    },
    async sellProduct() {
      try {
        const response = await fetch(`${BASE_URL}/customers/${this.customerEmail}/sell-to/${this.companyName}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            productName: this.productName,
            quantity: this.quantity,
            price: this.price
          })
        });

        if (response.status === HttpStatus.CREATED) {
          this.successMessage = await response.text();
          this.errorMessage = '';
        } else {
          this.errorMessage = await response.text();
          this.successMessage = '';
        }
      } catch (error) {
        this.errorMessage = error.message;
        this.successMessage = '';
      }
    }
  }
};
</script>

<template>
  <div>
    <h2>Sell Product</h2>
    <form @submit.prevent="sellProduct">
      <div>
        <label for="productReference">Product Name:</label>
        <input type="text" v-model="productName" required>
      </div>
      <div>
        <label for="companyName">Company Name:</label>
        <select id="companyName" v-model="companyName" required>
          <option v-for="company in this.companies" :key="company.companyName">
            {{ company.companyName }}
          </option>
        </select>
      </div>
      <div>
        <label for="quantity">Quantity:</label>
        <input type="number" v-model="quantity" required>
      </div>
      <div>
        <label for="price">Price ($):</label>
        <input type="number" id="price" v-model="price" step="0.01" min="0.01" required>
      </div>
      <button type="submit">Sell Product</button>
    </form>
    <message-component v-if="errorMessage" :message="errorMessage" :isError="true"/>
    <message-component v-if="successMessage" :message="successMessage" :isSuccess="true"/>
  </div>
</template>

<style scoped>
div {
  margin-bottom: 10px;
}

label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
}

input[type="text"],
input[type="number"],
select {
  width: 100%;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  background-color: #4CAF50;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #45a049;
}

form {
  max-width: 500px;
  margin: auto;
}
</style>
