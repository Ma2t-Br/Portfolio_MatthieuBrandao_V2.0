<script>
import MessageComponent from "@/components/MessageComponent.vue";
import HttpStatus from "@/components/HttpStatus";
import {BASE_URL} from "@/components/ApiConfig";
import '../assets/style/manage.css';
import { faGavel, faCheckCircle, faTrashAlt, faSyncAlt } from '@fortawesome/free-solid-svg-icons';
import {library} from "@fortawesome/fontawesome-svg-core";
library.add(faGavel, faCheckCircle, faTrashAlt, faSyncAlt);


export default {
  components: {MessageComponent},
  data() {
    return {
      users: [],
      successMessage: '',
      errorMessage: ''
    };
  },
  created() {
    this.fetchUsers();
  },
  methods: {
    async fetchUsers() {
      try {
        const response = await fetch(`${BASE_URL}/clients/all`);
        const data = await response.json();
        this.users = data
            .filter(user => user.clientRole === 'CUSTOMER')
            .map(user => ({
          email: user.email,
          status: user.validatedByAdmin ? (user.bannedByAdmin ? 'Banned' : 'Active') : 'Pending Validation'
        }));
      } catch (error) {
        console.error('Error fetching users:', error);
        this.errorMessage = error.message;
      }
    },
    async toggleBanUser(clientEmail, isBanned) {
      const action = isBanned ? 'unban' : 'ban';
      try {
        const response = await fetch(`${BASE_URL}/clients/${clientEmail}/${action}`, {method: 'PATCH'});

        if (response.status === HttpStatus.NOT_FOUND) {
          this.errorMessage = await response.text();
          this.successMessage = '';
        }
        else if (response.status === HttpStatus.OK){
          const userIndex = this.users.findIndex(user => user.email === clientEmail);
          if (userIndex !== -1) this.users[userIndex].status = isBanned ? 'Active' : 'Banned';
          this.successMessage = await response.text();
          this.errorMessage = '';
        }

      } catch (error) {
        this.successMessage = '';
        this.errorMessage = error.message;
      }
    },
    async validateUser(clientEmail) {
      try {
        const response = await fetch(`${BASE_URL}/clients/${clientEmail}/validate`, {method: 'PATCH'});

        if (response.status === HttpStatus.NOT_FOUND) {
          this.errorMessage = await response.text();
          this.successMessage = '';
        }
        else if (response.status === HttpStatus.OK){
          const userIndex = this.users.findIndex(user => user.email === clientEmail);
          if (userIndex !== -1) this.users[userIndex].status = 'Active';
          this.successMessage = await response.text();
          this.errorMessage = '';
        }

      } catch (error) {
        this.successMessage = '';
        this.errorMessage = error.message;
      }
    },
    async deleteUser(clientEmail) {
      try {
        await fetch(`${BASE_URL}/clients/${clientEmail}`, {method: 'DELETE'});
        const response = await fetch(`${BASE_URL}/customers/${clientEmail}`, {method: 'DELETE'});

        if (response.status === HttpStatus.NOT_FOUND) {
          this.errorMessage = await response.text();
          this.successMessage = '';
        }
        else if (response.status === HttpStatus.OK){
          this.users = this.users.filter(user => user.email !== clientEmail);
          this.successMessage = await response.text();
          this.errorMessage = '';
        }
      } catch (error) {
        this.successMessage = '';
        this.errorMessage = error.message;
      }
    },
    async resetPassword(clientEmail) {
      const newPassword = prompt('Enter new password:');
      if (!newPassword) return;
      try {
        const response = await fetch(`${BASE_URL}/clients/${clientEmail}/reset_password?newPassword=${newPassword}`, {method: 'PATCH'});

        if (response.status === HttpStatus.NOT_FOUND || response.status === HttpStatus.INTERNAL_SERVER_ERROR) {
          this.errorMessage = await response.text();
          this.successMessage = '';
        }
        else if (response.status === HttpStatus.OK){
          this.successMessage = await response.text();
          this.errorMessage = '';
        }

      } catch (error) {
        this.successMessage = '';
        this.errorMessage = error.message;
      }
    }
  }
};
</script>

<template>
  <div>
    <h2>Users Dashboard</h2>
    <table>
      <thead>
      <tr>
        <th>Email</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="user in users" :key="user.email">
        <td>{{ user.email }}</td>
        <td>{{ user.status }}</td>
        <td>
          <button @click="toggleBanUser(user.email, user.status === 'Banned')">
            <font-awesome-icon :icon="'gavel'" /> {{ user.status === 'Banned' ? 'Unban' : 'Ban' }}
          </button>
          <button v-if="user.status === 'Pending Validation'" @click="validateUser(user.email)">
            <font-awesome-icon icon="check-circle" /> Validate
          </button>
          <button @click="deleteUser(user.email)">
            <font-awesome-icon icon="trash-alt" /> Delete
          </button>
          <button @click="resetPassword(user.email)">
            <font-awesome-icon icon="sync-alt" /> Reset Password
          </button>
        </td>
      </tr>
      </tbody>
    </table>
  </div>
  <message-component v-if="successMessage" :message="successMessage" :isSuccess="true" />
  <message-component v-if="errorMessage" :message="errorMessage" :isError="true" />
</template>


<style scoped>
button {
  margin-right: 10px;
  padding: 5px 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: white;
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #f0f0f0;
}

font-awesome-icon {
  margin-right: 5px;
}
</style>
