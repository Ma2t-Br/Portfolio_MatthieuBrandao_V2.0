<script>
export default {
  name: 'HeaderComponent',
};
</script>

<template>
  <header>
    <div class="logo-container">
      <img src="../assets/logo.png" alt="Logo MultimediaStore" class="logo">
    </div>
    <h1>MultimediaStore</h1>
  </header>
</template>


<style scoped>
header {
  background-color: #007bff;
  color: #fff;
  padding: 1%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.logo-container {
  position: absolute;
  left: 1%;
}

.logo {
  height: auto;
  width: 10%;
}

h1 {
  flex-grow: 1;
  text-align: center;
}

</style>

