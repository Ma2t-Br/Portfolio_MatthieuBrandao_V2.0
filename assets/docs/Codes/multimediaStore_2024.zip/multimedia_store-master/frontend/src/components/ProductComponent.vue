<script>
import MessageComponent from "@/components/MessageComponent.vue";
import HttpStatus from "@/components/HttpStatus";
import { BASE_URL } from "@/components/ApiConfig";
import StarRating from "@/components/StarRating.vue";

export default {
  components: {
    MessageComponent,
    StarRating
  },
  data() {
    return {
      productReference: this.$route.params.productReference,
      customerEmail: '',
      product: null,
      vote: '',
      alreadyLiked: false,
      successMessage: '',
      errorMessage: '',
      isLoggedIn: false,
      isAdmin: false
    };
  },
  created() {
    this.fetchProduct();
    this.isLoggedIn = this.$root.getIsLoggedInFromCookies();
    this.isAdmin = this.$root.getIsAdminFromCookies();
    this.customerEmail = this.$root.getCustomerEmailFromCookies();
  },
  methods: {
    async fetchProduct() {
      try {
        const productResponse = await fetch(`${BASE_URL}/products/${this.productReference}`);
        this.product = await productResponse.json();

        const voteResponse = await fetch(`${BASE_URL}/votes/${this.productReference}/count`);
        if (voteResponse.status === HttpStatus.OK)
          this.vote = await voteResponse.text();

        if (this.isLoggedIn && !this.isAdmin) {
          const alreadyVotedResponse = await fetch(`${BASE_URL}/votes/${this.productReference}/${this.customerEmail}`);
          this.alreadyLiked = await alreadyVotedResponse.text() !== 'false';
        }
      } catch (error) {
        this.errorMessage = error.message;
        this.successMessage = '';
      }
    },
    async contactCompany() {
      try {
        const subject = prompt('Enter a subject:');
        if (!subject) {
          alert("Please enter a valid subject");
          return;
        }

        const text = prompt('Enter a message:');
        if (!text) {
          alert("Please enter a valid message");
          return;
        }

        const response = await fetch(`${BASE_URL}/customers/${this.customerEmail}/send_email_to/${this.product.company.companyName}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            subject: subject,
            text: text,
          })
        });

        if (response.status === HttpStatus.OK) {
          this.successMessage = await response.text();
          this.errorMessage = '';
        } else {
          this.successMessage = '';
          this.errorMessage = 'Email could not have been sent..';
        }
      } catch (error) {
        this.errorMessage = error.message;
        this.successMessage = '';
      }
    },
    async noteCompany(newRating) {
      try {
        const response = await fetch(`${BASE_URL}/customers/${this.customerEmail}/note/${this.product.company.companyName}?note=${newRating}`, {
          method: 'POST'
        });

        if (response.status === HttpStatus.NOT_FOUND) {
          this.errorMessage = await response.text();
          this.successMessage = '';
        } else if (response.status === HttpStatus.CREATED) {
          this.successMessage = await response.text();
          this.errorMessage = '';
        }
      } catch (error) {
        this.errorMessage = error.message;
        this.successMessage = '';
      }
    }
,
    async buyProduct() {
      try {
        const quantity = prompt('Enter the quantity to buy:');
        if (!quantity || isNaN(quantity) || !Number.isInteger(parseFloat(quantity)) || parseFloat(quantity) <= 0) {
          alert('Please enter a valid integer greater than 0.');
          return;
        }
        const response = await fetch(`${BASE_URL}/customers/${this.customerEmail}/buy/${this.productReference}?quantity=${quantity}`, {
          method: 'PATCH'
        });
        if (response.status === HttpStatus.NOT_FOUND || response.status === HttpStatus.FORBIDDEN) {
          this.errorMessage = await response.text();
          this.successMessage = '';
        } else if (response.status === HttpStatus.OK) {
          this.product.stockQuantity -= quantity;
          this.successMessage = await response.text();
          this.errorMessage = '';
        }
      } catch (error) {
        this.errorMessage = error.message;
        this.successMessage = '';
      }
    },
    async likeProduct() {
      try {
        if (this.alreadyLiked) {
          const response = await fetch(`${BASE_URL}/votes/${this.productReference}/${this.customerEmail}`, {
            method: 'DELETE'
          });
          if (response.status === HttpStatus.OK) {
            this.alreadyLiked = false;
            this.vote--;
          }
        } else {
          const response = await fetch(`${BASE_URL}/votes/${this.productReference}/${this.customerEmail}`, {
            method: 'POST'
          });
          if (response.status === HttpStatus.OK) {
            this.alreadyLiked = true;
            this.vote++;
          }
        }
      } catch (error) {
        this.errorMessage = error.message;
        this.successMessage = '';
      }
    }
  }
};
</script>

<template>
  <div class="productDetails">
    <h2>Product Details</h2>
    <div v-if="product" class="product">
      <h3>{{ product.productName }}</h3>
      <p>Category: {{ product.categoryName }}</p>
      <p>Company: {{ product.company.companyName }}
        <star-rating v-if="isLoggedIn && !isAdmin" :company-name="this.product.company.companyName"
                     :customer-email="this.customerEmail"
                     @rated="noteCompany">
        </star-rating>
        <button v-if="isLoggedIn && !isAdmin" @click="contactCompany" class="btn-contact">Contact Company</button>
      </p>
      <p>Stock Quantity: {{ product.stockQuantity }}</p>
      <p>Price: {{ product.price }} $</p>
      <p>Likes: {{ vote }}</p>
      <button v-if="isLoggedIn && !isAdmin" @click="buyProduct" class="btn-buy">
        <font-awesome-icon icon="shopping-cart" /> Buy
      </button>
      <button v-if="isLoggedIn && !isAdmin" @click="likeProduct" class="btn-like">
        <font-awesome-icon :icon="alreadyLiked ? 'thumbs-down' : 'thumbs-up'" />
        {{ alreadyLiked ? 'Dislike' : 'Like' }}
      </button>
    </div>
    <p v-else>No product details available.</p>
    <message-component v-if="errorMessage" :message="errorMessage" :isError="true"/>
    <message-component v-if="successMessage" :message="successMessage" :isSuccess="true"/>
  </div>
</template>


<style scoped>
.productDetails {
  max-width: 800px;
  margin: 20px auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  transition: box-shadow 0.3s;
  background: linear-gradient(to right, #ffffff, #f1f1f1);
}

.productDetails:hover {
  box-shadow: 0 8px 16px rgba(0,0,0,0.2); /* Ombrage plus prononcé au survol */
}

.product {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); /* Colonnes responsives */
  gap: 20px; /* Espacement entre les éléments */
}

button {
  margin-top: 10px;
  padding: 10px 20px;
  border-radius: 5px;
  border: none;
  background-color: #007BFF;
  color: white;
  cursor: pointer;
  transition: background-color 0.3s, transform 0.3s; /* Ajout de la transition pour le transform */
  margin-left: 10px;
}

button:hover {
  background-color: #0056b3;
  transform: translateY(-2px); /* Légère élévation au survol */
}
</style>


