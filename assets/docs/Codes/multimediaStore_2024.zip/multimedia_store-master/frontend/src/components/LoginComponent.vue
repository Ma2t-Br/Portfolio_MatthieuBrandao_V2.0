<script>
import MessageComponent from './MessageComponent.vue';
import HttpStatus from './HttpStatus.js';
import {BASE_URL} from "@/components/ApiConfig";

export default {
  components: {
    MessageComponent
  },
  data() {
    return {
      email: '',
      password: '',
      errorMessage: '',
      successMessage: ''
    };
  },
  methods: {
    async login() {
      try {
        const response = await fetch(`${BASE_URL}/clients/login`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            email: this.email,
            password: this.password
          })
        });

        if (response.status === HttpStatus.NOT_FOUND || response.status === HttpStatus.FORBIDDEN) {
          this.errorMessage = await response.text();
          this.successMessage = '';
        }
        else if (response.status === HttpStatus.FOUND) {
          this.errorMessage = '';
          const data = await response.json();
          this.successMessage = 'Login successful';

          document.cookie = `client_email=${data.email};`;
          document.cookie = `client_role=${data.role};`;

          window.location.href = "/";

        } else {
          this.errorMessage = 'An unexpected error occurred';
        }
      } catch (error) {
        this.errorMessage = 'An error occurred while logging in';
        this.successMessage = '';
      }
    },
    navigateToCreateAccount() {
      this.$router.push({ name: 'create-account' });
    }
  }
}
</script>

<template>
  <div class="login-container">
    <h2 class="login-title">Login</h2>
    <br>
    <form @submit.prevent="login" class="login-form">
      <div class="input-group">
        <label for="email">Email:</label>
        <input type="email" id="email" v-model="email" required>
      </div>
      <div class="input-group">
        <label for="password">Password:</label>
        <input type="password" id="password" v-model="password" required>
      </div>
      <button type="submit" class="login-button">Login</button>
      <div class="alternative">
        <span>Don't have an account?</span>
        <button type="button" @click="navigateToCreateAccount" class="signin-button">Sign in</button>
      </div>
    </form>
    <message-component v-if="errorMessage" :message="errorMessage" :isError="true" />
    <message-component v-if="successMessage" :message="successMessage" :isSuccess="true" />
  </div>
</template>


<style scoped>
.login-container {
  max-width: 400px;
  margin: 50px auto;
  padding: 20px;
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  text-align: center;
}

.login-title {
  font-weight: bold;
}

.input-group {
  margin-bottom: 20px;
}

.login-button, .signin-button {
  width: 100%;
  padding: 10px;
  border-radius: 5px;
  border: none;
  background-color: #007BFF;
  color: white;
  cursor: pointer;
  transition: background-color 0.3s;
}

.login-button:hover {
  background-color: #0056b3;
}

.alternative {
  margin-top: 20px;
}

.signin-button {
  background-color: transparent;
  color: #050505;
  text-decoration: underline;
}

.signin-button:hover{
  text-decoration: underline;
  color: #0303ee;
}
.input-group {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
}

.input-group label {
  flex: 0 0 100px; /* Fixed width for labels */
  margin-right: 10px; /* Space between label and input */
}

.input-group input {
  flex: 1; /* Allows the input to fill the rest of the space */
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}


</style>
