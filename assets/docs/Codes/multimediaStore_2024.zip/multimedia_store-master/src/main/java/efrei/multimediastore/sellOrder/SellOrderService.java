package efrei.multimediastore.sellOrder;

import efrei.multimediastore.company.Company;
import efrei.multimediastore.company.CompanyRepository;
import efrei.multimediastore.customer.Customer;
import efrei.multimediastore.customer.CustomerRepository;
import efrei.multimediastore.product.Product;
import efrei.multimediastore.product.ProductRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class SellOrderService {

    private final SellOrderRepository sellOrderRepository;

    private final CustomerRepository customerRepository;

    private final CompanyRepository companyRepository;
    private final ProductRepository productRepository;

    @Autowired
    public SellOrderService(SellOrderRepository sellOrderRepository,
                            CustomerRepository customerRepository,
                            CompanyRepository companyRepository,
                            ProductRepository productRepository) {
        this.sellOrderRepository = sellOrderRepository;
        this.customerRepository = customerRepository;
        this.companyRepository = companyRepository;
        this.productRepository = productRepository;
    }
    @Transactional
    public List<SellOrder> getSellOrdersByCustomerEmail(String customerEmail) throws EntityNotFoundException {
        Customer customer = customerRepository.findById(customerEmail)
                .orElseThrow(() -> new EntityNotFoundException("Customer not found with email: " + customerEmail));

        return sellOrderRepository.findAllByIdCustomer(customer);
    }

    @Transactional
    public void sellProduct(String customerEmail, String productName, String companyName,
                            Integer quantity, Float price) throws EntityNotFoundException {
        Customer customer = customerRepository.findById(customerEmail)
                .orElseThrow(() -> new EntityNotFoundException("Customer not found with email '" + customerEmail + "'"));

        Company company = companyRepository.findById(companyName)
                .orElseThrow(() -> new EntityNotFoundException("Company not found with name '" + companyName + "'"));

        float totalPrice = quantity * price;

        customer.addToWallet(totalPrice);
        customerRepository.save(customer);

        SellOrder existingSellOrder = sellOrderRepository.findByIdCustomerAndIdCompanyAndIdProductName(customer, company, productName)
                .orElse(null);

        if (existingSellOrder != null) {
            existingSellOrder.setTotalPrice(existingSellOrder.getTotalPrice() + totalPrice);
            existingSellOrder.setSoldQuantity(existingSellOrder.getSoldQuantity() + quantity);
            sellOrderRepository.save(existingSellOrder);
        } else {
            SellOrder sellOrder = new SellOrder(customer, company, productName);
            sellOrder.setTotalPrice(totalPrice);
            sellOrder.setSoldQuantity(quantity);
            sellOrderRepository.save(sellOrder);
        }
    }
}