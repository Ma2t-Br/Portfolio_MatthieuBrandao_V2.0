package efrei.multimediastore.vote;

import efrei.multimediastore.customer.Customer;
import efrei.multimediastore.product.Product;
import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import java.io.Serializable;

@Embeddable
public class VotePrimaryKey implements Serializable {

    @ManyToOne
    @JoinColumn(name = "product_reference", referencedColumnName = "product_reference")
    private Product product;

    @ManyToOne
    @JoinColumn(name = "customer_email", referencedColumnName = "customer_email")
    private Customer customer;

    public VotePrimaryKey() {

    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public VotePrimaryKey(Product product, Customer customer) {
        this.product = product;
        this.customer = customer;
    }
}
