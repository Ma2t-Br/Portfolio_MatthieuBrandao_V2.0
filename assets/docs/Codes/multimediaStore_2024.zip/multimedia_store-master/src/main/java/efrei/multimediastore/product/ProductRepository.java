package efrei.multimediastore.product;

import efrei.multimediastore.company.Company;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductRepository extends JpaRepository<Product, String> {
    List<Product> findByCategoryName(String categoryName);

    Optional<Product> findByCategoryNameAndProductReference(String categoryName, String productReference);

    @Query("SELECT DISTINCT p.categoryName FROM Product p")
    List<String> findAllCategoryNames();
}
