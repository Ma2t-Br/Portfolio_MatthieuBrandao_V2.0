package efrei.multimediastore.client;

import jakarta.persistence.EntityExistsException;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.List;

@Service
public class ClientService {
    private final ClientRepository clientRepository;

    @Autowired
    public ClientService(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }

    public List<Client> getClients() {
        return clientRepository.findAll();
    }

    public Client getClientById(String clientEmail) {
        return clientRepository.findById(clientEmail)
                .orElseThrow(() -> new EntityNotFoundException("Client with email '" + clientEmail + "' doesn't exist"));
    }

    public void addNewClient(Client client) throws NoSuchAlgorithmException, EntityExistsException {
        boolean clientExists = clientRepository.existsByEmail(client.getEmail());

        if (clientExists) {
            throw new EntityExistsException("Client with email '" + client.getEmail() + "' already exists");
        }

        client.setPassword(hashPassword(client.getPassword()));
        client.setClientRole("CUSTOMER");
        clientRepository.save(client);
    }

    public void validateClient(String clientEmail) {
        Client client = getClientById(clientEmail);

        client.setValidatedByAdmin(true);
        clientRepository.save(client);
    }

    public void banClient(String clientEmail) {
        Client client = getClientById(clientEmail);

        client.setBannedByAdmin(true);
        clientRepository.save(client);
    }

    public void unbanClient(String  clientEmail) {
        Client client = getClientById(clientEmail);

        client.setBannedByAdmin(false);
        clientRepository.save(client);
    }

    public void resetPassword(String clientEmail, String newPassword) throws NoSuchAlgorithmException {
        Client client = getClientById(clientEmail);

        client.setPassword(hashPassword(newPassword));
        clientRepository.save(client);
    }

    public void deleteClient(String clientEmail) {
        Client client = getClientById(clientEmail);
        clientRepository.delete(client);
    }

    public ResponseEntity<String> login(LoginRequest loginRequest) throws NoSuchAlgorithmException, EntityNotFoundException {
        String clientEmail = loginRequest.getEmail();
        String password = loginRequest.getPassword();
        boolean clientExists = clientRepository.existsByEmail(clientEmail);

        if (!clientExists) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No account found with email '" + clientEmail + "'");
        }

        Client client = clientRepository.findById(clientEmail)
                .orElseThrow(() -> new EntityNotFoundException("Client not found with email '" + clientEmail + "'"));

        if (incorrectPassword(client.getPassword(), password)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Incorrect email or password");
        }

        if (client.isBannedByAdmin()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body("Your account has been banned by the admin");
        }

        if (!client.isValidatedByAdmin()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body("Your account is pending validation by the admin");
        }

        return ResponseEntity.status(HttpStatus.FOUND)
                    .body("{\"email\":\"" + client.getEmail() + "\","
                    + "\"role\":\"" + client.getClientRole() + "\"}");
    }

    @Transactional
    public void updatePassword(String clientEmail, String oldPassword, String newPassword) throws Exception {
        Client client = getClientById(clientEmail);

        if (oldPassword == null || incorrectPassword(client.getPassword(), oldPassword))
            throw new Exception("The old password is incorrect");

        if (newPassword != null && incorrectPassword(client.getPassword(), newPassword))
            client.setPassword(hashPassword(newPassword));

        clientRepository.save(client);
    }

    private String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = digest.digest(password.getBytes());
        return Base64.getEncoder().encodeToString(hashBytes);
    }

    private boolean incorrectPassword(String passwordHash, String password) throws NoSuchAlgorithmException {
        String hashedPassword = hashPassword(password);
        return !hashedPassword.equals(passwordHash);
    }
}
