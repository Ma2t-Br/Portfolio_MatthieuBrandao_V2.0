package efrei.multimediastore.note;

import efrei.multimediastore.company.Company;
import efrei.multimediastore.customer.Customer;
import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import java.io.Serializable;

@Embeddable
public class NotePrimaryKey implements Serializable {

    @ManyToOne
    @JoinColumn(name = "company_name", referencedColumnName = "company_name")
    private Company company;

    @ManyToOne
    @JoinColumn(name = "customer_email", referencedColumnName = "customer_email")
    private Customer customer;

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
