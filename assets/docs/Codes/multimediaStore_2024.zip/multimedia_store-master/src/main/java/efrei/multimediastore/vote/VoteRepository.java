package efrei.multimediastore.vote;

import efrei.multimediastore.customer.Customer;
import efrei.multimediastore.product.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface VoteRepository extends JpaRepository<Vote, VotePrimaryKey> {

    Integer countAllByIdProduct(Product product);

    Boolean existsByIdProductAndIdCustomer(Product product, Customer customer);
}
