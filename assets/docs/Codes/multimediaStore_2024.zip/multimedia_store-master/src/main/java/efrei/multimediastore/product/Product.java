package efrei.multimediastore.product;

import efrei.multimediastore.company.Company;
import jakarta.persistence.*;

@Entity
@Table(name = "PRODUCT")
public class Product {

    @Id
    @Column(name = "product_reference")
    private String productReference;

    @ManyToOne
    @JoinColumn(name = "company_name", referencedColumnName = "company_name")
    private Company company;

    @Column(name = "category_name")
    private String categoryName;

    @Column(name = "product_name")
    private String productName;

    @Column(name = "stock_quantity")
    private int stockQuantity;

    @Column(name = "price")
    private float price;

    public Product() {

    }

    public String getProductReference() {
        return productReference;
    }

    public void setProductReference(String productReference) {
        this.productReference = productReference;
    }

    public Company getCompany() {
        return company;
    }

    public String getProductName() {
        return productName;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public int getStockQuantity() {
        return stockQuantity;
    }

    public void decreaseStockQuantity(int quantity) {
        this.stockQuantity -= quantity;
    }

    public void increaseStockQuantity(int quantityToAdd) {
        this.stockQuantity += quantityToAdd;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

}
