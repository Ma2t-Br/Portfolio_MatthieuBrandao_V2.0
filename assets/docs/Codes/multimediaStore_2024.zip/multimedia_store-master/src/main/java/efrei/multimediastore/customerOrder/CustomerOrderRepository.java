package efrei.multimediastore.customerOrder;

import efrei.multimediastore.customer.Customer;
import efrei.multimediastore.product.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CustomerOrderRepository extends JpaRepository<CustomerOrder, CustomerOrderPrimaryKey> {

    List<CustomerOrder> findAllByIdCustomer(Customer customer);

    void deleteByIdCustomer(Customer customer);

    Optional<CustomerOrder> findByIdCustomerAndIdProduct(Customer customer, Product product);

    void deleteByIdCustomerAndIdProduct(Customer customer, Product product);
}
