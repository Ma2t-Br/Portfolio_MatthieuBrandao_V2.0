package efrei.multimediastore.note;

import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("multimediastore/notes")
public class NoteController {

    private final NoteService noteService;

    @Autowired
    public NoteController(NoteService noteService) {
        this.noteService = noteService;
    }

    @GetMapping
    public ResponseEntity<List<Note>> getAllNotes() {
        List<Note> notes = noteService.getAllNotes();
        return ResponseEntity.status(HttpStatus.OK)
                .body(notes);
    }

    @GetMapping("/company/{companyName}")
    public ResponseEntity<List<Note>> getNotesByCompany(@PathVariable String companyName) {

        try {
            List<Note> notes = noteService.getNoteByCompany(companyName);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(notes);

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    @GetMapping("/customer/{customerEmail}")
    public ResponseEntity<List<Note>> getNotesByCustomer(@PathVariable String customerEmail) {
        try {
            List<Note> notes = noteService.getNoteByCustomer(customerEmail);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(notes);

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    @GetMapping("/company/{companyName}/customer/{customerEmail}")
    public ResponseEntity<Note> getNoteByCompanyAndCustomer(@PathVariable String companyName,
                                            @PathVariable String customerEmail) {
        try {
            Note note = noteService.getNoteByCompanyAndCustomer(companyName, customerEmail);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(note);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
}
