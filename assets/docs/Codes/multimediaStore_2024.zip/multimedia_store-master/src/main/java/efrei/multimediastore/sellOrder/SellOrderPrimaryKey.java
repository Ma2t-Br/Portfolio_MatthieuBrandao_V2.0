package efrei.multimediastore.sellOrder;

import efrei.multimediastore.company.Company;
import efrei.multimediastore.customer.Customer;
import efrei.multimediastore.product.Product;
import jakarta.persistence.*;

import java.io.Serializable;

@Embeddable
public class SellOrderPrimaryKey implements Serializable {

    @ManyToOne
    @JoinColumn(name = "company_name", referencedColumnName = "company_name")
    private Company company;

    @ManyToOne
    @JoinColumn(name = "customer_email", referencedColumnName = "customer_email")
    private Customer customer;

    @Column(name = "product_name")
    private String productName;

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
}
