package efrei.multimediastore.sellOrder;

public class SellData {
    private String productName;
    private Integer quantity;
    private Float price;

    public SellData() {}

    public SellData(String productReference, Integer quantity, Float price) {
        this.productName = productReference;
        this.quantity = quantity;
        this.price = price;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }
}
