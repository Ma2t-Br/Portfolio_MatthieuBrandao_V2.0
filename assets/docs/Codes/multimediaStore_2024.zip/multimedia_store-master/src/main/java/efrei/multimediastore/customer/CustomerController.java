package efrei.multimediastore.customer;

import efrei.multimediastore.email.EmailRequest;
import efrei.multimediastore.email.EmailService;
import efrei.multimediastore.note.NoteService;
import efrei.multimediastore.sellOrder.SellData;
import efrei.multimediastore.sellOrder.SellOrderService;
import jakarta.mail.MessagingException;
import jakarta.persistence.EntityExistsException;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "multimediastore/customers")
public class CustomerController {

    private final CustomerService customerService;
    private final PurchaseService purchaseService;
    private final EmailService emailService;
    private final NoteService noteService;

    private final SellOrderService sellOrderService;

    @Autowired
    public CustomerController(CustomerService customerService,
                              PurchaseService purchaseService,
                              EmailService emailService,
                              NoteService noteService,
                              SellOrderService sellOrderService) {
        this.customerService = customerService;
        this.purchaseService = purchaseService;
        this.emailService = emailService;
        this.noteService = noteService;
        this.sellOrderService = sellOrderService;
    }

    @PostMapping("")
    public ResponseEntity<String> saveNewCustomer(@RequestBody Customer customer) {
        try {
            customerService.addNewCustomer(customer);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body("Account with email '" + customer.getEmail() + "' has been created successfully");

        } catch (EntityExistsException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(e.getMessage());
        }
    }

    @GetMapping("/all")
    public ResponseEntity<List<Customer>> getCustomers() {
        List<Customer> customers = customerService.getCustomers();
        return ResponseEntity.status(HttpStatus.OK)
                .body(customers);
    }

    @GetMapping("{customerEmail}")
    public ResponseEntity<Customer> getCustomerById(@PathVariable String customerEmail) {
        try {
            Customer customer = customerService.getCustomerByEmail(customerEmail);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(customer);

        } catch (EntityNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/{customerEmail}/buy/{productReference}")
    public ResponseEntity<String> buyProduct(
            @PathVariable String customerEmail,
            @PathVariable String productReference,
            @RequestParam Integer quantity) {
        try {
            purchaseService.makePurchase(customerEmail, productReference, quantity);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Customer '" + customerEmail + "' " +
                            "has bought product '" + productReference + "' " +
                            "with quantity " + quantity);

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        } catch (Exception e) {
            System.out.println("hello");
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(e.getMessage());
        }
    }

    @PostMapping("{customerEmail}/send_email_to/{companyName}")
    public ResponseEntity<String> sendEmailToCompany(
            @PathVariable String customerEmail,
            @PathVariable String companyName,
            @RequestBody EmailRequest emailRequest) {

        try {
            emailService.sendEmailToCompany(customerEmail, companyName, emailRequest);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Email sent successfully");

        } catch (MessagingException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred while trying to send an email to company '" + companyName + "'" +
                            "from '" + customerEmail + "': " + e.getMessage());
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }

    @PostMapping("{customerEmail}/note/{companyName}")
    public ResponseEntity<String> noteCompany(
            @PathVariable String customerEmail,
            @PathVariable String companyName,
            @RequestParam Float note) {

        try {
            noteService.noteCompany(companyName, customerEmail, note);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body("Company's note has been saved successfully");

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }

    }

    @PostMapping("/{customerEmail}/sell-to/{companyName}")
    public ResponseEntity<String> sellProduct(
            @PathVariable String customerEmail,
            @PathVariable String companyName,
            @RequestBody SellData sellData) {

        String productName = sellData.getProductName();
        Integer quantity = sellData.getQuantity();
        Float price = sellData.getPrice();

        try {
            sellOrderService.sellProduct(customerEmail, productName, companyName, quantity, price);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body("Customer '" + customerEmail + "' sold " + quantity + " product '" + productName + "' " +
                            "for " + price + " $ each to company '" + companyName + "'");
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }

    @PatchMapping(path = {"{customerEmail}"})
    public ResponseEntity<String> updateInformation(
            @PathVariable("customerEmail") String customerEmail,
            @RequestParam(required = false) String lastName,
            @RequestParam(required = false) String firstName,
            @RequestParam(required = false) String address,
            @RequestParam(required = false) String avatar) {

        try {
            customerService.updateInformation(customerEmail, lastName, firstName, address, avatar);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Profile has been updated successfully");

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }

    }

    @DeleteMapping(path ="{customerEmail}")
    public ResponseEntity<String> deleteCustomer(@PathVariable("customerEmail") String customerEmail){
        try {
            customerService.deleteCustomer(customerEmail);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Customer '" + customerEmail + "' has been deleted successfully");

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }
}
