package efrei.multimediastore.customer;

import efrei.multimediastore.customerOrder.CustomerOrder;
import efrei.multimediastore.customerOrder.CustomerOrderRepository;
import efrei.multimediastore.product.Product;
import efrei.multimediastore.product.ProductRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PurchaseService {

    private final ProductRepository productRepository;
    private final CustomerRepository customerRepository;
    private final CustomerOrderRepository customerOrderRepository;

    @Autowired
    public PurchaseService(ProductRepository productRepository, CustomerRepository customerRepository, CustomerOrderRepository customerOrderRepository) {
        this.productRepository = productRepository;
        this.customerRepository = customerRepository;
        this.customerOrderRepository = customerOrderRepository;
    }

    @Transactional
    public void makePurchase(String customerEmail, String productReference, Integer quantity) throws Exception, EntityNotFoundException {
        Customer customer = customerRepository.findById(customerEmail)
                .orElseThrow(() -> new EntityNotFoundException("Customer not found with email '" + customerEmail + "'"));

        Product product = productRepository.findById(productReference)
                .orElseThrow(() -> new EntityNotFoundException("Product not found with reference '" + productReference + "'"));

        if (product.getStockQuantity() < quantity) {
            throw new Exception("Insufficient stock for product with reference '" + productReference + "'");
        }

        float totalPrice = product.getPrice() * quantity;

        if (customer.getWallet() < totalPrice) {
            throw new Exception("Insufficient funds for customer with email '" + customerEmail + "'");
        }

        CustomerOrder existingCustomerOrder = customerOrderRepository.findByIdCustomerAndIdProduct(customer, product)
                .orElse(null);

        product.decreaseStockQuantity(quantity);
        productRepository.save(product);

        customer.deductFromWallet(totalPrice);
        customerRepository.save(customer);

        if (existingCustomerOrder != null) {
            existingCustomerOrder.setOrderedQuantity(existingCustomerOrder.getOrderedQuantity() + quantity);
            existingCustomerOrder.setTotalPayed(existingCustomerOrder.getTotalPayed() + totalPrice);
            customerOrderRepository.save(existingCustomerOrder);
        } else {
            CustomerOrder customerOrder = new CustomerOrder(customer, product);
            customerOrder.setOrderedQuantity(quantity);
            customerOrder.setTotalPayed(totalPrice);
            customerOrder.setOrderStatus("Completed");
            customerOrderRepository.save(customerOrder);
        }
    }
}