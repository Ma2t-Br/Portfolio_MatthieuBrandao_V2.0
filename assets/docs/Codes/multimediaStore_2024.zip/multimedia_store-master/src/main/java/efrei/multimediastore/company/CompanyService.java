package efrei.multimediastore.company;

import jakarta.persistence.EntityExistsException;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class CompanyService {

    private final CompanyRepository companyRepository;

    @Autowired
    public CompanyService(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;
    }

    @Transactional(readOnly = true)
    public List<Company> getAllCompanies() {
        return companyRepository.findAll();
    }

    @Transactional
    public void addNewCompany(Company company) throws EntityExistsException{
        boolean companyExists = companyRepository.existsById(company.getCompanyName());

        if (companyExists) {
            throw new EntityExistsException("Company with name '" + company.getCompanyName() + "' already exists");
        }

        companyRepository.save(company);
    }

    @Transactional(readOnly = true)
    public Company getCompanyByName(String name) throws EntityNotFoundException {
        return companyRepository.findById(name)
                .orElseThrow(() -> new EntityNotFoundException("Company with name '" + name + "' doesn't exist"));
    }

    @Transactional
    public void deleteCompanyByName(String name) {
        companyRepository.deleteById(name);
    }
}
