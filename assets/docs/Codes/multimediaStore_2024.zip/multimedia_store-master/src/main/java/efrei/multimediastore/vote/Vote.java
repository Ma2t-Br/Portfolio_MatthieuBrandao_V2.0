package efrei.multimediastore.vote;

import jakarta.persistence.*;

@Entity
@Table(name = "VOTE")
public class Vote {

    @EmbeddedId
    private VotePrimaryKey id;

    public Vote() {

    }

    public VotePrimaryKey getId() {
        return id;
    }

    public void setId(VotePrimaryKey id) {
        this.id = id;
    }

}
