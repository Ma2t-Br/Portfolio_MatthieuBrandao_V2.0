package efrei.multimediastore.email;

import efrei.multimediastore.company.Company;
import efrei.multimediastore.company.CompanyRepository;
import efrei.multimediastore.customer.Customer;
import efrei.multimediastore.customer.CustomerRepository;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Value("${spring.mail.username}")
    private String webMasterEmail;

    private final JavaMailSender emailSender;
    private final CustomerRepository customerRepository;
    private final CompanyRepository companyRepository;

    @Autowired
    public EmailService(JavaMailSender emailSender,
                        CustomerRepository customerRepository,
                        CompanyRepository companyRepository) {
        this.emailSender = emailSender;
        this.customerRepository = customerRepository;
        this.companyRepository = companyRepository;
    }

    public void sendEmailToCompany(String customerEmail, String companyName, EmailRequest emailRequest) throws MessagingException, EntityNotFoundException {
        Customer customer = customerRepository.findById(customerEmail)
                .orElseThrow(() -> new EntityNotFoundException("Customer not found with email '" + customerEmail + "'"));

        Company company = companyRepository.findById(companyName)
                .orElseThrow(() -> new EntityNotFoundException("Company not found with name '" + companyName + "'"));

        this.sendEmail(customer.getEmail(), company.getEmail(), emailRequest);
    }

    public void sendEmailToWebMaster(String customerEmail, EmailRequest emailRequest) throws MessagingException {
        Customer customer = customerRepository.findById(customerEmail)
                .orElseThrow(() -> new EntityNotFoundException("Customer not found with email '" + customerEmail + "'"));

        this.sendEmail(customer.getEmail(), webMasterEmail, emailRequest);
    }

    private void sendEmail(String from, String to, EmailRequest emailRequest) throws MessagingException, EntityNotFoundException {
        MimeMessage message = emailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);
        helper.setFrom(from);
        helper.setTo(to);
        helper.setSubject(emailRequest.getSubject());
        helper.setText(emailRequest.getText(), true);
        emailSender.send(message);
    }
}
