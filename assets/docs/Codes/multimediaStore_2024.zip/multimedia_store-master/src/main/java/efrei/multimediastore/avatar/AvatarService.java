package efrei.multimediastore.avatar;

import jakarta.persistence.EntityNotFoundException;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Service
public class AvatarService {

    private final String UPLOAD_DIR = System.getProperty("user.dir") + "/avatars/images";

    public Resource getAvatarByFileName(String fileName) throws IOException, EntityNotFoundException {
        System.out.println(fileName);
        Path filePath = Paths.get(UPLOAD_DIR).resolve(fileName);
        System.out.println(filePath.toAbsolutePath());
        Resource resource = new UrlResource(filePath.toUri());

        if (resource.exists() || resource.isReadable()) {
            return resource;
        } else {
            throw new EntityNotFoundException("Avatar '" + fileName + "' not found");
        }
    }

    public String uploadFile(MultipartFile file) throws IOException {
        String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();

        Path uploadPath = Paths.get(UPLOAD_DIR);
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        Path filePath = uploadPath.resolve(fileName);
        Files.copy(file.getInputStream(), filePath);

        return fileName;
    }
}