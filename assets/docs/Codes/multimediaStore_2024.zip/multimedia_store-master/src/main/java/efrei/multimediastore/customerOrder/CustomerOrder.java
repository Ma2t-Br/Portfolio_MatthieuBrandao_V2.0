package efrei.multimediastore.customerOrder;

import efrei.multimediastore.customer.Customer;
import efrei.multimediastore.product.Product;
import jakarta.persistence.*;

@Entity
@Table(name = "CUSTOMER_ORDER")
public class CustomerOrder {

    @EmbeddedId
    private CustomerOrderPrimaryKey id;

    @Column(name = "ordered_quantity")
    private int orderedQuantity;

    @Column(name = "order_status")
    private String orderStatus;

    @Column(name = "total_payed")
    private Float totalPayed;

    public CustomerOrder(Customer customer, Product product) {
        this.id = new CustomerOrderPrimaryKey();
        this.id.setCustomer(customer);
        this.id.setProduct(product);
    }

    public CustomerOrder() {

    }
    public Customer getCustomer() {
        return id.getCustomer();
    }

    public int getOrderedQuantity() {
        return orderedQuantity;
    }

    public void setOrderedQuantity(int orderedQuantity) {
        this.orderedQuantity = orderedQuantity;
    }

    public Product getProduct() {
        return id.getProduct();
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Float getTotalPayed() {
        return totalPayed;
    }

    public void setTotalPayed(Float totalPayed) {
        this.totalPayed = totalPayed;
    }
}
