package efrei.multimediastore.vote;

import efrei.multimediastore.customer.Customer;
import efrei.multimediastore.customer.CustomerRepository;
import efrei.multimediastore.product.Product;
import efrei.multimediastore.product.ProductRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
public class VoteService {

    private final VoteRepository voteRepository;
    private final CustomerRepository customerRepository;
    private final ProductRepository productRepository;


    @Autowired
    public VoteService(VoteRepository voteRepository,
                       CustomerRepository customerRepository,
                       ProductRepository productRepository) {
        this.voteRepository = voteRepository;
        this.customerRepository = customerRepository;
        this.productRepository = productRepository;
    }

    @Transactional
    public Integer countVotesByProductReference(String productReference) throws EntityNotFoundException {
        Product product = productRepository.findById(productReference)
                .orElseThrow(() -> new EntityNotFoundException("Product with reference '" + productReference + "' doesn't exist"));

        return voteRepository.countAllByIdProduct(product);
    }

    @Transactional
    public void likeProduct(String productReference, String customerEmail) throws EntityNotFoundException {
        Customer customer = customerRepository.findById(customerEmail)
                .orElseThrow(() -> new EntityNotFoundException("Customer with email '" + customerEmail + "' doesn't exist"));

        Product product = productRepository.findById(productReference)
                .orElseThrow(() -> new EntityNotFoundException("Product with reference '" + productReference + "' doesn't exist"));

        Vote vote = new Vote();
        vote.setId(new VotePrimaryKey(product, customer));
        voteRepository.save(vote);

    }

    @Transactional
    public void dislikeProduct(String productReference, String customerEmail) throws EntityNotFoundException {
        Customer customer = customerRepository.findById(customerEmail)
                .orElseThrow(() -> new EntityNotFoundException("Customer with email '" + customerEmail + "' doesn't exist"));

        Product product = productRepository.findById(productReference)
                .orElseThrow(() -> new EntityNotFoundException("Product with reference '" + productReference + "' doesn't exist"));

        Vote vote = voteRepository.findById(new VotePrimaryKey(product, customer))
                .orElseThrow(() -> new EntityNotFoundException("Vote doesn't exist"));

        voteRepository.delete(vote);
    }

    @Transactional
    public Boolean existsByProductAndCustomer(String productReference, String customerEmail) throws EntityNotFoundException {
        Customer customer = customerRepository.findById(customerEmail)
                .orElseThrow(() -> new EntityNotFoundException("Customer with email '" + customerEmail + "' doesn't exist"));

        Product product = productRepository.findById(productReference)
                .orElseThrow(() -> new EntityNotFoundException("Product with reference '" + productReference + "' doesn't exist"));

        return voteRepository.existsByIdProductAndIdCustomer(product, customer);

    }
}
