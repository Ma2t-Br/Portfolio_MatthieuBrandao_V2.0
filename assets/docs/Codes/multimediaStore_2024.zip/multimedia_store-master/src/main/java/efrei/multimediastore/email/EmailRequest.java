package efrei.multimediastore.email;

public class EmailRequest {

    private String subject;
    private String text;

    public String getSubject() {
        return subject;
    }

    public String getText() {
        return text;
    }
}
