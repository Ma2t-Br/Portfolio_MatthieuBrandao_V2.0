package efrei.multimediastore.vote;

import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("multimediastore/votes")
public class VoteController {

    private final VoteService voteService;

    @Autowired
    public VoteController(VoteService voteService) {
        this.voteService = voteService;
    }

    @GetMapping("/{productReference}/{customerEmail}")
    public ResponseEntity<Boolean> getVoteByProductReferenceAndCustomerEmail(
            @PathVariable("productReference") String productReference,
            @PathVariable("customerEmail") String customerEmail) {

        try {
            Boolean exist = voteService.existsByProductAndCustomer(productReference, customerEmail);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(exist);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(false);
        }

    }

    @GetMapping("/{productReference}/count")
    public ResponseEntity<Integer> countVotesByProductReference(@PathVariable("productReference") String productReference) {
        try {
            Integer voteCount = voteService.countVotesByProductReference(productReference);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(voteCount);

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(0);
        }
    }

    @PostMapping("/{productReference}/{customerEmail}")
    public ResponseEntity<String> likeProduct(@PathVariable("productReference") String productReference,
                                              @PathVariable("customerEmail") String customerEmail) {

        try {
            voteService.likeProduct(productReference, customerEmail);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Successfully liked");
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @DeleteMapping("/{productReference}/{customerEmail}")
    public ResponseEntity<String> dislikeProduct(@PathVariable("productReference") String productReference,
                                                 @PathVariable("customerEmail") String customerEmail) {


        try {
            voteService.dislikeProduct(productReference, customerEmail);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Successfully disliked");
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}
