package efrei.multimediastore.customerOrder;

import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/multimediastore/customer-orders")
public class CustomerOrderController {

    private final CustomerOrderService customerOrderService;

    @Autowired
    public CustomerOrderController(CustomerOrderService customerOrderService) {
        this.customerOrderService = customerOrderService;
    }

    @GetMapping("/all")
    public ResponseEntity<List<CustomerOrder>> getAllCustomerOrders() {
        List<CustomerOrder> customerOrders = customerOrderService.getAllCustomerOrders();
        return ResponseEntity.status(HttpStatus.OK)
                .body(customerOrders);
    }

    @GetMapping("/customer/{customerEmail}")
    public ResponseEntity<List<CustomerOrder>> getCustomerOrdersByCustomerId(@PathVariable String customerEmail) {
        try {
            List<CustomerOrder> customerOrders = customerOrderService.getCustomerOrderByCustomer(customerEmail);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(customerOrders);

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    @GetMapping("/customer/{customerEmail}/{productReference}")
    public ResponseEntity<CustomerOrder> getCustomerOrdersByCustomerIdAndProductReference(
            @PathVariable String customerEmail,
            @PathVariable String productReference) {

        try {
            CustomerOrder customerOrder = customerOrderService.getCustomerOrderByCustomerAndProduct(customerEmail, productReference);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(customerOrder);

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(null);
        }
    }


    @DeleteMapping("/customer/{customerEmail}")
    public ResponseEntity<String> deleteCustomerOrderByCustomer(@PathVariable String customerEmail) {
        try {
            customerOrderService.deleteCustomerOrderByCustomer(customerEmail);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Customer orders for customer email " + customerEmail + " have been deleted");

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }

    @DeleteMapping("/customer/{customerEmail}/{productReference}")
    public ResponseEntity<String> deleteCustomerOrderByCustomer(
            @PathVariable String customerEmail,
            @PathVariable String productReference) {
        try {
            customerOrderService.deleteCustomerOrderByCustomerAndProduct(customerEmail, productReference);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Customer order for customer email " + customerEmail +
                            " and product with reference " + productReference + " has been deleted");

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }
}
