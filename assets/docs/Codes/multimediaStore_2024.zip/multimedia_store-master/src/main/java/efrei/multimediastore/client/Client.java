package efrei.multimediastore.client;

import jakarta.persistence.*;

@Entity
@Table(name = "CLIENT")
public class Client {
    @Id
    @Column(name = "client_email", unique = true)
    private String email;

    @Column(name = "password")
    private String password;

    @Column(name = "client_role", nullable = false, columnDefinition = "VARCHAR(255) DEFAULT 'CUSTOMER'")
    private String clientRole;

    @Column(name = "validated_by_admin", nullable = false, columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean validatedByAdmin;

    @Column(name = "banned_by_admin", nullable = false, columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean bannedByAdmin;


    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String passwordHash) {
        this.password = passwordHash;
    }

    public String getClientRole() {
        return clientRole;
    }

    public boolean isValidatedByAdmin() {
        return validatedByAdmin;
    }

    public void setValidatedByAdmin(boolean validatedByAdmin) {
        this.validatedByAdmin = validatedByAdmin;
    }

    public boolean isBannedByAdmin() {
        return bannedByAdmin;
    }

    public void setBannedByAdmin(boolean bannedByAdmin) {
        this.bannedByAdmin = bannedByAdmin;
    }

    public void setClientRole(String clientRole) {
        this.clientRole = clientRole;
    }
}
