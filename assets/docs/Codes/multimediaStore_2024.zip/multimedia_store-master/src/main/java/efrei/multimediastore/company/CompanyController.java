package efrei.multimediastore.company;

import jakarta.persistence.EntityExistsException;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("multimediastore/companies")
public class CompanyController {

    private final CompanyService companyService;

    @Autowired
    public CompanyController(CompanyService companyService) {
        this.companyService = companyService;
    }

    @GetMapping("/all")
    public ResponseEntity<List<Company>> getAllCompanies() {
        List<Company> companies = companyService.getAllCompanies();
        return ResponseEntity.status(HttpStatus.OK)
                .body(companies);
    }

    @PostMapping("")
    public ResponseEntity<String> saveNewCompany(@RequestBody Company company) {
        try {
            companyService.addNewCompany(company);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body("Company '" + company.getCompanyName() + "' has been created successfully");

        } catch (EntityExistsException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(e.getMessage());
        }
    }

    @GetMapping("/{name}")
    public ResponseEntity<Company> getCompanyByName(@PathVariable String name) {
        try {
            Company company = companyService.getCompanyByName(name);
            return new ResponseEntity<>(company, HttpStatus.OK);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    @DeleteMapping("/{name}")
    public ResponseEntity<String> deleteCompanyByName(@PathVariable String name) {
        try {
            companyService.deleteCompanyByName(name);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Company '" + name + "' deleted successfully");

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}