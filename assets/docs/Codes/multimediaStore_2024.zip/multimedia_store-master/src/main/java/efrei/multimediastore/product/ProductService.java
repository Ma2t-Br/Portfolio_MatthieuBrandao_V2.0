package efrei.multimediastore.product;
import jakarta.persistence.EntityExistsException;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    @Autowired
    public ProductService(ProductRepository productRepository){
        this.productRepository = productRepository;
    }

    @Transactional(readOnly = true)
    public List<Product> getProducts(){
        return productRepository.findAll();
    }

    @Transactional(readOnly = true)
    public List<Product> getProductsByCategory(String category) {
        return productRepository.findByCategoryName(category);
    }

    @Transactional(readOnly = true)
    public List<String> getAllCategories() {
        return productRepository.findAllCategoryNames();
    }


    @Transactional(readOnly = true)
    public Product getProductByReference(String productReference) throws EntityNotFoundException {
        return productRepository.findById(productReference)
                .orElseThrow(() -> new EntityNotFoundException("Product with reference '" + productReference + "' doesn't exist"));
    }

    @Transactional(readOnly = true)
    public Product getProductByCategoryAndReference(String category, String productReference) throws EntityNotFoundException {
        return productRepository.findByCategoryNameAndProductReference(category, productReference)
                .orElseThrow(() -> new EntityNotFoundException("Product with reference '" + productReference + "'" +
                        "and category '" + category + "' doesn't exist"));
    }

    @Transactional()
    public void addNewProduct(Product product) throws EntityExistsException {
        boolean productExists = productRepository
                .existsById(product.getProductReference());

        if (productExists) {
            throw new EntityExistsException("Product with reference '" + product.getProductReference() + "' already exists");
        }
        productRepository.save(product);
    }

    @Transactional()
    public void deleteProduct(String productReference) throws Exception {
        Product product = getProductByReference(productReference);

        if (product.getStockQuantity() > 0)
            throw new Exception("Product with reference '" + productReference + "' cannot be deleted " +
                    "because it has " + product.getStockQuantity() + " stock quantity");

        productRepository.delete(product);
    }

    @Transactional
    public void updateProductPrice(String productReference, float newPrice) throws EntityNotFoundException {
        Product product = getProductByReference(productReference);

        product.setPrice(newPrice);
        productRepository.save(product);
    }

    @Transactional
    public void increaseStockQuantity(String productReference, int quantityToAdd) throws EntityNotFoundException{
        Product product = getProductByReference(productReference);

        product.increaseStockQuantity(quantityToAdd);
        productRepository.save(product);
    }
}