package efrei.multimediastore.sellOrder;

import efrei.multimediastore.company.Company;
import efrei.multimediastore.customer.Customer;
import efrei.multimediastore.product.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SellOrderRepository extends JpaRepository<SellOrder, SellOrderPrimaryKey> {


    List<SellOrder> findAllByIdCustomer(Customer customer);

    Optional<SellOrder> findByIdCustomerAndIdCompanyAndIdProductName(Customer customer, Company company, String productName);
}
