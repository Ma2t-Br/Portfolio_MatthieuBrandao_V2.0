package efrei.multimediastore.note;


import efrei.multimediastore.company.Company;
import efrei.multimediastore.customer.Customer;
import jakarta.persistence.*;

@Entity
@Table(name = "NOTE")
public class Note {

    @EmbeddedId
    private NotePrimaryKey id;

    @Column(name = "note_value")
    private float noteValue;

    public Note(Customer customer, Company company) {
        this.id = new NotePrimaryKey();
        this.id.setCustomer(customer);
        this.id.setCompany(company);
    }

    public Note() {

    }

    public Company getCompany() {
        return id.getCompany();
    }

    public void setCompany(Company company) {
        this.id.setCompany(company);
    }

    public Customer getCustomer() {
        return id.getCustomer();
    }

    public void setCustomer(Customer customer) {
        this.id.setCustomer(customer);
    }

    public float getNoteValue() {
        return noteValue;
    }

    public void setNoteValue(float noteValue) {
        this.noteValue = noteValue;
    }
}
