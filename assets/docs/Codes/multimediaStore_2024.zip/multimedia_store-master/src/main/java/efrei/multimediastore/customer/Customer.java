package efrei.multimediastore.customer;

import jakarta.persistence.*;

@Entity
@Table(name = "CUSTOMER")
public class Customer {
    @Id
    @Column(name = "customer_email", unique = true)
    private String email;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "address")
    private String address;

    @Column(name = "wallet")
    private float wallet = 50f;

    @Column(name = "avatar")
    private String avatar;

    public Customer() {

    }

    public String getEmail() {
        return email;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getAddress() {
        return address;
    }

    public float getWallet() {
        return wallet;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void deductFromWallet(float amount) {
        this.wallet -= amount;
    }

    public void addToWallet(float amount) {
        this.wallet += amount;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }
}
