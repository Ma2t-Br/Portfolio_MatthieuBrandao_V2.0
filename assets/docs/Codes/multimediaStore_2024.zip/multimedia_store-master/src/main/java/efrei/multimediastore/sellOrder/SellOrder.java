package efrei.multimediastore.sellOrder;

import efrei.multimediastore.company.Company;
import efrei.multimediastore.customer.Customer;
import jakarta.persistence.*;

@Entity
@Table(name = "SELL_ORDER")
public class SellOrder {

    @EmbeddedId
    private SellOrderPrimaryKey id;

    @Column(name = "sold_quantity")
    private int soldQuantity;

    @Column(name = "total_price")
    private Float totalPrice;

    public SellOrder(Customer customer, Company company, String productName) {
        this.id = new SellOrderPrimaryKey();
        this.id.setCustomer(customer);
        this.id.setCompany(company);
        this.id.setProductName(productName);
    }

    public SellOrder() {

    }

    public Company getCompany() {
        return id.getCompany();
    }

    public void setCompany(Company company) {
        this.id.setCompany(company);
    }

    public Customer getCustomer() {
        return id.getCustomer();
    }

    public void setCustomer(Customer customer) {
        this.id.setCustomer(customer);
    }

    public String getProductName() {
        return id.getProductName();
    }

    public void setProductName(String productName) {
        this.id.setProductName(productName);
    }

    public Float getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Float totalPrice) {
        this.totalPrice = totalPrice;
    }

    public int getSoldQuantity() {
        return soldQuantity;
    }

    public void setSoldQuantity(int soldQuantity) {
        this.soldQuantity = soldQuantity;
    }
}