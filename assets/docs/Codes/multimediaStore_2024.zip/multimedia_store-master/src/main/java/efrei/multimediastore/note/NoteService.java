package efrei.multimediastore.note;

import efrei.multimediastore.company.Company;
import efrei.multimediastore.company.CompanyRepository;
import efrei.multimediastore.customer.Customer;
import efrei.multimediastore.customer.CustomerRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class NoteService {

    private final NoteRepository noteRepository;
    private final CompanyRepository companyRepository;
    private final CustomerRepository customerRepository;

    @Autowired
    public NoteService(NoteRepository noteRepository,
                       CompanyRepository companyRepository,
                       CustomerRepository customerRepository) {
        this.noteRepository = noteRepository;
        this.companyRepository = companyRepository;
        this.customerRepository = customerRepository;
    }

    @Transactional(readOnly = true)
    public List<Note> getAllNotes() {
        return noteRepository.findAll();
    }

    @Transactional
    public void noteCompany(String companyName, String customerEmail, float noteValue) throws EntityNotFoundException {
        Company company = companyRepository.findById(companyName)
                .orElseThrow(() -> new EntityNotFoundException("Company not found with name: " + companyName));

        Customer customer = customerRepository.findById(customerEmail)
                .orElseThrow(() -> new EntityNotFoundException("Customer not found with email: " + customerEmail));

        Note existingNote = noteRepository.findByIdCompanyAndIdCustomer(company, customer).orElse(null);

        if (existingNote != null) {
            existingNote.setNoteValue(noteValue);
            noteRepository.save(existingNote);
        } else {
            Note newNote = new Note(customer, company);
            newNote.setNoteValue(noteValue);
            noteRepository.save(newNote);
        }
    }

    @Transactional(readOnly = true)
    public List<Note> getNoteByCompany(String companyName) throws EntityNotFoundException{
        Company company = companyRepository.findById(companyName)
                .orElseThrow(() -> new EntityNotFoundException("Company not found with name '" + companyName + "'"));

        return noteRepository.findAllByIdCompany(company);
    }

    @Transactional(readOnly = true)
    public List<Note> getNoteByCustomer(String customerEmail) throws EntityNotFoundException {
        Customer customer = customerRepository.findById(customerEmail)
                .orElseThrow(() -> new EntityNotFoundException("Customer not found with email '" + customerEmail + "'"));

        return noteRepository.findAllByIdCustomer(customer);
    }

    @Transactional(readOnly = true)
    public Note getNoteByCompanyAndCustomer(String companyName, String customerEmail) throws EntityNotFoundException {
        Company company = companyRepository.findById(companyName)
                .orElseThrow(() -> new EntityNotFoundException("Company not found with name '" + companyName + "'"));

        Customer customer = customerRepository.findById(customerEmail)
                .orElseThrow(() -> new EntityNotFoundException("Customer not found with email '" + customerEmail + "'"));

        return noteRepository.findByIdCompanyAndIdCustomer(company, customer)
                .orElseThrow(() -> new EntityNotFoundException("Note not found"));
    }
}
