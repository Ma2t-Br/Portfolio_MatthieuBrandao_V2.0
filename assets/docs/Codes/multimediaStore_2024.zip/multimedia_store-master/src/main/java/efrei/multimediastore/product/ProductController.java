package efrei.multimediastore.product;

import jakarta.persistence.EntityExistsException;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@RestController
@RequestMapping(path = "multimediastore/products")
public class ProductController {

    private final ProductService productService;

    @Autowired
    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @PostMapping("")
    public ResponseEntity<String> saveNewProduct(@RequestBody Product product) {
        try {
            productService.addNewProduct(product);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body("Product with reference '" + product.getProductReference() + "' has been created successfully");
        } catch (EntityExistsException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(e.getMessage());
        }
    }

    @GetMapping("/all")
    public ResponseEntity<List<Product>> getProducts(){
        List<Product> products = productService.getProducts();

        return ResponseEntity.status(HttpStatus.OK)
                .body(products);
    }

    @GetMapping("/allCategories")
    public ResponseEntity<List<String>> getAllCategories(){
        List<String> categories = productService.getAllCategories();

        return ResponseEntity.status(HttpStatus.OK)
                .body(categories);
    }

    @GetMapping("{categoryName}/all")
    public ResponseEntity<List<Product>> getProductsByCategory(@PathVariable String categoryName){
        List<Product> productsByCategory = productService.getProductsByCategory(categoryName);

        return ResponseEntity.status(HttpStatus.OK)
                .body(productsByCategory);
    }

    @GetMapping("{productReference}")
    public ResponseEntity<Product> getProductById(@PathVariable String productReference){
        try {
            Product product = productService.getProductByReference(productReference);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(product);

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(null);
        }
    }

    @GetMapping("{categoryName}/{productReference}")
    public ResponseEntity<Product> getProductByCategoryAndReference(
            @PathVariable String categoryName,
            @PathVariable String productReference){

        try {
            Product product = productService.getProductByCategoryAndReference(categoryName, productReference);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(product);

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(null);
        }
    }

    @PatchMapping("{productReference}/increase-stock-quantity")
    public ResponseEntity<String> updateStockQuantity(
            @PathVariable("productReference") String productReference,
            @RequestParam int quantity) {
        try {
            productService.increaseStockQuantity(productReference, quantity);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Product '" + productReference + "' stock quantity has been updated successfully");

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }

    @PatchMapping("{productReference}/update-price")
    public ResponseEntity<String> updatePrice(
            @PathVariable("productReference") String productReference,
            @RequestParam float price) {
        try {
            productService.updateProductPrice(productReference, price);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Product '" + productReference + "' price has been updated successfully");

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }

    @DeleteMapping("{productReference}")
    public ResponseEntity<String> deleteProduct(@PathVariable("productReference") String productReference){
        try {
            productService.deleteProduct(productReference);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Product '" + productReference + "' has been deleted successfully");

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
        catch (Exception e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(e.getMessage());
        }
    }
}
