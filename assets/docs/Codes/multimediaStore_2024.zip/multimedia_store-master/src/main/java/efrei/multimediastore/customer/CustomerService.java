package efrei.multimediastore.customer;

import jakarta.persistence.EntityExistsException;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;

    @Autowired
    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @Transactional(readOnly = true)
    public List<Customer> getCustomers() {
        return customerRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Customer getCustomerByEmail(String customerEmail) throws EntityNotFoundException {
        return customerRepository.findById(customerEmail)
                .orElseThrow(() -> new EntityNotFoundException("Customer with email '" + customerEmail + "' doesn't exist"));
    }

    @Transactional
    public void addNewCustomer(Customer customer) throws EntityExistsException {
        boolean customerExists = customerRepository.existsByEmail(customer.getEmail());

        if (customerExists) {
            throw new EntityExistsException("Customer with email '" + customer.getEmail() + "' already exists");
        }

        customerRepository.save(customer);
    }

    @Transactional
    public void deleteCustomer(String customerEmail) {
        Customer customer = getCustomerByEmail(customerEmail);
        customerRepository.delete(customer);
    }

    @Transactional
    public void updateInformation(String customerEmail, String lastName, String firstName, String address, String avatar) {
        Customer customer = getCustomerByEmail(customerEmail);

        if (lastName != null && !Objects.equals(customer.getLastName(), lastName))
            customer.setLastName(lastName);

        if (firstName != null && !Objects.equals(customer.getFirstName(), firstName))
            customer.setFirstName(firstName);

        if (address != null && !Objects.equals(customer.getAddress(), address))
            customer.setAddress(address);

        if (avatar != null && !Objects.equals(customer.getAvatar(), avatar))
            customer.setAvatar(avatar);

        customerRepository.save(customer);
    }
}
