package efrei.multimediastore.customerOrder;

import efrei.multimediastore.customer.Customer;
import efrei.multimediastore.customer.CustomerRepository;
import efrei.multimediastore.product.Product;
import efrei.multimediastore.product.ProductRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class CustomerOrderService {

    private final CustomerOrderRepository customerOrderRepository;
    private final CustomerRepository customerRepository;
    private final ProductRepository productRepository;

    @Autowired
    public CustomerOrderService(CustomerOrderRepository customerOrderRepository,
                                CustomerRepository customerRepository,
                                ProductRepository productRepository){
        this.customerOrderRepository = customerOrderRepository;
        this.customerRepository = customerRepository;
        this.productRepository = productRepository;
    }

    @Transactional(readOnly = true)
    public List<CustomerOrder> getAllCustomerOrders() {
        return customerOrderRepository.findAll();
    }


    @Transactional(readOnly = true)
    public List<CustomerOrder> getCustomerOrderByCustomer(String customerEmail) throws EntityNotFoundException {
        Customer customer = customerRepository.findById(customerEmail)
                .orElseThrow(() -> new EntityNotFoundException("Customer with email '" + customerEmail + "' doesn't exist"));

        return customerOrderRepository.findAllByIdCustomer(customer);
    }

    @Transactional(readOnly = true)
    public CustomerOrder getCustomerOrderByCustomerAndProduct(String clientEmail, String productReference) throws EntityNotFoundException {
        Customer customer = customerRepository.findById(clientEmail)
                .orElseThrow(() -> new EntityNotFoundException("Customer with email '" + clientEmail + "' doesn't exist"));

        Product product = productRepository.findById(productReference)
                .orElseThrow(() -> new EntityNotFoundException("Product with reference '" + productReference + "' doesn't exist"));

        return customerOrderRepository.findByIdCustomerAndIdProduct(customer, product).orElse(null);
    }

    @Transactional
    public void deleteCustomerOrderByCustomer(String clientEmail) throws EntityNotFoundException {
        Customer customer = customerRepository.findById(clientEmail)
                .orElseThrow(() -> new EntityNotFoundException("Customer with email '" + clientEmail + "' doesn't exist"));

        customerOrderRepository.deleteByIdCustomer(customer);
    }

    @Transactional(readOnly = true)
    public void deleteCustomerOrderByCustomerAndProduct(String clientEmail, String productReference) throws EntityNotFoundException {
        Customer customer = customerRepository.findById(clientEmail)
                .orElseThrow(() -> new EntityNotFoundException("Customer with email '" + clientEmail + "' doesn't exist"));

        Product product = productRepository.findById(productReference)
                .orElseThrow(() -> new EntityNotFoundException("Product with reference '" + productReference + "' doesn't exist"));

        customerOrderRepository.deleteByIdCustomerAndIdProduct(customer, product);
    }
}
