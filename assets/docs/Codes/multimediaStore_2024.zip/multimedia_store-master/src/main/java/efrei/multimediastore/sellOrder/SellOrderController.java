package efrei.multimediastore.sellOrder;

import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("multimediastore/sell-orders")
public class SellOrderController {

    private final SellOrderService sellOrderService;

    @Autowired
    public SellOrderController(SellOrderService sellOrderService) {
        this.sellOrderService = sellOrderService;
    }

    @GetMapping("/customer/{customerEmail}")
    public ResponseEntity<List<SellOrder>> getCustomerOrdersByCustomerId(@PathVariable String customerEmail) {
        try {
            List<SellOrder> customerOrders = sellOrderService.getSellOrdersByCustomerEmail(customerEmail);
            return ResponseEntity.status(HttpStatus.OK)
                    .body(customerOrders);

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
}
