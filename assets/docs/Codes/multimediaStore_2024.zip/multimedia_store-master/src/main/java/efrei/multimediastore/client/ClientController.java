package efrei.multimediastore.client;

import efrei.multimediastore.email.EmailRequest;
import efrei.multimediastore.email.EmailService;
import jakarta.mail.MessagingException;
import jakarta.persistence.EntityExistsException;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.NoSuchAlgorithmException;
import java.util.List;

@RestController
@RequestMapping("multimediastore/clients")
public class ClientController {

    private final ClientService clientService;
    private final EmailService emailService;

    @Autowired
    public ClientController(ClientService clientService,
                            EmailService emailService) {
        this.clientService = clientService;
        this.emailService = emailService;
    }

    @PostMapping("")
    public ResponseEntity<String> saveNewClient(@RequestBody Client client) {
        try {
            clientService.addNewClient(client);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body("Client has been created successfully");

        } catch (NoSuchAlgorithmException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred while creating the client: " + e.getMessage());
        } catch (EntityExistsException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(e.getMessage());
        }
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginRequest loginRequest) {
        try {
            return clientService.login(loginRequest);
        } catch (NoSuchAlgorithmException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred while trying to login: " + e.getMessage());

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }

    @PostMapping("{customerEmail}/contact_web_master")
    public ResponseEntity<String> sendEmailToCompany(
            @PathVariable String customerEmail,
            @RequestBody EmailRequest emailRequest) {

        String webMasterEmail = "multimediastore.efrei@gmail.com";
        try {
            emailService.sendEmailToWebMaster(customerEmail, emailRequest);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Email sent successfully");

        } catch (MessagingException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred while trying to send an email '" + webMasterEmail + "'" +
                            "from '" + customerEmail + "': " + e.getMessage());
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }

    @GetMapping("/all")
    public ResponseEntity<List<Client>> getClients(){
        List<Client> clients = clientService.getClients();
        return ResponseEntity.status(HttpStatus.OK)
                .body(clients);
    }

    @GetMapping("{clientEmail}")
    public ResponseEntity<Client> getClientById(@PathVariable String clientEmail){
        try {
            Client client = clientService.getClientById(clientEmail);
            return ResponseEntity.status(HttpStatus.OK).body(client);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(null);
        }
    }

    @PatchMapping("{clientEmail}/validate")
    public ResponseEntity<String> validateClient(@PathVariable String clientEmail){
        try {
            clientService.validateClient(clientEmail);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Client '" + clientEmail + "' has been validated successfully");

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }

    @PatchMapping("{clientEmail}/ban")
    public ResponseEntity<String> banClient(@PathVariable String clientEmail){
        try {
            clientService.banClient(clientEmail);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Client '" + clientEmail + "' has been banned successfully");

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }

    @PatchMapping("{clientEmail}/unban")
    public ResponseEntity<String> unbanClient(@PathVariable String clientEmail){
        try {
            clientService.unbanClient(clientEmail);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Client '" + clientEmail + "' has been unbanned successfully");

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }

    @PatchMapping("{clientEmail}/reset_password")
    public ResponseEntity<String> resetPassword(@PathVariable String clientEmail, @RequestParam String newPassword){
        try {
            clientService.resetPassword(clientEmail, newPassword);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Client '" + clientEmail + "' password has been reset successfully");

        } catch (NoSuchAlgorithmException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred while trying to reset password for '" + clientEmail + "': " + e.getMessage());

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }

    @PatchMapping("{clientEmail}")
    public ResponseEntity<String> updatePassword(@PathVariable String clientEmail,
            @RequestParam String oldPassword,
            @RequestParam String newPassword) {

        try {
            clientService.updatePassword(clientEmail, oldPassword, newPassword);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Client '" + clientEmail + "' password has been updated successfully");

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }

    @DeleteMapping(path ="{clientEmail}")
    public ResponseEntity<String> deleteClient(@PathVariable("clientEmail") String clientEmail) {
        try {
            clientService.deleteClient(clientEmail);
            return ResponseEntity.status(HttpStatus.OK)
                    .body("Client '" + clientEmail + "' has been deleted successfully");

        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }
}