package efrei.multimediastore.note;

import efrei.multimediastore.company.Company;
import efrei.multimediastore.customer.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface NoteRepository extends JpaRepository<Note, Long> {

    Optional<Note> findByIdCompanyAndIdCustomer(Company company, Customer customer);

    List<Note> findAllByIdCompany(Company company);

    List<Note> findAllByIdCustomer(Customer customer);
}
