BEGIN;
DROP DATABASE IF EXISTS MULTIMEDIA_STORE;
CREATE DATABASE MULTIMEDIA_STORE;
USE MULTIMEDIA_STORE;
COMMIT;

BEGIN;
USE MULTIMEDIA_STORE;

CREATE TABLE CUSTOMER(
                         customer_email VARCHAR(255),
                         last_name VARCHAR(255),
                         first_name VARCHAR(255),
                         address VARCHAR(255),
                         wallet float DEFAULT 50,
                         avatar VARCHAR(255),
                         PRIMARY KEY (customer_email)
);
COMMIT;

BEGIN;
USE MULTIMEDIA_STORE;

CREATE TABLE COMPANY(
                        company_name VARCHAR(255),
                        phone_number VARCHAR(255),
                        address VARCHAR(255),
                        company_email VARCHAR(255),
                        PRIMARY KEY (company_name)
);
COMMIT;

BEGIN;
USE MULTIMEDIA_STORE;

CREATE TABLE PRODUCT(
                        product_reference VARCHAR(255),
                        company_name VARCHAR(255),
                        category_name VARCHAR(255),
                        product_name VARCHAR(255),
                        stock_quantity INT,
                        price FLOAT,
                        PRIMARY KEY (product_reference),
                        FOREIGN KEY (company_name) REFERENCES COMPANY(company_name)
);
COMMIT;

BEGIN;
USE MULTIMEDIA_STORE;

CREATE TABLE NOTE(
                     company_name VARCHAR(255),
                     customer_email VARCHAR(255),
                     note_value FLOAT,
                     PRIMARY KEY (company_name, customer_email),
                     FOREIGN KEY (company_name) REFERENCES COMPANY(company_name),
                     FOREIGN KEY (customer_email) REFERENCES CUSTOMER(customer_email)
);
COMMIT;

BEGIN;
USE MULTIMEDIA_STORE;

CREATE TABLE VOTE(
                     product_reference VARCHAR(255),
                     customer_email VARCHAR(255),
                     PRIMARY KEY (product_reference, customer_email),
                     FOREIGN KEY (product_reference) REFERENCES PRODUCT(product_reference),
                     FOREIGN KEY (customer_email) REFERENCES CUSTOMER(customer_email)
);
COMMIT;

BEGIN;
USE MULTIMEDIA_STORE;

CREATE TABLE CUSTOMER_ORDER(
                               customer_email VARCHAR(255),
                               product_reference VARCHAR(255),
                               ordered_quantity INT,
                               order_status VARCHAR(255),
                               total_payed FLOAT,
                               PRIMARY KEY (customer_email, product_reference),
                               FOREIGN KEY (customer_email) REFERENCES CUSTOMER(customer_email),
                               FOREIGN KEY (product_reference) REFERENCES PRODUCT(product_reference)
);
COMMIT;

BEGIN;
USE MULTIMEDIA_STORE;
CREATE TABLE SELL_ORDER(
                           company_name VARCHAR(255),
                           customer_email VARCHAR(255),
                           product_name VARCHAR(255),
                           sold_quantity INT,
                           total_price FLOAT,
                           PRIMARY KEY (company_name, customer_email, product_name),
                           FOREIGN KEY (company_name) REFERENCES COMPANY(company_name),
                           FOREIGN KEY (customer_email) REFERENCES CUSTOMER(customer_email)
);
COMMIT;

BEGIN;
USE MULTIMEDIA_STORE;

CREATE TABLE CLIENT (
                        client_email VARCHAR(255) UNIQUE,
                        password VARCHAR(255),
                        client_role VARCHAR(255) DEFAULT 'CUSTOMER',
                        validated_by_admin BOOLEAN DEFAULT FALSE,
                        banned_by_admin BOOLEAN DEFAULT FALSE,
                        PRIMARY KEY (client_email)
);
COMMIT;

BEGIN;
USE MULTIMEDIA_STORE;
INSERT INTO CLIENT (client_email, password, client_role, validated_by_admin, banned_by_admin)
VALUES ('multimediastore.efrei@gmail.com', 'jGl25bVBBBW96Qi9Te4V37Fnqchz/Eu4qB9vKrRIqRg=', 'ADMIN', true, false),
       ('john.doe@example.com', '8tgaJg3qihAN1ReYTlPFanUj2WlCqDS5zcJJvU6Meqk=', 'CUSTOMER', FALSE, FALSE),
       ('jane.smith@example.com', '8tgaJg3qihAN1ReYTlPFanUj2WlCqDS5zcJJvU6Meqk=', 'CUSTOMER', FALSE, FALSE),
       ('alice.jones@example.com', '8tgaJg3qihAN1ReYTlPFanUj2WlCqDS5zcJJvU6Meqk=', 'CUSTOMER', FALSE, FALSE),
       ('bob.brown@example.com', '8tgaJg3qihAN1ReYTlPFanUj2WlCqDS5zcJJvU6Meqk=', 'CUSTOMER', FALSE, FALSE),
       ('carol.white@example.com', '8tgaJg3qihAN1ReYTlPFanUj2WlCqDS5zcJJvU6Meqk=', 'CUSTOMER', FALSE, FALSE),
       ('dave.black@example.com', '8tgaJg3qihAN1ReYTlPFanUj2WlCqDS5zcJJvU6Meqk=', 'CUSTOMER', FALSE, FALSE),
       ('eve.green@example.com', '8tgaJg3qihAN1ReYTlPFanUj2WlCqDS5zcJJvU6Meqk=', 'CUSTOMER', FALSE, FALSE),
       ('frank.blue@example.com', '8tgaJg3qihAN1ReYTlPFanUj2WlCqDS5zcJJvU6Meqk=', 'CUSTOMER', FALSE, FALSE),
       ('grace.red@example.com', '8tgaJg3qihAN1ReYTlPFanUj2WlCqDS5zcJJvU6Meqk=', 'CUSTOMER', FALSE, FALSE),
       ('hank.yellow@example.com', '8tgaJg3qihAN1ReYTlPFanUj2WlCqDS5zcJJvU6Meqk=', 'CUSTOMER', FALSE, FALSE),
       ('felix.brinet@efrei.net', '8tgaJg3qihAN1ReYTlPFanUj2WlCqDS5zcJJvU6Meqk=','CUSTOMER',TRUE,FALSE);
COMMIT;


BEGIN;
USE MULTIMEDIA_STORE;

-- Insert companies
INSERT INTO COMPANY (company_name, phone_number, address, company_email) VALUES
     ('TechCorp', '123-456-7890', '123 Tech Street', 'contact@techcorp.com'),
     ('GadgetWorks', '234-567-8901', '456 Gadget Avenue', 'info@gadgetworks.com'),
     ('MediaMasters', '345-678-9012', '789 Media Blvd', 'support@mediamasters.com'),
     ('SoundWave', '456-789-0123', '101 Sound Lane', 'sales@soundwave.com'),
     ('Visionary', '567-890-1234', '202 Vision Road', 'contact@visionary.com'),
     ('GameZone', '678-901-2345', '303 Game Street', 'info@gamezone.com'),
     ('PhotoPro', '789-012-3456', '404 Photo Avenue', 'support@photopro.com'),
     ('BookBarn', '890-123-4567', '505 Book Blvd', 'sales@bookbarn.com'),
     ('MusicMania', '901-234-5678', '606 Music Lane', 'contact@musicmania.com'),
     ('FilmFactory', '012-345-6789', '707 Film Road', 'info@filmfactory.com');

-- Insert customers
INSERT INTO CUSTOMER (customer_email, last_name, first_name, address, wallet, avatar) VALUES
      ('john.doe@example.com', 'Doe', 'John', '123 Main St', 100, 'avatar1.png'),
      ('jane.smith@example.com', 'Smith', 'Jane', '456 Oak St', 150, 'avatar2.png'),
      ('alice.jones@example.com', 'Jones', 'Alice', '789 Pine St', 200, 'avatar3.png'),
      ('bob.brown@example.com', 'Brown', 'Bob', '101 Maple St', 250, 'avatar4.png'),
      ('carol.white@example.com', 'White', 'Carol', '202 Birch St', 300, 'avatar5.png'),
      ('dave.black@example.com', 'Black', 'Dave', '303 Cedar St', 350, 'avatar6.png'),
      ('eve.green@example.com', 'Green', 'Eve', '404 Elm St', 400, 'avatar7.png'),
      ('frank.blue@example.com', 'Blue', 'Frank', '505 Spruce St', 450, 'avatar8.png'),
      ('grace.red@example.com', 'Red', 'Grace', '606 Fir St', 500, 'avatar9.png'),
      ('hank.yellow@example.com', 'Yellow', 'Hank', '707 Willow St', 550, 'avatar10.png'),
      ('felix.brinet@efrei.net', 'Sissini','Enzo','12 rue des patates Villejuif 94800',1000,'avatar11.png');


-- Insert products
INSERT INTO PRODUCT (product_reference, company_name, category_name, product_name, stock_quantity, price) VALUES
      ('P001', 'TechCorp', 'Electronics', 'Smartphone', 100, 699.99),
      ('P002', 'GadgetWorks', 'Home Appliances', 'Vacuum Cleaner', 50, 199.99),
      ('P003', 'MediaMasters', 'Books', 'E-Reader', 200, 129.99),
      ('P004', 'SoundWave', 'Audio', 'Bluetooth Speaker', 150, 49.99),
      ('P005', 'Visionary', 'Cameras', 'Digital Camera', 75, 299.99),
      ('P006', 'GameZone', 'Gaming', 'Gaming Console', 80, 399.99),
      ('P007', 'PhotoPro', 'Photography', 'Tripod', 120, 79.99),
      ('P008', 'BookBarn', 'Literature', 'Novel', 300, 14.99),
      ('P009', 'MusicMania', 'Music', 'Guitar', 60, 499.99),
      ('P010', 'FilmFactory', 'Movies', 'Blu-ray Player', 90, 89.99);

-- Insert notes
INSERT INTO NOTE (company_name, customer_email, note_value) VALUES
    ('TechCorp', 'john.doe@example.com', 4.5),
    ('GadgetWorks', 'jane.smith@example.com', 9.5),
    ('MediaMasters', 'alice.jones@example.com', 5.0),
    ('SoundWave', 'bob.brown@example.com', 3.5),
    ('Visionary', 'carol.white@example.com', 6.5),
    ('GameZone', 'dave.black@example.com', 4.5),
    ('PhotoPro', 'eve.green@example.com', 4.5),
    ('BookBarn', 'frank.blue@example.com', 8.0),
    ('MusicMania', 'grace.red@example.com', 4.0),
    ('FilmFactory', 'hank.yellow@example.com', 7.5);

-- Insert votes
INSERT INTO VOTE (product_reference, customer_email) VALUES
     ('P001', 'john.doe@example.com'),
     ('P002', 'jane.smith@example.com'),
     ('P003', 'alice.jones@example.com'),
     ('P004', 'bob.brown@example.com'),
     ('P005', 'carol.white@example.com'),
     ('P006', 'dave.black@example.com'),
     ('P007', 'eve.green@example.com'),
     ('P008', 'frank.blue@example.com'),
     ('P009', 'grace.red@example.com'),
     ('P010', 'hank.yellow@example.com');

-- Insert customer orders
INSERT INTO CUSTOMER_ORDER (customer_email, product_reference, ordered_quantity, order_status, total_payed) VALUES
    ('john.doe@example.com', 'P001', 1, 'Shipped', 699.99),
    ('jane.smith@example.com', 'P002', 1, 'Delivered', 199.99),
    ('alice.jones@example.com', 'P003', 1, 'Processing', 129.99),
    ('bob.brown@example.com', 'P004', 2, 'Delivered', 99.98),
    ('carol.white@example.com', 'P005', 1, 'Shipped', 299.99),
    ('dave.black@example.com', 'P006', 1, 'Processing', 399.99),
    ('eve.green@example.com', 'P007', 1, 'Delivered', 79.99),
    ('frank.blue@example.com', 'P008', 3, 'Shipped', 44.97),
    ('grace.red@example.com', 'P009', 1, 'Processing', 499.99),
    ('hank.yellow@example.com', 'P010', 1, 'Delivered', 89.99);

-- Insert sell orders
INSERT INTO SELL_ORDER (company_name, customer_email, product_name, sold_quantity, total_price) VALUES
    ('TechCorp', 'john.doe@example.com', 'Smartphone', 1, 699.99),
    ('GadgetWorks', 'jane.smith@example.com', 'Vacuum Cleaner', 1, 199.99),
    ('MediaMasters', 'alice.jones@example.com', 'E-Reader', 1, 129.99),
    ('SoundWave', 'bob.brown@example.com', 'Bluetooth Speaker', 2, 99.98),
    ('Visionary', 'carol.white@example.com', 'Digital Camera', 1, 299.99),
    ('GameZone', 'dave.black@example.com', 'Gaming Console', 1, 399.99),
    ('PhotoPro', 'eve.green@example.com', 'Tripod', 1, 79.99),
    ('BookBarn', 'frank.blue@example.com', 'Novel', 3, 44.97),
    ('MusicMania', 'grace.red@example.com', 'Guitar', 1, 499.99),
    ('FilmFactory', 'hank.yellow@example.com', 'Blu-ray Player', 1, 89.99);

COMMIT;

BEGIN;
USE MULTIMEDIA_STORE;

-- Insert additional products
INSERT INTO PRODUCT (product_reference, company_name, category_name, product_name, stock_quantity, price) VALUES
      ('P011', 'TechCorp', 'Electronics', 'Laptop', 50, 999.99),
      ('P012', 'GadgetWorks', 'Home Appliances', 'Microwave Oven', 30, 149.99),
      ('P013', 'MediaMasters', 'Books', 'Tablet', 100, 199.99),
      ('P014', 'SoundWave', 'Audio', 'Headphones', 200, 29.99),
      ('P015', 'Visionary', 'Cameras', 'Action Camera', 40, 249.99),
      ('P016', 'GameZone', 'Gaming', 'Gaming Mouse', 150, 49.99),
      ('P017', 'PhotoPro', 'Photography', 'Camera Lens', 60, 399.99),
      ('P018', 'BookBarn', 'Literature', 'Science Fiction Novel', 300, 19.99),
      ('P019', 'MusicMania', 'Music', 'Drum Set', 20, 799.99),
      ('P020', 'FilmFactory', 'Movies', 'DVD Player', 70, 59.99),
      ('P021', 'TechCorp', 'Electronics', 'Smartwatch', 80, 199.99),
      ('P022', 'GadgetWorks', 'Home Appliances', 'Air Conditioner', 25, 499.99),
      ('P023', 'MediaMasters', 'Books', 'E-Book Reader', 120, 89.99),
      ('P024', 'SoundWave', 'Audio', 'Soundbar', 90, 129.99),
      ('P025', 'Visionary', 'Cameras', 'Camcorder', 35, 349.99),
      ('P026', 'GameZone', 'Gaming', 'Gaming Keyboard', 140, 69.99),
      ('P027', 'PhotoPro', 'Photography', 'Flash', 50, 99.99),
      ('P028', 'BookBarn', 'Literature', 'Mystery Novel', 250, 14.99),
      ('P029', 'MusicMania', 'Music', 'Electric Piano', 15, 999.99),
      ('P030', 'FilmFactory', 'Movies', 'Streaming Device', 60, 39.99),
      ('P031', 'TechCorp', 'Electronics', 'Tablet', 100, 299.99),
      ('P032', 'GadgetWorks', 'Home Appliances', 'Refrigerator', 20, 799.99),
      ('P033', 'MediaMasters', 'Books', 'Audio Book', 150, 29.99),
      ('P034', 'SoundWave', 'Audio', 'Home Theater System', 40, 499.99),
      ('P035', 'Visionary', 'Cameras', 'Mirrorless Camera', 30, 599.99),
      ('P036', 'GameZone', 'Gaming', 'VR Headset', 50, 399.99),
      ('P037', 'PhotoPro', 'Photography', 'Memory Card', 200, 19.99),
      ('P038', 'BookBarn', 'Literature', 'Historical Novel', 220, 24.99),
      ('P039', 'MusicMania', 'Music', 'Violin', 25, 499.99),
      ('P040', 'FilmFactory', 'Movies', 'Projector', 45, 299.99),
      ('P041', 'TechCorp', 'Electronics', 'Desktop Computer', 70, 899.99),
      ('P042', 'GadgetWorks', 'Home Appliances', 'Washing Machine', 15, 699.99),
      ('P043', 'MediaMasters', 'Books', 'Comic Book', 180, 9.99),
      ('P044', 'SoundWave', 'Audio', 'Turntable', 60, 199.99),
      ('P045', 'Visionary', 'Cameras', 'DSLR Camera', 25, 799.99),
      ('P046', 'GameZone', 'Gaming', 'Gaming Chair', 100, 149.99),
      ('P047', 'PhotoPro', 'Photography', 'Camera Bag', 80, 49.99),
      ('P048', 'BookBarn', 'Literature', 'Fantasy Novel', 270, 19.99),
      ('P049', 'MusicMania', 'Music', 'Saxophone', 20, 699.99),
      ('P050', 'FilmFactory', 'Movies', '4K Blu-ray Player', 50, 129.99),
      ('P051', 'TechCorp', 'Electronics', 'Smart TV', 40, 1199.99),
      ('P052', 'GadgetWorks', 'Home Appliances', 'Dishwasher', 18, 599.99),
      ('P053', 'MediaMasters', 'Books', 'Cookbook', 160, 29.99),
      ('P054', 'SoundWave', 'Audio', 'Wireless Earbuds', 150, 99.99),
      ('P055', 'Visionary', 'Cameras', 'Security Camera', 50, 149.99),
      ('P056', 'GameZone', 'Gaming', 'Gaming Monitor', 60, 299.99),
      ('P057', 'PhotoPro', 'Photography', 'Photo Printer', 30, 199.99),
      ('P058', 'BookBarn', 'Literature', 'Romance Novel', 240, 14.99),
      ('P059', 'MusicMania', 'Music', 'Keyboard', 35, 299.99),
      ('P060', 'FilmFactory', 'Movies', 'Media Player', 55, 49.99),
      ('P061', 'TechCorp', 'Electronics', 'Router', 90, 79.99),
      ('P062', 'GadgetWorks', 'Home Appliances', 'Coffee Maker', 70, 99.99),
      ('P063', 'MediaMasters', 'Books', 'Travel Guide', 130, 19.99),
      ('P064', 'SoundWave', 'Audio', 'Microphone', 110, 59.99),
      ('P065', 'Visionary', 'Cameras', 'Drone', 20, 499.99),
      ('P066', 'GameZone', 'Gaming', 'Game Controller', 120, 59.99),
      ('P067', 'PhotoPro', 'Photography', 'Lighting Kit', 40, 149.99),
      ('P068', 'BookBarn', 'Literature', 'Thriller Novel', 210, 19.99),
      ('P069', 'MusicMania', 'Music', 'Bass Guitar', 25, 599.99),
      ('P070', 'FilmFactory', 'Movies', 'Sound System', 35, 199.99),
      ('P071', 'TechCorp', 'Electronics', 'External Hard Drive', 80, 129.99),
      ('P072', 'GadgetWorks', 'Home Appliances', 'Blender', 60, 49.99),
      ('P073', 'MediaMasters', 'Books', 'Biography', 140, 24.99),
      ('P074', 'SoundWave', 'Audio', 'Portable Speaker', 100, 79.99),
      ('P075', 'Visionary', 'Cameras', 'Photo Frame', 50, 39.99),
      ('P076', 'GameZone', 'Gaming', 'Gaming Headset', 90, 79.99),
      ('P077', 'PhotoPro', 'Photography', 'Photo Album', 70, 29.99),
      ('P078', 'BookBarn', 'Literature', 'Poetry Book', 200, 14.99),
      ('P079', 'MusicMania', 'Music', 'Trumpet', 20, 499.99),
      ('P080', 'FilmFactory', 'Movies', 'Home Cinema System', 30, 399.99),
      ('P081', 'TechCorp', 'Electronics', 'Smart Home Hub', 50, 149.99),
      ('P082', 'GadgetWorks', 'Home Appliances', 'Toaster', 80, 29.99),
      ('P083', 'MediaMasters', 'Books', 'Self-Help Book', 150, 19.99),
      ('P084', 'SoundWave', 'Audio', 'Amplifier', 40, 299.99),
      ('P085', 'Visionary', 'Cameras', 'Lens Filter', 60, 19.99),
      ('P086', 'GameZone', 'Gaming', 'Gaming Desk', 50, 199.99),
      ('P087', 'PhotoPro', 'Photography', 'Backdrop', 30, 49.99),
      ('P088', 'BookBarn', 'Literature', 'Children\'s Book', 180, 9.99),
      ('P089', 'MusicMania', 'Music', 'Clarinet', 25, 399.99),
      ('P090', 'FilmFactory', 'Movies', 'Streaming Stick', 70, 49.99);

COMMIT;

