#ifndef _HEADER_FILE_
#define _HEADER_FILE_

char** read_file(char*, int*);
void display_file(char**, int); // This function displays the loaded file
void free_file(char**);

#endif