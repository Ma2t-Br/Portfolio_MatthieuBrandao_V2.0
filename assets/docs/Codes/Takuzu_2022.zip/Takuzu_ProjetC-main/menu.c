/*-----------------------------------------------------------
    menu.c : Regroupe les fonctions en lien avec la gestion du menu.
    Créé par :  Matthieu Brandao
                Alexandre Baudin
-----------------------------------------------------------*/

#include "menu.h"

Matrix menu_grid(int choix){
    srand(time(0));
    if (choix == 1){
        int type_grid = range_input_int(1,2,"Type de grille :\n"
                                        "1. Grille predefinie\n"
                                        "2. Creation intelligente de la grille\n");
        switch(type_grid){
            case 1:{
                return fill_matrix(4,rand()%1);
            }
            case 2:{
                return create_grid(4);
            }
        }
    } else if (choix == 2){
        int type_grid = range_input_int(1,2,"Type de grille :\n"
                                            "1. Grille predefinie\n"
                                            "2. Creation intelligente de la grille\n");
        switch(type_grid) {
            case 1: {
                return fill_matrix(8, rand() % 1);
            }
            case 2: {
                return create_grid(8);
            }
        }
    }
}

int menu(bool start) {
    // arborescence des menus
    int choix, type_grid;
    if (start == true) {
        line();
        printf("*** BIENVENUE DANS TAKUZU ***\n"
               "\nCe jeu a ete realise par :\nMatthieu Brandao\nAlexandre Baudin\n");
    }
    line();
    choix = range_input_int(1,3,"Plusieurs choix s'offrent a vous :\n"
                                                        "1. Resoudre un 4x4\n"
                                                        "2. Resoudre un 8x8\n"
                                                        "3. Quit");
    line();
    Matrix grid = menu_grid(choix);
    line();
    switch(choix){
        case 1:{
            // matrice 4x4
            choix = range_input_int(1,4,"Type de verification :\n"
                                        "1. Verification par correspondance au modele\n"
                                        "2. Verification intelligente \n"
                                        "3. Laisser l'ordinateur resoudre la grille\n"
                                        "4. Retour");
            line();
            switch(choix){
                case 1:{
                    // verification par correspondance
                    choix = range_input_int(1,3,"Quel mode?\n"
                                                "1. Choisir un masque\n"
                                                "2. Creation intelligente du masque\n"
                                                "3. Retour");
                    line();
                    switch(choix){
                        case 1:{
                            // Choix du masque
                            printf("Voici les masques existants :\n");
                            for (int i = 0; i < 2; i++) {
                                printf("\n%d.\n", i + 1);
                                print_matrix(fill_mask(4, i));
                            }
                            choix = range_input_int(1, 2, "Quelle est votre choix?");
                            Start_Game(grid, fill_mask(4, choix - 1), 'c');
                            break;
                        }
                        case 2: {
                            // creation intelligente du masque
                            int level = range_input_int(1,((4*4)/2)-1,"Quelle niveau souhaitez-vous?\n"
                                                                      "(1 tres facile, 7 presque impossible)");
                            Matrix mask = Alea_mask(4, level);
                            printf("Voici le masque cree :\n");
                            print_matrix(mask);
                            Start_Game(fill_matrix(4, 0), mask, 'c');
                            break;
                        }
                        case 3: {
                            // retour
                            return 0;
                        }
                    }
                    break;
                }
                case 2:{
                    // vérification intelligente
                    choix = range_input_int(1,3,"Quel mode?\n"
                                                "1. Choisir un masque\n"
                                                "2. Creation intelligente du masque\n"
                                                "3. Retour");
                    line();
                    switch(choix){
                        case 1:{
                            // Choix du masque
                            printf("Voici les masques existants :\n");
                            for (int i = 0; i < 2; i++) {
                                printf("\n%d.\n", i + 1);
                                print_matrix(fill_mask(4, i));
                            }
                            choix = range_input_int(1, 2, "Quelle est votre choix?");
                            Start_Game(fill_matrix(4, 0), fill_mask(4, choix - 1), 'i');
                            break;
                        }
                        case 2: {
                            // creation intelligente du masque
                            int level = range_input_int(1,((4*4)/2)-1,"Quelle niveau souhaitez-vous?\n"
                                                                      "(1 tres facile, 7 presque impossible)");
                            Matrix mask = Alea_mask(4, level);
                            printf("Voici le masque cree :\n");
                            print_matrix(mask);
                            Start_Game(fill_matrix(4, 0), mask, 'i');
                            break;
                        }
                        case 3: {
                            // retour
                            return 0;
                        }
                    }
                    break;

                }
                case 3:{
                    //résolution auto
                    choix = range_input_int(1,3,"Quel mode?\n"
                                                "1. Choisir un masque\n"
                                                "2. Creation intelligente du masque\n"
                                                "3. Retour");
                    line();
                    switch(choix){
                        case 1:{
                            // Choix du masque
                            printf("Voici les masques existants :\n");
                            for (int i = 0; i < 2; i++) {
                                printf("\n%d.\n", i + 1);
                                print_matrix(fill_mask(4, i));
                            }
                            choix = range_input_int(1, 2, "Quelle est votre choix?");
                            Start_Automatic_Game(fill_matrix(4, 0), fill_mask(4, choix - 1));
                            line_end(); printf("Grille resolues"); line_end();
                            break;
                        }
                        case 2: {
                            // creation intelligente du masque
                            int level = range_input_int(1,((4*4)/2)-1,"Quelle niveau souhaitez-vous?\n"
                                                                      "(1 tres facile, 7 presque impossible)");
                            Matrix mask = Alea_mask(4, level);
                            printf("Voici le masque cree :\n");
                            print_matrix(mask);
                            Start_Automatic_Game(fill_matrix(4, 0), mask);
                            line_end(); printf("Grille resolues"); line_end();
                            break;
                        }
                        case 3: {
                            // retour
                            return 0;
                        }
                    }
                    break;
                }
                case 4:{
                    //retour
                    return 0;
                }

            }
            break;
        }
        case 2:{
            // matrice 8x8
            choix = range_input_int(1,4,"Type de verification :\n"
                                        "1. Verification par correspondance au modele\n"
                                        "2. Verification inteligente \n"
                                        "3. Laisser l'ordinateur resoudre la grille\n"
                                        "4. Retour");
            line();
            switch(choix){
                case 1:{
                    // verification par correspondance
                    choix = range_input_int(1,3,"Quel mode?\n"
                                                "1. Choisir un masque\n"
                                                "2. Creation intelligente du masque\n"
                                                "3. Retour");
                    line();
                    switch(choix) {
                        case 1:{
                            // choix du masque
                            printf("Voici les masques existants :\n");
                            for (int i=0; i<2; i++){
                                printf("%d.\n", i+1);
                                print_matrix(fill_mask(8,i));
                            }
                            choix = range_input_int(1,2,"Quel est votre choix?");
                            Start_Game(fill_matrix(8,0), fill_mask(8,choix-1), 'c');
                            break;
                        }
                        case 2:{
                            // creation intelligente du masque
                            int level = range_input_int(1,7,"Quel niveau souhaitez-vous?\n"
                                                                      "(1 tres facile, 7 presque impossible)");
                            Matrix mask = Alea_mask(8, level);
                            printf("Voici le masque cree :\n");
                            print_matrix(mask);
                            Start_Game(fill_matrix(8, 0), mask, 'c');
                            break;

                        }
                        case 3:{
                            // retour
                            return 0;
                        }
                    }
                    break;
                }
                break;
                case 2:{
                    //verif intellligente
                    choix = range_input_int(1,3,"Quel mode?\n"
                                                "1. Choisir un masque\n"
                                                "2. Creation intelligente du masque\n"
                                                "3. Retour");
                    line();
                    switch(choix) {
                        case 1:{
                            // choix du masque
                            printf("Voici les masques existants :\n");
                            for (int i=0; i<2; i++){
                                printf("%d.\n", i+1);
                                print_matrix(fill_mask(8,i));
                            }
                            choix = range_input_int(1,2,"Quel est votre choix?");
                            Start_Game(fill_matrix(8,0), fill_mask(8,choix-1), 'i');
                            break;
                        }
                        case 2:{
                            // creation intelligente du masque
                            int level = range_input_int(1,7,"Quel niveau souhaitez-vous?\n"
                                                            "(1 tres facile, 7 presque impossible)");
                            Matrix mask = Alea_mask(8, level);
                            printf("Voici le masque cree :\n");
                            print_matrix(mask);
                            Start_Game(fill_matrix(8, 0), mask, 'i');
                            break;
                        }
                        case 3:{
                            // retour
                            return 0;
                        }
                    }
                    break;
                }
                case 3:{
                    //resolution auto
                    choix = range_input_int(1,3,"Quel mode?\n"
                                                "1. Choisir un masque\n"
                                                "2. Creation intelligente du masque\n"
                                                "3. Retour");
                    line();
                    switch(choix) {
                        case 1:{
                            // choix du masque
                            printf("Voici les masques existants :\n");
                            for (int i=0; i<2; i++){
                                printf("%d.\n", i+1);
                                print_matrix(fill_mask(8,i));
                            }
                            choix = range_input_int(1,2,"Quel est votre choix?");
                            Start_Automatic_Game(fill_matrix(8,0), fill_mask(8,choix-1));
                            break;
                        }
                        case 2:{
                            // creation intelligente du masque
                            int level = range_input_int(1,7,"Quel niveau souhaitez-vous?\n"
                                                            "(1 tres facile, 7 presque impossible)");
                            Matrix mask = Alea_mask(8, level);
                            printf("Voici le masque cree :\n");
                            print_matrix(mask);
                            Start_Automatic_Game(fill_matrix(8, 0), mask);
                            break;
                        }
                        case 3:{
                            // retour
                            return 0;
                        }
                    }
                    break;

                }
                case 4:{
                    //retour
                    return 0;
                }
            }
        }
        case 3:{
            // quitter
            return 1;
        }
    }
    return 0;
}