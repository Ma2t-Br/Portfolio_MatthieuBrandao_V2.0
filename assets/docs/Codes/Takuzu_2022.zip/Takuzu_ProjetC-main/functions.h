//    Créé par : Matthieu Brandao, Alexandre Baudin
//    Projet : Takuzu

#ifndef PROJET_TAKUZU_FUNCTIONS_H
#define PROJET_TAKUZU_FUNCTIONS_H

#include "utilities.h"
#include "mat.h"
#include <string.h>
#define TAILLE 4

void line();
void line_end();
bool good_lines(Matrix mat);
bool good_columns(Matrix mat);
int* moveinput(Matrix mat);
int range_input_int(int min, int max, char* msg);
char range_input_char(char min, char max, char* msg);
bool move_like_model(int* move, Matrix mat);
int move_in_middle_row3_line(Matrix mat,Matrix mask,int* move);
int move_in_middle_row3_column(Matrix mat,Matrix mask,int* move);
int move_last_digit_in_line(Matrix mat, Matrix mask, int* move);
int move_last_digit_in_column(Matrix mat, Matrix mask, int* move);
int move_is_next_to_2_identical_numbers_line(Matrix mat, Matrix mask, int* move);
int move_is_next_to_2_identical_numbers_column(Matrix mat, Matrix mask, int* move);
int move_sum_too_high_line(Matrix mat, Matrix mask, int* move);
int move_sum_too_high_column(Matrix mat, Matrix mask, int* move);
int move_makes_two_same_lines(Matrix mat,Matrix mask,int* move);
int move_makes_two_same_columns(Matrix mat,Matrix mask,int* move);
int possible_moves(Matrix mask, int** move_tab);
bool is_move_possible(Matrix mask, int* move);
void print_mat(int** mat, int lines, int columns);
void print_tab(int* tab,int size);
int* intelligent_choice(Matrix mat, Matrix mask);
char* indice(Matrix mat, Matrix mask, int* move);
void print_move(int* move);
char* dyn_str(char* message);
int verif_move(Matrix mat, Matrix mask, int* move);
int full_lines_list(Matrix mask, int* lines_list);
int full_columns_list(Matrix mask, int* lines_list);

#endif //PROJET_TAKUZU_FUNCTIONS_H
