//    Créé par : Matthieu Brandao, Alexandre Baudin
//    Projet : Takuzu

#ifndef PROJET_TAKUZU_UTILITIES_H
#define PROJET_TAKUZU_UTILITIES_H

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#endif //PROJET_TAKUZU_UTILITIES_H
