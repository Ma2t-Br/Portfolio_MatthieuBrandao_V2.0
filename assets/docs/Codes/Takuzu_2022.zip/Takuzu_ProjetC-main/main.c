/*-----------------------------------------------------------
    main.c : Fichier principal. Lancement du jeu.
    Créé par :  Matthieu Brandao
                Alexandre Baudin
-----------------------------------------------------------*/

#include "utilities.h"
#include "functions.h"
#include "mat.h"
#include "menu.h"


int main(void) {
    // code
    int r;
    r = menu(true);
    while (r != 1) {
        r = menu(false);
    }
    return 0;
}