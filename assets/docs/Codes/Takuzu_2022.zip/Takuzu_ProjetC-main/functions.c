/*-----------------------------------------------------------
    functions.c : Regroupe les fonctions communes au programme.
    Créé par :  Matthieu Brandao
                Alexandre Baudin
-----------------------------------------------------------*/

#include "functions.h"

void line() {
    // ligne verticale
    printf("\n--------------------------------------------------\n");
}

void line_end() {
    // ligne verticale
    printf("\n&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");
}

bool good_lines(Matrix mat) {
    // Retourne un booléen en fonction de si les lignes respectent les rêgles
    bool test = true;
    for (int line = 0; line < mat.size; line++) {
        if (sum_line(mat, line) != mat.size / 2) {
            test = false;
            break;
        }
    }
    return test;
}

bool good_columns(Matrix mat) {
    bool test = true;
    for (int column = 0; column < mat.size; column++) {
        if (sum_column(mat, column) == mat.size / 2) {
            test = false;
            break;
        }
    }
    return test;
}

int range_input_int(int min, int max, char* msg){
    // vérifie que l'entrée est bien un entier et qu'il est compris entre min et max
    int x, r;
    printf("%s\n",msg);
    do {
        printf("->");
        r = scanf("%d", &x);
        scanf("%*c");
    } while (r == 0 || x < min || x > max);
    return x;
}

char range_input_char(char min, char max, char* msg){
    // vérifie que l'entrée est bien un caractère et qu'il est compris entre min et max
    char x;
    int r;
    printf("%s\n",msg);
    do {
        printf("->");
        r = scanf("%c", &x);
        scanf("%*c");
    } while (r == 0 || x < min || x > max);
    return x;
}

bool is_move_possible(Matrix mask, int* move){
    // retourne true si le coup entré par l'utilisateur n'est pas sur une case déja affichée
    // retourne false dans le cas contraire
    if(mask.matrix[move[0]][move[1]]==1)
        return false;
    else
        return true;
}

 int* moveinput(Matrix mask){
    // récupère la position et le coup du joueur
    int* move = (int*) malloc(mask.size * sizeof(int));
    do {
        move[0] = range_input_int(1, mask.size, "ligne :") - 1;
        move[1] = range_input_char('A', (char) ('A' + mask.size - 1), "colonne :") - 'A';
        move[2] = range_input_int(0, 1, "choix de la valeur placee (0 ou 1) :");
        if (!is_move_possible(mask,move))
            printf("cette case est deja visible\n\n");
    }while(!is_move_possible(mask,move));
    return move;
}

void print_move(int* move){
    printf("Le coup joue est:\n"
           "Ligne : %d\n"
           "Colonne : %c\n"
           "Choix : %d\n",move[0]+1,(char)(move[1]+'A'),move[2]);
}

char* dyn_str(char* message){
    int l= strlen(message);
    char* str= (char*) calloc(l+1,sizeof(char));
    for(int i=0;i<l+1;i++)
        str[i]=message[i];
    return str;
}

bool move_like_model(int* move, Matrix mat){
    // vérifie si le coup est le même que sur le model
    if (mat.matrix[move[0]][move[1]] == move[2]){
        return true;
    }
    return false;
}

int possible_moves(Matrix mask, int** move_tab){
    // modifie une liste (move_tab) et y met les coordonnées des cases pas encore découvertes et retourne leur nombre
    int k=0;
    for(int i=0;i<mask.size;i++) {
        for (int j = 0; j < mask.size; j++) {
            if (mask.matrix[i][j] == 0) {
                int* move = (int*) calloc(2, sizeof(int));
                move[0]=i;
                move[1]=j;
                move_tab[k] = move;
                k++;
            }
        }
    }
    return k;
}

void print_mat(int** mat, int lines, int columns){
    for(int i=0;i<lines;i++){
        for(int j=0;j<columns;j++){
            printf("%d ",mat[i][j]);
        }
        printf("\n");
    }
}

void print_tab(int* tab,int size){
    for(int i=0;i<size;i++){
        printf("%d ",tab[i]);
    }
}

// verification d'un coup valide

int move_in_middle_row3_line(Matrix mat,Matrix mask,int* move){
    //sert à savoir si le choix du joueur est au milieu de 2 chiffres semblables: code du return :
    // -1 : ne sait pas
    //  0 : le coup est pseudo valide sur la ligne
    //  1 : le coup est un 0 et est entouré de deux 0
    //  2 : le coup est un 1 et est entouré de deux 1
    if(move[1]==0 || move[1]==mat.size-1)
        return 0;
    else{
        if (mask.matrix[move[0]][move[1] - 1] == 1 && mask.matrix[move[0]][move[1] + 1] == 1) {
            if (mat.matrix[move[0]][move[1] - 1] == mat.matrix[move[0]][move[1] + 1]) {
                if (move[2] == 0 && mat.matrix[move[0]][move[1] + 1] == 0) {
                    return 1;
                } else if (move[2] == 1 && mat.matrix[move[0]][move[1] + 1] == 1)
                    return 2;
                else
                    return 0;
            }
            else
                return 0;
        }
        else
            return -1;
    }
}

int move_in_middle_row3_column(Matrix mat,Matrix mask,int* move) {
    /* meme code que la fonction du dessus mais verifie par colonne
    -1 : ne sait pas
     0 : le coup est pseudo valide sur la colonne
     1 : le coup est un 0 et est entouré de deux 0
     2 : le coup est un 1 et est entouré de deux 1  */
    if(move[0]==0 || move[0]==mat.size-1)
        return 0;
    else{
        if (mask.matrix[move[0]-1][move[1]] == 1 && mask.matrix[move[0]+1][move[1]] == 1) {
            if (mat.matrix[move[0]-1][move[1]] == mat.matrix[move[0]+1][move[1]]) {
                if (move[2] == 0 && mat.matrix[move[0]+1][move[1]] == 0) {
                    return 1;
                } else if (move[2] == 1 && mat.matrix[move[0]+1][move[1]] == 1)
                    return 2;
                else
                    return 0;
            }
            else
                return 0;
        }
        else
            return -1;
    }
}

int move_last_digit_in_line(Matrix mat, Matrix mask, int* move){
    //code : -1 : le choix n'est pas le dernier chiffre à trouver sur une ligne (ou le choix est deja affiché (ne devrait pas arriver))
    //  0 : le choix est le dernier d'une ligne et bon
    //  1 : le choix est le dernier d'une ligne mais pas bon
    if(sum_line(mask,move[0])==mask.size-1 && mask.matrix[move[0]][move[1]]==0){
        int s=0;
        for(int i=0;i<mat.size;i++){
            if(i==move[1])
                s+=move[2];
            else
                s+=mat.matrix[move[0]][i];
        }
        if(s==mat.size/2)
            return 0;
        else
            return 1;
    }
    else
        return -1;
}

int move_last_digit_in_column(Matrix mat, Matrix mask, int* move){
    //code : -1 : le choix n'est pas le dernier chiffre à trouver sur une ligne (ou le choix est deja affiché (ne devrait pas arriver))
    //  0 : le choix est le dernier d'une colonne et bon
    //  1 : le choix est le dernier d'une coloonne mais pas bon
    if(sum_column(mask,move[1])==mask.size-1 && mask.matrix[move[0]][move[1]]==0){
        int s=0;
        for(int i=0;i<mat.size;i++){
            if(i==move[0])
                s+=move[2];
            else
                s+=mat.matrix[i][move[1]];
        }
        if(s==mat.size/2)
            return 0;
        else
            return 1;
    }
    else
        return -1;
}

int move_is_next_to_2_identical_numbers_line(Matrix mat, Matrix mask, int* move){
    /* permet de savoir si le choix de l'utilisateur est à coté de 2 chiffres identiques et si il est bon
     * code:
     * -1 : ne sait pas
     *  0 : le choix est valide
     *  cas ou le choix est invalide :
     *  1 : il y a deux 0 à droite
     *  2 : il y a deux 1 à droite
     *  3 : il y a deux 0 à gauche
     *  4 : il y a deux 1 à gauche
     */
    //verifier à droite
    bool valid_right=false;
    if(move[1]<mat.size -2) {
        if (mask.matrix[move[0]][move[1]+1] == 1 && mask.matrix[move[0]][move[1]+2] == 1) {
            if (mat.matrix[move[0]][move[1]+1] == mat.matrix[move[0]][move[1]+2]) {
                if (move[2] == mat.matrix[move[0]][move[1]+1]) {
                    if (move[2] == 0)
                        return 1;
                    else
                        return 2;
                }
                valid_right=true;
            }
            else
                valid_right=true;
        }
    }
    //verifier à gauche
    if(move[1]>1) {
        if (mask.matrix[move[0]][move[1]-1] == 1 && mask.matrix[move[0]][move[1]-2] == 1) {
            if (mat.matrix[move[0]][move[1]-1] == mat.matrix[move[0]][move[1]-2]) {
                if (move[2] == mat.matrix[move[0]][move[1]-1]) {
                    if (move[2] == 0)
                        return 3;
                    else
                        return 4;
                }
                else
                    return 0;
            } else
                return 0;
        }
        return -1;
    }
    if(valid_right==true)
        return 0;
    else
        return -1;
}

int move_is_next_to_2_identical_numbers_column(Matrix mat, Matrix mask, int* move){
    /* permet de savoir si le choix de l'utilisateur est à coté de 2 chiffres identiques et si il est bon
     * code:
     * -1 : ne sait pas
     *  0 : le choix est valide
     *  cas ou le choix est invalide :
     *  1 : il y a deux 0 au dessus
     *  2 : il y a deux 1 au dessus
     *  3 : il y a deux 0 en dessous
     *  4 : il y a deux 1 en dessous
     */
    //verifier au dessus
    bool valid_right=false;
    if(move[0]>1) {
        if (mask.matrix[move[0]-1][move[1]] == 1 && mask.matrix[move[0]-2][move[1]] == 1) {
            if (mat.matrix[move[0]-1][move[1]] == mat.matrix[move[0]-2][move[1]]) {
                if (move[2] == mat.matrix[move[0]-1][move[1]]) {
                    if (move[2] == 0)
                        return 1;
                    else
                        return 2;
                }
                valid_right=true;
            }
            else
                valid_right=true;
        }
    }
    //verifier en dessous
    if(move[0]<mat.size-2) {
        if (mask.matrix[move[0]+1][move[1]] == 1 && mask.matrix[move[0]+2][move[1]] == 1) {
            if (mat.matrix[move[0]+1][move[1]] == mat.matrix[move[0]+2][move[1]]) {
                if (move[2] == mat.matrix[move[0]+1][move[1]]) {
                    if (move[2] == 0)
                        return 3;
                    else
                        return 4;
                }
                else
                    return 0;
            } else
                return 0;
        }
        return -1;
    }
    if(valid_right==true)
        return 0;
    else
        return -1;
}

int move_sum_too_high_line(Matrix mat, Matrix mask, int* move){
    //retourne 0 si il y a trop de 0 sur la ligne
    // ''' de 1 sur la ligne
    // -1 si si il n'y a pas de pb
    int n0=0;
    int n1=0;
    if (sum_line(mask,move[0])>=mask.size/2){
        for(int i=0;i<mat.size;i++){
            if(i==move[1]) {
                if (move[2] == 0)
                    n0 += 1;
                else
                    n1 += 1;
            }
            else if (mask.matrix[move[0]][i]==1) {
                if (mat.matrix[move[0]][i] == 0)
                    n0 += 1;
                else
                    n1 += 1;
            }
        }
    }
    if(n0>mat.size/2)
        return 0;
    else if(n1>mat.size/2)
        return 1;
    else
        return -1;
}

int move_sum_too_high_column(Matrix mat, Matrix mask, int* move){
    //retourne 0 si il y a trop de 0 sur la colonne
    // ''' de 1 sur la colonne
    // -1 si si il n'y a pas de pb
    int n0=0;
    int n1=0;
    if (sum_column(mask,move[1])>=mask.size/2){
        for(int i=0;i<mat.size;i++){
            if(i==move[0]) {
                if (move[2] == 0)
                    n0 += 1;
                else
                    n1 += 1;
            }
            else if (mask.matrix[i][move[1]]==1) {
                if (mat.matrix[i][move[1]] == 0)
                    n0 += 1;
                else
                    n1 += 1;
            }
        }
    }
    if(n0>mat.size/2)
        return 0;
    else if(n1>mat.size/2)
        return 1;
    else
        return -1;
}

int full_lines_list(Matrix mask, int* lines_list){
    //modifie lines_list pour y mettre les indices des lignes qui sont complètement révélées par le masque
    //retourne la longueur de cette liste
    int k=0;
    for (int i=0;i<mask.size;i++){
        if (sum_line(mask,i)==mask.size){
            k++;
            lines_list[k-1]=i;
        }
    }
    return k;
}

int full_columns_list(Matrix mask, int* columns_list){
    //modifie columns_list pour y mettre les indices des lignes qui sont complètement révélées par le masque
    //retourne la longueur de cette liste
    int k=0;
    for (int i=0;i<mask.size;i++){
        if (sum_column(mask,i)==mask.size){
            k++;
            columns_list[k-1]=i;
        }
    }
    return k;
}

int move_makes_two_same_lines(Matrix mat,Matrix mask,int* move){
    // retourne 1 si le choix fait apparaitre deux lignes similaires
    // 0 si la ligne qu'il fait apparaitre est unique
    // -1 si la ligne sur laquelle on a joué il reste plus de 2 cases a trouver ou si il n'y
    if (sum_line(mask,move[0])==mat.size-2) {
        int *lines_list = (int *) calloc(mat.size, sizeof(int));
        int len = full_lines_list(mask, lines_list);
        if (len == 0) {
            return -1;
        }
        else{
            for(int line=0;line<len;line++){
                int tmp=mat.matrix[move[0]][move[1]];
                mat.matrix[move[0]][move[1]]=move[2];
                int s=0;
                for (int i=0;i<mat.size;i++)
                    if(mat.matrix[move[0]][i]==mat.matrix[lines_list[line]][i])
                        s++;
                mat.matrix[move[0]][move[1]]=tmp;
                if(s>mat.size-2)
                    return 1;
            }
            return 0;
        }
    }
    else
        return -1;
}

int move_makes_two_same_columns(Matrix mat,Matrix mask,int* move){
    //retourne 1 si le choix fait apparaitre deux colonnes similaires
    // 0 si la colonne qu'il fait apparaitre est unique
    // -1 si la colonne sur laquelle on a joué n'est pas complétée par le choix fait
    if (sum_column(mask,move[1])==mat.size-2) {
        int *columns_list = (int *) calloc(mat.size, sizeof(int));
        int len = full_columns_list(mask, columns_list);
        if (len == 0) {
            return -1;
        }
        else{
            for(int column=0;column<len;column++){
                int tmp=mat.matrix[move[0]][move[1]];
                mat.matrix[move[0]][move[1]]=move[2];
                int s=0;
                for (int i=0;i<mat.size;i++) {
                    if (mat.matrix[i][move[1]] == mat.matrix[i][columns_list[column]])
                        s++;
                }
                mat.matrix[move[0]][move[1]]=tmp;
                if(s>mat.size-2)
                    return 1;
            }
            return 0;
        }
    }
    else
        return -1;
}

int verif_move(Matrix mat, Matrix mask, int* move){

    // verifie un choix selon toutes les regles du Takuzu
    // code des erreurs en bas de la fonction
    // si a ou b ou c ou... =0 : la verification pense que le coup est bon jusque là
    // si a ou b ou c ou... =-1 : la verification ne sait pas si le coup est valide à cette étape
    // des les deux cas, la verification doit continuer

    int a= move_in_middle_row3_line(mat,mask,move);
    if(a==-1 || a==0 ){
        int b= move_in_middle_row3_column(mat,mask,move);
        if(b==-1 || b==0){
            int c= move_is_next_to_2_identical_numbers_line(mat,mask,move);
            if(c==-1 || c==0){
                int d=move_is_next_to_2_identical_numbers_column(mat,mask,move);
                if(d==-1 || d==0){
                    int e= move_last_digit_in_line(mat,mask,move);
                    if(e==-1 || e==0){
                        int f= move_last_digit_in_column(mat,mask,move);
                        if(f==-1 || f==0){
                            int g= move_sum_too_high_line(mat,mask,move);
                            if(g==-1){
                                int h=move_sum_too_high_column(mat,mask,move);
                                if(h==-1){
                                    int i= move_makes_two_same_lines(mat,mask,move);
                                    if(i==-1 || i==0){
                                        int j= move_makes_two_same_columns(mat,mask,move);
                                        if(j==-1)
                                            return -1;
                                        else if(j==0)
                                            return 0;
                                        else
                                            return 20;
                                    }else
                                        return 19;

                                }else if(h==0)
                                    return 17;
                                else
                                    return 18;

                            }else if(g==0)
                                return 15;
                            else
                                return 16;

                        }else
                            return 14;

                    }else
                        return 13;

                }else if(d==1)
                    return 9;
                else if(d==2)
                    return 10;
                else if(d==3)
                    return 11;
                else
                    return 12;

            }else if(c==1)
                return 5;
            else if(c==2)
                return 6;
            else if(c==3)
                return 7;
            else
                return 8;

        }else if(b==1)
            return 3;
        else
            return 4;

    }else if(a==1)
        return 1;
    else
        return 2;

    // code pour les coups :
    // -1 : ne sait pas si le coup est valide ou non
    //  0 : le coup est valide
    //  coups invalides :
    //  1 : le coup est un 0 et est entouré de deux 0 (ligne)
    //  2 : le coup est un 1 et est entouré de deux 1 (ligne)
    //  3 : le coup est un 0 et est entouré de deux 0 (colonne)
    //  4 : le coup est un 1 et est entouré de deux 1 (colonne)
    //  5 : il y a deux 0 à droite
    //  6 : il y a deux 1 à droite
    //  7 : il y a deux 0 à gauche
    //  8 : il y a deux 1 à gauche
    //  9 : il y a deux 0 au dessus
    //  10 : il y a deux 1 au dessus
    //  11 : il y a deux 0 en dessous
    //  12 : il y a deux 1 en dessous
    //  13 : le choix est le dernier d'une ligne mais pas bon
    //  14 : le choix est le dernier d'une colonne mais pas bon
    //  15 : il y a trop de 0 sur la ligne
    //  16 : il y a trop de 1 sur la ligne
    //  17 : il y a trop de 0 sur la colonne
    //  18 : il y a trop de 1 sur la colonne
    //  19 : le choix fait apparaitre deux lignes similaires
    //  20 : le choix fait apparaitre deux colonnes similaires
}

char* indice(Matrix mat, Matrix mask, int* move){
    char* size_string= (char*) calloc(2,sizeof(char));
    int len=sprintf(size_string,"%d",mat.size/2);
    int r= verif_move(mat,mask,move);
    if(r==-1) {
        move[2] = 1 - move[2]; // transforme le choix de 0 en 1 ou de 1 en 0
        r= verif_move(mat,mask,move);
        move[2] = 1 - move[2];
        if (r!=0){
            if(move_like_model(move,mat))
                return "le coup est valide et correcte";
            else
                return "le coup est valide mais incorrecte";
        }
        else
            return "le coup est invalide";
    }
    if(r==0) {
        if (move_like_model(move, mat))
            return "le coup est valide et correcte";
        else
            return "le coup est valide mais incorrecte";
    }
    if(r==1)
        return "entre deux 0 sur une ligne il doit y avoir un 1";
    else if (r==2)
        return  "entre deux 1 sur une ligne il doit y avoir un 0";
    else if (r==3)
        return "entre deux 0 sur une colonne il doit y avoir un 1";
    else if (r==4)
        return "entre deux 1 sur une colonne il doit y avoir un 0";
    else if (r==5)
        return "a gauche de deux 0 il doit y avoir un 1";
    else if (r==6)
        return "a gauche de deux 1 il doit y avoir un 0";
    else if (r==7)
        return "a droite de deux 0 il doit y avoir un 1";
    else if (r==8)
        return "a droite de deux 1 il doit y avoir un 0";
    else if (r==9)
        return "en dessous de deux 0 il doit y avoir un 1";
    else if (r==10)
        return "en dessous de deux 1 il doit y avoir un 0";
    else if (r==11)
        return "au dessus de deux 0 il doit y avoir un 1";
    else if (r==12)
        return "au dessus de deux 1 il doit y avoir un 0";
    else if (r==13)
        return "sur une ligne il doit y avoir autant de 1 que de 0";
    else if (r==14)
        return "sur une colonne il doit y avoir autant de 1 que de 0";
    else if (r==15 || r==16) {
        char* message= dyn_str("sur une ligne il ne peut y avoir que ");
        strcat(message,size_string);
        if (r==15)
            strcat(message," zeros aux maximum");
        else
            strcat(message," uns aux maximum");
        return message;
    }
    else if (r==17 || r==18) {
        char* message= dyn_str("sur une colonne il ne peut y avoir que ");
        strcat(message,size_string);
        if (r==17)
            strcat(message," zeros aux maximum");
        else
            strcat(message," uns aux maximum");
        return message;
    }
    else if(r==19)
        return "il ne peut pas y avoir deux lignes similaires";
    else if(r==20)
        return "il ne peut pas y avoir deux colonnes similaires";
}

int* intelligent_choice(Matrix mat, Matrix mask){
    //retourne un choix qui est valide et affiche pourquoi il est valide
    //si il n'y a aucun coup possible dont on est sure est valide, on pioche la reponse dans la grille solution

    int** move_tab= (int**) calloc(mask.size*mask.size,sizeof(int*));
    int n= possible_moves(mask,move_tab);
    int* move= (int*) calloc(3,sizeof(int));
    for (int i=0;i<n;i++){
        move[0]=move_tab[i][0];
        move[1]=move_tab[i][1];
        move[2]=1;
        int r= verif_move(mat,mask,move);
        if(r>0){
            printf("%s\n",indice(mat,mask,move)); //FIXME logique presque bonne
            move[2]=0;
            return move;
        }
        else if(r==0){
            move[2]=0;
            r= verif_move(mat,mask,move);
            if(r>0){
                printf("%s\n",indice(mat,mask,move));
                move[2]=1;
                return move;
            }
        }
        else{
            move[2]=0;
            r= verif_move(mat,mask,move);
            if(r>0){
                printf("%s\n",indice(mat,mask,move));
                move[2]=1;
                return move;
            }
            if(i=n-1){
                printf("pas d'indice donc l'ordinateur pioche la reponse :\n");
                if(move_like_model(move,mat)==true)
                    return move;
                else
                    move[2]=0;
                return move;
            }
        }
    }
    move[0]=-1; // utilisé uniquement pour le developpement de la fonction, inutile en pratique
    move[1]=-1;
    move[2]=-1;
    return move;
}
