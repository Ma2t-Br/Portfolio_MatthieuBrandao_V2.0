//    Créé par : Matthieu Brandao, Alexandre Baudin
//    Projet : Takuzu

#ifndef PROJET_TAKUZU_MENU_H
#define PROJET_TAKUZU_MENU_H

#include "utilities.h"
#include "functions.h"
#include "mat.h"
#include "Game.h"

int menu(bool start);

#endif //PROJET_TAKUZU_MENU_H
