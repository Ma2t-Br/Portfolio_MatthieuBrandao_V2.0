//    Créé par : Matthieu Brandao, Alexandre Baudin
//    Projet : Takuzu

#ifndef PROJET_TAKUZU_GAME_H
#define PROJET_TAKUZU_GAME_H

#include "utilities.h"
#include "mat.h"
#include "functions.h"
#include <unistd.h>

void Start_Game(Matrix mat, Matrix mask, char mode);
void Start_Automatic_Game(Matrix mat, Matrix mask);
#endif //PROJET_TAKUZU_GAME_H
