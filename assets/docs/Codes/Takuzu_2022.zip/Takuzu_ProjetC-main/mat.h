//    Créé par : Matthieu Brandao, Alexandre Baudin
//    Projet : Takuzu

#ifndef PROJET_TAKUZU_MAT_H
#define PROJET_TAKUZU_MAT_H

#include "utilities.h"

typedef struct {
    int **matrix;
    int size;
    char type; // m for "mask", g for "grid"
} Matrix;

typedef struct {
    int *line;
    int size;
} Line;

Matrix transpose(Matrix mat);
bool check_mask_1(Matrix mat);
bool same_line(Matrix mat);
bool same_column(Matrix mat);
bool compare_tab(int *t, int *s, int taille);
bool no_3_digits_tab(int* tab, int size);
Matrix create_matrix(int size);
Matrix fill_matrix(int size, int version);
Matrix fill_mask(int size, int version);
void print_matrix_mask(Matrix mat, Matrix mask);
void print_matrix(Matrix mat);
void unveil_mask(Matrix* mask, int* pos);
bool check_mask_1(Matrix mat);
Matrix Alea_mask(int size, int level);
Matrix create_grid(int size);
int sum_line(Matrix grid, int line);
int sum_column(Matrix grid, int column);
Line create_binary_line(int number,int size);
bool check_line(Line line);
int create_valid_lines_matrix(Line* valid_lines, int size);
void print_tab_lines(Line* tab,int lines,int columns);

int extern Grates4[1][4][4];
int extern Grates8[1][8][8];
int extern Masks4[2][4][4];
int extern Masks8[2][8][8];

#endif //PROJET_TAKUZU_MAT_H