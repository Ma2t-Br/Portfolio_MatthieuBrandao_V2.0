/*-----------------------------------------------------------
    mat.c : Regroupe les fonctions en lien avec la gestion des matrices.
    Créé par :  Matthieu Brandao
                Alexandre Baudin
-----------------------------------------------------------*/

#include "mat.h"
#include "functions.h"

char alpha[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'};

int Grates4[1][4][4] = {{1, 1, 0, 0,
                         0, 0, 1, 1,
                         0, 1, 0, 1,
                         1, 0, 1, 0}};                                        // Model matrice 4x4

int Grates8[1][8][8] = {{1, 0, 1, 1, 0, 1, 0, 0,
                         1, 0, 1, 0, 1, 0, 0, 1,
                         0, 1, 0, 1, 1, 0, 1, 0,
                         0, 1, 0, 1, 0, 1, 1, 0,
                         1, 0, 1, 0, 0, 1, 0, 1,
                         0, 1, 0, 0, 1, 0, 1, 1,
                         0, 0, 1, 1, 0, 1, 1, 0,
                         1, 1, 0, 0, 1, 0, 0, 1}};        // Model matrice 8x8

int Masks4[2][4][4] = {{1, 1, 1, 1,
                               0, 0, 0, 1,
                               0, 0, 0, 1,
                               0, 0, 0, 1},
                                // 1er Masque 4x4
                       {0, 0, 1, 1,
                               1, 1, 1, 1,
                               1, 1, 1, 1,
                               1, 1, 1, 1}};
                                // 2e Masque 4x4

int Masks8[2][8][8] = {{1, 1, 1, 1, 1, 1, 1, 1,
                               1, 1, 1, 1, 1, 1, 1, 1,
                               0, 0, 0, 0, 1, 1, 1, 1,
                               0, 0, 0, 0, 1, 1, 1, 1,
                               0, 0, 0, 0, 1, 1, 1, 1,
                               0, 0, 0, 0, 1, 1, 1, 1,
                               0, 0, 0, 0, 1, 1, 1, 1,
                               0, 0, 0, 0, 1, 1, 1, 1},
                                // 1er masque 8*8
                       {1, 1, 1, 1, 1, 1, 1, 1,
                               1, 1, 1, 1, 1, 1, 1, 1,
                               1, 0, 0, 0, 1, 1, 1, 1,
                               1, 0, 0, 0, 1, 1, 1, 1,
                               1, 0, 0, 0, 1, 1, 1, 1,
                               1, 0, 0, 0, 1, 1, 1, 1,
                               1, 0, 0, 0, 1, 1, 1, 1,
                               1, 1, 1, 1, 1, 1, 1, 1}};
                                //2e Masque 8*8


Matrix create_matrix(int size) {
    // Creation d'un tableau dynamique de taille "size" et de type "m" ou "g"
    /*
       entrées :    size : taille de la matrice
       sortie :     matrice vide (de type Matrix)
    */
    Matrix Dyn_tab;
    Dyn_tab.matrix = (int **) malloc(size * sizeof(int *));
    for (int i = 0; i < size; i++) {
        *(Dyn_tab.matrix + i) = (int *) malloc(size * sizeof(int));
    }
    Dyn_tab.size = size;
    return Dyn_tab;
}

Matrix fill_matrix(int size, int version) {
    // remplissage d'une matrice à partir des models
    /*
       entrées :    size : taille de la matrice
                    version : version du model
       sortie :     masque rempli (de type Matrix)
    */
    Matrix mat = create_matrix(size);
    mat.type = 'g'; // for grid
    if (mat.size == 4) {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                *(*(mat.matrix + i) + j) = Grates4[version][i][j];
            }
        }
    } else if (mat.size == 8) {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                *(*(mat.matrix + i) + j) = Grates8[version][i][j];
            }
        }
    }
    return mat;
}

Matrix fill_mask(int size, int version) {
    // remplissage d'un masque à partir des models correspondants
    /*
       entrées :    size : taille du masque
                    version : version du model
       sortie :     masque rempli (de type Matrix)
    */
    Matrix mat = create_matrix(size);
    mat.type = 'm'; // for mask
    if (mat.size == 4) {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                *(*(mat.matrix + i) + j) = Masks4[version][i][j];
            }
        }
    } else if (size == 8) {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                *(*(mat.matrix + i) + j) = Masks8[version][i][j];
            }
        }
    }
    return mat;
}

void print_matrix(Matrix mat) {
    // affiche la matrice au complet avec un cadre
    /*
       entrées :    mat : matrice à afficher
       aucune sortie
    */
    printf(" ");
    for (int i = 0; i < mat.size; i++) printf("  %c", alpha[i]);
    printf("\n ");
    for (int i = 0; i < mat.size; i++) printf(" --");
    printf("\n");
    for (int i = 0; i < mat.size; i++) {
        printf("%d| ", i + 1);
        for (int j = 0; j < mat.size; j++) {
            printf("%d  ", mat.matrix[i][j]);
        }
        printf("\n");
    }
}


void print_matrix_mask(Matrix mat, Matrix mask) {
    // affiche la matrice avec un cadre et un masque par-dessus
    /*
       entrées :    mat : matrice à afficher
                    masque : masque à appliquer
       aucune sortie
    */
    printf(" ");
    for (int i = 0; i < mat.size; i++) {
        printf("  %c", alpha[i]);
    }
    printf("\n ");
    for (int i = 0; i < mat.size; i++) printf(" --");
    printf("\n");
    for (int i = 0; i < mat.size; i++) {
        printf("%d| ", i + 1);
        for (int j = 0; j < mat.size; j++) {
            if (mask.matrix[i][j] == 1) {
                printf("%d  ", mat.matrix[i][j]);
            } else {
                printf("   ");
            }
        }
        printf("\n");
    }
}

Matrix Alea_mask(int size, int level){
    // cré un masque en fonction du level
    /*
       entrées :    level : niveau entré précédemment
                    size : taille de la matrice
       sortie :     le masque créé (de type Matrix)
    */
    srand(time(0));
    int x, y;
    Matrix alea_mask = create_matrix(size);
    alea_mask.type = 'm'; // for mask
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            *(*(alea_mask.matrix + i) + j) = 1;
        }
    }
    for (int i=0; i < level*(size/2); i++){
        x = rand()%size;
        y = rand()%size;
        *(*(alea_mask.matrix + x) + y) = 0;
    }
    return alea_mask;
}

void unveil_mask(Matrix* mask, int* pos) {
    // dévoile le masque à la position pos
    mask->matrix[pos[0]][pos[1]] = 1;
}

bool compare_tab(int *t, int *s, int taille) {
    int i = 0;
    while (i < taille && t[i] == s[i]) {
        i++;
    }
    if (i == taille) {
        return true;
    } else {
        return false;
    }
}

bool check_mask_1(Matrix mat){
    // vérifie si le masque est complétement rempli de 1
    int s=0;
    for(int i=0;i<mat.size;i++)
        for (int j=0;j<mat.size;j++)
            s+=mat.matrix[i][j];
    if(s==mat.size*mat.size)
        return true;
    else
        return false;
}

bool same_line(Matrix mat){
    // vérifie s'il y a 2 colonnes pareil
    //retourne 1 si il y a deux fois la meme ligne dans la matrice, 0 sinon
    bool B = false;
    int i,j;
    int y1 = -1, y2 = -1;
    i = 0;
    for (i=0;i<mat.size;i++)
        for(j=i+1;j< mat.size;j++)
            if(compare_tab(mat.matrix[i],mat.matrix[j],mat.size))
                B=true;
    return B;
}

Matrix transpose(Matrix mat){
    //retourne la matrice transposée de mat
    Matrix t = create_matrix(mat.size);
    t.type = 'g';
    for(int i=0;i<t.size;i++){
        for(int j=0;j<t.size;j++){
            t.matrix[j][i]=mat.matrix[i][j];
        }
    }
    return t;
}
bool same_column(Matrix mat){
    // vérifie s'il y a 2 colonnes pareil
    //retourne 1 si il y a deux fois la meme colonne dans la matrice, 0 sinon
    return(same_line(transpose(mat)));
}

bool no_3_digits_tab(int* tab, int size){ //retourne 1 si dans un tab il n'y a pas 3 fois le meme chiffre d affilé
    bool B=true;
    for (int i=0;i<size-2;i++){
        if(tab[i]==tab[i+1] && tab[i]==tab[i+2])
            B=false;
    }
    return B;
}

bool no_3_digits_matrix(Matrix mat){
    bool verif = true;
    for (int two=1; two<=2; two++){
        for (int i=0; i < mat.size; i++){
            verif = no_3_digits_tab(mat.matrix[i], mat.size);
        }
        if (two<2) mat = transpose(mat);
    }
    return verif;
}

bool check_matrix(Matrix mat) {
    for (int i = 0; i < mat.size; i++) {
        continue;
    }
}

int sum_line(Matrix grid, int line) {
    // retourne la somme des termes sur la ligne
    int somme = 0;
    for (int i = 0; i < grid.size; i++) {
        somme += grid.matrix[line][i]; // *(*(grid+line)+i)
    }
    return somme;
}

int sum_column(Matrix grid, int column) {
    // retourne la somme des termes sur la colonne
    int somme = 0;
    for (int i = 0; i < grid.size; i++) {
        somme += grid.matrix[i][column]; // *(*(grid+i)+column)
    }
    return somme;
}

int sum_Line(Line line) {
    // retourne la somme des termes de la ligne
    int somme = 0;
    for (int i = 0; i < line.size; i++) {
        somme += line.line[i]; // *(*(grid+line)+i)
    }
    return somme;
}

Matrix create_grid(int size){
    // création automatique d'une grille
    srand(time(0));
    Matrix grid = create_matrix(size);
    bool good_columns;
    grid.type = 'g';
    do {
        for (int line=0; line < size; line++){
            do{
                for (int column=0; column < size; column++){
                    grid.matrix[line][column] = rand()%2;
                }
            } while(sum_line(grid, line) != size/2);
        }
        good_columns = true;
        for (int column=0; column < size; column++){
            if (sum_column(grid, column) != size/2){
                good_columns = false;
            }
        }
    } while(same_line(grid) == true ||
            same_column(grid) == true ||
            good_columns == false
            );
    return grid;
}

//partie 3

Line create_binary_line(int number,int size){
    // crée un tableau de 1 et de 0 correspondant à number en binaire
    // et le retourne sous forme d'un type Line
    int* line =(int*) calloc(size,sizeof(int));
    for(int i=0;i<size;i++){
        line[size-i-1]=number%2;
        number/=2;
    }
    Line line1;
    line1.line=line;
    line1.size=size;
    return line1;
}

bool check_line(Line line){
    // verifie si la ligne de binaire est valide
    if(sum_Line(line)==line.size/2)
        if(no_3_digits_tab(line.line,line.size)==1)
            return true;
    return false;
}

int create_valid_lines_matrix(Line* valid_lines, int size){
    //crée un tableau n'ayant que des lignes en binaire valides
    int k=0;
    for(int i=0;i<pow(2,(double)size)-1;i++){
        Line line= create_binary_line(i,size);
        if(check_line(line)){
            valid_lines[k]=line;
            k++;
        }
    }
    return k;
}

void print_tab_lines(Line* tab,int lines,int columns){
    //affiche un tableau de valeur de type Line
    for(int i=0;i<lines;i++){
        for(int j=0;j<columns;j++){
            printf("%d ",tab[i].line[j]);
        }
        printf("\n");
    }
}