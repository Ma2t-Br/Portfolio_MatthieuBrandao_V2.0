/*-----------------------------------------------------------
    Game.c : Regroupe les fonctions en lien avec le lancement du jeu.
    Créé par :  Matthieu Brandao
                Alexandre Baudin
-----------------------------------------------------------*/

#include "Game.h"

void Start_Game(Matrix mat, Matrix mask, char mode) { // mode : 'i' for 'intelligent', 'c' for 'correspondence'
    // lancement du jeu
    int* move = (int*) malloc(3 * sizeof(int));
    int life = 3;
    line();
    printf("Le jeu commence !");
    if (mode == 'c'){ // mode correspondance avec un modele
        do {
            line();
            print_matrix_mask(mat, mask);
            printf("\nA vous de jouer.\t\t\t vie(s) : %d\n", life);
            move = moveinput(mask);
            if (move_like_model(move,mat) == true){
                line(); printf("So good");
                unveil_mask(&mask,move);
            } else{
                line(); printf("So bad. Le coup ne correspond pas. Une vie en moins!");
                life -= 1;
            }
        } while (check_mask_1(mask) == false && life != 0);
    }
    else if(mode=='i'){ // mode verification intelligente
        do {
            line();
            print_matrix_mask(mat, mask);
            printf("\nA vous de jouer.\t\t\t vie(s) : %d\n", life);
            move = moveinput(mask);
            printf("\n");
            int r = verif_move(mat, mask, move);
            if(r==-1) {
                move[2] = 1 - move[2]; // transforme le choix de 0 en 1 ou de 1 en 0
                r= verif_move(mat,mask,move);
                if(r==0) {
                    line(); printf("So bad,\n");
                    life--;
                }
                else {
                    line(); printf("So good,\n");
                    if (!move_like_model(move, mat))
                        unveil_mask(&mask, move);
                    move[2] = 1 - move[2];
                }
            }
            else if(r>0) {
                line(); printf("So bad,\n");
                life--;
            }
            else {
                line(); printf("So good,\n");
                if (move_like_model(move, mat))
                    unveil_mask(&mask, move);
            }

            printf("%s", indice(mat, mask, move));
        }
        while (check_mask_1(mask) == false && life != 0);
    }
    if (life>0){
        line(); line_end(); printf("Vous avez Gagne"); line_end();
    } else{
        line(); line_end(); printf("Vous avez Perdu"); line_end();
    }
}

void Start_Automatic_Game(Matrix mat, Matrix mask){
    int** move_list =(int**) calloc(mat.size*mat.size,sizeof (int*));
    int* move = (int*) calloc(3,sizeof (int));
    int k=possible_moves(mask,move_list);
    line();
    printf("L'ordinateur commence a jouer :");
    line();
    printf("\n");
    print_matrix_mask(mat,mask);
    line();
    for(int i=0;i<k;i++){
        printf("Resonnement : ");
        move = intelligent_choice(mat,mask);
        printf("\n");
        unveil_mask(&mask,move);
        print_move(move);
        printf("\n");
        sleep(4);
        print_matrix_mask(mat,mask);
        sleep(4);
        line();
    }
}