package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly;
import fr.arsenelapostolet.efrei.monopoly.Location;
import fr.arsenelapostolet.efrei.monopoly.Color;

import java.math.BigDecimal;
import java.util.List;

public class Space implements Location {

    private final String name;
    private final LocationKind kind;
    private final Color color;
    private final int price;
    private String owner;
    private Rent rent;
    private int buildLevel;

    public Space(String name, LocationKind kind, Color color, int price) {
        this.name = name;
        this.kind = kind;
        this.color = color;
        this.price = price;
        this.buildLevel = 0;
    }

    public String getName(){
        return this.name;
    }

    public LocationKind getKind(){
        return this.kind;
    }

    public BigDecimal getPrice(){ return new BigDecimal(this.price); }

    @Override
    public String getOwner() {
        return this.owner;
    }

    @Override
    public Color getColor() {
        return color;
    }

    public Rent getRent(){ return this.rent; }

    public void setOwner(String newOwner){ this.owner = newOwner; }

    public void setRent(Rent rent){this.rent=rent; }


    public BigDecimal calculateRent(int scorePlayer, List<Player> players) {
        return new BigDecimal(0);
    }

    public int getBuildLevel(){return this.buildLevel;}

    public void incrementBuildLevel(){ this.buildLevel = this.buildLevel+1<=5? this.buildLevel+1 : this.buildLevel; }

}
