package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Objects;

public class DefaultFileReader implements FileReader {

    @Override
    public BufferedReader getBufferedReader(String path) throws IOException{
        return new BufferedReader(new InputStreamReader(Objects.requireNonNull(getClass().getResourceAsStream(path))));
    }
}
