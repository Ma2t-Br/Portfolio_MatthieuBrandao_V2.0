package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services;

import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Player;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Space;
import fr.arsenelapostolet.efrei.monopoly.Location;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public class PropertyService {
    private final PlayerService playerService ;

    public PropertyService(PlayerService playerService){
        this.playerService = playerService;
    }


    public int numberOfPropertyOwned(String player, List<Player> players, Location.LocationKind kind){
        return (int) playerService.getPlayer(player, players).getProperties()
                .stream()
                .filter(companies -> companies.getKind() == kind)
                .count();
    }

    public Player transferAssetsToOwner(String owner, Player currentPlayer, List<Player> players, Map<String, Location> playersLocation) {
        playerService.getPlayer(owner, players).addCash(currentPlayer.getCash());
        Player nextCurrentPlayer = players.get((players.indexOf(currentPlayer) + 1) % players.size());
        playerService.removePlayer(currentPlayer, playersLocation, players);
        return nextCurrentPlayer;
    }
}