package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Locations;

import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Player;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services.PlayerService;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services.PropertyService;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Space;
import fr.arsenelapostolet.efrei.monopoly.Color;

import java.math.BigDecimal;
import java.util.List;

public class Station extends Space {
    public Station(String name,Color color, int price) {
        super(name, LocationKind.STATION, color, price);
    }

    public BigDecimal calculateRent(int scorePlayer, List<Player> players){
        PropertyService propertyService = new PropertyService(new PlayerService());
        int numberOfPropertyOwned = propertyService.numberOfPropertyOwned(this.getOwner(), players, LocationKind.STATION);

        BigDecimal rent = BigDecimal.valueOf(0);

        switch (numberOfPropertyOwned) {
            case 1 -> rent = BigDecimal.valueOf(25);
            case 2 -> rent = BigDecimal.valueOf(50);
            case 3 -> rent = BigDecimal.valueOf(100);
            case 4 -> rent = BigDecimal.valueOf(200);
        }

        return rent;
    }
}
