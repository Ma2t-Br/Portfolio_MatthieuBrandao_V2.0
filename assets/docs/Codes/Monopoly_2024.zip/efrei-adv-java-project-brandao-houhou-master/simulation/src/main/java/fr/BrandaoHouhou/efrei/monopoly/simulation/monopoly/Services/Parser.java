package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services;
import fr.arsenelapostolet.efrei.monopoly.Color;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.FileReader;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Rent;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Space;
import fr.arsenelapostolet.efrei.monopoly.Location;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Locations.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.math.BigDecimal;

public class Parser {
    static String pathMonopoly = "/monopoly.csv";
    static String pathRent = "/rent.csv";


    public static List<Location> parseFile(FileReader fileReader) {
        List<Location> spaces = new ArrayList<>();
        try (BufferedReader reader = fileReader.getBufferedReader(pathMonopoly)) {
            reader.readLine();
            String line;
            while ((line = reader.readLine()) != null) {
                fillSpace(line, spaces);
            }
        } catch (IOException | RuntimeException e) {
            return null;
        }
        return spaces;
    }

    public static List<Location> parseRentFile(FileReader fileReader,List<Location> spaces){
        try (BufferedReader reader = fileReader.getBufferedReader(pathRent)) {
            reader.readLine();
            String line;
            while ((line = reader.readLine()) != null) {
                fillSpaceRent(line, spaces);
            }
        } catch (IOException | RuntimeException e) {
            return null;
        }
        return spaces;
    }

    private static void fillSpace (String line, List<Location> spaces){
        int price;
        String[] elements = line.split(",", -1);

        if (elements[3].trim().isEmpty()) {
            price = 0;
        }else{
            price = Integer.parseInt(elements[3].trim());
        }

        Location spaceObject = LocationGenerator.buildLocation(elements[0].trim(), getLocationKind(elements[1].trim()), stringToColor(elements[2].trim()), price);
        spaces.add(spaceObject);
    }

    public static void fillSpaceRent (String line, List<Location> spaces){
        String[] elements = line.split(",", -1);
        String element0 = elements[0].trim();
        BigDecimal element1 = new BigDecimal(elements[1].trim());
        BigDecimal element2 = new BigDecimal(elements[2].trim());
        BigDecimal element3 = new BigDecimal(elements[3].trim());
        BigDecimal element4 = new BigDecimal(elements[4].trim());
        BigDecimal element5 = new BigDecimal(elements[5].trim());
        BigDecimal element6 = new BigDecimal(elements[6].trim());
        BigDecimal element7 = new BigDecimal(elements[7].trim());
        Rent rent = new Rent(element0, element1, element2, element3, element4, element5, element6, element7);
          for (Location space : spaces) {
                if (space.getName().equals(element0)) {
                 ((Space) space).setRent(rent);
                }
          }
    }

    public static Location.LocationKind getLocationKind(String kind) {
        return Location.LocationKind.valueOf(kind.toUpperCase());
    }

    public static List<Location> parse(FileReader fileReader){
        List<Location> spaces = parseFile(fileReader);
        return parseRentFile(fileReader, spaces);
    }

    public static Color stringToColor(String color){
        return color.isEmpty() ? null : Color.valueOf(color.toUpperCase());
    }

}


