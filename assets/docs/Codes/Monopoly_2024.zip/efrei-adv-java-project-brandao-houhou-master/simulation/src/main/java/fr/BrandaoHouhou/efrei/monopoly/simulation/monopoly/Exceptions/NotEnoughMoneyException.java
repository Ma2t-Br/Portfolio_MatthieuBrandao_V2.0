package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Exceptions;


public class NotEnoughMoneyException extends Exception {

    public NotEnoughMoneyException(String message) {
        super(message);
    }
}
