package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Locations;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services.PlayerService;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services.PropertyService;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Player;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Space;
import fr.arsenelapostolet.efrei.monopoly.Color;

import java.math.BigDecimal;
import java.util.List;

public class Company extends Space {
    public Company(String name, Color color, int price) {
        super(name, LocationKind.COMPANY, color, price);
    }

    public BigDecimal calculateRent(int scorePlayer, List<Player> players){
        PropertyService propertyService = new PropertyService(new PlayerService());
        int numberOfCompaniesOwned = propertyService.numberOfPropertyOwned(this.getOwner(), players, LocationKind.COMPANY);

        BigDecimal rent = BigDecimal.valueOf(0);

        if (numberOfCompaniesOwned == 1) {
            rent = BigDecimal.valueOf(scorePlayer * 4L);
        } else if (numberOfCompaniesOwned == 2) {
            rent = BigDecimal.valueOf(scorePlayer * 10L);
        }

        return rent;
    }
}
