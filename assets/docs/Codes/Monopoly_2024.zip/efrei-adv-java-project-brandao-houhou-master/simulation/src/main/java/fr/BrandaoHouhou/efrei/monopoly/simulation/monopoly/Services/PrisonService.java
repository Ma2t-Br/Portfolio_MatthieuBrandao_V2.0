package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Exceptions.NotEnoughMoneyException;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Player;
import fr.arsenelapostolet.efrei.monopoly.Location;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public class PrisonService {

    public void goToPrisonIfNecessary(Player currentPlayer, Map<String, Location> playersLocation, List<Location> locationList) {
        if (playersLocation.get(currentPlayer.getName()).getKind().equals(Location.LocationKind.GO_TO_JAIL)){
            playersLocation.put(currentPlayer.getName(), locationList.stream()
                    .filter(location -> location.getKind().equals(Location.LocationKind.JAIL))
                    .findFirst()
                    .orElse(null));
            currentPlayer.setPrisonRound(1);
        }
    }

    public void manageJail(Player currentPlayer) throws NotEnoughMoneyException {
        if (currentPlayer.getPrisonRound() > 0){
            if (currentPlayer.getPrisonRound()+ 1 >= 3){
                payJail(currentPlayer);
            } else {
                currentPlayer.setPrisonRound(currentPlayer.getPrisonRound() + 1);
            }
        }
    }

    public void payJail(Player currentPlayer)throws NotEnoughMoneyException{

        if(currentPlayer.getCash().compareTo(BigDecimal.valueOf(50)) >= 0){
            currentPlayer.removeCash(BigDecimal.valueOf(50));
            currentPlayer.setPrisonRound(0);
        }else{
            if(currentPlayer.getPrisonRound() + 1 >= 3)
                throw new NotEnoughMoneyException("You don't have enough money to pay the prison");
            else
                currentPlayer.setPrisonRound(currentPlayer.getPrisonRound() + 1);
        }
    }

}
