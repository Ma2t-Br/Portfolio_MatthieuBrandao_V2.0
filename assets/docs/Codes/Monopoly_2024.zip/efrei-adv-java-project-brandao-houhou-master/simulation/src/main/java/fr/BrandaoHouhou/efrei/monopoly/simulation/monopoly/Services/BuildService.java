package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services;

import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Player;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Space;
import fr.arsenelapostolet.efrei.monopoly.Location;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Exceptions.CannotBuildException;

import java.util.List;

public class BuildService {

    public void playerCanBuild(Player currentPlayer, List<Location> monopolyMap, String currentLocation) throws CannotBuildException {

        Space propertyToUpgrade = getPropertyToUpgrade(monopolyMap, currentLocation);

        if(propertyToUpgrade == null)
            throw new CannotBuildException("This property doesn't exist");

        if(propertyToUpgrade.getBuildLevel() == 5)
            throw new CannotBuildException("This property is already at the maximum level");

        if(propertyToUpgrade.getOwner() == null || !propertyToUpgrade.getOwner().equals(currentPlayer.getName()))
            throw new CannotBuildException("You don't own this property");

        if(!currentPlayer.ownsAllPropertiesOfCurrentLocationColor(monopolyMap, propertyToUpgrade))
            throw new CannotBuildException("You don't own all the properties of this color");

        if(!currentPlayer.hasEnoughMoneyToBuild(propertyToUpgrade))
            throw new CannotBuildException("You don't have enough money to build");

    }

    public void buildProperty(Player currentPlayer, List<Location> monopolyMap, String currentLocation) {
        Space propertyToUpgrade = getPropertyToUpgrade(monopolyMap, currentLocation);
        propertyToUpgrade.incrementBuildLevel();
        currentPlayer.removeCash(propertyToUpgrade.getRent().getCost());
    }

    public Space getPropertyToUpgrade(List<Location> monopolyMap, String currentLocation){
        return (Space) monopolyMap.stream()
                .filter(location -> location.getName().equals(currentLocation))
                .findFirst()
                .orElse(null);
    }
}
