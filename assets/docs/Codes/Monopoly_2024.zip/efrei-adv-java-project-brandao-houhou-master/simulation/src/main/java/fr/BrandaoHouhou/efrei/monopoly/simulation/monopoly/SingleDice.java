package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly;

import java.util.Random;

public class SingleDice {

    public int throwSixSidedDice() {
        return new Random().nextInt(6) + 1;
    }
}
