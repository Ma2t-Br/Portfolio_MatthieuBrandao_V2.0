package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly;

import fr.arsenelapostolet.efrei.monopoly.Location;
import fr.arsenelapostolet.efrei.monopoly.Color;

import java.math.BigDecimal;
import java.util.List;
import java.util.ArrayList;
import java.util.Objects;
import java.util.stream.Collectors;

public class Player {

    private final String name;
    private BigDecimal cash;
    private final List<Space> properties = new ArrayList<>();
    private int prisonRound;
    private int score;

    public Player(String name){
        this.name = name;
        this.cash = BigDecimal.valueOf(1500);
        this.prisonRound = 0;
    }

    public void addCash(BigDecimal amount){
        cash = cash.add(amount);
    }

    public void removeCash(BigDecimal amount){
        cash = cash.subtract(amount);
    }

    public BigDecimal getCash(){
        return cash;
    }

    public String getName(){
        return name;
    }

    public void addProperty(Space property){
        properties.add(property);
    }

    public void removeProperty(Space property){
        properties.remove(property);
    }

    public List<Space> getProperties(){
        return properties;
    }

    public void setPrisonRound(int prisonRound){
        this.prisonRound = prisonRound;
    }

    public int getPrisonRound(){
        return prisonRound;
    }

    public int getScore() {
        return this.score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setCash(BigDecimal cash) {
        this.cash = cash;
    }


    public Boolean ownsAllPropertiesOfCurrentLocationColor(List<Location> monopolyMap, Space currentLocation) {
        Color color = currentLocation.getColor();
        List<Space> properties = getAllPropertiesByColor(color);
        return monopolyMap.stream()
                .filter(property -> Objects.equals(property.getColor(), color) &&
                        Objects.equals(property.getKind(), Location.LocationKind.PROPERTY))
                .allMatch(properties::contains);

    }

    public List<Space> getAllPropertiesByColor(Color color) {
        return properties.stream().filter(property -> Objects.equals(property.getColor(), color) &&
                Objects.equals(property.getKind(), Location.LocationKind.PROPERTY))
                .collect(Collectors.toList());
    }

    public Boolean hasEnoughMoneyToBuild(Space propertyToUpgrade) {
        return cash.compareTo(propertyToUpgrade.getRent().getCost()) >= 0;
    }

}
