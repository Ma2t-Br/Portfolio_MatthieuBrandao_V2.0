package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services;

import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Player;
import fr.arsenelapostolet.efrei.monopoly.Location;

import java.util.List;
import java.util.Map;

public class PlayerService {

    public void initPlayers(List<String> playerIds, List<Player> players) {
        players.addAll(playerIds.stream()
                .map(Player::new)
                .toList());
    }

    public Player getPlayer(String name, List<Player> players) {
        return players.stream()
                .filter(player -> player.getName().equals(name))
                .findFirst()
                .orElse(null);
    }

    public void removePlayer(Player player, Map<String, Location> playersLocation, List<Player> players){
        playersLocation.remove(player.getName());
        players.remove(player);
    }
}
