package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Exceptions;


public class CannotBuildException extends Exception {

    public CannotBuildException(String message) {
        super(message);
    }
}
