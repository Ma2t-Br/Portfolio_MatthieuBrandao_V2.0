package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services;

import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Player;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Space;
import fr.arsenelapostolet.efrei.monopoly.Location;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public class PaymentService {
    private final MovementsService movementsService;
    private final PropertyService propertyService;
    private final PlayerService playerService;

    public PaymentService(MovementsService movementsService, PropertyService propertyService, PlayerService playerService){
        this.movementsService = movementsService;
        this.propertyService = propertyService;
        this.playerService = playerService;
    }
    public void buyProperty(Map<String, Location> playersLocation, Player currentPlayer){
        Space currentSpace = (Space) playersLocation.get(currentPlayer.getName());
        currentPlayer.removeCash(currentSpace.getPrice());
        currentSpace.setOwner(currentPlayer.getName());
        currentPlayer.addProperty(currentSpace);
    }

    public Player payRentIfNecessary(Player currentPlayer, Map<String, Location> playersLocation, List<Player> players) {
        Space currentSpace = movementsService.getCurrentPlayerSpace(playersLocation, currentPlayer);
        String owner = currentSpace.getOwner();

        if (owner != null && !owner.equals(currentPlayer.getName())) {
            BigDecimal rent = currentSpace.calculateRent(currentPlayer.getScore(), players);
            currentPlayer = handleRentPayment(owner, rent, currentPlayer, players, playersLocation);
        }
        return currentPlayer;
    }

    private Player handleRentPayment(String owner, BigDecimal rent, Player currentPlayer, List<Player> players, Map<String, Location> playersLocation) {
        BigDecimal previousPlayerCash = currentPlayer.getCash().subtract(rent);

        if (previousPlayerCash.compareTo(BigDecimal.valueOf(0)) < 0) {
            currentPlayer = propertyService.transferAssetsToOwner(owner, currentPlayer, players, playersLocation);
        } else {
            performRentPayment(owner, rent, currentPlayer, players);
        }
        return currentPlayer;
    }
    private void performRentPayment(String owner, BigDecimal rent, Player currentPlayer, List<Player> players) {
        currentPlayer.removeCash(rent);
        playerService.getPlayer(owner, players).addCash(rent);
    }
    private void performTaxPayment(BigDecimal tax, Player currentPlayer) {
        currentPlayer.removeCash(tax);
    }
    public void payTaxIfNecessary(Player currentPlayer, Map<String, Location> playersLocation, List<Player> players) {
        Space currentSpace = movementsService.getCurrentPlayerSpace(playersLocation, currentPlayer);
        if(currentSpace.getKind().equals(Location.LocationKind.TAX)){
            performTaxPayment(currentSpace.getPrice(), currentPlayer);
        }
    }

}
