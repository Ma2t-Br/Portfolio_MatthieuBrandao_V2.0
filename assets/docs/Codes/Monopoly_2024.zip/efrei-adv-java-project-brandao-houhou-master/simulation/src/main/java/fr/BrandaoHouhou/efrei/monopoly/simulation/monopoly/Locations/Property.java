package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Locations;

import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Player;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Space;
import fr.arsenelapostolet.efrei.monopoly.Color;

import java.math.BigDecimal;
import java.util.List;

public class Property extends Space {

    public Property(String name,Color color, int price) {
        super(name, LocationKind.PROPERTY, color, price);
    }

    public BigDecimal calculateRent(int scorePlayer, List<Player> players){
        return switch (this.getBuildLevel()) {
            case 0 -> this.getRent().getBare();
            case 1 -> this.getRent().getLvl1();
            case 2 -> this.getRent().getLvl2();
            case 3 -> this.getRent().getLvl3();
            case 4 -> this.getRent().getLvl4();
            case 5 -> this.getRent().getLvl5();
            default -> null;
        };
    }
}
