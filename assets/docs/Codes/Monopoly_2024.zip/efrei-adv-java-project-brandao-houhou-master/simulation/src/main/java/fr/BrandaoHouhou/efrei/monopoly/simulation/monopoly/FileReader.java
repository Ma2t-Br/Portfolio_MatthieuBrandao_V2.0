package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly;
import java.io.BufferedReader;
import java.io.IOException;

public interface FileReader {

    public BufferedReader getBufferedReader(String path) throws IOException;
}
