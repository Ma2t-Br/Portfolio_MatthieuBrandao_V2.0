package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Locations;
import fr.arsenelapostolet.efrei.monopoly.Color;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Space;

public class Tax  extends Space {
    public Tax(String name, Color color, int price) {
        super(name, LocationKind.TAX, color, price);
    }
}