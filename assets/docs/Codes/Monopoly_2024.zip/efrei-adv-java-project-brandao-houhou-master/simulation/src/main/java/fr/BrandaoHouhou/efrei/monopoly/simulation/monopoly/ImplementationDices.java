package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly;
import fr.arsenelapostolet.efrei.monopoly.Dices;
import java.util.Random;

public class ImplementationDices implements Dices {

    public SingleDice dice;

    public ImplementationDices(SingleDice dice){ this.dice = dice; }

    @Override
    public int throwTwoSixSidedDices() {
        return dice.throwSixSidedDice() + dice.throwSixSidedDice();
    }
}
