package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly;
import java.math.BigDecimal;

public class Rent {

    private final String property ;
    private final BigDecimal cost;
    private final BigDecimal lvl1;
    private final BigDecimal lvl2;
    private final BigDecimal lvl3;
    private final BigDecimal lvl4;
    private final BigDecimal lvl5;
    private final BigDecimal bare;

    public Rent(String property,BigDecimal cost,BigDecimal lvl1,BigDecimal lvl2,BigDecimal lvl3,BigDecimal lvl4,BigDecimal lvl5,BigDecimal bare){
        this.property=property;
        this.cost=cost;
        this.lvl1=lvl1;
        this.lvl2=lvl2;
        this.lvl3=lvl3;
        this.lvl4=lvl4;
        this.lvl5=lvl5;
        this.bare=bare;
    }

    public String getProperty(){
        return this.property;
    }

    public BigDecimal getCost(){
        return this.cost;
    }

    public BigDecimal getLvl1(){
        return this.lvl1;
    }

    public BigDecimal getLvl2(){
        return this.lvl2;
    }

    public BigDecimal getLvl3(){
        return this.lvl3;
    }

    public BigDecimal getLvl4(){
        return this.lvl4;
    }

    public BigDecimal getLvl5(){
        return this.lvl5;
    }

    public BigDecimal getBare(){
        return this.bare;
    }
}
