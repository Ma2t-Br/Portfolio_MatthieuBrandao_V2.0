package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Locations;
import fr.arsenelapostolet.efrei.monopoly.Location;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Space;
import fr.arsenelapostolet.efrei.monopoly.Color;


public class LocationGenerator{

    public static Space buildLocation(String name, Location.LocationKind kind, Color color,int price) {
        return switch (kind){
            case PROPERTY -> new Property(name, color, price);
            case STATION -> new Station(name, color, price);
            case COMPANY -> new Company(name, color, price);
            case TAX -> new Tax(name, color, price);
            default -> new Space(name, kind, color, price);
        };

    }
}