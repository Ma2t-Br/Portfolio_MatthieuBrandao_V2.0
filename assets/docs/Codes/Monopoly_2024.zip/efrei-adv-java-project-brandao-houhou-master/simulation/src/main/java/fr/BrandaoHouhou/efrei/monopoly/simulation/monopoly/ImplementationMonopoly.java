package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly;

import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Exceptions.CannotBuildException;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Exceptions.NotEnoughMoneyException;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services.*;
import fr.arsenelapostolet.efrei.monopoly.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ImplementationMonopoly implements Monopoly {

    private final Map<String, Location> playersLocation = new HashMap<>();
    private final List<Player> players = new ArrayList<>();
    private final Dices dices;
    private final List<Location> monopolyMap = Parser.parse(new DefaultFileReader());
    private final PrisonService prisonService;
    private final PlayerService playerService;
    private Player currentPlayer;
    private final MovementsService movementsService;
    private final PaymentService paymentService;
    private final BuildService buildService;

    public ImplementationMonopoly(Dices dices, List<String> playerIds, MovementsService movementsService, PaymentService paymentService, PlayerService playerService,PrisonService prisonService, BuildService buildService){
        this.dices = dices;
        this.movementsService = movementsService;
        this.paymentService = paymentService;
        this.prisonService = prisonService;
        this.playerService = playerService;
        this.buildService = buildService;

        playerService.initPlayers(playerIds, players);
        movementsService.initPlayersLocation(players, playersLocation, monopolyMap);
        currentPlayer = players.getFirst();
        movementsService.movePlayer(playersLocation, monopolyMap, dices, currentPlayer);
    }



    @Override
    public void submitOrder(String playerName, OrderKind order, Map<String, Object> propertyName) throws GameFinishedException {

        if (!isCurrentPlayer(playerName)) {
            return;
        }
        checkGameFinished();

        switch (order){
            case IDLE :
                if (currentPlayer.getPrisonRound() > 0 ){
                    try {
                        prisonService.manageJail(currentPlayer);
                    }catch (NotEnoughMoneyException e){
                        playerService.removePlayer(currentPlayer, playersLocation, players);
                    }
                }
                break;
            case BUY :
                paymentService.buyProperty(playersLocation, currentPlayer);
                break;
            case PAY_PRISON :
                handlePayPrisonOrder(currentPlayer);
                break;
            case BUILD :
                try{
                    buildService.playerCanBuild(currentPlayer, monopolyMap, propertyName.get("propertyName").toString());
                    buildService.buildProperty(currentPlayer, monopolyMap, propertyName.get("propertyName").toString());
                } catch (CannotBuildException ignored) {}

                break;
        }

        updateCurrentPlayer();
        move();
    }

    private void updateCurrentPlayer() {
        currentPlayer = players.get((players.indexOf(currentPlayer) + 1) % players.size());
    }

    private void checkGameFinished() throws GameFinishedException {
        if (players.size() < 2) {
            throw new GameFinishedException();
        }
    }

    private boolean isCurrentPlayer(String playerName) {
        return currentPlayer.getName().equals(playerName);
    }

    private void handlePayPrisonOrder(Player currentPlayer)  {
        try {
            if (currentPlayer.getPrisonRound() > 1) {
                prisonService.payJail(currentPlayer);
                movementsService.releasePlayerFromPrison(playersLocation, monopolyMap, currentPlayer);
                prisonService.goToPrisonIfNecessary(currentPlayer, playersLocation, monopolyMap);
                currentPlayer = paymentService.payRentIfNecessary(currentPlayer, playersLocation, players);
            }
        } catch (NotEnoughMoneyException e) {
            playerService.removePlayer(currentPlayer, playersLocation, players);
        }
    }

    private void move(){
        movementsService.movePlayer(playersLocation, monopolyMap, dices, currentPlayer);
        prisonService.goToPrisonIfNecessary(currentPlayer, playersLocation, monopolyMap);
        currentPlayer = paymentService.payRentIfNecessary(currentPlayer, playersLocation, players);
        paymentService.payTaxIfNecessary(currentPlayer, playersLocation, players);
    }

    @Override
    public Map<String, Location> getPlayersLocation() {
        return new HashMap<>(playersLocation);
    }

    @Override
    public Map<String, BigDecimal> getPlayersBalance() {
        Map<String, BigDecimal> playersBalance = new HashMap<>();
        for (Player player: players) {
            playersBalance.put(player.getName(), player.getCash());
        }
        return playersBalance;
    }

    @Override
    public List<Location> getBoard() {
        return new ArrayList<>(monopolyMap);
    }
}