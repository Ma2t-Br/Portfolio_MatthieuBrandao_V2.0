package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services;

import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Player;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Space;
import fr.arsenelapostolet.efrei.monopoly.Dices;
import fr.arsenelapostolet.efrei.monopoly.Location;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public class MovementsService {

    public void initPlayersLocation(List<Player> players, Map<String, Location> playersLocation, List<Location> monopolyMap) {
        players.stream()
                .map(Player::getName)
                .forEach(name -> playersLocation.put(name, monopolyMap.getFirst()));
    }

    public void movePlayer(Map<String, Location> playersLocation, List<Location> monopolyMap, Dices dices, Player currentPlayer){
        Location currentLocation = playersLocation.get(currentPlayer.getName());
        int currentPosition = monopolyMap.indexOf(currentLocation);
        currentPlayer.setScore(dices.throwTwoSixSidedDices());
        int scorePlayer = currentPlayer.getScore();
        int nextPosition = (currentPosition + scorePlayer) % monopolyMap.size() ;
        int numberOfLaps = (currentPosition + scorePlayer) / monopolyMap.size();

        if (currentPlayer.getPrisonRound() > 0)
            return;

        playersLocation.put(currentPlayer.getName(), monopolyMap.get(nextPosition));
        currentPlayer.addCash(new BigDecimal(numberOfLaps*200));
    }

    public Space getCurrentPlayerSpace(Map<String, Location> playersLocation, Player currentPlayer) {
        return (Space) playersLocation.get(currentPlayer.getName());
    }

    public void releasePlayerFromPrison(Map<String, Location> playersLocation, List<Location> monopolyMap, Player currentPlayer) {
        Location currentLocation = playersLocation.get(currentPlayer.getName());
        int currentPosition = monopolyMap.indexOf(currentLocation);

        int scorePlayer = currentPlayer.getScore();
        int nextPosition = (currentPosition + scorePlayer) % monopolyMap.size() ;
        int numberOfLaps = (currentPosition + scorePlayer) / monopolyMap.size();

        playersLocation.put(currentPlayer.getName(), monopolyMap.get(nextPosition));
        currentPlayer.addCash(new BigDecimal(numberOfLaps*200));
    }

}
