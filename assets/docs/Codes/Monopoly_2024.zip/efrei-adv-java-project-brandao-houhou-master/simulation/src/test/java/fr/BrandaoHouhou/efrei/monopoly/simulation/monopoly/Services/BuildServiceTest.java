package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services;

import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Exceptions.CannotBuildException;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Locations.LocationGenerator;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Player;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Rent;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Space;
import fr.arsenelapostolet.efrei.monopoly.Color;
import fr.arsenelapostolet.efrei.monopoly.Location;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class BuildServiceTest {
    private BuildService buildService;

    @BeforeEach
    public void setUp() {
        buildService = new BuildService();
    }

    @Test
    public void testPlayerCanBuild() {
        boolean passed = false;

        Player currentPlayer = new Player("Player1");
        List<Location> monopolyMap = new ArrayList<>();
        Space property = new Space("Property1", Location.LocationKind.PROPERTY, Color.RED, 200);
        property.setOwner(currentPlayer.getName());
        currentPlayer.addProperty(property);
        monopolyMap.add(property);
        String currentLocation = "Property1";

        BigDecimal cost = new BigDecimal(10);
        BigDecimal generalPrice = new BigDecimal(11);
        property.setRent(new Rent("Property1", cost, generalPrice, generalPrice, generalPrice, generalPrice, generalPrice, generalPrice));

        try{
            buildService.playerCanBuild(currentPlayer, monopolyMap, currentLocation);
            passed = true;
        } catch (CannotBuildException ignored){}

        assertTrue(passed);
    }

    @Test
    public void testPlayerCannotBuildNonexistentProperty() {
        Player currentPlayer = new Player("Player1");
        List<Location> monopolyMap = new ArrayList<>();
        String currentLocation = "NonexistentProperty";

        assertThrows(CannotBuildException.class, () -> buildService.playerCanBuild(currentPlayer, monopolyMap, currentLocation));
    }

    @Test
    public void testPlayerCannotBuildMaxLevelProperty() {
        Player currentPlayer = new Player("Player1");
        List<Location> monopolyMap = new ArrayList<>();
        Space property = new Space("Property1", Location.LocationKind.PROPERTY, Color.RED, 200);

        for (int i=0; i<5; i++){property.incrementBuildLevel();}// Set property to max level

        monopolyMap.add(property);
        String currentLocation = "Property1";

        assertThrows(CannotBuildException.class, () -> buildService.playerCanBuild(currentPlayer, monopolyMap, currentLocation));
    }

    @Test
    public void testPlayerDoesNotOwnProperty() {
        Player currentPlayer = new Player("Player1");
        List<Location> monopolyMap = new ArrayList<>();
        Space property = new Space("Property1", Location.LocationKind.PROPERTY, Color.RED, 200);
        monopolyMap.add(property);
        String currentLocation = "Property1";

        assertThrows(CannotBuildException.class, () -> buildService.playerCanBuild(currentPlayer, monopolyMap, currentLocation));
    }

    @Test
    public void testPlayerDoesNotOwnAllPropertiesOfColor() {
        Player currentPlayer = new Player("Player1");
        List<Location> monopolyMap = new ArrayList<>();
        Space property1 = new Space("Property1", Location.LocationKind.PROPERTY, Color.RED, 200);
        Space property2 = new Space("Property2", Location.LocationKind.PROPERTY, Color.RED, 200);
        property1.setOwner(currentPlayer.getName());
        currentPlayer.addProperty(property1);
        monopolyMap.add(property1);
        monopolyMap.add(property2);
        String currentLocation = "Property1";

        assertThrows(CannotBuildException.class, () -> buildService.playerCanBuild(currentPlayer, monopolyMap, currentLocation));
    }

    @Test
    public void testPlayerDoesNotHaveEnoughMoneyToBuild() {
        Player currentPlayer = new Player("Player1");
        List<Location> monopolyMap = new ArrayList<>();
        Space property = new Space("Property1", Location.LocationKind.PROPERTY, Color.RED, 200);
        property.setOwner(currentPlayer.getName());
        monopolyMap.add(property);
        currentPlayer.addProperty(property);
        String currentLocation = "Property1";

        BigDecimal cost = new BigDecimal(1500+500); //More than the player cash
        BigDecimal generalPrice = new BigDecimal(11);
        property.setRent(new Rent("Property1", cost, generalPrice, generalPrice, generalPrice, generalPrice, generalPrice, generalPrice));

        assertThrows(CannotBuildException.class, () -> buildService.playerCanBuild(currentPlayer, monopolyMap, currentLocation));
    }

    @Test
    public void testBuildProperty() {


        Player currentPlayer = new Player("Player1");
        List<Location> monopolyMap = new ArrayList<>();
        Space property = LocationGenerator.buildLocation("Property1", Location.LocationKind.PROPERTY, Color.RED, 200);
        property.setOwner(currentPlayer.getName());
        monopolyMap.add(property);
        String currentLocation = "Property1";

        BigDecimal cost = new BigDecimal(10);
        BigDecimal generalPrice = new BigDecimal(11);
        property.setRent(new Rent("Property1", cost, generalPrice, generalPrice, generalPrice, generalPrice, generalPrice, generalPrice));

        buildService.buildProperty(currentPlayer, monopolyMap, currentLocation);

        assertEquals(1, property.getBuildLevel());
        assertEquals(BigDecimal.valueOf(1500-10), currentPlayer.getCash()); // Assuming the property cost is deducted immediately
    }
}
