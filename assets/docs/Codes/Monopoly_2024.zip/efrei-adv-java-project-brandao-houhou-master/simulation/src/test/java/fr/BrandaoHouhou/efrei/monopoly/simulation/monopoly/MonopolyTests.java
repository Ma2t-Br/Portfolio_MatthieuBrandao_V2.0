package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly;


import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services.*;
import fr.arsenelapostolet.efrei.monopoly.BaseMonopolyTests;
import fr.arsenelapostolet.efrei.monopoly.Dices;

import java.util.List;


public class MonopolyTests extends BaseMonopolyTests {

    @Override
    public ImplementationMonopoly createMonopoly (Dices dices,List<String> players){
        MovementsService movementsService = new MovementsService();
        PlayerService playerService = new PlayerService();
        PropertyService propertyService = new PropertyService(playerService);
        PaymentService paymentService = new PaymentService(movementsService, propertyService, playerService);
        PrisonService prisonService = new PrisonService();
        BuildService buildService = new BuildService();
        return new ImplementationMonopoly(dices,  players, movementsService, paymentService, playerService, prisonService, buildService);
    }

}
