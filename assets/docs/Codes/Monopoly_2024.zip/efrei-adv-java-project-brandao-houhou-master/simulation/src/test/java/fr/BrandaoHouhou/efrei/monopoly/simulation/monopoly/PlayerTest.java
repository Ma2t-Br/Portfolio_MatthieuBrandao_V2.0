package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly;

import fr.arsenelapostolet.efrei.monopoly.Color;
import fr.arsenelapostolet.efrei.monopoly.Location;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PlayerTest {

    Player player;

    @BeforeEach
    public void setUp(){
        player = new Player("player");
    }

    @Test
    public void testAddCash(){
        player.addCash(new BigDecimal(200));
        assertEquals(player.getCash(), new BigDecimal(1700));
    }

    @Test
    public void testRemoveCash(){
        player.removeCash(new BigDecimal(600));
        assertEquals(player.getCash(), new BigDecimal(900));
    }

    @Test
    public void testAddProperty_ThenRemoveIt(){
        Space property = new Space("SpaceTest", Location.LocationKind.COMPANY, Color.RED, 1500);
        player.addProperty(property);
        assertEquals(player.getProperties().size(), 1);
        assertEquals(player.getProperties().getFirst(), property);

        player.removeProperty(property);
        assertEquals(player.getProperties().size(), 0);
    }
}
