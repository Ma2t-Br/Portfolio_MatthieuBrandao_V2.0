package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services;

import fr.arsenelapostolet.efrei.monopoly.Color;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Player;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Space;
import fr.arsenelapostolet.efrei.monopoly.Location;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class PaymentServiceTest {

    private PaymentService paymentService;
    private MovementsService movementsService;
    private PropertyService propertyService;
    private PlayerService playerService;

    @BeforeEach
    public void setUp() {
        movementsService = mock(MovementsService.class);
        propertyService = mock(PropertyService.class);
        playerService = mock(PlayerService.class);
        paymentService = new PaymentService(movementsService, propertyService, playerService);
    }

    @Test
    public void testBuyProperty() {
        Map<String, Location> playersLocation = new HashMap<>();
        Player currentPlayer = new Player("Player");
        Space currentSpace = new Space("SpaceTest", Location.LocationKind.COMPANY, Color.RED, 1500);
        playersLocation.put(currentPlayer.getName(), currentSpace);

        paymentService.buyProperty(playersLocation, currentPlayer);

        assertEquals(currentSpace.getOwner(), currentPlayer.getName());
        assertEquals(1, currentPlayer.getProperties().size());
        assertEquals(currentSpace, currentPlayer.getProperties().get(0));
    }
}