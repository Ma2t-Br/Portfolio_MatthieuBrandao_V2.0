package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services;

import fr.arsenelapostolet.efrei.monopoly.Color;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Locations.Company;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Player;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Space;
import fr.arsenelapostolet.efrei.monopoly.Dices;
import fr.arsenelapostolet.efrei.monopoly.Location;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class MovementsServiceTest {

    private MovementsService movementsService;
    private Dices dices;

    @BeforeEach
    public void setUp() {
        movementsService = new MovementsService();
        dices = mock(Dices.class);
    }

    @Test
    public void testInitPlayersLocation() {
        List<Player> players = new ArrayList<>();
        Player player1 = new Player("Player1");
        Player player2 = new Player("Player2");
        players.add(player1);
        players.add(player2);

        Map<String, Location> playersLocation = new HashMap<>();
        List<Location> monopolyMap = new ArrayList<>();
        Location location1 = new Company("Location1", Color.RED, 100);
        Location location2 = new Company("Location2", Color.DARKBLUE, 50);
        monopolyMap.add(location1);
        monopolyMap.add(location2);

        movementsService.initPlayersLocation(players, playersLocation, monopolyMap);

        assertEquals(2, playersLocation.size());
        assertEquals(location1, playersLocation.get("Player1"));
        assertEquals(location1, playersLocation.get("Player2"));
    }

    @Test
    public void testMovePlayer() {
        Map<String, Location> playersLocation = new HashMap<>();
        Player player = new Player("Player");
        playersLocation.put(player.getName(), new Company("Location1", Color.RED, 100));
        List<Location> monopolyMap = new ArrayList<>();
        Location location1 = new Company("Location1", Color.RED, 100);
        Location location2 = new Company("Location2", Color.DARKBLUE, 50);
        monopolyMap.add(location1);
        monopolyMap.add(location2);

        when(dices.throwTwoSixSidedDices()).thenReturn(5); // Mocking dice throw

        movementsService.movePlayer(playersLocation, monopolyMap, dices, player);

        assertEquals(5, player.getScore());
        assertEquals(location1, playersLocation.get(player.getName()));
    }

    @Test
    public void testGetCurrentPlayerSpace() {
        Map<String, Location> playersLocation = new HashMap<>();
        Player player = new Player("Player");
        Space space = new Space("SpaceTest", Location.LocationKind.COMPANY, Color.RED, 1500);
        playersLocation.put(player.getName(), space);

        Space currentPlayerSpace = movementsService.getCurrentPlayerSpace(playersLocation, player);

        assertEquals(space, currentPlayerSpace);
    }
}
