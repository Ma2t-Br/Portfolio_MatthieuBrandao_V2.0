package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services;

import fr.arsenelapostolet.efrei.monopoly.Color;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Locations.Company;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Player;
import fr.arsenelapostolet.efrei.monopoly.Location;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class PlayerServiceTest {

    private PlayerService playerService;

    @BeforeEach
    public void setUp() {
        playerService = new PlayerService();
    }

    @Test
    public void testInitPlayers() {
        List<String> playerIds = List.of("Player1", "Player2", "Player3");
        List<Player> players = new ArrayList<>();

        playerService.initPlayers(playerIds, players);

        assertEquals(3, players.size());
        assertEquals("Player1", players.get(0).getName());
        assertEquals("Player2", players.get(1).getName());
        assertEquals("Player3", players.get(2).getName());
    }

    @Test
    public void testGetPlayer_PlayerExists() {
        List<Player> players = new ArrayList<>();
        Player player1 = new Player("Player1");
        players.add(player1);

        Player foundPlayer = playerService.getPlayer("Player1", players);

        assertEquals(player1, foundPlayer);
    }

    @Test
    public void testGetPlayer_PlayerDoesNotExist() {
        List<Player> players = new ArrayList<>();
        Player player1 = new Player("Player1");
        players.add(player1);

        Player foundPlayer = playerService.getPlayer("Player2", players);

        assertNull(foundPlayer);
    }

    @Test
    public void testRemovePlayer() {
        List<Player> players = new ArrayList<>();
        Map<String, Location> playersLocation = new HashMap<>();
        Player player1 = new Player("Player1");
        players.add(player1);
        playersLocation.put("Player1", new Company("Location1", Color.RED, 100));

        playerService.removePlayer(player1, playersLocation, players);

        assertEquals(0, players.size());
        assertEquals(0, playersLocation.size());
    }
}
