package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly;

import fr.arsenelapostolet.efrei.monopoly.Dices;
import fr.arsenelapostolet.efrei.monopoly.Location;

import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

public class DicesTest {
    SingleDice dice = mock(SingleDice.class);

    @Test
    void testThrowTwoSixSidedDices() {

        when(dice.throwSixSidedDice()).thenReturn(3).thenReturn(2);

        ImplementationDices Dices = new ImplementationDices(dice);

        int result = Dices.throwTwoSixSidedDices();
        assertEquals(5, result);
    }
}
