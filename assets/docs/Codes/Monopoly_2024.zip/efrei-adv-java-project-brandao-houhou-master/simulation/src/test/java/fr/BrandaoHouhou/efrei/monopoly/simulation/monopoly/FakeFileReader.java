package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly;

import java.io.BufferedReader;
import java.io.StringReader;


public class FakeFileReader implements FileReader{

        private final String data;

        public FakeFileReader(String lines){
                this.data = lines;
        }

        @Override
        public BufferedReader getBufferedReader(String path){
                return new BufferedReader(new StringReader(data));
        }
}
