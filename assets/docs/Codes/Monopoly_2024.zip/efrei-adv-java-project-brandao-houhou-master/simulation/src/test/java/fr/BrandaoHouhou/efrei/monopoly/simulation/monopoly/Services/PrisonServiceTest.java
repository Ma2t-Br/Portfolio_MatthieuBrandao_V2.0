package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services;

import fr.arsenelapostolet.efrei.monopoly.Color;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Exceptions.NotEnoughMoneyException;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Player;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Space;
import fr.arsenelapostolet.efrei.monopoly.Location;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class PrisonServiceTest {

    private PrisonService prisonService;

    private PlayerService playerService;

    @BeforeEach
    public void setUp() {
        playerService = new PlayerService();
        prisonService = new PrisonService();
    }

    @Test
    public void imprisonPlayerIfNecessary() {
        Map<String, Location> playersLocation = new HashMap<>();
        Player currentPlayer = new Player("Player");
        Space currentSpace = new Space("SpaceTest", Location.LocationKind.GO_TO_JAIL, Color.RED, 1500);
        playersLocation.put(currentPlayer.getName(), currentSpace);
        List<Location> locationList = new ArrayList<>();
        Location jail = new Space("Jail", Location.LocationKind.JAIL, Color.RED, 1500);
        locationList.add(jail);
        prisonService.goToPrisonIfNecessary(currentPlayer, playersLocation, locationList);
        assertEquals(jail, playersLocation.get(currentPlayer.getName()));
    }

    @Test
    public void payJailTest() throws NotEnoughMoneyException {
        Player currentPlayer = new Player("Player");
        currentPlayer.setPrisonRound(2);
        prisonService.payJail(currentPlayer);
        assertEquals(BigDecimal.valueOf(1450), currentPlayer.getCash());
        assertEquals(0, currentPlayer.getPrisonRound());
    }

    @Test
    public void after3PrisonRoundYourNotOut_enoughCash() {
        Map<String, Location> playersLocation = new HashMap<>();
        Player currentPlayer = new Player("Player");
        List<Player> players = new ArrayList<>();
        players.add(currentPlayer);

        currentPlayer.setCash(BigDecimal.valueOf(50));
        Space currentSpace = new Space("SpaceTest", Location.LocationKind.JAIL, Color.RED, 1500);
        playersLocation.put(currentPlayer.getName(), currentSpace);
        currentPlayer.setPrisonRound(2);

        //Bloc order IDLE
        if (currentPlayer.getPrisonRound() > 0 ){
            try {
                prisonService.manageJail(currentPlayer);
            }catch (NotEnoughMoneyException e){
                playerService.removePlayer(currentPlayer, playersLocation, players);
            }
        }

        assertEquals(BigDecimal.valueOf(0), currentPlayer.getCash());
        assertEquals(1, playersLocation.size());
    }

    @Test
    public void after3PrisonRoundYourOut_NotEnoughCash() {
        Map<String, Location> playersLocation = new HashMap<>();
        Player currentPlayer = new Player("Player");
        List<Player> players = new ArrayList<>();
        players.add(currentPlayer);

        currentPlayer.setCash(BigDecimal.valueOf(40));
        Space currentSpace = new Space("SpaceTest", Location.LocationKind.JAIL, Color.RED, 1500);
        playersLocation.put(currentPlayer.getName(), currentSpace);
        currentPlayer.setPrisonRound(2);

        //Bloc order IDLE
        if (currentPlayer.getPrisonRound() > 0 ){
            try {
                prisonService.manageJail(currentPlayer);
            }catch (NotEnoughMoneyException e){
                playerService.removePlayer(currentPlayer, playersLocation, players);
            }
        }

        assertEquals(BigDecimal.valueOf(40), currentPlayer.getCash());
        assertEquals(0, playersLocation.size());
    }
}

