package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services;

import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.FakeFileReader;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services.Parser;
import fr.arsenelapostolet.efrei.monopoly.Location;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ParserTest {

    List<Location> monopolyMap;

    @BeforeEach
    public void setUp() {
        String dataMonopoly =
                "name,kind,color,price"
                        + "\n"
                        + "Rue Victor Hugo 2,property,brown,61"
                        + "\n"
                        + "Rue Victor Hugo 1,property,brown,62"
                        + "\n"
                        + "Rue Victor Hugo 4,property,brown,63";
        String dataRent =
                "property,cost,lvl1,lvl2,lvl3,lvl4,lvl5,bare"
                        + "\n"
                        + "Rue Victor Hugo 2,50,10,30,90,160,250,2"
                        + "\n"
                        + "Rue Victor Hugo 1,50,20,60,180,320,450,4"
                        + "\n"
                        + "Rue Victor Hugo 4,50,30,90,270,400,550,6";

        monopolyMap = Parser.parseFile(new FakeFileReader(dataMonopoly));
        monopolyMap = Parser.parseRentFile(new FakeFileReader(dataRent),monopolyMap);
    }

    @Test
    @DisplayName("Test map size")
    public void testParsedMapSize() {
        assertEquals(monopolyMap.size(), 3);
    }

    @Test
    @DisplayName("Test map element")
    public void testParsedMapElement() {
        assertEquals(monopolyMap.get(0).getName(), "Rue Victor Hugo 2");
        assertEquals(monopolyMap.get(0).getKind(), Location.LocationKind.PROPERTY);
    }

}
