package fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Services;

import fr.arsenelapostolet.efrei.monopoly.Color;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Locations.Company;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Player;
import fr.BrandaoHouhou.efrei.monopoly.simulation.monopoly.Space;
import fr.arsenelapostolet.efrei.monopoly.Location;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class PropertyServiceTest {

    private PropertyService propertyService;

    @BeforeEach
    public void setUp() {
        PlayerService playerService = new PlayerService();
        propertyService = new PropertyService(playerService);
    }

    @Test
    public void testNumberOfCompaniesOwned() {
        List<Player> players = new ArrayList<>();
        Player player1 = new Player("Player1");
        Player player2 = new Player("Player2");
        players.add(player1);
        players.add(player2);

        Space company1 = new Space("Company1", Location.LocationKind.COMPANY, Color.RED, 1500);
        Space company2 = new Space("Company2", Location.LocationKind.COMPANY, Color.DARKBLUE, 1500);
        Space property = new Space("Property", Location.LocationKind.PROPERTY, Color.GREEN, 1000);

        player1.addProperty(company1);
        player1.addProperty(property);
        player2.addProperty(company2);

        int numberOfCompaniesPlayer1 = propertyService.numberOfPropertyOwned("Player1", players, Location.LocationKind.COMPANY);
        int numberOfCompaniesPlayer2 = propertyService.numberOfPropertyOwned("Player2", players, Location.LocationKind.COMPANY);

        assertEquals(1, numberOfCompaniesPlayer1);
        assertEquals(1, numberOfCompaniesPlayer2);
    }

    @Test
    public void testTransferAssetsToOwner() {
        List<Player> players = new ArrayList<>();
        Map<String, Location> playersLocation = new HashMap<>();
        Player player1 = new Player("Player1");
        Player player2 = new Player("Player2");
        players.add(player1);
        players.add(player2);
        playersLocation.put("Player1", new Company("Location1", Color.RED, 100));

        player1.addCash(BigDecimal.valueOf(1000));
        player2.addCash(BigDecimal.valueOf(1500));

        propertyService.transferAssetsToOwner("Player1", player2, players, playersLocation);

        assertEquals(BigDecimal.valueOf(5500), player1.getCash());
        assertEquals(1, players.size());
    }
}
