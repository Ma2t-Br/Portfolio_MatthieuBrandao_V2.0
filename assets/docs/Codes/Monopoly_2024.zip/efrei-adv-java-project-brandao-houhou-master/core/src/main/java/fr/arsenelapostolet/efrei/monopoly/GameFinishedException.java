package fr.arsenelapostolet.efrei.monopoly;

public class GameFinishedException extends RuntimeException {
}
