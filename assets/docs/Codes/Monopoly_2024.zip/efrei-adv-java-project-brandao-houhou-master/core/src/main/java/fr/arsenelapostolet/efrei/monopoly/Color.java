package fr.arsenelapostolet.efrei.monopoly;


    public enum Color {
        BROWN, LIGHTBLUE, ROSE, ORANGE, RED, YELLOW, GREEN, DARKBLUE
    }




