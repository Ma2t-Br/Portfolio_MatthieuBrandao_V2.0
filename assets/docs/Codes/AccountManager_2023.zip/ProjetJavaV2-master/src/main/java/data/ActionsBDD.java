package data;

import java.sql.SQLException;

public interface ActionsBDD {

    void afficherTousLesProgrammeurs()  throws SQLException;
    //TODO 10 programmeurs !!!!!!

    void afficherUnProgrammeur() throws SQLException;
    //TODO avec l'id (saisise à nouveau)

    void supprimerUnProgrammeur() throws SQLException;
    //TODO avec l'id (saisise à nouveau)

    void ajouterUnProgrammeur() throws SQLException;
    //TODO avec l'id (saisise à nouveau)

    void modifierLeSalaire() throws SQLException;
}
