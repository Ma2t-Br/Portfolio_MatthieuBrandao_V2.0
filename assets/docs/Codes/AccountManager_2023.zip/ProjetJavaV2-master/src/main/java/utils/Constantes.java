package utils;

import java.sql.*;
import java.util.Scanner;

public class Constantes {
    public static final String url = "jdbc:mysql://localhost:8889/APTN61_BD";
    public static final String user = "adm";
    public static final String password = "adm";
    public static Connection connection;


    static {
        try {
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static ResultSet query(String sqlRequest) throws SQLException {
        Statement stmt = connection.createStatement();
        return stmt.executeQuery(sqlRequest);
    }

    public static void update(String sqlRequest) throws SQLException {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate(sqlRequest);
    }

    public static int lireChoixUtilisateur_int() {
        Scanner scanner;

        boolean correctScan;
        do {
            try {
                scanner = new Scanner(System.in);
                return scanner.nextInt();
            } catch (Exception e) {
                System.err.println("Erreur de saisie. Veuillez entrer un nombre valide.");
                correctScan = false;
            }
        } while (!correctScan);
        return -1; // Retourne une valeur caractéristique en cas d'erreur du programme.
    }
    public static String lireChoixUtilisateur_string() {
        ;
        Scanner scanner = new Scanner(System.in);
        try {
            return scanner.nextLine();
        } catch (Exception e) {
            System.err.println("Erreur de saisie. Veuillez ré-essayer.");
            return "Null"; // Retourne une valeur invalide en cas d'erreur de saisie.
        }
    }
}
