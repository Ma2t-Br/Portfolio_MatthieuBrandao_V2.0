package exec;
import data.ActionsBDDImpl;
import utils.Constantes;


public class Menu {
    public Menu() {
    }

    public static void menu() {
        ActionsBDDImpl actionsBDD = new ActionsBDDImpl();
        while (true) {
            afficherMenu();
            int choix = Constantes.lireChoixUtilisateur_int();
            boolean correctScan = true;

            switch (choix) {
                case 1:
                    try{
                        actionsBDD.afficherTousLesProgrammeurs();
                    } catch (Exception e){
                        System.err.println("Le programme ne parvient pas à extraire l'ensemble des programeurs : \n" + e);
                    }
                    break;
                case 2:

                    do {
                        try {
                            actionsBDD.afficherUnProgrammeur();
                            correctScan = true;
                        } catch (Exception e) {
                            System.err.println("Le programme ne parvient pas à extraire le programeur.");
                            correctScan=false;
                        }
                    } while(!correctScan);
                    break;
                case 3:
                    do {
                        try {
                            actionsBDD.supprimerUnProgrammeur();
                            System.out.println("SUPPRESSION REUSSI");
                            correctScan = true;
                        } catch (Exception e) {
                            System.err.println("Le programme ne parvient pas à extraire le programeur pour le supprimer.");
                            correctScan=false;
                        }
                    } while(!correctScan);
                    break;
                case 4:
                    try {
                        actionsBDD.ajouterUnProgrammeur();
                        System.out.println("AJOUT REUSSI");
                    } catch (Exception e) {
                        System.err.println("Le programme ne parvient pas à ajouter le programeur dans la base." + e);
                    }
                    break;
                case 5:
                    do{
                        try {
                            actionsBDD.modifierLeSalaire();
                            System.out.println("MODIFICATION REUSSI");
                            correctScan = true;
                        } catch (Exception e) {
                            System.err.println("Le programme ne parvient pas à modifier le salaire du programeur.");
                            correctScan=false;
                        }
                    } while(!correctScan);
                    break;
                case 6:
                    System.out.println("Programme terminé. Au revoir !");
                    return; // Sortie du programme
                default:
                    System.err.println("Choix invalide. Veuillez entrer un nombre entier entre 1 et 6.");
                    break;
            }
        }
    }

    public static void afficherMenu() {
        System.out.println("<<<<<<<<<<<<<<<< MENU >>>>>>>>>>>>>>>>");
        System.out.println("1. Afficher tous les programmeurs");
        System.out.println("2. Afficher un programmeur");
        System.out.println("3. Supprimer un programmeur");
        System.out.println("4. Ajouter un programmeur");
        System.out.println("5. Modifier le salaire");
        System.out.println("6. Quitter le programme");
        System.out.println();
        System.out.println("Quel est votre choix ?");
    }
}
