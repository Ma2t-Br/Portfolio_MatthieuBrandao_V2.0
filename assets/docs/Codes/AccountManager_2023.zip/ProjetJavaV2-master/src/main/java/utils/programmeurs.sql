DROP TABLE IF EXISTS programmeur;
DROP TABLE IF EXISTS responsable;


CREATE TABLE IF NOT EXISTS responsable (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255),
    prenom VARCHAR(255),
    poste VARCHAR(255)
    );
ALTER TABLE responsable AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS programmeur (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255),
    prenom VARCHAR(255),
    adresse VARCHAR(255),
    pseudo VARCHAR(255),
    responsable_id INT,
    hobby VARCHAR(255),
    naissance INT,
    salaire DOUBLE,
    prime DOUBLE,
    FOREIGN KEY (responsable_id) REFERENCES responsable(id)
    );
ALTER TABLE responsable AUTO_INCREMENT = 1;

INSERT INTO responsable (nom, prenom, poste)
VALUES
    ('Didier', 'Achvar', 'Directeur'),
    ('Karim', 'Lahlou', 'Chef de projet'),
    ('Jacques', 'Augustin', 'Chef de projet');

INSERT INTO programmeur (nom, prenom, adresse, pseudo, responsable_id, hobby, naissance, salaire, prime)
VALUES
    ('Torvalds', 'Linus', '2 avenue Linux Git', 'linuxroot', 1, 'Salsa', 1969, 2170, 50),
    ('Strastrup', 'Bjarne', '294 rue C++', 'c++1', 2, 'Voyages', 1950, 2466, 80),
    ('Golsing', 'James', '3 bvd JVM', 'javapapa', 2, 'Peinture', 1955, 1987, 10);