module com.example.projetjavav2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.projetjavav2 to javafx.fxml;
    exports com.example.projetjavav2;
}