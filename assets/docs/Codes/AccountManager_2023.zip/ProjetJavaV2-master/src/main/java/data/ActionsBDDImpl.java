package data;
import utils.Constantes;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ActionsBDDImpl implements ActionsBDD{

    @Override
    public void afficherTousLesProgrammeurs() throws SQLException{
        System.out.println("Affichage de tous les programmeurs ... ");
        for (ProgrammeursBean prog : getProgrammeursBean(Constantes.query("SELECT * from programmeur"))) {
                System.out.println(prog);
                System.out.println("----------------------------------------------");
        }
    }
    public void afficherTousLesResponsables() throws SQLException{
        System.out.println("Affichage de tous les responsables ... ");
        for (ResponsableBean resp : getResponsablesBean(Constantes.query("SELECT * from responsable"))) {
            System.out.println(resp.getId() + ". " + resp);
            System.out.println("----------------------------------------------");
        }
    }

    @Override
    public void afficherUnProgrammeur() throws SQLException{
        System.out.println("Affichage d'un seul programmeur ... ");
        System.out.println("ID du programmeur à afficher : ");
        int id = Constantes.lireChoixUtilisateur_int();

        System.out.println(getProgrammeursBean(Constantes.query("SELECT * from programmeur WHERE id=" + id)).get(0));
    }
    @Override
    public void supprimerUnProgrammeur() throws SQLException{
        System.out.println("Suppression d'un programmeur ... ");
        System.out.println("ID du programmeur à supprimer : ");
        int id = Constantes.lireChoixUtilisateur_int();

        getProgrammeursBean(Constantes.query("SELECT * from programmeur WHERE id=" + id)).get(0);
        deleteProgrammeurBean(id);
    }

    @Override
    public void ajouterUnProgrammeur() throws SQLException{
        System.out.println("mAjout d'un programmeur ... ");
        System.out.println("Informations du programmeur à ajouter : ");

        System.out.println("Nom : ");
        String nom = Constantes.lireChoixUtilisateur_string();
        System.out.println("Prenom : ");
        String prenom = Constantes.lireChoixUtilisateur_string();
        System.out.println("Adresse : ");
        String adresse = Constantes.lireChoixUtilisateur_string();
        System.out.println("Pseudo : ");
        String pseudo = Constantes.lireChoixUtilisateur_string();
        System.out.println("Responsable : ");

        System.out.println("################################");
        afficherTousLesResponsables();
        System.out.println("################################");

        int idResponsable;
        boolean correctScan;
        do {
            System.out.println("Id du responsable : ");
            idResponsable = Constantes.lireChoixUtilisateur_int(); /*TODO: check if idResponsable exists*/
            try {
                getResponsableBeanById(idResponsable);
                correctScan = true;
            } catch (Exception e) {
                System.err.println("Le programme ne parvient pas à extraire le responsable avec l'ID " + idResponsable + ". Veuillez ré-essayer.");
                correctScan=false;
            }
        } while (!correctScan);

        System.out.println("Hobby : ");
        String hobby = Constantes.lireChoixUtilisateur_string();
        System.out.println("Année de naissance : ");
        int naissance = Constantes.lireChoixUtilisateur_int();
        System.out.println("Salaire : ");
        double salaire = Constantes.lireChoixUtilisateur_int();
        System.out.println("Prime : ");
        double prime = Constantes.lireChoixUtilisateur_int();

        Constantes.update("INSERT INTO programmeur (nom, prenom, adresse, pseudo, responsable_id, hobby, naissance, salaire, prime) VALUES (" +
                                     "'" + nom +
                                     "', '" + prenom +
                                     "', '" + adresse +
                                     "', '" + pseudo +
                                     "', " + idResponsable +
                                     ", '" + hobby +
                                     "', " + naissance +
                                     ", " + salaire +
                                     ", " + prime + ")");
    };

    @Override
    public void modifierLeSalaire() throws SQLException{
        System.out.println("Modification du salaire d'un programmeur ... ");
        System.out.println("ID du programmeur à modifier : ");
        int id = Constantes.lireChoixUtilisateur_int();
        getProgrammeursBean(Constantes.query("SELECT * from programmeur WHERE id=" + id)).get(0);

        System.out.println("Nouveau salaire : ");
        double newSalary = Constantes.lireChoixUtilisateur_int();

        updateProgrammeurBean(id, newSalary);
    }

    public static ResponsableBean getResponsableBeanById(int id) throws SQLException{
        ResultSet rs = Constantes.query("SELECT * from responsable WHERE id=" + id);
        rs.next();
        return new ResponsableBean(rs.getInt("id"), rs.getString("nom"), rs.getString("prenom"), rs.getString("poste"));
    }

    public static List<ResponsableBean> getResponsablesBean(ResultSet rs) throws SQLException{
        List<ResponsableBean> Resp = new ArrayList<>();
        while (rs.next()) {
            Resp.add(new ResponsableBean(
                    rs.getInt("id"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("poste")
            ));
        }
        return Resp;
    }

    public static List<ProgrammeursBean> getProgrammeursBean(ResultSet rs) throws SQLException{
        List<ProgrammeursBean> Progs = new ArrayList<>();
        while (rs.next()) {
            Progs.add(new ProgrammeursBean(
                    rs.getInt("id"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("adresse"),
                    rs.getString("pseudo"),
                    getResponsableBeanById(rs.getInt("responsable_id")),
                    rs.getString("hobby"),
                    rs.getInt("naissance"),
                    rs.getDouble("salaire"),
                    rs.getDouble("prime")
            ));
        }
        return Progs;
    }

    public static void deleteProgrammeurBean(int id) throws SQLException{
        Constantes.update("DELETE FROM programmeur WHERE id=" + id);
    }

    public static void updateProgrammeurBean(int id, double newSalary) throws SQLException{
        Constantes.update("UPDATE programmeur SET salaire=" + newSalary + " WHERE id=" + id);
    }

}
