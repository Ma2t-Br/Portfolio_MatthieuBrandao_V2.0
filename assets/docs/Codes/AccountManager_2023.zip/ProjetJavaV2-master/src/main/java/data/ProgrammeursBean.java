package data;

public class ProgrammeursBean {
    private int id;
    private String nom;
    private String prenom;
    private String adresse;
    private String pseudo;
    private ResponsableBean responsable;
    private String hobby;
    private int naissance;
    private double salaire;
    private double prime;

    public ProgrammeursBean(int id, String nom, String prenom, String adresse, String pseudo, ResponsableBean responsable, String hobby, int naissance, double salaire, double prime) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.adresse = adresse;
        this.pseudo = pseudo;
        this.responsable = responsable;
        this.hobby = hobby;
        this.naissance = naissance;
        this.salaire = salaire;
        this.prime = prime;
    }

    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getAdresse() {
        return adresse;
    }

    public String getPseudo() {
        return pseudo;
    }

    public ResponsableBean getResponsable() {
        return responsable;
    }

    public String getHobby() {
        return hobby;
    }

    public int getNaissance() {
        return naissance;
    }

    public double getSalaire() {
        return salaire;
    }

    public double getPrime() {
        return prime;
    }


    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public void setPseudo(String pseudo) {
        this.pseudo = pseudo;
    }

    public void setResponsable(ResponsableBean responsable) {
        this.responsable = responsable;
    }

    public void setHobby(String hobby) {
        this.hobby = hobby;
    }

    public void setNaissance(int naissance) {
        this.naissance = naissance;
    }

    public void setSalaire(double salaire) {
        this.salaire = salaire;
    }

    public void setPrime(double prime) {
        this.prime = prime;
    }


    @Override
    public String toString() {
        return "Id=" + id +
                "\nNom= " + nom +
                "\nPrenom=" + prenom +
                "\nadresse= " + adresse +
                "\nPseudo= " + pseudo +
                "\nResponsable= " + responsable.toString() +
                "\nHobby= " + hobby +
                "\nNaissance= " + naissance +
                "\nSalaire= " + salaire +
                "\nPrime= " + prime
                ;
    }
}
