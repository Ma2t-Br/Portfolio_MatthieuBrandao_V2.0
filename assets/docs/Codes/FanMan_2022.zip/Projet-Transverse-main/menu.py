from levels import *

pg.init()

txtcol = (0, 0, 0)
txtcolH = (200, 0, 0)
txtcolS = (0, 50, 150)

LineWidth = 7
fontH = pg.font.Font('freesansbold.ttf', 20)
fontL = pg.font.Font('freesansbold.ttf', 17)
ActivePlayer = [IMAGE, MASS]
ActiveLevel = 1
PlayerList = ["Images/Persos/Amna.png", "Images/Persos/bonhomme.png"]


class Button(Rendered):
    def __init__(self,
                 pos: list | tuple,
                 width: int = 100,
                 height: int = 100 / 2,
                 text: str = "dummy",
                 function=None,
                 text_col=txtcol,
                 font=fontL,
                 colors=None,
                 hoverToggle: bool = True,
                 dirpath: str = "Images",
                 firstimage: str = None,
                 convert_alpha: bool = True
                 ):

        if function is None:
            function = [0, 0]
        if colors is None:
            colors = [txtcol, txtcolH]
        if firstimage is None:
            firstimage = f"{dirpath}/wood.png"
        super().__init__(pos, (width, height), dirpath, firstimage, convert_alpha)
        self.rect.update(
            (to_rel(self.rect.left, WIDTH) if self.rect.left < 0 else 0, self.rect.top),
            (WIDTH, to_rel(self.rect.height, HEIGHT))
        )
        self.font = font
        (self.x, self.y) = pos[0], pos[1]
        self.colors = colors
        self.activeCol = colors[0]
        self.Line = LineWidth
        self.text = text
        self.width = to_rel(width, WIDTH)
        self.height = to_rel(height, HEIGHT)
        self.rect = pg.Rect(self.x, self.y, self.width, self.height)
        self.hoverToggle = hoverToggle
        self.function = function

    def SelectLevel(self):
        global ActiveLevel
        ActiveLevel = self.function[1]

    def StartGame(self):
        if ActiveLevel == 1:
            Win = level1(ActivePlayer)
            EndMenu(Win)

        elif ActiveLevel == 2:
            Win = level2(ActivePlayer)
            EndMenu(Win)

        elif ActiveLevel == 3:
            Win = level3(ActivePlayer)
            EndMenu(Win)

    def CharSelect(self, loop):
        image: str
        mass: int
        if self.function[1] == 1:
            image = "Images/Persos/Amna.png"
            mass = 70
        elif self.function[1] == 2:
            image = "Images/Persos/bonhomme.png"
            mass = 50
        global ActivePlayer
        ActivePlayer = [image, mass]

    def Function(self, loop):
        if self.function[0] == 0:
            loop = False
            Main_menu()

        elif self.function[0] == 1:
            loop = False
            LevelMenu()

        elif self.function[0] == 2:
            loop = False
            self.SelectLevel()

        elif self.function[0] == 3:
            loop = False
            CharMenu()

        elif self.function[0] == 4:
            self.CharSelect(loop)

        elif self.function[0] == 5:
            loop = False
            CreditMenu()

        elif self.function[0] == 8:
            self.StartGame()

    def Hovered(self):
        if self.rect.collidepoint(pg.mouse.get_pos()) and self.hoverToggle:
            self.activeCol = self.colors[1]
            self.font = fontH
        else:
            self.activeCol = self.colors[0]
            self.font = fontL

    def ActionClicked(self, loop):
        if self.rect.collidepoint(pg.mouse.get_pos()) and pg.mouse.get_pressed(5)[0]:
            self.Function(loop)

    def SelectedLevel(self):
        if self.function[1] == ActiveLevel:
            self.activeCol = txtcolS

    def SelectedChar(self):
        if PlayerList[self.function[1] - 1] == ActivePlayer[0]:
            self.activeCol = txtcolS

    def DrawButton(self):
        self.Hovered()
        if self.function[0] == 2:
            self.SelectedLevel()
        if self.function[0] == 4:
            self.SelectedChar()

        TextSurf, TextRect = text_objects(self.text, self.font, self.activeCol)
        TextRect.center = (self.x + self.width / 2, self.y + self.height / 2)
        SCREEN.blit(TextSurf, TextRect)


def CreditMenu():
    background = import_background("Fond_credits.png", SCREEN)
    button1 = Button((WIDTH // 2 - 75, HEIGHT - 100), 30, 10, "Main Menu", [0, 0])

    Buttons = CleverRenders(
        button1,
    )
    SCREEN.blit(background, (0, 0))
    pg.display.flip()

    loop = True
    while loop is True:

        Buttons.update(SCREEN, background)

        for event in pg.event.get():
            if event.type == pg.QUIT or \
                    (event.type == pg.KEYDOWN and event.key in [pg.K_ESCAPE]):
                loop = False

        pressed = pg.key.get_pressed()
        if pressed[pg.K_LEFT]:
            pass

        dirty_rects = list()
        dirty_rects += Buttons.draw(SCREEN)
        for button in Buttons:
            button.DrawButton()
        pg.display.update(dirty_rects)
        for button in Buttons:
            button.ActionClicked(loop)

        clock.tick(TICKRATE)
    pg.quit()


def CharMenu():
    background = import_background("Fond_menu.png", SCREEN)

    button1 = Button((WIDTH // 2 - 170, HEIGHT // 2 - 50), 30, 10, "Amna", [4, 1])
    button2 = Button((WIDTH // 2, HEIGHT // 2 - 50), 30, 10, "Stickman", [4, 2])
    button3 = Button((WIDTH // 2 - 75, HEIGHT // 2 + 100), 30, 10, "Retour Menu", [0, 0])

    Buttons = CleverRenders(
        button1,
        button2,
        button3
    )
    SCREEN.blit(background, (0, 0))
    pg.display.flip()

    loop = True
    while loop is True:

        Buttons.update(SCREEN, background)

        for event in pg.event.get():
            if event.type == pg.QUIT or \
                    (event.type == pg.KEYDOWN and event.key in [pg.K_ESCAPE]):
                loop = False

        pressed = pg.key.get_pressed()
        if pressed[pg.K_LEFT]:
            pass

        dirty_rects = list()
        dirty_rects += Buttons.draw(SCREEN)
        for button in Buttons:
            button.DrawButton()
        pg.display.update(dirty_rects)
        for button in Buttons:
            button.ActionClicked(loop)

        clock.tick(TICKRATE)
    pg.quit()


def LevelMenu():
    background = import_background("Fond_menu.png", SCREEN)

    button1 = Button((WIDTH // 2 - 160, HEIGHT // 2 - 50), 20, 10, "Niveau 1", [2, 1])
    button2 = Button((WIDTH // 2 - 50, HEIGHT // 2 - 50), 20, 10, "Niveau 2", [2, 2])
    button3 = Button((WIDTH // 2 + 60, HEIGHT // 2 - 50), 20, 10, "Niveau 3", [2, 3])
    button4 = Button((WIDTH // 2 - 75, HEIGHT // 2 + 100), 40, 10, "Retour Menu", [0, 0])

    Buttons = CleverRenders(
        button1,
        button2,
        button3,
        button4
    )
    SCREEN.blit(background, (0, 0))
    pg.display.flip()

    loop = True
    while loop is True:

        Buttons.update(SCREEN, background)

        for event in pg.event.get():
            if event.type == pg.QUIT or \
                    (event.type == pg.KEYDOWN and event.key in [pg.K_ESCAPE]):
                loop = False

        pressed = pg.key.get_pressed()
        if pressed[pg.K_LEFT]:
            pass

        dirty_rects = list()
        dirty_rects += Buttons.draw(SCREEN)
        for button in Buttons:
            button.DrawButton()
        pg.display.update(dirty_rects)
        for button in Buttons:
            button.ActionClicked(loop)

        clock.tick(TICKRATE)
    pg.quit()


def Main_menu():
    pg.init()
    background = import_background("Fond_menu.png", SCREEN)

    button1 = Button((WIDTH // 2 - 75, HEIGHT // 2 - 100), 30, 10, "JOUER", [8, 0])
    button2 = Button((WIDTH // 2 - 170, HEIGHT // 2), 30, 10, "Personnages", [3, 0])
    button3 = Button((WIDTH // 2, HEIGHT // 2), 30, 10, "Niveaux", [1, 0])
    button4 = Button((WIDTH // 2 + 70, HEIGHT - 100), 30, 10, "Crédits", [5, 0])

    Buttons = CleverRenders(
        button1,
        button2,
        button3,
        button4
    )
    SCREEN.blit(background, (0, 0))
    pg.display.update()

    loop = True
    while loop is True:
        for event in pg.event.get():
            if event.type == pg.QUIT or \
                    (event.type == pg.KEYDOWN and event.key in [pg.K_ESCAPE]):
                loop = False

        dirty_rects = list()
        Buttons.update(SCREEN, background)
        dirty_rects += Buttons.draw(SCREEN)
        for button in Buttons:
            button.DrawButton()
        pg.display.update(dirty_rects)
        clock.tick(TICKRATE)
        for button in Buttons:
            button.ActionClicked(loop)

    pg.quit()


def EndMenu(Win):
    if Win is False:
        background = import_background("Fond_gameover.png", SCREEN)
    else:
        background = import_background("Fond_win.png", SCREEN)

    button1 = Button((WIDTH // 2 - 75, HEIGHT - 100), 30, 10, "Retour Menu", [0, 0])

    Buttons = CleverRenders(
        button1,
    )
    SCREEN.blit(background, (0, 0))
    pg.display.flip()

    loop = True
    while loop is True:

        Buttons.update(SCREEN, background)

        for event in pg.event.get():
            if event.type == pg.QUIT or \
                    (event.type == pg.KEYDOWN and event.key in [pg.K_ESCAPE]):
                loop = False

        pressed = pg.key.get_pressed()
        if pressed[pg.K_LEFT]:
            pass

        dirty_rects = list()
        dirty_rects += Buttons.draw(SCREEN)
        for button in Buttons:
            button.DrawButton()
        pg.display.update(dirty_rects)
        for button in Buttons:
            button.ActionClicked(loop)

        clock.tick(TICKRATE)
    pg.quit()


Main_menu()
pg.quit()
