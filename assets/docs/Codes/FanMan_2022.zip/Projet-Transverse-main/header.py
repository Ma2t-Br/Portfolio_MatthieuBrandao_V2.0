import pygame as pg

pg.init()
clock = pg.time.Clock()

TICKRATE: int = 30
HEIGHT: int = pg.display.get_desktop_sizes()[0][1] - 50
WIDTH: int = int(HEIGHT / 7 * 4)
USE_RELATIVE = True
pg.display.set_icon(pg.image.load("Images/efrei logo.png"))
SCREEN = pg.display.set_mode((WIDTH, HEIGHT), pg.NOFRAME)
pg.display.set_caption("Jeu FanMan", "FanMan")


def reset(rendered_group, bonhomme, background):
    if bonhomme.life > 0:
        return False
    bonhomme.life += 1
    SCREEN.blit(background, (0, 0))
    for sprite in rendered_group.sprites():
        sprite.reset()
    pg.display.update()
    return True


"""Level Constants"""
g: float = 10  # constante gravitationnelle
FALL_SPEED: float = 0.1
AIR: float = 1500
DECELERATION: float = 0.95

"""Character Constants"""
MASS = 70
IMAGE = "Images/Persos/Amna.png"
