# <center> Documentation Projet Transverse </center>

# <center> *Le module PyGame* </center>
___

## INTRODUCTION


### Initilisation

-   Il est obligatoire au début du programme d'initiliser pygame avec : " import pygame "
    puis " pygame.init() ".
-   Pour utiliser le temps, utiliser clock : " clock = pygame.time.Clock() ".


### Création de la fenetre de jeu

-   Créer la fenetre de jeu :
> Screen = pygame.display.set_mode((x, y))
-	x et y étant la taille de la fenetre (ex. 1920x1080)("0,0" met en full screen.


### Maintiens de la fenetre de jeu

- Pour maintenir la fenetre de jeu ouverte il faut introduire une boucle while tournant 
    jusqu'à la fermeture du jeu (On l'appellera "boucle de jeu") :

```python
# loop est un bouléen nous permettant de garder la boucle en coutinue et de l'arreter quand souhaité
loop = True

while loop:
	# Introduction d'un évenement "QUIT"
	for event in pygame.event.get(): # récupération des évenement à chaque boucle
		if event.type == pygame.QUIT:
			loop = False
```

### Fin du programme

-	Toujours penser à fermer le programme à la fin avec l'instruction :

> pygame.quit()

-	Cela n'est pas obligatoire mais fermera le programme plus proprement en fin de partie


### Rendu

```python
import pygame

pygame.init()
screen = pygame.display.set_mode(0,0)
loop = True

while loop:
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			loop = False

pygame.quit()
```

___
## IMAGE, EVENEMENTS, DEPLACEMENT

### Ajout d'une image

-	Récupération de l'image :

> Image = pygame.image.load("image.png").convert() # En argument le chemin de l'image // '.convert' permet de convertir dans le meilleur format

-	Affichage de l'image, Insertion du code dans la boucle de jeu :

> screen.blit(image, (xs,ys)) # 'image' est la surface à afficher // 'xs' et 'ys' sont les coordonnées de la surface

-	IMPORTANT : Le repère est en haut à gauche de l'écran (vers la droite x croissant)(vers le bas y croissant)

-	Pour gérer la taille de l'image on utilise la commande suivante:

```python
pygame.transform.scale(surface,(taille, taille))
Image = pygame.transform.scale(pygame.image.load("image.png").convert(),(200, 200)) # en appliquant l'image précédente avec une taille carré de 200px
```
	
-	Ne pas oublier de mettre à jour l'écran, 2 méthodes (à appliquer en fin de boucle):

```python
pygame.display.flip() # Met à jour l'ensemble de la fenetre
pygame.display.update() # sans arguments l'ensemble de la fenetre // avec (x, y, with, height) met à jour le rectangle correspondant à la position et la taille renseignée
```

### Evenements

- Liste des évenements utiles 
  - QUIT : fermeture de la fenetre
  - KEYDOWN : touche du clavier enfoncée (event.key donne la valeur de la touche du clavier)
  - KEYUP : touche du clavier relachée (event.key)
  - MOUSEBUTTONDOWN : bouton de la souris (event.pos donne la position de la souris au moment du click)(event.button donne le bouton clické de la souris)
  - MOUSEBUTTONUP : bouton de la souris (event.pos)(event.button)
  - MOUSEMOTION : Mouvement de la souris

- Pour capturer ces évenements, on introduit les tests dans la boucle 'for event.type in pygame.event.get()' :

```python
for event in pygame.event.get():
	if event.key == pygame.K_LEFT:
		print("Fleche de gauche")
	if event.key == pygame.K_RIGHT:
		print("Fleche de droite")
	if event.key == pygame.K_UP:
		print("Fleche du haut")
	if event.key == pygame.K_DOWN:
		print("Fleche du bas")
```

-	Pour detecter les touches appuyées durant un temps, on utilise une autre méthode:

```python
pressed = pygame.key.get_pressed # retourne un dictionnaire où la valeur pour chaque touche est =1 si la touche est pressée sinon =0
if pressed[pygame.K_LEFT]:
	print("Fleche de gauche")
if pressed[pygame.K_RIGHT]:
	print("Fleche de droite")
if pressed[pygame.K_UP]:
	print("Fleche du haut")
if pressed[pygame.K_DOWN]:
	print("Fleche du bas")
```

### Traitement de la fenetre

-	Nous ajouterons un bout de code afin de régénérer notre fenetre à chaque boucle pour éviter de dupliquer les surface déplacer sur l'écran :

> screen.fill(0,0,0) # arguments code RGB du fond

-	Finalement nous utiliserons l'outil 'clock' pour limiter les image par seconde de notre jeu

> clock.tick(60) # l'argument est le nombre de fps

### Rendu

```python
import pygame

pygame.init()

screen = pygame.display.set_mode((0,0))
clock = pygame.time.Clock()
loop = True
Image = pygame.transform.scale(pygame.image.load("image.png").convert(), (200,200))
x = 0
y = 0

while loop:
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			loop = False

	pressed = pygame.key.get_pressed # retourne un dictionnaire où la valeur pour chaque touche est =1 si la touche est pressée sinon =0
	if pressed[pygame.K_LEFT]:
		print("Fleche de gauche")
	if pressed[pygame.K_RIGHT]:
		print("Fleche de droite")
	if pressed[pygame.K_UP]:
		print("Fleche du haut")
	if pressed[pygame.K_DOWN]:
		print("Fleche du bas")

	screen.fill((255,255,255))
	screen.blit(Image, (x,y))
	pygame.display.flip()
	clock.tick(60)

pygame.quit()
```

# <center> *Les classes* </center>
___
Durant cette partie nous prendrons comme exemple un Joueur

##Définition
Une classe est un ensemble de méthode. Elle prend comme entrée un objet et 
peut alors lui attribuer des variables, des fonctions, et d'autres choses
qui sont donc propre à l'objet.

## Déclaration et initialisation d'une classe

### La déclaration
- Pour déclarer une classe, rien de plus simple, commencer par le mot clef 
'class' suivit de son nom et les deux points :

```python
class Joueur :
    # Instruction
```

### Initialisation

- A votre objet qui entre dans cette classe, il faudra déclarer ses attribues 
(ex. Un joueur a un pseudo, une équipe, des spécialités, ...).
- Pour cela il faudra appeler (comme une foncton) votre première méthode par un
nom clef spécifique **(1)** et initialiser les attributs liés à l'objet **(2)** :

```python
class Joueur :
    def __init__(self): #self désigne l'objet entré dans la classe
        self.pseudo = "Terminator"
        self.equipe = 1
        self.specialités = ("Fort", "Grimpeur", "Combattant")
```

- Ici vous avez bien créé votre class mais elle n'a pas grand intérè; quelque sois 
l'objet renseigné il aura toujour les mêmes attributs. C'est pour ca que l'on peut 
ajouter des paramettres tout comme une fonction :

```python
class Joueur :
    def __init__(self, pseudo:str = "Terminator", equipe:int = 1, specialités:tuple = ("Fort", "Grimpeur", "Combattant")): #self désigne l'objet entré dans la classe
        self.pseudo = pseudo
        self.equipe = equipe
        self.specialités = specialités
```

## Instructions dans la classe

### Attributs et objets

- Pour acceder à l'attribut d'un objet, il faut d'abord creer l'objet :
> Joueur1 = Joueur (pseudo = "SuperMan", specialités = ("Super Force", "Voler"))
- Ensuite on peut récupérer/appeler ses attributs en oubliant pas que l'attribue est lié à l'objet :
> Joueur1.specialités
- Les attributs de classe sont des 'variables' déclarées dans la classe en-dehors des méthodes.
Ils sont liés à la classe et non objet comme précédement. Ces attributs sont donc vrai pour
tout les objets dépendant de cette classe. On les déclare comme tel :
> Nom_de_la_partie = "GTA V"

### Méthodes

- 3 grands type de méthode!
  - Methode : fonction sur un objet
  - Methode de classe : fonction sur une classe
  - Methode statique : fonction indépendante

- La méthode agit sur l'objet, elle aura toujour en argument ' self ' qui est l'objet 
traité. Permet de modifier/créer des attribues de l'objet et en générale de travailler 
sur l'objet.

```python
class Joueur :
    def __init__(self, pseudo:str = "Terminator", equipe:int = 1, specialités:tuple = ("Fort", "Grimpeur", "Combattant")): #self désigne l'objet entré dans la classe
        self.pseudo = pseudo
        self.equipe = equipe
        self.specialités = specialités
    
    def modifierEquipeDuJoueur (self):
        self.equipe = int(input("Numéro de la nouvelle équipe: "))
        print("La nouvelle équipe de {} a le numéro {}".format(self.pseudo, self.equipe))
```

- La méthode de classe agit sur la classe. Elle portera un intérè dans une utilisation 
plus complexe des classes. Pour l'instant retenons la comme une methode permettant de 
gérer la classe. Elle aura toujour pour argument 'cls' (la classe) et devra être déclaré 
dans la classe (avec ' classmethod() ' ) :

 ```python
class Joueur :
    
    Joueur.Nom_de_la_partie = "Call Of Duty"
    jeuEnCours = classmethod(jeuEnCours)  
  
    def __init__(self, pseudo:str = "Terminator", equipe:int = 1, specialités:tuple = ("Fort", "Grimpeur", "Combattant")): #self désigne l'objet entré dans la classe
        self.pseudo = pseudo
        self.equipe = equipe
        self.specialités = specialités
    
    def jeuEnCours (cls):
        print(f"Vous jouez à {Joeur.Nom_de_la_partie}")
 ```

- La méthode Statique s'apparente à une fonction classique, elle est indépendante (peut 
être appelé partout dans le code sans réel lien avec le 'thème' de la class à laquelle 
elle appartient). L'utilité est plus dans la propreté du code, en regrouppant dans des 
classes les fonctions/méthodes qui se ressemblent. Ne pas oublier qu'elle s'appelle grâce
à la classe à laquelle elles appartiennent et devra être déclaré dans la classe (avec 
' staticmethod() ' ) :

```python
class Joueur :

    messages = staticmethod(messages)
    
    def __init__(self, pseudo:str = "Terminator", equipe:int = 1, specialités:tuple = ("Fort", "Grimpeur", "Combattant")): #self désigne l'objet entré dans la classe
        self.pseudo = pseudo
        self.equipe = equipe
        self.specialités = specialités
    
    def messages (keyWord:str):
        if keyWord == "Erreur":
            print("Une erreur s'est produite. Relancer le programme.")
        elif keyWord == "Winner":
            print("Vous êtes un gagnant !")
        else:
            print("Vous avez perdu")
```

## Rendu
```python
class Joueur :
    
    Joueur.Nom_de_la_partie = "Call Of Duty"
    messages = staticmethod(messages)
    jeuEnCours = classmethod(jeuEnCours)
    
    def __init__(self, pseudo:str = "Terminator", equipe:int = 1, specialités:tuple = ("Fort", "Grimpeur", "Combattant")): #self désigne l'objet entré dans la classe
        self.pseudo = pseudo
        self.equipe = equipe
        self.specialités = specialités
    
    def modifierEquipeDuJoueur (self, NouvelleEquipe:int):
        self.equipe = NouvelleEquipe
        print("La nouvelle équipe de {} a le numéro {}".format(self.pseudo, self.equipe))
    
    def jeuEnCours (cls):
       print(f"Vous jouez à {Joueur.Nom_de_la_partie}")
    
    def messages (keyWord:str):
        if keyWord == "Erreur":
            print("Une erreur s'est produite. Relancer le programme.")
        elif keyWord == "Winner":
            print("Vous êtes un gagnant !")
        else:
            print("Vous avez perdu")

# Initilisation du joueur
Aymeric = Joueur (pseudo = "SuperMan", specialités = ("Super Force", "Voler"))

# Affichage d'un attribut
print(f"La spécialité de votre joueur est {Aymeric.specialités}")

# Appel des différentes méthodes
Aymeric.modifierEquipeDuJoueur(int(input("Numéro de la nouvelle équipe: ")))
Joueur.jeuEnCours()
Joueur.messages("Winner")
```