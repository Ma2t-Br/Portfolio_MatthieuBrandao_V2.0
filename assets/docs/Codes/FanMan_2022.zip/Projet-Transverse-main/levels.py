from game import *

pg.init()


def level1(perso=None):
    """Niveau 1 campagne : 2 vies, fond campagne"""
    if perso is None:
        perso = [IMAGE, MASS]
    bonhomme = Player((50, 10), (15, 14.3), perso[0], firstimage=perso[0], mass=perso[1])
    piscine = Piscine((80, 91.9), (37.5, 11.4), "Images/Target/boue.png", speed=[1.5, 0])
    souffleurs = [
        Souffleur(25, (17.5, 4.8), 1, "Images/souffleur", convert_alpha=True),
        Souffleur(50, (17.5, 4.8), -1, "Images/souffleur", convert_alpha=True)
    ]
    to_collide = pg.sprite.Group(piscine, tuple(souffleurs))
    rendered = CleverRenders(bonhomme, piscine, tuple(souffleurs))
    background = import_background("Level_3.jpg", SCREEN)

    play_music_loop("Musiques/level1.mp3")
    res = start_game(rendered, bonhomme, piscine, souffleurs, to_collide, background)
    pg.mixer.music.fadeout(500)
    return res


def level2(perso=None):
    """Niveau 2 far-ouest : 2 vies, fond far-ouest"""
    if perso is None:
        perso = [IMAGE, MASS]

    bonhomme = Player((50, 10), (15, 14.3), perso[0], firstimage=perso[0], mass=perso[1])
    piscine = Piscine((55, 91.9), (18.5, 5.7), "Images/Target/botte_foin.png", speed=[0.6, 0])
    souffleur = Souffleur(70, (17.5, 4.8), 1, "Images/souffleur", convert_alpha=True)

    to_collide = pg.sprite.Group(piscine, souffleur)
    rendered = CleverRenders(bonhomme, piscine, souffleur)
    background = import_background("Level_2.jpg", SCREEN)

    play_music_loop("Musiques/level2.mp3")
    res = start_game(rendered, bonhomme, piscine, [souffleur], to_collide, background)
    pg.mixer.music.fadeout(500)
    return res


def level3(perso=None):
    """Niveau 3 espace : 1 vie, fond far-ouest"""
    if perso is None:
        perso = [IMAGE, MASS]

    bonhomme = Player((50, 10), (15, 14.3), perso[0], firstimage=perso[0], mass=perso[1])
    piscine = Piscine((15, 90), (25, 7.6), "Images/Target/portail.png", speed=[0, 0])
    souffleurs = [Souffleur(30, (17.5, 5), 1, "Images/souffleur", convert_alpha=True)]
    for i in range(1, 4):
        souffleurs += [Souffleur(60 + 5 * i, (17.5, 5), 1, "Images/souffleur", convert_alpha=True)]

    to_collide = pg.sprite.Group(piscine, tuple(souffleurs))
    rendered = CleverRenders(bonhomme, piscine, tuple(souffleurs))
    background = import_background("Level1.jpg", SCREEN)
    play_music_loop("Musiques/level3.mp3")
    res = start_game(rendered, bonhomme, piscine, souffleurs, to_collide, background)
    pg.mixer.music.fadeout(500)
    return res
