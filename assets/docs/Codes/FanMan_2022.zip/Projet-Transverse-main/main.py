from menu import *


def main() -> None:
    pg.event.set_blocked([
        pg.JOYBUTTONUP,
        pg.JOYBUTTONDOWN,
        pg.JOYHATMOTION,
        pg.JOYAXISMOTION,
        pg.JOYBALLMOTION,
        pg.JOYDEVICEADDED,
        pg.JOYDEVICEREMOVED,
    ])


if __name__ == "__main__":
    main()
