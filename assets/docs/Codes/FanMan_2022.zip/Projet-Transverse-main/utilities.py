import os

from header import *

pg.init()


def to_rel(value: int | float | list | tuple,
           relative: int | float | list[int | float] | tuple) -> int | float | list:
    if USE_RELATIVE is False:
        return value
    if isinstance(value, list) or isinstance(value, tuple):
        new_val = list(value)
        for i, el in enumerate(value):
            if isinstance(list(relative), list):
                new_val[i] = el * relative[i] / 100
            else:
                new_val[i] = el * relative / 100
        return new_val
    return value * relative / 100


class CleverRenders(pg.sprite.RenderUpdates):
    """Clear & update in one function call (update)"""

    def update(self, *args, **kwargs) -> None:
        self.clear(*args, **kwargs)
        super().update(*args, **kwargs)


def get_image(path: str, scale: tuple[float, float] | list[float, float]) -> pg.Surface:
    return pg.transform.scale(imagelist[os.path.relpath(path)], to_rel(scale, (WIDTH, HEIGHT)))


class Rendered(pg.sprite.Sprite):
    """
    Classe fondamentale pour chaque objet affiché.

    Tous ses objets partagent la propriété has_started, qui détermine si le jeu a commencé.
    Elles possèdent individuellement une propriété :
    - speed (vitesse)
    - imagelist (liste d'images → animation)
    - image
    - rect

    :param position: Topleft coordinates
    :param imagepath: Image file or folder, searches in the Images folder
    :param scale: Scales the image by this argument
    :param convert_alpha: Convert the image with alpha is True; else it does normally.
    """

    has_started = False

    def __init__(self,
                 position: tuple[float, float],
                 scale: tuple[float, float],
                 imagepath: str,
                 firstimage: str = None,  # 1st element of self.imagelist
                 convert_alpha: bool = False
                 ):
        super().__init__()
        self._position, self._scale = position, scale
        import_images(imagepath, convert_alpha)
        self._firstimage = (imagepath if firstimage is None else firstimage)
        if os.path.lexists(self._firstimage) is False:
            raise FileNotFoundError(f"""firstimage "{self._firstimage}" is not a valid path""")

        self.speed: list[float, float] = [0, 0]
        self.image = get_image(self._firstimage, self._scale)
        self.rect = self.image.get_rect(center=to_rel(self._position, (WIDTH, HEIGHT)))
        # rect = coordonnées et espace occupé par l'objet
        self.collide_rect = self.rect.copy()

    def update(self, screen, background):
        self.rect.move_ip(to_rel(self.speed, (WIDTH, HEIGHT)))
        self.collide_rect.move_ip(to_rel(self.speed, (WIDTH, HEIGHT)))

    def reset(self):
        self.image = get_image(self._firstimage, self._scale)
        self.rect = self.image.get_rect(center=to_rel(self._position, (WIDTH, HEIGHT)))
        self.collide_rect = self.rect.copy()
        self.speed = [0, 0]


class Piscine(Rendered):
    """Rebondit sur les côtés de l'écran"""

    def __init__(self,
                 position: tuple[float, float],
                 scale: tuple[float, float],
                 imagepath: str,
                 speed: list[float, float],
                 firstimage: str = None,
                 ):
        self._speed = speed
        super().__init__(position, scale, imagepath, firstimage, True)
        SCREEN.get_rect().clamp_ip(self.rect)

        self.speed = self._speed.copy()
        self.sens = 1

    def update(self, screen: pg.Surface, background: pg.Surface) -> None:
        if screen.get_rect().contains(self.rect) is False:
            self.sens *= -1
            self.speed[0] *= self.sens
            self.speed[1] *= self.sens
        super().update(screen, background)

    def reset(self) -> None:
        super().reset()
        self.speed = self._speed.copy()


class Souffleur(Rendered):
    """Objet qui peut souffler du vent, altérant la vitesse du joueur."""

    def __init__(self,
                 height: float,
                 scale: tuple[float, float],
                 side: int,
                 dirpath: str,
                 firstimage: str = None,
                 convert_alpha: bool = False
                 ):
        if firstimage is None:
            firstimage = f"{dirpath}/souffleur.png"
        super().__init__((0, height), scale, dirpath, firstimage, convert_alpha)
        self.side = side
        self.windimage = get_image(f"{dirpath}/vent.png", self._scale)
        self.wind_offset = 0
        self.reset()
        self._position = to_rel(self.rect.center, (100 / WIDTH, 100 / HEIGHT))
        self.is_blowing = False

    def handle_input(self, event_list):
        """
        Récupère et gère les entrées de l'ordinateur.

        :param event_list: Facultatif en pratique, permet de ne pas oublier de pg.event.get().
        """
        if self.rect.collidepoint(pg.mouse.get_pos()) is True \
                and pg.mouse.get_pressed(5)[0] is True:  # 1er bouton souris
            self.is_blowing = True
        else:
            self.is_blowing = False

    def draw_wind(self, background: pg.Surface) -> pg.Rect:
        screen = pg.display.get_surface()
        windrect = self.windimage.get_rect(left=self.rect.right, top=self.rect.top)
        if self.side == -1:
            windrect.update((0, self.rect.top), windrect.size)
        dirty_rect = screen.blit(background, windrect, area=windrect)
        if self.is_blowing:
            if (0 < self.wind_offset < WIDTH) is False:
                if self.side == 1:
                    self.wind_offset = self.rect.right
                else:
                    self.wind_offset = self.rect.left
            screen.blit(self.windimage, (windrect.left, windrect.top),
                        ((windrect.width - self.wind_offset, 0), (windrect.width, windrect.height)))
            screen.blit(self.windimage, (windrect.left + self.wind_offset, windrect.top),
                        ((0, 0), (windrect.width - self.wind_offset, windrect.height)))
            self.wind_offset += self.side * to_rel(5, WIDTH)
        return dirty_rect

    def reset(self):
        self.image = get_image(self._firstimage, self._scale)
        self.speed = [0, 0]
        if self.side == -1:
            self.image = pg.transform.flip(self.image, True, False)
            self.rect.update((WIDTH, self.rect.top), self.rect.size)
        self.rect.clamp_ip(SCREEN.get_rect())
        self.windimage = pg.transform.scale(self.windimage, (WIDTH - self.rect.width, self.rect.height))

        if self.side == -1:
            self.windimage = pg.transform.flip(self.windimage, True, False)

        self.collide_rect.update((0, self.rect.top), (WIDTH, self.rect.height))
        self.is_blowing = False


class Player(Rendered):

    def __init__(self,
                 position: tuple[float, float],
                 scale: tuple[float, float],
                 imagepath: str = IMAGE,
                 firstimage: str = None,
                 mass: float = MASS
                 ):
        super().__init__(position, scale, imagepath, firstimage, True)
        self.is_falling = False
        self.mass = mass
        self.life = 0

    def handle_input(self, event_list):
        """Récupère et gère les entrées de l'ordinateur."""
        pressed = [event.key for event in event_list if event.type == pg.KEYDOWN]
        if self.has_started is False and self.is_falling is False \
                and pg.K_SPACE in pressed:
            self.has_started = self.is_falling = True
            self.image = pg.transform.rotate(self.image, 180)

    def fall(self):
        """Fait tomber le joueur."""
        if self.is_falling:
            self.speed[1] += g * FALL_SPEED / TICKRATE

    def handle_collision(self, to_collide: pg.sprite.AbstractGroup, rendered_group, background: pg.Surface, loop):
        """Gère la collision entre le joueur et la piscine ou les souffleurs."""
        collided_list = spritecollide(self, to_collide)
        collided_with_souffleur = False
        for collided in collided_list:
            if isinstance(collided, Piscine):
                self.has_started = self.is_falling = False
                loop = False
                return True
            elif isinstance(collided, Souffleur):
                if collided.is_blowing:
                    collided_with_souffleur = True
                    if collided.rect.left <= self.rect.left:
                        self.speed[0] += AIR / (self.mass * TICKRATE)
                    else:
                        self.speed[0] -= AIR / (self.mass * TICKRATE)
        if collided_with_souffleur is False:
            self.speed[0] *= DECELERATION

        if SCREEN.get_rect().contains(self.rect) is False:
            if self.has_started is True and self.rect.bottom >= HEIGHT:
                self.has_started = self.is_falling = False
                self.life = 1
                loop = False
                r = reset(rendered_group, self, background)
                if r is False:
                    return False

            if self.collide_rect.left < 0 or self.collide_rect.right > WIDTH:
                self.collide_rect.clamp_ip(SCREEN.get_rect())
                self.speed[0] *= -1.1


def import_images(imagename: str | os.PathLike, convert_alpha: bool) -> None:
    """Import one or multiple images in the Images folder"""

    global imagelist

    def convert_cond(image: pg.Surface):
        if convert_alpha is True:
            image = image.convert_alpha()
        else:
            image = image.convert()
        return image

    def set_entry(path: str | os.PathLike) -> None:
        if os.path.relpath(path) not in imagelist:
            imagelist[os.path.relpath(path)] = convert_cond(pg.image.load(path))

    def _create_dict(path: str | os.PathLike) -> None:
        """Création du contenu d'imagelist, reproduisant la structure du dossier/fichier sélectionné."""
        if os.path.isdir(path):
            with os.scandir(path) as folder:
                for entry in folder:
                    if entry.is_file():
                        set_entry(entry.path)
                    elif entry.is_dir():
                        _create_dict(entry.path)

        else:
            set_entry(path)

    if os.path.lexists(imagename) is False:  # il faut que le chemin cible vers une chose existante
        raise FileNotFoundError(f"""imagename "{imagename}" is not a valid path""")

    _create_dict(imagename)


def spritecollide(sprite: pg.sprite.Sprite, group: pg.sprite.AbstractGroup) -> list[pg.sprite.Sprite]:
    def collided(s1: pg.sprite.Sprite, s2: pg.sprite.Sprite) -> bool:
        return s1.collide_rect.colliderect(s2.collide_rect)

    return pg.sprite.spritecollide(sprite, group, dokill=False, collided=collided)


imagelist: dict[str, pg.Surface] = dict()
backgrounds: dict[str, pg.Surface] = dict()


def play_music_loop(path: str):
    pg.mixer.music.load(path)
    pg.mixer.music.play(loops=-1)


def import_background(bg_path: str, screen: pg.Surface) -> pg.Surface:
    global backgrounds
    path = os.path.join('Images/Background', bg_path)
    if path not in backgrounds:
        backgrounds[path] = pg.image.load(path).convert()
    newrect = backgrounds[path].get_rect(center=screen.get_rect().center).clip(screen.get_rect())
    return pg.transform.scale(backgrounds[path], newrect.size)


def text_objects(text, font, color=(0, 0, 0)):
    textSurface = font.render(text, True, color)
    return textSurface, textSurface.get_rect()
