from utilities import *

pg.init()


def handle_quit(event_list: list) -> bool:
    """Gère les entrées permettant de quitter le jeu"""
    for event in event_list:
        if event.type == pg.QUIT or event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE:
            return False
    return True


def handle_inputs(event_list, player: Player, souffleurs: list[Souffleur]):
    """Gère toutes les handle_input"""
    player.handle_input(event_list)
    if player.is_falling:
        player.fall()
    for s in souffleurs:
        s.handle_input(event_list)


def draw_rendered(rendered: pg.sprite.AbstractGroup, souffleurs: list[Souffleur], background: pg.Surface) -> list[
    pg.Rect]:
    """Dessine tous les rendus"""
    dirty_rects = list()
    for souffleur in souffleurs:
        windrect = souffleur.draw_wind(background)
        dirty_rects += [windrect]
    dirty_rects += rendered.draw(SCREEN)
    return dirty_rects


def start_game(rendered: pg.sprite.AbstractGroup, player: Player, piscine: Piscine, souffleurs: list[Souffleur],
               to_collide: pg.sprite.AbstractGroup, background: pg.Surface) -> bool:
    """Fonction générale permettant de faire un jeu"""
    SCREEN.blit(background, (0, 0))
    pg.display.update()

    loop = True
    while loop is True:
        eventlist = pg.event.get()
        loop = handle_quit(eventlist)
        handle_inputs(eventlist, player, souffleurs=souffleurs)

        win = player.handle_collision(to_collide, rendered, background, loop)

        if win is True:
            return True
        elif win is False:
            return False

        rendered.update(SCREEN, background)
        dirty_rects = draw_rendered(rendered, souffleurs, background)
        pg.display.update(dirty_rects)
        clock.tick(TICKRATE)

    pg.quit()
