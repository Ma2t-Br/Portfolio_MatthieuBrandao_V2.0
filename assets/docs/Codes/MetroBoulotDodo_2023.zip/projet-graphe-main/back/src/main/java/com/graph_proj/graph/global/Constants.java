package com.graph_proj.graph.global;

import com.graph_proj.graph.models.metro.Metro;

public class Constants {

    public static Metro METRO = new Metro();

    public static final String fileName = "metro.txt";

    private Constants(){}
}
