package com.graph_proj.graph.models.metro;

public record Direction(String ligne, String direction) {

}