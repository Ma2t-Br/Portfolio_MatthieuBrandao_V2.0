export interface Station{
    nom: string;
    lignes: string[];
}