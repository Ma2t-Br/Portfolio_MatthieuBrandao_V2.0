# INETUM APP. SCANNER

---

## 🛡️ Présentation

Les applications stratégiques gagnent continuellement en complexité, rendant leur sécurité, leur maintenabilité et la maîtrise des risques techniques de plus en plus critiques. Des audits réguliers sont indispensables pour analyser le code, identifier les vulnérabilités et comprendre les dépendances applicatives.

Cependant, les solutions existantes sont souvent coûteuses, lourdes à déployer et difficiles à exploiter. Chez Inetum, l’utilisation d’outils comme CAST met en évidence ces limites : dépendance à des bases de données, complexité d’usage et graphes parfois peu lisibles, freinant l’analyse efficace d’un grand nombre d’applications.

**Inetum App. Scanner** apporte une réponse moderne et performante à ces enjeux grâce à une analyse accélérée par l’Intelligence Artificielle. La solution génère des graphes de dépendances clairs et interprétables, permettant de visualiser l’ensemble des liens entre les classes et d’identifier rapidement les zones critiques.

Les vulnérabilités détectées sont directement accessibles et contextualisées selon les standards du **NIST**, facilitant la compréhension des risques de sécurité et des actions correctives à mener. Enfin, un rapport d’audit rédigé de manière claire et humaine est automatiquement produit, fournissant des recommandations ciblées sur les classes analysées et considérées comme problématiques.

## 👑 Acteurs

### Equipe projet :
- Matthieu BRANDAO (matthieu.brandao@efrei.net)
- Jade HATOUM (jade.hatoum@efrei.net)
- Cédric ALONSO (cédric.alonso@efrei.net)
- Sirine YAHIA (sirine.yahia@efrei.net)
- Guillaume GOMEZ (guillaume.gomez@efrei.net)

### Déposants INETUM :
- Stephen PERIN (stephen.perin@inetum.com)
- Nicolas HACHET (nicolas.hachet@inetum.com)
- Lahna GASMI (lahna.gasmi@inetum.com)

### Mentors académiques :
- Julien SAID (julien.said@intervenants.efrei.net)

## 🚀 Fonctionnalités Clés

- **Analyse de code accélérée par l’IA** : Utilisation de modèles avancés pour une analyse rapide et précise du code source.
- **Graphes de dépendances clairs** : Visualisation intuitive des relations entre les classes.
- **Détection de vulnérabilités contextualisée** : Identification des failles de sécurité selon les standards NIST.
- **Rapport d’audit automatisé** : Génération de rapports détaillés avec recommandations.

## 🤖 Principales technologies

- Langage : C\# (.\NET)
- Frameworks / bibliothèques typiques :
    - ASP\.NET Core (si application web / API)
    - Entity Framework Core (accès aux données)
    - xUnit / NUnit / MSTest (tests unitaires)
    - Serilog / Microsoft\.Extensions\.Logging (journalisation)
- Outils : JetBrains Rider, dotnet CLI