using Core.contracts;
using Core.models;
using Core.services;
using Microsoft.Extensions.Logging;
using Moq;
using Worker.pipeline.implementations.steps;

namespace Worker.Tests;

public class TestGenerateHtmlReportStep
{
    private const string JobId = "886c146a-15ec-495d-8204-146df42fe843";
    private readonly string _testDir = Path.Combine(TestContext.CurrentContext.TestDirectory, "..", "..", "..");
    private string _output = null!;
    private string _templatePath = null!;
    private Mock<IJobWorkspace> _workspaceMock = null!;
    private Mock<ILogger<GenerateHtmlReportStep>> _loggerMock = null!;
    private GenerateHtmlReportStep _step = null!;

    [SetUp]
    public void SetUp()
    {
        _output = Path.Combine(_testDir, "report_test_" + Guid.NewGuid());
        Directory.CreateDirectory(_output);

        _workspaceMock = new Mock<IJobWorkspace>();
        _workspaceMock.Setup(w => w.GetOutputDirectory(JobId)).Returns(_output);

        _loggerMock = new Mock<ILogger<GenerateHtmlReportStep>>();

        var templatesDir = Path.Combine(AppContext.BaseDirectory, "templates");
        Directory.CreateDirectory(templatesDir);
        _templatePath = Path.Combine(templatesDir, "report_template.html");
        const string templateContent = "<html><body>{{ job_id }} {{ for v in vulnerabilities }}{{ v.cve_id }};{{ end }} {{ for a in audit }}{{ a.class_name }};{{ end }}</body></html>";
        File.WriteAllText(_templatePath, templateContent);

        _step = new GenerateHtmlReportStep(_workspaceMock.Object, _loggerMock.Object);
    }

    [TearDown]
    public void TearDown()
    {
        try { Directory.Delete(_output, true); }
        catch
        {
            // ignored
        }
    
        try { File.Delete(_templatePath); }
        catch
        {
            // ignored
        }
    }

    [Test]
    public async Task ExecuteAsync_WritesReportHtml()
    {
        // Arrange
        var vulnerabilities = new[]
        {
            new DependencyVulnerability { CveId = "CVE-2025-48734", CvssScore = 8.8, Severity = "HIGH", Dependency = "commons-beanutils-1.9.4.jar" },
            new DependencyVulnerability { CveId = "CVE-2025-48924", CvssScore = 5.3, Severity = "MEDIUM", Dependency = "commons-lang3-3.17.0.jar" }
        };

        var dependencyVulnerabilitiesResult = new DependencyVulnerabilitiesResult(
            JobId,
            DateTime.UtcNow,
            vulnerabilities.Length,
            new List<DependencyVulnerability>(vulnerabilities)
        );

        var sourceCodeAuditList = new List<SourceCodeAudit>
        {
            new(
                "JobDispatcher",
                "Heuristic Risk",
                true,
                5,
                string.Empty,
                string.Empty,
                new List<AffectedFile> { new("/src/JobDispatcher.cs", 10, 20, "public class JobDispatcher { }") }
            )
        };

        var auditWrapper = new SourceCodeAuditResult(
            JobId,
            DateTime.UtcNow,
            sourceCodeAuditList.Count,
            sourceCodeAuditList
        );

        var vulJson = System.Text.Json.JsonSerializer.Serialize(dependencyVulnerabilitiesResult);
        await File.WriteAllTextAsync(Path.Combine(_output, "dependency-vulnerabilities.json"), vulJson);

        var auditJson = System.Text.Json.JsonSerializer.Serialize(auditWrapper);
        await File.WriteAllTextAsync(Path.Combine(_output, "code-source-audit.json"), auditJson);

        var context = new JobEnvelope
        {
            Message = new JobMessage(JobId, "")
        };

        // Act
        await _step.ExecuteAsync(context, CancellationToken.None);

        // Assert
        var reportPath = Path.Combine(_output, "report.html");
        Assert.That(File.Exists(reportPath), "report.html should be created");

        var content = await File.ReadAllTextAsync(reportPath);
        Assert.Multiple(() =>
        {
            Assert.That(content, Does.Contain(JobId));
            Assert.That(content, Does.Contain("CVE-2025-48734"));
            Assert.That(content, Does.Contain("JobDispatcher"));
        });
    }
}