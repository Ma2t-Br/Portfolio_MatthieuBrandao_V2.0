﻿namespace Worker.models;

public sealed record MemoryMetadata(string Source, string ClassName);