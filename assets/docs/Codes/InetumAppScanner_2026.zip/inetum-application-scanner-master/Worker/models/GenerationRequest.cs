namespace Worker.models;

public sealed record GenerationRequest(
    string Prompt,
    string Format = "json",
    string Model = "mistral:latest",
    bool Stream = false);