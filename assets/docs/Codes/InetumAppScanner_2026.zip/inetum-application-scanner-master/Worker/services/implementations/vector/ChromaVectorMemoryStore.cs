﻿using System;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Worker.configuration;
using Worker.models;
using Worker.services.storage;

namespace Worker.services.implementations.vector;

public sealed class ChromaVectorMemoryStore : IVectorMemoryStore
{
    private const string CollectionName = "code_memory";

    private readonly HttpClient _client;
    private readonly ILogger<ChromaVectorMemoryStore> _logger;
    private string _collectionId = "";

    public ChromaVectorMemoryStore(
        IOptions<ChromaSettings> configuration,
        ILogger<ChromaVectorMemoryStore> logger)
    {
        var settings = configuration.Value;
        _logger = logger;
        _client = new HttpClient
        {
            BaseAddress = new Uri(settings.Uri),
            Timeout = TimeSpan.FromMinutes(settings.TimeoutMinutes)
        };
    }

    public async Task InitializeAsync()
    {
        try { await _client.GetAsync("/api/v1/heartbeat"); }
        catch { _logger.LogError("[AI] Chroma not reachable."); return; }

        var response = await _client.GetAsync("/api/v1/collections");
        if (!response.IsSuccessStatusCode) return;

        var json = await response.Content.ReadAsStringAsync();
        using var doc = JsonDocument.Parse(json);

        foreach (var col in doc.RootElement.EnumerateArray()
                     .Where(column => column.GetProperty("name").GetString() == CollectionName))
        {
            _collectionId = col.GetProperty("id").GetString()!;
            return;
        }

        var create = await _client.PostAsync(
            "/api/v1/collections",
            JsonContent.Create(new { name = CollectionName, metadata = new { description = "Code" } }));

        if (create.IsSuccessStatusCode)
        {
            using var created = JsonDocument.Parse(await create.Content.ReadAsStringAsync());
            _collectionId = created.RootElement.GetProperty("id").GetString()!;
        }
    }

    public async Task SaveAsync(string id, float[] embedding, string document, MemoryMetadata metadata)
    {
        if (string.IsNullOrEmpty(_collectionId))
            await InitializeAsync();

        await _client.PostAsync(
            $"/api/v1/collections/{_collectionId}/delete",
            JsonContent.Create(new { ids = new[] { id } }));

        await _client.PostAsync(
            $"/api/v1/collections/{_collectionId}/add",
            JsonContent.Create(new
            {
                ids = new[] { id },
                embeddings = new[] { embedding },
                documents = new[] { document },
                metadatas = new[] { new { source = metadata.Source, className = metadata.ClassName } }
            }));
    }

    public async Task ClearAsync()
    {
        if (!string.IsNullOrEmpty(_collectionId))
        {
            await _client.DeleteAsync($"/api/v1/collections/{_collectionId}");
            _collectionId = "";
            await InitializeAsync();
        }
    }
}
