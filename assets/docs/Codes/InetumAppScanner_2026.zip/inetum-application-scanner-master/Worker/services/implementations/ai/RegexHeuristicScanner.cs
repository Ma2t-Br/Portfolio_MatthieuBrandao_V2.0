﻿using System.Text.RegularExpressions;
using Worker.services.ai;

namespace Worker.services.implementations.ai;

public sealed class RegexHeuristicScanner : IHeuristicScanner
{
    private static readonly Regex Sql =
        new(@"\b(SELECT|INSERT|UPDATE|DELETE|FROM|WHERE)\b",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex Interpolation =
        new("""(\$"|"\s*\+|\+\s*")""",
            RegexOptions.Compiled);

    private static readonly Regex Secret =
        new(@"\b(password|passwd|pwd|key|secret|token|auth)\b",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex SecretAssign =
        new("""(=|:)\s*["'][^"'\s]{3,}["']""",
            RegexOptions.Compiled);

    public bool Detect(string code) =>
        (Sql.IsMatch(code) && Interpolation.IsMatch(code)) ||
        (Secret.IsMatch(code) && SecretAssign.IsMatch(code));
}
