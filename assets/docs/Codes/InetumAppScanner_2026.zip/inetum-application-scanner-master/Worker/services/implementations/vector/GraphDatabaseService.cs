using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Core.models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Neo4j.Driver;
using Worker.configuration;
using Worker.services.storage;

namespace Worker.services.implementations.vector;

public class GraphDatabaseService : IGraphDatabaseService, IDisposable
{
    private readonly IDriver _driver;
    private readonly ILogger<GraphDatabaseService> _logger;

    public GraphDatabaseService(ILogger<GraphDatabaseService> logger, IOptions<Neo4JSettings> configuration)
    {
        _logger = logger;
        var settings = configuration.Value;
        _driver = GraphDatabase.Driver(settings.Uri, AuthTokens.Basic(settings.Username, settings.Password));
    }

    public async Task InitSchemaAsync()
    {
        try
        {
            await using var session = _driver.AsyncSession();
            try
            {
                await session.ExecuteWriteAsync(async tx =>
                {
                    await tx.RunAsync("CREATE CONSTRAINT IF NOT EXISTS FOR (c:Class) REQUIRE c.name IS UNIQUE");
                });

                await session.ExecuteWriteAsync(async tx =>
                {
                    await tx.RunAsync("CREATE CONSTRAINT IF NOT EXISTS FOR (f:File) REQUIRE f.name IS UNIQUE");
                });

                _logger.LogInformation("[GRAPH] Schema constraints ensured.");
            }
            catch (Exception exception)
            {
                _logger.LogError("[GRAPH] Schema constraints creation warning/info: {errorMessage}", exception.Message);
            }
        }
        catch (Exception exception)
        {
            _logger.LogError("[GRAPH ERROR] Could not ensure schema constraints: {errorMessage}", exception.Message);
        }

        try
        {
            await using var dataSession = _driver.AsyncSession();
            await dataSession.ExecuteWriteAsync(async tx =>
            {
                await tx.RunAsync("MATCH (n) WHERE n.__preserve IS NULL DETACH DELETE n");
            });
            _logger.LogInformation("[GRAPH] Data cleanup completed.");
        }
        catch (Exception exception)
        {
            _logger.LogError("[GRAPH ERROR] Data cleanup failed: {errorMessage}", exception.Message);
        }
    }

    public async Task AddFileStructureAsync(string fileName, string className, string methodName)
    {
        await using var session = _driver.AsyncSession();
        await session.ExecuteWriteAsync(async tx => {
            var query = @"
                MERGE (f:File {name: $fileName})
                MERGE (c:Class {name: $className})
                MERGE (m:Method {name: $methodName})
                MERGE (f)-[:CONTAINS]->(c)
                MERGE (c)-[:HAS_METHOD]->(m)
            ";
            await tx.RunAsync(query, new { fileName, className, methodName });
        });
    }

    public async Task<bool> AddVulnerabilityAsync(string className, string type, string description)
    {
        await using var session = _driver.AsyncSession();

        try
        {
            var writeResult = await session.ExecuteWriteAsync(async tx => {
                var query = @"
                    MATCH (c:Class {name: $className})
                    MERGE (v:Vulnerability {type: $type, description: $description})
                    MERGE (c)-[:HAS_VULNERABILITY]->(v)
                    RETURN c.name as className, id(v) as vulnId
                ";

                var result = await tx.RunAsync(query, new { className, type, description });
                return await result.SingleAsync();
            });

            var createdClass = writeResult["className"].As<string>();
            var vulnId = writeResult["vulnId"].As<long>();

            _logger.LogInformation("[GRAPH] Link created for exact class: {createdClass}, vulnId={vulnId}", createdClass, vulnId);
            return true;
        }
        catch (Exception exception)
        {
            _logger.LogError("[GRAPH ERROR] AddVulnerability failed for {className}: {errorMessage}", className, exception.Message);
            return false;
        }
    }

    public async Task<bool> AddVulnerabilityDetailedAsync(string className, string type, string description, string vulnerabilityType, string detailedAnalysis, string remediation, int riskScore)
    {
        await using var session = _driver.AsyncSession();
        try
        {
            var writeResult = await session.ExecuteWriteAsync(async tx => {
                var query = @"
                    MATCH (c:Class {name: $className})
                    MERGE (v:Vulnerability {type: $type, description: $description})
                    SET v.vulnerabilityType = $vulnerabilityType,
                        v.detailedAnalysis = $detailedAnalysis,
                        v.remediation = $remediation,
                        v.riskScore = $riskScore
                    MERGE (c)-[:HAS_VULNERABILITY]->(v)
                    RETURN c.name as className, id(v) as vulnId
                ";
                var result = await tx.RunAsync(query, new { className, type, description, vulnerabilityType, detailedAnalysis, remediation, riskScore });
                return await result.SingleAsync();
            });

            var createdClass = writeResult["className"].As<string>();
            var vulnId = writeResult["vulnId"].As<long>();

            _logger.LogInformation("[GRAPH] Detailed vulnerability created for class: {createdClass}, vulnId={vulnId}", createdClass, vulnId);
            return true;
        }
        catch (Exception exception)
        {
            _logger.LogError("[GRAPH ERROR] AddVulnerabilityDetailed failed for {className}: {errorMessage}", className, exception.Message);
            return false;
        }
    }

    public async Task<bool> ClassExistsAsync(string className)
    {
        await using var session = _driver.AsyncSession();
        try
        {
            var res = await session.ExecuteReadAsync(async tx => {
                var r = await tx.RunAsync("MATCH (c:Class {name: $className}) RETURN count(c) as cnt", new { className });
                return await r.SingleAsync();
            });

            var cnt = res["cnt"].As<long>();
            return cnt > 0;
        }
        catch
        {
            return false;
        }
    }

    public async Task<string?> FindClosestClassAsync(string fuzzyClassName)
    {
        await using var session = _driver.AsyncSession();
        var candidates = new List<string>();

        try
        {
            await session.ExecuteReadAsync(async tx => {
                var r = await tx.RunAsync("MATCH (c:Class) RETURN c.name as name");
                await foreach (var record in r)
                {
                    candidates.Add(record["name"].As<string>());
                }
            });
        }
        catch (Exception exception)
        {
            _logger.LogError("[GRAPH ERROR] Failed to fetch class names for fuzzy matching: {errorMessage}", exception.Message);
            return null;
        }

        if (candidates.Count == 0) return null;

        var exact = candidates.FirstOrDefault(c => string.Equals(c, fuzzyClassName, StringComparison.OrdinalIgnoreCase));
        if (exact != null) return exact;

        var contains = candidates.FirstOrDefault(className => className.Contains(fuzzyClassName, StringComparison.OrdinalIgnoreCase));
        if (contains != null) return contains;

        string? best = null;
        var bestScore = int.MaxValue;
        foreach (var candidate in candidates)
        {
            var d = LevenshteinDistance(fuzzyClassName.ToLowerInvariant(), candidate.ToLowerInvariant());
            if (d >= bestScore) continue;
            bestScore = d; best = candidate;
        }

        return bestScore <= 3 ? best : null;
    }

    private static int LevenshteinDistance(string s, string t)
    {
        var n = s.Length;
        var m = t.Length;
        if (n == 0) return m;
        if (m == 0) return n;

        var d = new int[n + 1, m + 1];
        for (int i = 0; i <= n; i++) d[i, 0] = i;
        for (int j = 0; j <= m; j++) d[0, j] = j;

        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= m; j++)
            {
                int cost = (t[j - 1] == s[i - 1]) ? 0 : 1;
                d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1), d[i - 1, j - 1] + cost);
            }
        }
        return d[n, m];
    }

    public async Task<List<(string ClassName, string VulnType, string Description, string VulnerabilityType, string DetailedAnalysis, string Remediation, int RiskScore, string Status)>> GetFullAuditReportAsync()
    {
        var report = new List<(string, string, string, string, string, string, int, string)>();
        await using var session = _driver.AsyncSession();

        await session.ExecuteReadAsync(async tx => {
            var query = "MATCH (c:Class)-[:HAS_VULNERABILITY]->(v:Vulnerability) RETURN c.name as className, v.type as vtype, v.description as desc, v.vulnerabilityType as vultype, v.detailedAnalysis as analysis, v.remediation as remediation, v.riskScore as riskScore, c.status as status";
            var result = await tx.RunAsync(query);

            await foreach (var record in result)
            {
                report.Add((
                    record["className"].As<string>(),
                    record["vtype"].As<string>(),
                    record["desc"].As<string>(),
                    record["vultype"].As<string>(),
                    record["analysis"].As<string>(),
                    record["remediation"].As<string>(),
                    record["riskScore"].As<int>(),
                    record["status"].As<string>()
                ));
            }
        });
        return report;
    }

    public async Task ClearGraphAsync()
    {
        await using var session = _driver.AsyncSession();
        await session.ExecuteWriteAsync(async tx => {
            await tx.RunAsync("MATCH (n) DETACH DELETE n");
        });
        _logger.LogInformation("[GRAPH] All nodes and relationships have been deleted.");
    }

    public async Task ClearVulnerabilitiesForClassAsync(string className)
    {
        await using var session = _driver.AsyncSession();
        try
        {
            await session.ExecuteWriteAsync(async tx => {
                var query = @"
                    MATCH (c:Class {name: $className})-[r:HAS_VULNERABILITY]->(v:Vulnerability)
                    DELETE r
                    WITH v
                    OPTIONAL MATCH (v)--(other)
                    WHERE other IS NULL
                    DELETE v
                ";
                await tx.RunAsync(query, new { className });
            });

            _logger.LogInformation("[GRAPH] Cleared vulnerabilities for class: {className}", className);
        }
        catch (Exception exception)
        {
            _logger.LogError("[GRAPH ERROR] Failed to clear vulnerabilities for {className}: {errorMessage}", className, exception.Message);
        }
    }

    public async Task<List<string>> GetClassesByFileNamesAsync(IEnumerable<string> fileNames)
    {
        var classes = new List<string>();
        await using var session = _driver.AsyncSession();
        try
        {
            await session.ExecuteReadAsync(async tx => {
                var query = "MATCH (f:File)-[:CONTAINS]->(c:Class) WHERE f.name IN $files RETURN DISTINCT c.name AS name";
                var r = await tx.RunAsync(query, new { files = fileNames });
                await foreach (var record in r)
                {
                    classes.Add(record["name"].As<string>());
                }
            });
        }
        catch (Exception exception)
        {
            _logger.LogError("[GRAPH ERROR] GetClassesByFileNames failed: {errorMessage}", exception.Message);
        }

        return classes;
    }

    public async Task SetClassStatusAsync(string className, string status)
    {
        await using var session = _driver.AsyncSession();
        try
        {
            await session.ExecuteWriteAsync(async tx => {
                var query = @"
                    MATCH (c:Class {name: $className})
                    SET c.status = $status
                    RETURN c.name as name
                ";
                await tx.RunAsync(query, new { className, status });
            });
        }
        catch (Exception exception)
        {
            _logger.LogError("[GRAPH ERROR] Failed to set status for {className}: {errorMessage}", className, exception.Message);
        }
    }

    public async Task SaveVulnerabilityAsync(Vulnerability v)
    {
        await AddVulnerabilityDetailedAsync(
            v.ClassName,
            "AI Detected Risk",
            v.DetailedAnalysis,
            v.VulnerabilityType,
            v.DetailedAnalysis,
            v.Remediation,
            v.RiskScore
        );
    }

    public void Dispose() => _driver?.Dispose();
}