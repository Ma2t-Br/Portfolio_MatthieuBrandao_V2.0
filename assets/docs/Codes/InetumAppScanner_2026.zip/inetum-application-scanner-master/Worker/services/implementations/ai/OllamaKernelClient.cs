﻿using System;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Worker.configuration;
using Worker.models;
using Worker.services.ai;

namespace Worker.services.implementations.ai;

public sealed class OllamaKernelClient : ISemanticKernelClient
{
    private readonly HttpClient _client;
    private readonly string _modelId;

    public OllamaKernelClient(IOptions<OllamaSettings> configuration)
    {
        var settings = configuration.Value;
        _client = new HttpClient
        {
            BaseAddress = new Uri(settings.Uri),
            Timeout = TimeSpan.FromMinutes(settings.TimeoutMinutes)
        };
        _modelId = settings.ModelId;
    }

    public async Task<float[]> GenerateEmbeddingAsync(string input)
    {
        var response = await _client.PostAsync(
            "/api/embeddings",
            JsonContent.Create(new { model = _modelId, input }));

        response.EnsureSuccessStatusCode();

        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        return doc.RootElement.GetProperty("embedding")
            .EnumerateArray()
            .Select(x => (float)x.GetDouble())
            .ToArray();
    }

    public async Task<string> GenerateAsync(GenerationRequest request)
    {
        var content = new StringContent(JsonSerializer.Serialize(request), Encoding.UTF8, "application/json");
        var response = await _client.PostAsync("/api/generate", content);
        
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadAsStringAsync();
    }

    public ValueTask DisposeAsync()
    {
        _client.Dispose();
        return ValueTask.CompletedTask;
    }
}