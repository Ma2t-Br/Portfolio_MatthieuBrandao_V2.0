﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Core.models;
using Microsoft.Extensions.Logging;
using Worker.models;
using Worker.services.ai;
using Worker.services.implementations.ai.promptBuilders;
using Worker.services.storage;

namespace Worker.services.implementations.ai;

public sealed class CodeAnalysisService : ISemanticKernelService
{
    private readonly ISemanticKernelClient _kernel;
    private readonly IVectorMemoryStore _memory;
    private readonly IHeuristicScanner _heuristic;
    private readonly ILogger<CodeAnalysisService> _logger;
    private const int MinimumRiskScore = 4;

    public CodeAnalysisService(
        ISemanticKernelClient kernel,
        IVectorMemoryStore memory,
        IHeuristicScanner heuristic,
        ILogger<CodeAnalysisService> logger)
    {
        _kernel = kernel;
        _memory = memory;
        _heuristic = heuristic;
        _logger = logger;
    }
    
    public async Task SaveCodeFragmentAsync(string id, string content, string filePath)
    {
        var embedding = await _kernel.GenerateEmbeddingAsync(content);

        await _memory.SaveAsync(
            id,
            embedding,
            content,
            new MemoryMetadata(
                Source: filePath,
                ClassName: Path.GetFileNameWithoutExtension(filePath)));
    }

    public async Task<List<Vulnerability>> AnalyzeCodeDirectlyAsync(string code)
    {
        var match = Regex.Match(code, @"class\s+(\w+)");
        var className = match.Success ? match.Groups[1].Value : "UnknownClass";

        try
        {
            var request = new SecurityAuditPromptBuilder().Build(className, code);
            var response = await _kernel.GenerateAsync(request);
            var result = new AuditVulnerabilityResponseParser().Parse(response);

            if (result is { IssueFound: true, RiskScore: >= MinimumRiskScore })
            {
                return
                [
                    new Vulnerability
                    {
                        ClassName = className,
                        RiskScore = result.RiskScore,
                        VulnerabilityType = result.VulnerabilityType,
                        DetailedAnalysis = result.DetailedAnalysis,
                        Remediation = result.Remediation,
                        Description = result.DetailedAnalysis,
                        Status = "Open"
                    }
                ];
            }
        }
        catch (Exception ex)
        {
            _logger.LogError("[AI] Error parsing {class}: {msg}", className, ex.Message);

            if (_heuristic.Detect(code))
            {
                var fallback = VulnerabilityResult.HeuristicFallback();
                return
                [
                    new Vulnerability
                    {
                        ClassName = className,
                        RiskScore = fallback.RiskScore,
                        VulnerabilityType = fallback.VulnerabilityType,
                        DetailedAnalysis = fallback.DetailedAnalysis,
                        Remediation = fallback.Remediation,
                        Status = "Open"
                    }
                ];
            }
        }

        return [];
    }
}