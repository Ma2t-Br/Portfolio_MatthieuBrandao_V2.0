﻿using Worker.models;
using Worker.services.ai;

namespace Worker.services.implementations.ai.promptBuilders;

public sealed class SecurityAuditPromptBuilder : IPromptBuilder
{
    private const int MaxCodeLength = 6000;

    public GenerationRequest Build(string className, string code)
    {
        var safeCode = code.Length > MaxCodeLength
            ? code[..MaxCodeLength] + "\n...[Truncated]"
            : code;
        
        var prompt = $$"""
            ROLE: Security Auditor.
            TASK: Scan C# code for security risks (SQL Injection, XSS, Hardcoded Secrets, and others vulnerabilities you found).

            CRITICAL INSTRUCTION: You MUST output valid JSON only. No markdown, no text before or after.

            FORMAT:
            {
                "issueFound": true/false,
                "riskScore": 0-10,
                "vulnerabilityType": "Short Name",
                "detailedAnalysis": "Explanation",
                "remediation": "Fix code"
            }

            CODE TO ANALYZE:
            Class: {{className}}
            Content:
            {{safeCode}}
        """;
        
        return new GenerationRequest(Prompt: prompt);
    }
}