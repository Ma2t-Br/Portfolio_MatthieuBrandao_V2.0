using System.Collections.Generic;
using System.Threading.Tasks;
using Core.models;

namespace Worker.services.storage;

public interface IGraphDatabaseService
{
    Task InitSchemaAsync();
    Task AddFileStructureAsync(string fileName, string className, string methodName);
    Task<bool> AddVulnerabilityAsync(string className, string type, string description);
    Task<bool> AddVulnerabilityDetailedAsync(string className, string type, string description, string vulnerabilityType, string detailedAnalysis, string remediation, int riskScore);
    Task<bool> ClassExistsAsync(string className);
    Task<string?> FindClosestClassAsync(string fuzzyClassName);
    Task<List<string>> GetClassesByFileNamesAsync(IEnumerable<string> fileNames);
    Task SetClassStatusAsync(string className, string status);
    Task<List<(string ClassName, string VulnType, string Description, string VulnerabilityType, string DetailedAnalysis, string Remediation, int RiskScore, string Status)>> GetFullAuditReportAsync();
    Task ClearGraphAsync();

    Task SaveVulnerabilityAsync(Vulnerability v);
}