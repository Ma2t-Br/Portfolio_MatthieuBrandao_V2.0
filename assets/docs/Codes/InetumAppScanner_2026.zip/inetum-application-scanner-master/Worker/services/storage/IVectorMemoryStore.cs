﻿using System.Threading.Tasks;
using Worker.models;

namespace Worker.services.storage;

public interface IVectorMemoryStore
{
    Task InitializeAsync();
    Task SaveAsync(string id, float[] embedding, string document, MemoryMetadata metadata);
    Task ClearAsync();
}