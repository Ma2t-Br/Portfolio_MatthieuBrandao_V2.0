﻿using Worker.models;

namespace Worker.services.ai;

public interface IAnalysisResponseParser
{
    VulnerabilityResult Parse(string response);
}