﻿using System;
using System.Threading.Tasks;
using Worker.models;

namespace Worker.services.ai;

public interface ISemanticKernelClient : IAsyncDisposable
{
    Task<string> GenerateAsync(GenerationRequest request);
    Task<float[]> GenerateEmbeddingAsync(string input);
}