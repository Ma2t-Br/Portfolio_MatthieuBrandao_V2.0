﻿namespace Worker.services.ai;

public interface IHeuristicScanner
{
    bool Detect(string code);
}