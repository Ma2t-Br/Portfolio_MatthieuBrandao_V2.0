using System.Collections.Generic;
using System.Threading.Tasks;
using Core.models;

namespace Worker.services.ai;

public interface ISemanticKernelService
{
    Task SaveCodeFragmentAsync(string id, string content, string filePath);
    Task<List<Vulnerability>> AnalyzeCodeDirectlyAsync(string code);
}