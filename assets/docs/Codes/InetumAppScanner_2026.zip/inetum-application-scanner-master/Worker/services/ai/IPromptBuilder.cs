﻿using Worker.models;

namespace Worker.services.ai;

public interface IPromptBuilder
{
    GenerationRequest Build(string className, string code);
}