﻿namespace Worker.configuration;

public sealed class OllamaSettings
{
    public required string Uri { get; init; }
    public required string ModelId { get; init; }
    public required int TimeoutMinutes { get; init; }
}