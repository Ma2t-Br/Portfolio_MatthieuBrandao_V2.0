﻿namespace Worker.configuration;

public sealed class DependencyCheckSettings
{
    public required string DockerImage { get; init; }
    public required string Arguments { get; init; }
    public required string NvdApiKey { get; init; }
    public required string CacheDirectory { get; init; }
    public required int TimeoutMinutes { get; init; }
}