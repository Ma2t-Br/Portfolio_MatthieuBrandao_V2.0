﻿namespace Worker.configuration;

public sealed class Neo4JSettings
{
    public required string Uri { get; init; }
    public required string Username { get; init; }
    public required string Password { get; init; }
}