﻿namespace Worker.configuration;

public sealed class ChromaSettings
{
    public required string Uri { get; init; }
    public required int TimeoutMinutes { get; init; }
}