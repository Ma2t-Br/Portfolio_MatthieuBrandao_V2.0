﻿namespace Worker.configuration;

public static class AnalysisLanguage
{
    public const string Csharp = "*.cs";
    public const string Java = "*.java";
    public const string Php = "*.php";
}