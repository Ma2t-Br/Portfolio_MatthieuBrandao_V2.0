﻿using System.Threading;
using System.Threading.Tasks;
using Core.contracts;
using Core.models;

namespace Worker.pipeline;

public interface IJobPipeline
{
    Task ExecuteAsync(Job job, JobEnvelope context, CancellationToken stoppingToken);

}