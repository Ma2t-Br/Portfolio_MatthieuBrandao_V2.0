﻿using System.Threading;
using System.Threading.Tasks;
using Core.contracts;

namespace Worker.pipeline;

public interface IPipelineStep
{
    string Name { get; }

    Task ExecuteAsync(JobEnvelope context, CancellationToken cancellationToken = default);
}