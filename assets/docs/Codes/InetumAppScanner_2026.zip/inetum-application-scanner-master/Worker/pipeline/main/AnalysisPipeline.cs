﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Core.broker;
using Core.models;
using Core.repositories;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Worker.pipeline.main;

public class AnalysisPipeline : BackgroundService
{
    private readonly IJobPipeline _jobPipeline;
    private readonly IJobRepository _jobRepository;
    private readonly IJobQueue _jobQueue;
    private readonly RetryPolicy _retryPolicy;
    private readonly ILogger<AnalysisPipeline> _logger;
    private Job? _currentJob;

    public AnalysisPipeline(
        IJobPipeline jobPipeline,
        IJobRepository jobRepository,
        IJobQueue jobQueue,
        RetryPolicy retryPolicy,
        ILogger<AnalysisPipeline> logger)
    {
        _jobPipeline = jobPipeline;
        _jobRepository = jobRepository;
        _jobQueue = jobQueue;
        _retryPolicy = retryPolicy;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        stoppingToken.Register(() =>
        {
            if (_currentJob == null)
                return;

            try
            {
                _logger.LogWarning(
                    "Worker shutting down. Canceling job {JobId}",
                    _currentJob.Id);

                _currentJob.MarkCanceled();
                _jobRepository.SaveAsync(_currentJob, CancellationToken.None)
                    .GetAwaiter()
                    .GetResult();            
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to cancel job during shutdown");
            }
        });

        _logger.LogInformation("Now listening for jobs to process");
        await foreach (var envelope in _jobQueue.ConsumeAsync(
                           QueueNames.Jobs,
                           stoppingToken))
        {
            _logger.LogInformation(
                "Job message received. JobId={JobId}, Attempt={Attempt}",
                envelope.Message.JobId,
                envelope.Attempt + 1);

            var job = await _jobRepository.GetAsync(envelope.Message.JobId, stoppingToken);

            if (job == null)
            {
                _logger.LogError(
                    "Job {JobId} not found. Sending to DLQ.",
                    envelope.Message.JobId);

                // ACK before DLQ publish to avoid redelivery
                await _jobQueue.AcknowledgeAsync(envelope, stoppingToken);

                await _jobQueue.PublishToDlqAsync(
                    envelope,
                    "Job not found",
                    stoppingToken);

                continue;
            }

            using (_logger.BeginScope("JobId:{JobId}", job.Id))
            {
                if (job.Status is not (JobStatus.Queued or JobStatus.Retrying))
                {
                    _logger.LogWarning("Cannot start job: Invalid job status [{jobStatus}]", job.Status);

                    // ACK and ignore duplicate / stale delivery
                    await _jobQueue.AcknowledgeAsync(envelope, stoppingToken);
                    continue;
                }
                
                _currentJob = job;

                try
                {
                    job.MarkRunning();
                    await _jobRepository.SaveAsync(job, stoppingToken);

                    _logger.LogInformation("Job marked as Running");
                    
                    _logger.LogInformation("Executing pipeline...");
                    await _jobPipeline.ExecuteAsync(job, envelope, stoppingToken);

                    job.MarkCompleted();
                    await _jobRepository.SaveAsync(job, stoppingToken);
                    
                    await _jobQueue.AcknowledgeAsync(envelope, stoppingToken);
                    _logger.LogInformation("Pipeline completed successfully");
                }
                catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
                {
                    _logger.LogWarning(
                        "Job {JobId} canceled due to cancellation request.",
                        job.Id);

                    job.MarkCanceled();
                    await _jobRepository.SaveAsync(job, CancellationToken.None);

                    await _jobQueue.AcknowledgeAsync(envelope, CancellationToken.None);
                }
                catch (Exception exception)
                {
                    _logger.LogError(
                        exception,
                        "Error processing pipeline. Attempt {Attempt}/{MaxAttempts}",
                        envelope.Attempt + 1,
                        _retryPolicy.MaxAttempts);

                    if (envelope.Attempt >= _retryPolicy.MaxAttempts)
                    {
                        job.MarkFailed(exception.Message);
                        await _jobRepository.SaveAsync(job, stoppingToken);

                        _logger.LogError("Pipeline failed permanently. Publishing to DLQ.");

                        await _jobQueue.PublishToDlqAsync(
                            envelope,
                            exception.Message,
                            stoppingToken);
                    }
                    else
                    {
                        _logger.LogWarning("Retrying pipeline (Attempt {Attempt})", envelope.Attempt + 1);

                        job.MarkRetry();
                        await _jobRepository.SaveAsync(job, stoppingToken);

                        await _jobQueue.RetryAsync(
                            envelope,
                            stoppingToken);
                    }
                }
                finally
                {
                    _currentJob = null;
                }
            }
        }
    }
}