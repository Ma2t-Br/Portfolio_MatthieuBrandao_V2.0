﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Core.contracts;
using Core.models;
using Core.repositories;
using Microsoft.Extensions.Logging;

namespace Worker.pipeline.implementations;

public class JobPipeline : IJobPipeline
{
    private readonly IEnumerable<IPipelineStep> _steps;
    private readonly IJobRepository _jobRepository;
    private readonly ILogger<JobPipeline> _logger;

    public JobPipeline(IEnumerable<IPipelineStep> steps, IJobRepository jobRepository, ILogger<JobPipeline> logger)
    {
        _steps = steps.ToList();
        _jobRepository = jobRepository;
        _logger = logger;
    }

    public async Task ExecuteAsync(Job job, JobEnvelope context, CancellationToken cancellationToken)
    {
       
       for (var stepIndex = job.CurrentStepIndex; stepIndex < _steps.Count(); stepIndex++)
       {
           var step = _steps.ElementAt(stepIndex);

           _logger.LogInformation(
               "[PIPELINE] Executing step {stepIndex}: {stepName}",
               stepIndex,
               step.Name);

           try
           {
               await step.ExecuteAsync(context, cancellationToken);
                
               _logger.LogInformation("[PIPELINE] Successfully executed step {stepIndex}: {stepName}", stepIndex, step.Name);
               job.MarkStepCompleted(stepIndex);
               await _jobRepository.SaveAsync(job, cancellationToken);
           }
           catch (Exception exception)
           {
               _logger.LogError(
                   exception,
                   "[PIPELINE ERROR] Step {stepIndex}: {stepName} failed",
                   stepIndex,
                   step.Name);

               throw;
           }
       }
    }
}