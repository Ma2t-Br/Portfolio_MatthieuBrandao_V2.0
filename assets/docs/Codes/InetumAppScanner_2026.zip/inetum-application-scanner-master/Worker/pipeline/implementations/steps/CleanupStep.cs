using System.Threading;
using System.Threading.Tasks;
using Core.contracts;
using Microsoft.Extensions.Logging;
using Worker.services;
using Worker.services.storage;

namespace Worker.pipeline.implementations.steps;

public class CleanupStep : IPipelineStep
{
    private readonly IGraphDatabaseService _graphService;
    private readonly ILogger<CleanupStep> _logger;

    public string Name => "Graph Cleanup";

    public CleanupStep(IGraphDatabaseService graphService, ILogger<CleanupStep> logger)
    {
        _graphService = graphService;
        _logger = logger;
    }

    public async Task ExecuteAsync(JobEnvelope context, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("[CLEANUP] Cleaning database before starting new analysis...");
        await _graphService.ClearGraphAsync();
    }
}