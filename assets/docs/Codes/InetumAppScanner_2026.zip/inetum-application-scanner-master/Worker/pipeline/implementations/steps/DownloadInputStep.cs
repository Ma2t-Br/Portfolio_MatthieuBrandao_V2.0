﻿using System.IO;
using System.IO.Compression;
using System.Threading;
using System.Threading.Tasks;
using Core.contracts;
using Core.services;
using Microsoft.Extensions.Logging;

namespace Worker.pipeline.implementations.steps;

public sealed class DownloadInputStep : IPipelineStep
{
    public string Name => "Download Input ZIP";

    private readonly IFileStorageService _storage;
    private readonly IJobWorkspace _workspace;
    private readonly ILogger<DownloadInputStep> _logger;

    public DownloadInputStep(IFileStorageService storage, IJobWorkspace workspace, ILogger<DownloadInputStep> logger)
    {
        _storage = storage;
        _workspace = workspace;
        _logger = logger;
    }

    public async Task ExecuteAsync(JobEnvelope context, CancellationToken cancellationToken = default)
    {
        var jobId = context.Message.JobId;
        var jobRoot = _workspace.GetJobRoot(jobId);
        var srcDir = _workspace.GetSourceDirectory(jobId);

        Directory.CreateDirectory(jobRoot);
        Directory.CreateDirectory(srcDir);

        var zipPath = Path.Combine(jobRoot, "input.zip");
        var blobPath = context.Message.SourcePath;

        if (!File.Exists(zipPath))
        {
            _logger.LogInformation("[DOWNLOAD] Downloading {blobPath} to {localPath}", blobPath, zipPath);
            await _storage.DownloadAsync(blobPath, zipPath, cancellationToken);
        }
        else
        {
            _logger.LogInformation("[DOWNLOAD] Zip already exists at {localPath}, skipping download.", zipPath);
        }

        _logger.LogInformation("[DOWNLOAD] Extracting {zip} to {srcDir}", zipPath, srcDir);
        ZipFile.ExtractToDirectory(zipPath, srcDir, overwriteFiles: true);
    }
}