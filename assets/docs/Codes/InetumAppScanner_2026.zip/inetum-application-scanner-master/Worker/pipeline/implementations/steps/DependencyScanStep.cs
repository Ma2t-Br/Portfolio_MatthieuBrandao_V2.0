﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Core.contracts;
using Core.models;
using Core.services;
using Microsoft.Extensions.Options;
using Worker.configuration;
using Worker.services.json;

namespace Worker.pipeline.implementations.steps;

public sealed class DependencyScanStep : IPipelineStep
{
    public string Name => "Dependency Scan (OWASP Dependency-Check)";

    private readonly IJobWorkspace _workspace;
    private readonly DependencyCheckSettings _settings;

    public DependencyScanStep(IJobWorkspace workspace, IOptions<DependencyCheckSettings> options)
    {
        _workspace = workspace;
        _settings = options.Value;
    }

    public async Task ExecuteAsync(JobEnvelope context, CancellationToken stoppingToken)
    {
        var jobId = context.Message.JobId;

        var srcDir = _workspace.GetSourceDirectory(jobId);
        
        var outDir = _workspace.GetOutputDirectory(jobId);

        Directory.CreateDirectory(outDir);

        var scanRoot = ResolveScanRoot(srcDir);

        var cacheDir = Path.Combine(
            _workspace.GetBaseDirectory(),
            _settings.CacheDirectory);

        Directory.CreateDirectory(cacheDir);

        var arguments =
            $"run --rm " +
            $"-v \"{scanRoot}:/src:ro\" " +
            $"-v \"{outDir}:/out\" " +
            $"-v \"{cacheDir}:/usr/share/dependency-check/data\" " +
            $"{_settings.DockerImage} " +
            $"dependency-check.sh " +
            $"--scan /src " +
            $"--out /out " +
            $"--nvdApiKey {_settings.NvdApiKey} " +
            $"{_settings.Arguments}";

        using var process = new Process();
        process.StartInfo = new ProcessStartInfo
        {
            FileName = "docker",
            Arguments = arguments
        };

        process.Start();

        if (!process.WaitForExit(_settings.TimeoutMinutes * 60 * 1000))
            throw new TimeoutException("Dependency-Check timed out");

        var reportPath = Path.Combine(outDir, "dependency-check-report.json");

        var findings = Parse(reportPath, jobId);

        var outputJson = Path.Combine(outDir, "dependency-vulnerabilities.json");
        await JsonReportWriter.WriteObjectAsync(findings, outputJson, stoppingToken);
    }

    private static string ResolveScanRoot(string dir)
    {
        var dirs = Directory.GetDirectories(dir);
        var files = Directory.GetFiles(dir);
        return dirs.Length == 1 && files.Length == 0 ? dirs[0] : dir;
    }

    private static DependencyVulnerabilitiesResult Parse(string reportPath, string jobId)
    {
        using var stream = File.OpenRead(reportPath);
        using var doc = JsonDocument.Parse(stream);

        var results = new Dictionary<string, DependencyVulnerability>();

        if (!doc.RootElement.TryGetProperty("dependencies", out var dependencies))
            return new DependencyVulnerabilitiesResult(jobId, DateTime.UtcNow, 0, Array.Empty<DependencyVulnerability>());

        foreach (var dependency in dependencies.EnumerateArray())
        {
            var dependencyName =
                dependency.GetProperty("fileName").GetString() ?? "unknown";

            if (!dependency.TryGetProperty("vulnerabilities", out var vulnerabilities))
                continue;

            foreach (var vulnerability in vulnerabilities.EnumerateArray())
            {
                if (!vulnerability.TryGetProperty("name", out var cveProp))
                    continue;

                var cveId = cveProp.GetString();
                if (string.IsNullOrWhiteSpace(cveId))
                    continue;

                if (results.TryGetValue(cveId, out var finding)) continue;
                
                finding = new DependencyVulnerability
                {
                    CveId = cveId,
                    Dependency = dependencyName,
                    Severity = vulnerability.GetProperty("severity").GetString() ?? "UNKNOWN",
                    CvssScore = ExtractCvssScore(vulnerability),
                };

                results[cveId] = finding;
            }
        }

        var list = results.Values.ToList();
        return new DependencyVulnerabilitiesResult(jobId, DateTime.UtcNow, list.Count, list);
    }

    private static double? ExtractCvssScore(JsonElement vulnerability)
    {
        if (vulnerability.TryGetProperty("cvssv3", out var cvss3) &&
            cvss3.TryGetProperty("baseScore", out var score3))
        {
            return score3.GetDouble();
        }

        if (vulnerability.TryGetProperty("cvssv2", out var cvss2) &&
            cvss2.TryGetProperty("score", out var score2))
        {
            return score2.GetDouble();
        }

        return null;
    }
}