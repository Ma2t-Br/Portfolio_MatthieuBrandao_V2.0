﻿using System.IO;
using System.IO.Compression;
using System.Threading;
using System.Threading.Tasks;
using Core.contracts;
using Core.services;
using Microsoft.Extensions.Logging;

namespace Worker.pipeline.implementations.steps;

public sealed class UploadOutputStep : IPipelineStep
{
    public string Name => "Upload Output";

    private readonly IJobWorkspace _workspace;
    private readonly IFileStorageService _storage;
    private readonly ILogger<UploadOutputStep> _logger;

    public UploadOutputStep(IJobWorkspace workspace, IFileStorageService storage, ILogger<UploadOutputStep> logger)
    {
        _workspace = workspace;
        _storage = storage;
        _logger = logger;
    }

    public async Task ExecuteAsync(JobEnvelope context, CancellationToken stoppingToken = default)
    {
        var jobId = context.Message.JobId;
        var outputDir = _workspace.GetOutputDirectory(jobId);

        if (!Directory.Exists(outputDir))
        {
            _logger.LogWarning("[UPLOAD] Output directory not found: {dir}", outputDir);
            return;
        }

        var tempZip = Path.Combine(Path.GetTempPath(), $"{jobId}_output.zip");
        if (File.Exists(tempZip)) File.Delete(tempZip);

        _logger.LogInformation("[UPLOAD] Zipping output directory for job {jobId}", jobId);

        await Task.Run(() =>
        {
            for (var attempt = 0; attempt < 2; attempt++)
            {
                try
                {
                    if (File.Exists(tempZip)) File.Delete(tempZip);
                    ZipFile.CreateFromDirectory(outputDir, tempZip, CompressionLevel.Optimal, includeBaseDirectory: false);
                    break;
                }
                catch (IOException ex) when (attempt == 0)
                {
                    _logger.LogWarning("[UPLOAD] File in use, retrying zip: {message}", ex.Message);
                    Thread.Sleep(500);
                }
            }
        }, stoppingToken);

        var blobPath = $"jobs/{jobId}/output/output.zip";
        _logger.LogInformation("[UPLOAD] Uploading output zip to blob: {blob}", blobPath);

        await _storage.UploadAsync(blobPath, tempZip, stoppingToken);

        if (File.Exists(tempZip)) File.Delete(tempZip);

        _logger.LogInformation("[UPLOAD] Output upload complete for job {jobId}", jobId);
    }
}