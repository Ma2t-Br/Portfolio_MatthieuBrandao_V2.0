using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Core.contracts;
using Core.services;
using Microsoft.Extensions.Logging;
using Worker.configuration;
using Worker.services.ai;
using Worker.services.storage;

namespace Worker.pipeline.implementations.steps;

public sealed class VectorIndexStep : IPipelineStep
{
    public string Name => "Vector Index";

    private readonly ISemanticKernelService _analysisService;
    private readonly IGraphDatabaseService _graph;
    private readonly IJobWorkspace _workspace;
    private readonly ILogger<VectorIndexStep> _logger;

    public VectorIndexStep(ISemanticKernelService analysisService, IGraphDatabaseService graph, IJobWorkspace workspace, ILogger<VectorIndexStep> logger)
    {
        _analysisService = analysisService;
        _graph = graph;
        _workspace = workspace;
        _logger = logger;
    }

    public async Task ExecuteAsync(JobEnvelope context, CancellationToken cancellationToken)
    {
        var jobId = context.Message.JobId;
        var srcDir = _workspace.GetSourceDirectory(jobId);

        if (!Directory.Exists(srcDir))
        {
            _logger.LogError("[VECTOR] Source directory not found: {srcDir}", srcDir);
            return;
        }

        var files = Directory.GetFiles(srcDir, AnalysisLanguage.Csharp, SearchOption.AllDirectories);
        _logger.LogInformation("[VECTOR] Found {count} files to index.", files.Length);

        foreach (var file in files)
        {
            if (cancellationToken.IsCancellationRequested)
                break;

            try
            {
                var content = await File.ReadAllTextAsync(file, cancellationToken);
                if (string.IsNullOrWhiteSpace(content))
                    continue;

                var fileName = Path.GetFileName(file);
                var uniqueId = $"{jobId}:{fileName}";
                var safeContent = content.Length > 2000 ? content[..2000] : content;

                await _analysisService.SaveCodeFragmentAsync(uniqueId, safeContent, fileName);

                var className = ExtractClassName(content) ?? Path.GetFileNameWithoutExtension(file);
                await _graph.AddFileStructureAsync(fileName, className, "AnalyzedFile");

                _logger.LogInformation("[VECTOR] Indexed {fileName} ({className})", fileName, className);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "[VECTOR] Failed processing {file}", file);
            }
        }
    }

    private static string? ExtractClassName(string content)
    {
        const string marker = "class ";
        var index = content.IndexOf(marker, StringComparison.Ordinal);
        if (index < 0) return null;

        index += marker.Length;
        var end = content.IndexOfAny([' ', '{', ':', '\n', '\r'], index);
        return end > index
            ? content[index..end].Trim()
            : null;
    }
}