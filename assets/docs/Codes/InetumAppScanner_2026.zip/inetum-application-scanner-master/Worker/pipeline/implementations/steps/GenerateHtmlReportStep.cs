using System;
using System.IO;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Core.contracts;
using Core.services;
using Microsoft.Extensions.Logging;
using Scriban;

namespace Worker.pipeline.implementations.steps;

public sealed class GenerateHtmlReportStep : IPipelineStep
{
    public string Name => "Generate HTML Report";

    private readonly IJobWorkspace _workspace;
    private readonly ILogger<GenerateHtmlReportStep> _logger;

    public GenerateHtmlReportStep(IJobWorkspace workspace, ILogger<GenerateHtmlReportStep> logger)
    {
        _workspace = workspace;
        _logger = logger;
    }

    public async Task ExecuteAsync(JobEnvelope context, CancellationToken cancellationToken = default)
    {
        var jobId = context.Message.JobId;
        var outputDir = _workspace.GetOutputDirectory(jobId);

        var dependencyVulnerabilities = await LoadResultAsync<DependencyVulnerabilitiesResult>(
            Path.Combine(outputDir, "dependency-vulnerabilities.json"), cancellationToken);
        
        var codeVulnerabilities = await LoadResultAsync<SourceCodeAuditResult>(
            Path.Combine(outputDir, "code-source-audit.json"), cancellationToken);
        
        var templatePath = Path.Combine(AppContext.BaseDirectory, "templates", "report_template.html");
        var templateContent = await File.ReadAllTextAsync(templatePath, cancellationToken);

        var templateData = new
        {
            job_id = jobId,
            date = DateTime.UtcNow.ToString("f"),
            vulnerabilities = dependencyVulnerabilities.Vulnerabilities,
            audit = codeVulnerabilities.Audit
        };

        var template = Template.Parse(templateContent);
        var resultHtml = await template.RenderAsync(templateData);

        var outputPath = Path.Combine(outputDir, "report.html");
        await File.WriteAllTextAsync(outputPath, resultHtml, cancellationToken);

        _logger.LogInformation("[REPORT] Inetum Report successfully generated at {path}", outputPath);
    }

    private static async Task<T> LoadResultAsync<T>(string path, CancellationToken ct)
    {
        if (!File.Exists(path)) throw new FileNotFoundException("JSON result file not found", path);

        await using var stream = File.OpenRead(path);
        var serializerOptions = new JsonSerializerOptions()
        {
            PropertyNameCaseInsensitive = true
        };
        
        stream.Position = 0;
        return await JsonSerializer.DeserializeAsync<T>(stream, serializerOptions, ct) ?? throw new InvalidOperationException("Failed to deserialized JSON result file at " + path);
    }
}