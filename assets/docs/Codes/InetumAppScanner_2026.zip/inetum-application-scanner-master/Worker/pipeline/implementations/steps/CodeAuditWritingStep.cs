using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Core.contracts;
using Core.models;
using Core.services;
using Microsoft.Extensions.Logging;
using Worker.configuration;
using Worker.services;
using Worker.services.json;
using Worker.services.storage;

namespace Worker.pipeline.implementations.steps;

public sealed class CodeAuditWritingStep : IPipelineStep
{
    public string Name => "Audit Reporting";

    private readonly IGraphDatabaseService _graph;
    private readonly IJobWorkspace _workspace;
    private readonly ILogger<CodeAuditWritingStep> _logger;
    private static readonly char[] Separator = ['\n', '\r'];

    public CodeAuditWritingStep(
        IGraphDatabaseService graph,
        IJobWorkspace workspace,
        ILogger<CodeAuditWritingStep> logger)
    {
        _graph = graph;
        _workspace = workspace;
        _logger = logger;
    }

    public async Task ExecuteAsync(JobEnvelope context, CancellationToken stoppingToken = default)
    {
        var jobId = context.Message.JobId;
        var outDir = _workspace.GetOutputDirectory(jobId);
        Directory.CreateDirectory(outDir);

        var report = await _graph.GetFullAuditReportAsync();
        if (report.Count == 0)
        {
            _logger.LogInformation("[AUDIT] No vulnerabilities found.");
            var outputJson = Path.Combine(outDir, "code-source-audit.json");
            var auditResult = new SourceCodeAuditResult(
                jobId,
                DateTime.UtcNow,
                0,
                [] 
            );
            await JsonReportWriter.WriteObjectAsync(auditResult, outputJson, stoppingToken);
            return;
        }
        
        try
        {
            var reports = new List<SourceCodeAudit>();

            foreach (var item in report)
            {
                var affectedFiles = new List<AffectedFile>();

                // Try to find matching source files and include snippets (up to 3)
                try
                {
                    var srcDir = _workspace.GetSourceDirectory(jobId);
                    if (Directory.Exists(srcDir))
                    {
                        var matches = Directory.EnumerateFiles(srcDir, AnalysisLanguage.Csharp, SearchOption.AllDirectories)
                            .Where(f => string.Equals(Path.GetFileNameWithoutExtension(f), item.ClassName, StringComparison.OrdinalIgnoreCase))
                            .Take(3);

                        affectedFiles.AddRange(matches.Select(file => ExtractSnippetFromFile(file, item.ClassName)));
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogDebug(ex, "[AUDIT] Error locating source files for {className}", item.ClassName);
                }
                
                if (affectedFiles.Count == 0)
                    affectedFiles.Add(new AffectedFile(item.ClassName, null, null, null));

                var auditReport = new SourceCodeAudit(
                    item.ClassName,
                    !string.IsNullOrWhiteSpace(item.VulnerabilityType) ? item.VulnerabilityType : (!string.IsNullOrWhiteSpace(item.VulnType) ? item.VulnType : "Unknown"),
                    true,
                    ClampRisk(item.RiskScore),
                    EnsureEscaped(item.DetailedAnalysis),
                    SanitizeRemediation(item.Remediation),
                    affectedFiles
                );

                reports.Add(auditReport);
            }
            
            
            var outputJson = Path.Combine(outDir, "code-source-audit.json");
            var auditResult = new SourceCodeAuditResult(
                jobId,
                DateTime.UtcNow,
                reports.Count,
                reports
            );
            await JsonReportWriter.WriteObjectAsync(auditResult, outputJson, stoppingToken);
            
            _logger.LogInformation("[AUDIT] Audit report written to {path}", outputJson);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[AUDIT] Failed to generate JSON report");
        }
    }

    private static int ClampRisk(int risk)
    {
        return risk switch
        {
            < 0 => 0,
            > 10 => 10,
            _ => risk
        };
    }

    private static string EnsureEscaped(string? input)
    {
        return string.IsNullOrEmpty(input) ? string.Empty : input.Replace("\0", "");
    }

    private static string SanitizeRemediation(string? remediation)
    {
        if (string.IsNullOrEmpty(remediation)) return string.Empty;
        remediation = Regex.Replace(remediation, @"```[\s\S]*?```", "", RegexOptions.Multiline);
        remediation = remediation.Replace("`", "");
        remediation = Regex.Replace(remediation, "\\s+", " ").Trim();

        var lines = remediation.Split(Separator, StringSplitOptions.RemoveEmptyEntries);
        if (lines.Length > 5)
        {
            var filtered = new List<string>();
            foreach (var line in lines)
            {
                var t = line.Trim();
                if (t.Contains(';') || t.Contains('{') || t.Contains("}") || t.Contains("=>")) continue;
                filtered.Add(t);
                if (filtered.Count >= 5) break;
            }
            remediation = filtered.Count > 0 ? string.Join(" ", filtered) : "See remediation in the system (code removed for policy).";
        }

        remediation = remediation.Replace("`", "");
        return remediation;
    }

    private static AffectedFile ExtractSnippetFromFile(string filePath, string className)
    {
        try
        {
            var lines = File.ReadAllLines(filePath);
            var pattern = $@"\bclass\s+{Regex.Escape(className)}\b";
            var idx = -1;
            for (var i = 0; i < lines.Length; i++) if (Regex.IsMatch(lines[i], pattern)) { idx = i; break; }
            if (idx == -1) for (var i = 0; i < lines.Length; i++) if (lines[i].Contains(className)) { idx = i; break; }

            int start = 0, end = Math.Min(lines.Length - 1, 20);
            if (idx != -1) { start = Math.Max(0, idx - 3); end = Math.Min(lines.Length - 1, idx + 3); }

            var snippetLines = lines.Skip(start).Take(end - start + 1);
            var snippet = string.Join("\n", snippetLines);
            if (snippet.Length > 2000) snippet = snippet.Substring(0, 2000) + "\n...";

            snippet = Regex.Replace(snippet, @"```[\s\S]*?```", "", RegexOptions.Multiline);
            snippet = snippet.Replace("`", "");

            return new AffectedFile(filePath, start + 1, end + 1, snippet);
        }
        catch
        {
            return new AffectedFile(filePath, null, null, null);
        }
    }
}