using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Core.contracts;
using Core.services;
using Microsoft.Extensions.Logging;
using Worker.configuration;
using Worker.services;
using Worker.services.ai;
using Worker.services.storage;

namespace Worker.pipeline.implementations.steps;

public sealed class AiAnalysisStep : IPipelineStep
{
    public string Name => "AI Analysis (Mistral)";

    private readonly ISemanticKernelService _analysisService;
    private readonly IGraphDatabaseService _graph;
    private readonly IJobWorkspace _workspace;
    private readonly ILogger<AiAnalysisStep> _logger;

    public AiAnalysisStep(
        ISemanticKernelService analysisService,
        IGraphDatabaseService graph,
        IJobWorkspace workspace,
        ILogger<AiAnalysisStep> logger)
    {
        _analysisService = analysisService;
        _graph = graph;
        _workspace = workspace;
        _logger = logger;
    }

    public async Task ExecuteAsync(JobEnvelope context, CancellationToken cancellationToken = default)
    {
        var jobId = context.Message.JobId;
        var srcDir = _workspace.GetSourceDirectory(jobId);

        if (!Directory.Exists(srcDir))
        {
            _logger.LogError("[AI] Source directory not found: {srcDir}", srcDir);
            return;
        }

        var files = Directory.GetFiles(srcDir, AnalysisLanguage.Csharp, SearchOption.AllDirectories);
        _logger.LogInformation("[AI] Found {count} C# files.", files.Length);

        var totalFindings = 0;

        foreach (var file in files)
        {
            if (cancellationToken.IsCancellationRequested)
                break;

            if (file.Contains($"{Path.DirectorySeparatorChar}bin{Path.DirectorySeparatorChar}") ||
                file.Contains($"{Path.DirectorySeparatorChar}obj{Path.DirectorySeparatorChar}"))
                continue;

            try
            {
                var code = await File.ReadAllTextAsync(file, cancellationToken);
                var className = Path.GetFileNameWithoutExtension(file);

                _logger.LogInformation("[AI] Analysing file {className}", className);

                var findings = await _analysisService.AnalyzeCodeDirectlyAsync(code);

                foreach (var finding in findings)
                {
                    finding.ClassName = className;
                    await _graph.SaveVulnerabilityAsync(finding);
                }

                totalFindings += findings.Count;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "[AI] Error analyzing {file}", file);
            }
        }

        _logger.LogInformation("[AI] Analysis completed. Vulnerabilities found: {count}", totalFindings);
    }
}