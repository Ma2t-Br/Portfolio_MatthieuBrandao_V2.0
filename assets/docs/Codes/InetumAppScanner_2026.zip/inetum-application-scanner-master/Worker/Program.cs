﻿using System;
using System.Collections.Generic;
using System.Threading;
using Core.broker;
using Core.broker.implementations;
using Core.configuration;
using Core.repositories;
using Core.repositories.implementations;
using Core.services;
using Core.services.implementations;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;
using Worker.configuration;
using Worker.pipeline;
using Worker.pipeline.implementations;
using Worker.pipeline.implementations.steps;
using Worker.pipeline.main;
using Worker.services.ai;
using Worker.services.implementations.ai;
using Worker.services.implementations.ai.promptBuilders;
using Worker.services.implementations.vector;
using Worker.services.storage;

var builder = Host.CreateApplicationBuilder(args);

builder.Services
    .AddOptions<RetryPolicy>()
    .Bind(builder.Configuration.GetSection("RetryPolicy"))
    .Validate(retryPolicy =>
    {
        retryPolicy.Validate();
        return true;
    });

builder.Services.AddSingleton(sp =>
    sp.GetRequiredService<
        Microsoft.Extensions.Options.IOptions<RetryPolicy>>().Value);

builder.Services.AddSingleton<IConnectionFactory>(_ =>
    new ConnectionFactory
    {
        HostName = builder.Configuration["RabbitMQ:Host"],
        UserName = builder.Configuration["RabbitMQ:Username"],
        Password = builder.Configuration["RabbitMQ:Password"],
        DispatchConsumersAsync = true,
        AutomaticRecoveryEnabled = true,
        NetworkRecoveryInterval = TimeSpan.FromSeconds(10)
    });

builder.Services.AddSingleton<IConnection>(sp =>
{
    var logger = sp.GetRequiredService<ILoggerFactory>()
        .CreateLogger("RabbitMQ");

    var factory = sp.GetRequiredService<IConnectionFactory>();

    while (true)
    {
        try
        {
            logger.LogInformation("Attempting RabbitMQ connection...");
            var connection = factory.CreateConnection();
            logger.LogInformation("RabbitMQ connection established");
            return connection;
        }
        catch (Exception ex)
        {
            logger.LogWarning(
                ex,
                "RabbitMQ not ready. Retrying in 5 seconds...");
            Thread.Sleep(TimeSpan.FromSeconds(5));
        }
    }
});

builder.Services.AddSingleton<IJobQueue, RabbitMqJobQueue>();

builder.Services.Configure<MongoSettings>(builder.Configuration.GetSection("MongoDB"));
builder.Services.AddSingleton<IJobRepository, MongoJobRepository>();

builder.Services.Configure<AzureBlobSettings>(builder.Configuration.GetSection("AzureBlob"));
builder.Services.AddSingleton <IFileStorageService, BlobStorageService>();

builder.Services.Configure<Neo4JSettings>(builder.Configuration.GetSection("Neo4J"));
builder.Services.Configure<OllamaSettings>(builder.Configuration.GetSection("Ollama"));
builder.Services.Configure<ChromaSettings>(builder.Configuration.GetSection("ChromaDB"));

builder.Services.AddSingleton <IPromptBuilder, SecurityAuditPromptBuilder>();
builder.Services.AddSingleton<IAnalysisResponseParser, AuditVulnerabilityResponseParser>();

builder.Services.AddSingleton<ISemanticKernelClient, OllamaKernelClient>();
builder.Services.AddSingleton<IGraphDatabaseService, GraphDatabaseService>();
builder.Services.AddSingleton<IVectorMemoryStore, ChromaVectorMemoryStore>();

builder.Services.AddSingleton<ISemanticKernelService, CodeAnalysisService>();
builder.Services.AddSingleton<IHeuristicScanner, RegexHeuristicScanner>();

builder.Services.AddSingleton<IJobWorkspace, JobWorkspace>();

builder.Services.Configure<DependencyCheckSettings>(builder.Configuration.GetSection("DependencyCheck"));

var pipelineSteps = builder.Configuration
                        .GetSection("Pipeline:Steps")
                        .Get<string[]>()
                    ?? [];

var stepRegistry = new Dictionary<string, Type>(StringComparer.OrdinalIgnoreCase)
{
    ["Cleanup"] = typeof(CleanupStep),
    ["DependencyScan"] = typeof(DependencyScanStep),
    ["VectorIndex"] = typeof(VectorIndexStep),
    ["AiAnalysis"] = typeof(AiAnalysisStep),
    ["AuditReporting"] = typeof(CodeAuditWritingStep),
    ["GenerateHTMLReport"] = typeof(GenerateHtmlReportStep)
};
builder.Services.AddSingleton(typeof(IPipelineStep), typeof(DownloadInputStep));
foreach (var stepName in pipelineSteps)
{
    if (!stepRegistry.TryGetValue(stepName, out var stepType))
    {
        throw new InvalidOperationException($"Pipeline step '{stepName}' is not registered.");
    }

    builder.Services.AddSingleton(typeof(IPipelineStep), stepType);
}
builder.Services.AddSingleton(typeof(IPipelineStep), typeof(UploadOutputStep));

builder.Services.AddSingleton<IJobPipeline, JobPipeline>();

builder.Services.AddHostedService<AnalysisPipeline>();

var app = builder.Build();

app.Run();