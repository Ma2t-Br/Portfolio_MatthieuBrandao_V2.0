﻿import { Layout, Menu } from "antd";
import {
    DashboardOutlined,
    UploadOutlined,
} from "@ant-design/icons";
import { Outlet, useLocation, useNavigate } from "react-router-dom";

const { Sider, Header, Content } = Layout;

export default function DashboardLayout() {
    const navigate = useNavigate();
    const location = useLocation();

    return (
        <Layout style={{ minHeight: "100vh" }}>
            <Sider theme="dark">
                <div
                    style={{
                        height: 48,
                        margin: 16,
                        color: "white",
                        fontWeight: 600,
                    }}
                >
                    Job Dashboard
                </div>

                <Menu
                    theme="dark"
                    mode="inline"
                    selectedKeys={[location.pathname]}
                    onClick={({ key }) => navigate(key)}
                    items={[
                        { key: "/jobs", icon: <DashboardOutlined />, label: "Jobs" },
                        { key: "/upload", icon: <UploadOutlined />, label: "Upload" },
                    ]}
                />
            </Sider>

            <Layout>
                <Header
                    style={{
                        background: "#fff",
                        padding: "0 24px",
                        fontWeight: 500,
                    }}
                >
                    {location.pathname === "/jobs" && "Monitoring"}
                    {location.pathname === "/upload" && "Create"}
                </Header>

                <Content
                    style={{
                        margin: 24,
                        background: "#f5f7fa",
                    }}
                >
                    <Outlet />
                </Content>
            </Layout>
        </Layout>
    );
}