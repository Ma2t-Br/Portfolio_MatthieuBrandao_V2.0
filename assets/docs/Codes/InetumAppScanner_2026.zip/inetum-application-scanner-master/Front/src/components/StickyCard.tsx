﻿import { Card } from "antd";
import { ReactNode } from "react";

export default function StickyCard({ title, children, offset = 88 }: {
    title?: string;
    children: ReactNode;
    offset?: number;
}) {
    return (
        <div
            style={{
                position: "sticky",
                top: offset,
                zIndex: 10,
            }}
        >
            <Card size="small" title={title}>
                {children}
            </Card>
        </div>
    );
}