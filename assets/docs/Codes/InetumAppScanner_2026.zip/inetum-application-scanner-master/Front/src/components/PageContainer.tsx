﻿import { ReactNode } from "react";
import { Space, Typography } from "antd";

const { Title } = Typography;

export default function PageContainer({ title, extra, children }: {
    title: string;
    extra?: ReactNode;
    children: ReactNode;
}) {
    return (
        <Space direction="vertical" size="large" style={{ width: "100%" }}>
            <Space
                align="center"
                style={{ width: "100%", justifyContent: "space-between" }}
            >
                <Title level={3} style={{ margin: 0 }}>
                    {title}
                </Title>
                {extra}
            </Space>

            {children}
        </Space>
    );
}