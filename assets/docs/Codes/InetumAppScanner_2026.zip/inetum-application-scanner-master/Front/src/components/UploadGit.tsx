﻿import { Card, Spin, Input, Button, Space } from "antd";
import { useState } from "react";

export default function UploadGit({
                                      loading,
                                      onUpload,
                                  }: {
    loading: boolean;
    onUpload: (repositoryUrl: string, branch: string | null) => Promise<void>;
}) {
    const [repositoryUrl, setRepositoryUrl] = useState("");
    const [branch, setBranch] = useState("");

    const submit = async () => {
        await onUpload(repositoryUrl, branch.trim() ? branch : null);
        setRepositoryUrl("");
        setBranch("");
    };

    return (
        <Card>
            {loading ? (
                <Spin />
            ) : (
                <Space direction="vertical" style={{ width: "100%" }}>
                    <Input
                        placeholder="Git repository URL"
                        value={repositoryUrl}
                        onChange={(event) => setRepositoryUrl(event.target.value)}
                    />

                    <Input
                        placeholder="Branch (optional)"
                        value={branch}
                        onChange={(event) => setBranch(event.target.value)}
                    />

                    <Button
                        type="primary"
                        onClick={submit}
                        disabled={!repositoryUrl}
                    >
                        Upload from GIT repository
                    </Button>
                </Space>
            )}
        </Card>
    );
}