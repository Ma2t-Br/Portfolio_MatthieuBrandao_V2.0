﻿import { Drawer, Timeline, Button, Typography } from "antd";
import { CheckCircleOutlined, CloseCircleOutlined, StopOutlined } from "@ant-design/icons";
import { getReport } from "../gateway/api";

export default function JobDrawer({ job, close }: any) {
    if (!job) return null;

    const openReport = async () => {
        const html = await getReport(job.id);
        const blob = new Blob([html], { type: "text/html" });
        window.open(URL.createObjectURL(blob));
    };

    const formatDate = (date: string) =>
        new Date(date).toLocaleString(undefined, {
            dateStyle: "medium",
            timeStyle: "short",
        });

    return (
        <Drawer
            open={!!job}
            onClose={close}
            width={450}
            title={
                <Typography.Text
                    copyable={{ text: job.id }}
                    style={{ fontSize: 14 }}
                >
                    { job.id }
                </Typography.Text>
            }
        >
        <Timeline>
            <Timeline.Item>
                Created at {formatDate(job.createdAt)}
            </Timeline.Item>

            {job.enqueuedAt && (
                    <Timeline.Item>
                        Enqueued at {formatDate(job.enqueuedAt)}
                    </Timeline.Item>
                )}

                {job.startedAt && (
                    <Timeline.Item>
                        Started at {formatDate(job.startedAt)}
                    </Timeline.Item>
                )}

                {job.completedAt && (
                    <Timeline.Item
                        color="green"
                        dot={<CheckCircleOutlined />}
                    >
                        Completed at {formatDate(job.completedAt)}
                    </Timeline.Item>
                )}

                {job.canceledAt && (
                    <Timeline.Item
                        color="red"
                        dot={<StopOutlined />}
                    >                        
                        Canceled at {formatDate(job.canceledAt)}
                    </Timeline.Item>
                )}

                {job.failedAt && (
                    <Timeline.Item
                        color="red"
                        dot={<CloseCircleOutlined />}
                    >                          
                        Failed at {formatDate(job.failedAt)}: {job.error}
                    </Timeline.Item>
                )}
            </Timeline>

            {job.status === "Completed" && (
                <Button type="primary" onClick={openReport} style={{ marginTop: 16 }}>
                    Open report
                </Button>
            )}
        </Drawer>
    );
}