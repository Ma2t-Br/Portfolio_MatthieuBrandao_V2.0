﻿import { Segmented, Badge } from "antd";

const statuses = ["All", "Queued", "Running", "Completed", "Canceled", "Failed"];

export default function JobsFilters({ jobs, setFilter }: any) {
    const count = (status: string) => {
        try {
            status === "All" ? jobs.length : jobs.filter((job: any) => job.status === status).length;
        }
        catch (error) {
            return 0;
        }
    }

    return (
        <Segmented
            options={statuses.map(status => ({
                label: <Badge count={count(status)}>{status}</Badge>,
                value: status,
            }))}
            onChange={setFilter}
            defaultValue="All"
        />
    );
}