﻿import { Table, Tag } from "antd";

const colors: any = {
    Created: "default",
    Queued: "default",
    Running: "processing",
    Completed: "green",
    Canceled: "red",
    Failed: "red",
};

export default function JobsTable({ jobs, onClick }: any) {
    return (
        <Table
            rowKey="id"
            dataSource={jobs}
            onRow={(job) => ({ onClick: () => onClick(job) })}
            columns={[
                { title: "JobId", dataIndex: "id" },
                {
                    title: "Status",
                    render: (_: any, job: any) => (
                        <Tag color={colors[job.status]}>{job.status}</Tag>
                    ),
                },
            ]}
        />
    );
}