﻿import { Upload, Card, Spin } from "antd";
import { InboxOutlined } from "@ant-design/icons";

const { Dragger } = Upload;

export default function UploadZip({ loading, onUpload }: {
    loading: boolean;
    onUpload: (file: File) => Promise<void>;
}) {
    return (
        <Card>
            {loading ? (<Spin />) : 
                (<Dragger
                    accept=".zip"
                    showUploadList={false}
                    customRequest={async ({ file, onSuccess, onError }) => {
                        try {
                            await onUpload(file as File);
                            onSuccess?.({});
                        } catch (e) {
                            onError?.(e as Error);
                        }
                    }}
                >
                    <InboxOutlined style={{ fontSize: 48 }} />
                    <p>Drag & drop C# zip</p>
                </Dragger>
            )}
        </Card>
    );
}