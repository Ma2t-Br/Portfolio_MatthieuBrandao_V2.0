import axios from "axios";

export const api = axios.create({
    baseURL: import.meta.env.VITE_API_BASE_URL || "http://host.docker.internal:8080",
});

export const createJobFromZip = async (file: File) => {
    const formData = new FormData();
    formData.append("file", file);

    const { data } = await api.post("/ias/jobs/zip", formData);
    return data.id;
};

export const createJobFromGitRepository = async (repositoryUrl: string, branch: string | null) => {
    const { data } = await api.post("/ias/jobs/git", {
        repositoryUrl,
        branch
    });

    return data.id;
}

export const enqueueJob = async (id: string) => {
    api.post(`/ias/jobs/${id}/enqueue`);
};

export const getJobs = async () => {
    const { data } = await api.get("/ias/jobs");
    return data;
};

export const getReport = async (id: string) => {
    const { data } = await api.get(`/ias/jobs/${id}/report`);
    return data.report;
};