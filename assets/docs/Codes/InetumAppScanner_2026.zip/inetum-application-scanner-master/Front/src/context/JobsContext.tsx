﻿import { createContext, useContext, useEffect, useRef, useState } from "react";
import { message } from "antd";
import { getJobs } from "../gateway/api";

type JobsContextType = {
    jobs: any[];
    loading: boolean;
    refresh: () => Promise<void>;
};

const JobsContext = createContext<JobsContextType | null>(null);

export function JobsProvider({ children }: { children: React.ReactNode }) {
    const [jobs, setJobs] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const initialized = useRef(false);

    const loadJobs = async (silent = false) => {
        try {
            if (!silent) setLoading(true);
            const data = await getJobs();
            setJobs(data);
        } catch (e) {
            if (!silent) message.error("Failed to load jobs");
        } finally {
            if (!silent) setLoading(false);
        }
    };

    useEffect(() => {
        if (initialized.current) return;
        initialized.current = true;
        loadJobs();
    }, []);

    useEffect(() => {
        const id = setInterval(() => {
            loadJobs(true);
        }, 10_000);

        return () => clearInterval(id);
    }, []);

    return (
        <JobsContext.Provider
            value={{
                jobs,
                loading,
                refresh: () => loadJobs(true),
            }}
        >
            {children}
        </JobsContext.Provider>
    );
}

export function useJobs() {
    const context = useContext(JobsContext);
    if (!context) {
        throw new Error("useJobs must be used inside JobsProvider");
    }
    return context;
}