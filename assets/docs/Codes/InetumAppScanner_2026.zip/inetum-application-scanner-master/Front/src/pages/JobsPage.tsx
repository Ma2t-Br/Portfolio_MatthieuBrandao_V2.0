﻿import { useState } from "react";
import { Row, Col, Card, Spin } from "antd";
import PageContainer from "../components/PageContainer";
import StickyCard from "../components/StickyCard";
import JobsTable from "../components/JobsTable";
import JobDrawer from "../components/JobDrawer";
import JobsFilters from "../components/JobsFilters";
import { useJobs } from "../context/JobsContext";

export default function JobsPage() {
    const { jobs, loading } = useJobs(); // Jobs and loading from context
    const [selected, setSelected] = useState<any | null>(null);
    const [filter, setFilter] = useState("All");

    const filtered = filter === "All" ? jobs : jobs.filter(job => job.status === filter);

    return (
        <PageContainer title="Jobs">
            <Row gutter={[24, 24]}>
                <Col span={24}>
                    <StickyCard title="Filters">
                        <JobsFilters jobs={jobs} setFilter={setFilter} />
                    </StickyCard>
                </Col>

                <Col span={24}>
                    <Card>
                        {loading ? <Spin /> : <JobsTable jobs={filtered} onClick={setSelected} />}
                    </Card>
                </Col>
            </Row>

            <JobDrawer job={selected} close={() => setSelected(null)} />
        </PageContainer>
    );
}