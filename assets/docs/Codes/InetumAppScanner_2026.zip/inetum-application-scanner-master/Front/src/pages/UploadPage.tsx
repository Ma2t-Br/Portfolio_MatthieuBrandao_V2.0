﻿import { message } from "antd";
import { useState } from "react";
import PageContainer from "../components/PageContainer";
import UploadZip from "../components/UploadZip";
import UploadGit from "../components/UploadGit";
import { createJobFromZip, createJobFromGitRepository, enqueueJob } from "../gateway/api";

export default function UploadPage() {
    const [loadingZip, setLoadingZip] = useState(false);
    const [loadingGit, setLoadingGit] = useState(false);

    const uploadZip = async (file: File) => {
        try {
            setLoadingZip(true);
            const id = await createJobFromZip(file);
            await enqueueJob(id);
            message.success(`Job ${id} created`);
        } catch {
            message.error("Failed to upload the .zip");
        } finally {
            setLoadingZip(false);
        }
    };

    const uploadGit = async (repositoryUrl: string, branch: string | null) => {
        try {
            setLoadingGit(true);
            const id = await createJobFromGitRepository(repositoryUrl, branch);
            await enqueueJob(id);
            message.success(`Job ${id} created`);
        } catch {
            message.error("Failed to upload Git repository");
        } finally {
            setLoadingGit(false);
        }
    };

    return (
        <PageContainer title="Upload jobs">
            <UploadZip loading={loadingZip} onUpload={uploadZip} />
            <UploadGit loading={loadingGit} onUpload={uploadGit} />
        </PageContainer>
    );
}