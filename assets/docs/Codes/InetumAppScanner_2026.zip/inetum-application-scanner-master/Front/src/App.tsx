﻿import { BrowserRouter } from "react-router-dom";
import AppRouter from "./router/AppRouter";
import { JobsProvider } from "./context/JobsContext";

export default function App() {
    return (
        <BrowserRouter>
            <JobsProvider>
                <AppRouter />
            </JobsProvider>
        </BrowserRouter>
    );
}