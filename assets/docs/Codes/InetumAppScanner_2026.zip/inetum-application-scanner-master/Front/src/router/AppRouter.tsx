﻿import { Routes, Route, Navigate } from "react-router-dom";
import DashboardLayout from "../layout/DashboardLayout";
import JobsPage from "../pages/JobsPage";
import UploadPage from "../pages/UploadPage";

export default function AppRouter() {
    return (
        <Routes>
            <Route element={<DashboardLayout />}>
                <Route path="/" element={<Navigate to="/jobs" replace />} />
                <Route path="/jobs" element={<JobsPage />} />
                <Route path="/upload" element={<UploadPage />} />
            </Route>
        </Routes>
    );
}