﻿namespace Api.security;

using System;

public sealed class RateLimitPolicy
{
    public int RequestsPerMinute { get; init; } = 5;
    public int Burst { get; init; } = 2;

    public TimeSpan Window => TimeSpan.FromMinutes(1);

    public void Validate()
    {
        if (RequestsPerMinute < 1)
            throw new InvalidOperationException(
                "RateLimitPolicy.RequestsPerMinute must be >= 1");

        if (Burst < 0)
            throw new InvalidOperationException(
                "RateLimitPolicy.Burst must be >= 0");
    }
}