﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Api.contracts.error;
using Api.contracts.jobResponses;
using Api.contracts.jobSources;
using Api.contracts.report;
using Api.contracts.requests;
using Api.factories;
using Api.services;
using Core.models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;

namespace Api.controllers;

[ApiController]
[Route("ias/jobs")]
[SwaggerTag("Manage ingestion and processing jobs")]
[Produces("application/json")]
public class JobController : ControllerBase
{
    private readonly JobFacade _jobFacade;
    private readonly IJobResponseFactory _jobResponseFactory;
    private readonly ILogger<JobController> _logger;
    
    public JobController(JobFacade jobFacade, IJobResponseFactory jobResponseFactory, ILogger<JobController> logger)
    {
        _jobFacade = jobFacade;
        _jobResponseFactory = jobResponseFactory;
        _logger = logger;
    }

    [HttpGet]
    [SwaggerOperation(
        Summary = "Get all jobs",
        Description = "Gets all the jobs."
    )]
    [SwaggerResponse(StatusCodes.Status200OK, "Jobs found", typeof(IEnumerable<JobResponse>))]
    public async Task<ActionResult<IEnumerable<JobResponse>>> GetAllJobs()
    {
        _logger.LogInformation("GET all jobs.");

        var jobs = await _jobFacade.GetAllJobsAsync();
        
        var response = jobs.Select(object (job) => _jobResponseFactory.Create(job));
        return Ok(response);
    }

    [HttpGet("{jobId}")]
    [SwaggerOperation(
        Summary = "Get the job status",
        Description = "Returns metadata and current execution status of a job."
    )]
    [ProducesResponseType(typeof(JobResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    [SwaggerResponse(StatusCodes.Status200OK, "Job found", typeof(JobResponse))]
    [SwaggerResponse(StatusCodes.Status404NotFound, "Job not found", typeof(ErrorResponse))]
    public async Task<ActionResult<JobResponse>> GetJob(string jobId)
    {
        _logger.LogInformation("GET job with id '{jobId}.'", jobId);
        var job = await _jobFacade.GetJobAsync(jobId);
        if (job == null)
            return NotFound(
                new ErrorResponse(StatusCodes.Status404NotFound,
                    $"Job '{jobId}' not found."
                    ));

        var response = _jobResponseFactory.Create(job);
        return Ok(response);
    }

    [HttpPost("zip")]
    [Consumes("multipart/form-data")]
    [EnableRateLimiting("perIp")]
    [SwaggerOperation(
        Summary = "Create a job from a ZIP file",
        Description = "Ingests a ZIP archive and creates a new processing job."
    )]
    [ProducesResponseType(typeof(JobResponse), StatusCodes.Status202Accepted)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [SwaggerResponse(StatusCodes.Status202Accepted, "Job successfully created", typeof(JobResponse))]
    [SwaggerResponse(StatusCodes.Status400BadRequest, "Missing or invalid file", typeof(ErrorResponse))]
    public async Task<ActionResult<JobResponse>> CreateJobFromZip(IFormFile? file)
    {
        if (file == null || file.Length == 0)
        {
            _logger.LogWarning("Ingest request rejected: no file received");
            return BadRequest(
                new ErrorResponse(StatusCodes.Status400BadRequest,
                    "No file received."
                    ));
        }

        try
        {
            _logger.LogInformation("Ingesting '{fileName}' to azurite blob", file.FileName);
            
            var source = new ZipUploadSource(
                file.OpenReadStream(),
                file.FileName,
                file.Length);

            var jobMessage = await _jobFacade.IngestAsync(source);
            var createdAt = DateTime.UtcNow;
            _logger.LogInformation("Job '{jobId}' successfully created at {now}",
                jobMessage.JobId,
                createdAt
            );
            
            var job = await _jobFacade.GetJobAsync(jobMessage.JobId);
            var response = _jobResponseFactory.Create(job!);

            return Accepted(response);
        }
        catch (InvalidOperationException exception)
        {
            var errorMessage = $"Error while ingesting file '{file.FileName}'";
            _logger.LogError(exception, errorMessage);

            return BadRequest(
                new ErrorResponse(StatusCodes.Status400BadRequest, errorMessage));
        }
    }
    
    [HttpPost("git")]
    [Consumes("application/json")]
    [EnableRateLimiting("perIp")]
    [SwaggerOperation(
        Summary = "Create a job from a GIT repository",
        Description = "Ingests a GIT repository and creates a new processing job."
    )]
    [ProducesResponseType(typeof(JobResponse), StatusCodes.Status202Accepted)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [SwaggerResponse(StatusCodes.Status202Accepted, "Job successfully created", typeof(JobResponse))]
    [SwaggerResponse(StatusCodes.Status400BadRequest, "Missing or invalid GIT repository", typeof(ErrorResponse))]
    public async Task<ActionResult<JobResponse>> CreateJobFromGitRepository([FromBody] GitIngestRequest request)
    {
        try
        {
            _logger.LogInformation("Ingesting GIT repository '{gitRepository}' to azurite blob", request.RepositoryUrl);
            
            var source = new GitRepositorySource(request.RepositoryUrl, request.Branch);

            var jobMessage = await _jobFacade.IngestAsync(source);
            var createdAt = DateTime.UtcNow;
            _logger.LogInformation("Job '{jobId}' successfully created at {now}",
                jobMessage.JobId,
                createdAt
            );
            
            var job = await _jobFacade.GetJobAsync(jobMessage.JobId);
            var response = _jobResponseFactory.Create(job!);

            return Accepted(response);
        }
        catch (Exception exception)
        {
            var errorMessage = $"Error while ingesting GIT repository '{request.RepositoryUrl}'";
            _logger.LogError(exception, errorMessage);

            return BadRequest(
                new ErrorResponse(StatusCodes.Status400BadRequest, errorMessage));
        }
    }
    
    [HttpPost("{jobId}/enqueue")]
    [EnableRateLimiting("perIp")]
    [SwaggerOperation(
        Summary = "Enqueue a job",
        Description = "Pushes the job to the background processing queue."
    )]
    [ProducesResponseType(typeof(JobResponse), StatusCodes.Status202Accepted)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    [SwaggerResponse(StatusCodes.Status202Accepted, "Job successfully enqueued", typeof(JobResponse))]
    [SwaggerResponse(StatusCodes.Status404NotFound, "Job not found", typeof(ErrorResponse))]
    [SwaggerResponse(StatusCodes.Status409Conflict, "Invalid job state for enqueueing", typeof(ErrorResponse))]
    public async Task<ActionResult<JobResponse>> EnqueueJob(string jobId)
    {
        var job = await _jobFacade.GetJobAsync(jobId);
        if (job == null)
            return NotFound(
                new ErrorResponse(
                    StatusCodes.Status404NotFound, 
                    $"Job '{jobId}' not found."
                ));

        if (job.Status != JobStatus.Created)
            return Conflict(
                new ErrorResponse(
                    StatusCodes.Status409Conflict,
                    $"Job '{jobId}' cannot be enqueued with status {job.Status}."
                ));
        
        job = await _jobFacade.EnqueueJobAsync(job);
        
        var enqueuedAt = DateTime.UtcNow;
        _logger.LogInformation("Job '{jobId}' successfully enqueued at {now}", jobId, enqueuedAt);

        var response = _jobResponseFactory.Create(job);
        return Accepted(response);
    }
    
    [HttpGet("{jobId}/report")]
    [SwaggerOperation(
        Summary = "Get the report for a specific job",
        Description = "Retrieves the generated report when the job has completed."
    )]
    [ProducesResponseType(typeof(ReportResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    [SwaggerResponse(StatusCodes.Status200OK, "Report successfully returned", typeof(ReportResponse))]
    [SwaggerResponse(StatusCodes.Status404NotFound, "Job or report not found", typeof(ErrorResponse))]
    [SwaggerResponse(StatusCodes.Status409Conflict, "Job has not completed yet", typeof(ErrorResponse))]
    public async Task<ActionResult<ReportResponse>> GetDevReport(string jobId)
    {
        _logger.LogInformation("GET report for job '{jobId}'", jobId);
        var job = await _jobFacade.GetJobAsync(jobId);
        if (job == null)
            return NotFound(
                new ErrorResponse(StatusCodes.Status404NotFound,
                    $"Job '{jobId}' not found."
                    ));
        
        if (job.Status != JobStatus.Completed)
            return Conflict(
                new ErrorResponse(StatusCodes.Status409Conflict,
                    $"Job '{jobId}' is not completed (status: {job.Status})."
                    ));

        const string reportFileName = "report.html";
        var report = await _jobFacade.GetReportAsync(jobId, reportFileName);
        if (report == null)
            return NotFound(
                new ErrorResponse(StatusCodes.Status404NotFound,
                    "Report not found."
                    ));
        
        return Ok(
            new ReportResponse(
                jobId,
                job.CompletedAt,
                report
            ));
    }
}