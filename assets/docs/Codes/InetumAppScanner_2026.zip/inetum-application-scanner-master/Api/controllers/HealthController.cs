﻿using Microsoft.AspNetCore.Http;
using Swashbuckle.AspNetCore.Annotations;

namespace Api.controllers;

using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("health")]
[SwaggerTag("Service monitoring endpoints")]
[Produces("application/json")]
public class HealthController : ControllerBase
{
    [HttpGet]
    [SwaggerOperation(
        Summary = "Health check",
        Description = "Returns the operational status of the API."
    )]
    [SwaggerResponse(StatusCodes.Status200OK, "Service is healthy")]
    public IActionResult Health() => Ok(new { status = "Healthy" });
}