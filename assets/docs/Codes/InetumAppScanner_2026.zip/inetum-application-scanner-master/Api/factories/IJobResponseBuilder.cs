﻿using Api.contracts.jobResponses;
using Core.models;

namespace Api.factories;

public interface IJobResponseBuilder
{
    JobStatus Status { get; }
    JobResponse Build(Job job);
}