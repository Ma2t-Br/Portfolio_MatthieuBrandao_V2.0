﻿using Api.contracts.jobResponses;
using Core.models;

namespace Api.factories.implementations.builders;

public class CompletedJobResponseBuilder : IJobResponseBuilder
{
    public JobStatus Status => JobStatus.Completed;

    public JobResponse Build(Job job) =>
        new CompletedJobResponse
        {
            Id = job.Id,
            Status = Status,
            CreatedAt = job.CreatedAt,
            EnqueuedAt = job.EnqueuedAt!.Value,
            StartedAt = job.StartedAt!.Value,
            CompletedAt = job.CompletedAt!.Value
        };
}