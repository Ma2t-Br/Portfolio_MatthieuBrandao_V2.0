﻿using Api.contracts.jobResponses;
using Core.models;

namespace Api.factories.implementations.builders;

public sealed class CreatedJobResponseBuilder : IJobResponseBuilder
{
    public JobStatus Status => JobStatus.Created;

    public JobResponse Build(Job job) =>
        new CreatedJobResponse
        {
            Id = job.Id,
            Status = Status,
            CreatedAt = job.CreatedAt
        };
}