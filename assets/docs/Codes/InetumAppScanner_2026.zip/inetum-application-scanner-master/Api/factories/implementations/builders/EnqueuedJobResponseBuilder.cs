﻿using Api.contracts.jobResponses;
using Core.models;

namespace Api.factories.implementations.builders;

public sealed class EnqueuedJobResponseBuilder : IJobResponseBuilder
{
    public JobStatus Status => JobStatus.Queued;

    public JobResponse Build(Job job) =>
        new EnqueuedJobResponse
        {
            Id = job.Id,
            Status = Status,
            CreatedAt = job.CreatedAt,
            EnqueuedAt = job.EnqueuedAt!.Value
        };
}