﻿using Api.contracts.jobResponses;
using Core.models;

namespace Api.factories.implementations.builders;

public class FailedJobResponseBuilder : IJobResponseBuilder
{
    public JobStatus Status => JobStatus.Failed;

    public JobResponse Build(Job job) =>
        new FailedJobResponse
        {
            Id = job.Id,
            Status = Status,
            CreatedAt = job.CreatedAt,
            EnqueuedAt = job.EnqueuedAt!.Value,
            StartedAt = job.StartedAt!.Value,
            FailedAt = job.FailedAt!.Value,
            Error = job.Error ?? "Unknown error"
        };
}