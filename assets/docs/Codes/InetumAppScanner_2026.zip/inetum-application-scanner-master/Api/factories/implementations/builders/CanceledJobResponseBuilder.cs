﻿using Api.contracts.jobResponses;
using Core.models;

namespace Api.factories.implementations.builders;

public class CanceledJobResponseBuilder : IJobResponseBuilder
{
    public JobStatus Status => JobStatus.Canceled;

    public JobResponse Build(Job job) =>
        new CanceledJobResponse
        {
            Id = job.Id,
            Status = Status,
            CreatedAt = job.CreatedAt,
            EnqueuedAt = job.EnqueuedAt!.Value,
            StartedAt = job.StartedAt!.Value,
            CanceledAt = job.CanceledAt!.Value
        };
}