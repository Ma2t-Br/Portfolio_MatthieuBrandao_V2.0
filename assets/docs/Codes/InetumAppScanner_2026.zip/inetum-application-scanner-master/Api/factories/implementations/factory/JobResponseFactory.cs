﻿using System;
using System.Collections.Generic;
using System.Linq;
using Api.contracts.jobResponses;
using Core.models;

namespace Api.factories.implementations.factory;

public sealed class JobResponseFactory : IJobResponseFactory
{
    private readonly IReadOnlyDictionary<JobStatus, IJobResponseBuilder> _builders;

    public JobResponseFactory(IEnumerable<IJobResponseBuilder> builders)
    {
        _builders = builders.ToDictionary(builder => builder.Status);
    }

    public JobResponse Create(Job job)
    {
        if (!_builders.TryGetValue(job.Status, out var builder))
            throw new InvalidOperationException(
                $"No JobResponseBuilder registered for status {job.Status}"
            );

        return builder.Build(job);
    }
}