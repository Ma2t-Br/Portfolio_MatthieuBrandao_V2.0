﻿using Api.contracts.jobResponses;
using Core.models;

namespace Api.factories.implementations.builders;

public sealed class RunningJobResponseBuilder : IJobResponseBuilder
{
    public JobStatus Status => JobStatus.Running;

    public JobResponse Build(Job job) =>
        new RunningJobResponse
        {
            Id = job.Id,
            Status = Status,
            CreatedAt = job.CreatedAt,
            EnqueuedAt = job.EnqueuedAt!.Value,
            StartedAt = job.StartedAt!.Value
        };
}