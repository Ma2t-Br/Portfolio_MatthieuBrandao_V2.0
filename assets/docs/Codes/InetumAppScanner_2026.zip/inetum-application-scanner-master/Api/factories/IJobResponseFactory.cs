﻿using Api.contracts.jobResponses;
using Core.models;

namespace Api.factories;

public interface IJobResponseFactory
{
    JobResponse Create(Job job);
}