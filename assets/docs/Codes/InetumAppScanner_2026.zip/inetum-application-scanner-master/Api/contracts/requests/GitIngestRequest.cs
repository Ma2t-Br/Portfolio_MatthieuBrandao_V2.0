﻿namespace Api.contracts.requests;

public sealed record GitIngestRequest(
    string RepositoryUrl,
    string? Branch);