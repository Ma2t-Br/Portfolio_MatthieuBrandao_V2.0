﻿using System;
using System.Text.Json.Serialization;
using Core.models;

namespace Api.contracts.jobResponses;

public abstract record JobResponse
{
    [JsonPropertyOrder(0)]
    public required string Id { get; init; }

    [JsonPropertyOrder(1)]
    public required JobStatus Status { get; init; }

    [JsonPropertyOrder(2)]
    public required DateTime CreatedAt { get; init; }
}