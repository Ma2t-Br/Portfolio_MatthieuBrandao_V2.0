﻿using System;
using System.Text.Json.Serialization;

namespace Api.contracts.jobResponses;

public record CompletedJobResponse : RunningJobResponse
{
    [JsonPropertyOrder(5)]
    public required DateTime CompletedAt { get; init; }
}