﻿namespace Api.contracts.jobResponses;

public record CreatedJobResponse : JobResponse;