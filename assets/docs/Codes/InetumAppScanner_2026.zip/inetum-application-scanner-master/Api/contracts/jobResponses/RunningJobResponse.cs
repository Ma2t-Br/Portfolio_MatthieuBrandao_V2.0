﻿using System;
using System.Text.Json.Serialization;

namespace Api.contracts.jobResponses;

public record RunningJobResponse : EnqueuedJobResponse
{
    [JsonPropertyOrder(4)]
    public required DateTime StartedAt { get; init; }
}