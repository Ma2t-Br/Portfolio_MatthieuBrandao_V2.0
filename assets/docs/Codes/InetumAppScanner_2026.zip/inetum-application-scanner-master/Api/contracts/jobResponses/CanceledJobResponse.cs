﻿using System;
using System.Text.Json.Serialization;

namespace Api.contracts.jobResponses;

public record CanceledJobResponse : RunningJobResponse
{
    [JsonPropertyOrder(5)]
    public required DateTime CanceledAt { get; init; }
}