﻿using System;
using System.Text.Json.Serialization;

namespace Api.contracts.jobResponses;

public record EnqueuedJobResponse : CreatedJobResponse
{
    [JsonPropertyOrder(3)]
    public required DateTime EnqueuedAt { get; init; }
}