﻿using System;
using System.Text.Json.Serialization;

namespace Api.contracts.jobResponses;

public record FailedJobResponse : RunningJobResponse
{
    [JsonPropertyOrder(5)]
    public required DateTime FailedAt { get; init; }
    
    [JsonPropertyOrder(6)]
    public required string Error { get; init; }
}