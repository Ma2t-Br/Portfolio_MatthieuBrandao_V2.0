﻿using System.IO;

namespace Api.contracts.jobSources;

public sealed record ZipUploadSource(
    Stream Content,
    string FileName,
    long Length
) : JobSource;