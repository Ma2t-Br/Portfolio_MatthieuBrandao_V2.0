﻿namespace Api.contracts.jobSources;

public abstract record JobSource;