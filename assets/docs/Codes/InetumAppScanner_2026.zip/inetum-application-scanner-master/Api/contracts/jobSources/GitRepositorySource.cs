﻿namespace Api.contracts.jobSources;

public sealed record GitRepositorySource(
    string RepositoryUrl,
    string? Branch = null
) : JobSource;