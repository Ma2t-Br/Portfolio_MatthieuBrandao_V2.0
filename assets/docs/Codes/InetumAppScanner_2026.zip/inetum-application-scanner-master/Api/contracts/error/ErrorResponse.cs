﻿namespace Api.contracts.error;

public record ErrorResponse(int StatusCode, string Error);