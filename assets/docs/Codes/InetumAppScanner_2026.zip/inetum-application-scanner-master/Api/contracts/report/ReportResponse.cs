﻿using System;

namespace Api.contracts.report;

public record ReportResponse(
    string JobId,
    DateTime? GeneratedAt,
    object Report
);