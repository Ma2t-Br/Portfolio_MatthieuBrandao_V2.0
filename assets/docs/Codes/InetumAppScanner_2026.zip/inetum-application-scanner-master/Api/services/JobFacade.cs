﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Api.contracts.jobSources;
using Api.useCases.enqueueJob;
using Api.useCases.getAllJobs;
using Api.useCases.getJob;
using Api.useCases.getReport;
using Api.useCases.ingestJob;
using Core.contracts;
using Core.models;

namespace Api.services;

public sealed class JobFacade
{
    private readonly IngestJobUseCase _ingest;
    private readonly EnqueueJobUseCase _enqueue;
    private readonly GetJobUseCase _get;
    private readonly GetAllJobsUseCase _getAll;
    private readonly GetJobReportUseCase _getReport;

    public JobFacade(
        IngestJobUseCase ingest,
        EnqueueJobUseCase enqueue,
        GetJobUseCase get,
        GetAllJobsUseCase getAll,
        GetJobReportUseCase getReport)
    {
        _ingest = ingest;
        _enqueue = enqueue;
        _get = get;
        _getAll = getAll;
        _getReport = getReport;
    }

    public Task<JobMessage> IngestAsync(JobSource source, CancellationToken stoppingToken = default)
        => _ingest.ExecuteAsync(new IngestJobCommand(source), stoppingToken);

    public Task<Job> EnqueueJobAsync(Job job, CancellationToken stoppingToken = default)
        => _enqueue.ExecuteAsync(new EnqueueJobCommand(job), stoppingToken);

    public Task<Job?> GetJobAsync(string jobId, CancellationToken stoppingToken = default)
        => _get.ExecuteAsync(new GetJobCommand(jobId), stoppingToken);

    public Task<IEnumerable<Job>> GetAllJobsAsync(CancellationToken stoppingToken = default)
        => _getAll.ExecuteAsync(new GetAllJobsCommand(), stoppingToken);

    public Task<string?> GetReportAsync(string jobId, string file, CancellationToken stoppingToken = default)
        => _getReport.ExecuteAsync(new GetJobReportCommand(jobId, file), stoppingToken);
}