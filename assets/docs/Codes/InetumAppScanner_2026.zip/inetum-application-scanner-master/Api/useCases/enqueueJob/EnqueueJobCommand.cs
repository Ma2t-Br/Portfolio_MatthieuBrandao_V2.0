﻿using Core.models;

namespace Api.useCases.enqueueJob;

public sealed record EnqueueJobCommand(Job Job);