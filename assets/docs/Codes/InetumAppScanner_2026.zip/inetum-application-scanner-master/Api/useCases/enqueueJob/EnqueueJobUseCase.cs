﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Core.broker;
using Core.contracts;
using Core.models;
using Core.repositories;

namespace Api.useCases.enqueueJob;

public sealed class EnqueueJobUseCase : IUseCase<EnqueueJobCommand, Job>
{
    private readonly IJobRepository _repository;
    private readonly IJobDispatcher _dispatcher;

    public EnqueueJobUseCase(
        IJobRepository repository,
        IJobDispatcher dispatcher)
    {
        _repository = repository;
        _dispatcher = dispatcher;
    }

    public async Task<Job> ExecuteAsync(EnqueueJobCommand command, CancellationToken stoppingToken)
    {
        var job = command.Job;
        await _repository.SaveAsync(job, stoppingToken);

        var message = new JobMessage(
            job.Id,
            job.SourcePath ?? string.Empty);

        return await _dispatcher.DispatchAsync(message, stoppingToken);
    }
}