﻿using System.Threading;
using System.Threading.Tasks;
using Core.models;
using Core.repositories;

namespace Api.useCases.getJob;

public sealed class GetJobUseCase : IUseCase<GetJobCommand, Job?>
{
    private readonly IJobRepository _repository;

    public GetJobUseCase(IJobRepository repository)
    {
        _repository = repository;
    }

    public Task<Job?> ExecuteAsync(GetJobCommand query, CancellationToken stoppingToken)
        => _repository.GetAsync(query.JobId, stoppingToken);
}