﻿namespace Api.useCases.getJob;

public sealed record GetJobCommand(string JobId);