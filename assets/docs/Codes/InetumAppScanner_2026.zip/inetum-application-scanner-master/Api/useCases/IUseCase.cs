﻿using System.Threading;
using System.Threading.Tasks;

namespace Api.useCases;

public interface IUseCase<in TInput, TResult>
{
    Task<TResult> ExecuteAsync(TInput input, CancellationToken stoppingToken);
}