﻿using System.IO;
using System.IO.Compression;
using System.Threading;
using System.Threading.Tasks;
using Core.services;

namespace Api.useCases.getReport;

public sealed class GetJobReportUseCase : IUseCase<GetJobReportCommand, string?>
{
    private readonly IFileStorageService _storage;
    private readonly IJobWorkspace _workspace;

    public GetJobReportUseCase(
        IFileStorageService storage,
        IJobWorkspace workspace)
    {
        _storage = storage;
        _workspace = workspace;
    }

    public async Task<string?> ExecuteAsync(GetJobReportCommand query, CancellationToken stoppingToken)
    {
        var blobPath = $"jobs/{query.JobId}/output/output.zip";

        if (!await _storage.ExistsAsync(blobPath, stoppingToken))
            return null;

        var outputDir = _workspace.GetOutputDirectory(query.JobId);
        Directory.CreateDirectory(outputDir);

        var localZip = Path.Combine(outputDir, "output.zip");
        if (!File.Exists(localZip))
            await _storage.DownloadAsync(blobPath, localZip, stoppingToken);

        ExtractZip(localZip, outputDir, query.JobId);

        var reportPath = Path.Combine(outputDir, query.ReportFileName);
        return File.Exists(reportPath)
            ? await File.ReadAllTextAsync(reportPath, stoppingToken)
            : null;
    }

    private static void ExtractZip(string zip, string outputDir, string jobId)
    {
        var temp = Path.Combine(Path.GetTempPath(), $"{jobId}_output.zip");
        if (File.Exists(temp)) File.Delete(temp);

        File.Copy(zip, temp, true);
        ZipFile.ExtractToDirectory(temp, outputDir, true);
        File.Delete(temp);
    }
}