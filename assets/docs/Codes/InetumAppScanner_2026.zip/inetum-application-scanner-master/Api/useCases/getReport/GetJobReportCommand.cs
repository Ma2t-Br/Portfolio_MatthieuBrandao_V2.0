﻿namespace Api.useCases.getReport;

public sealed record GetJobReportCommand(
    string JobId,
    string ReportFileName);
