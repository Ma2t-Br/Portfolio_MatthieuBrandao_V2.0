﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace Api.useCases.ingestJob.git;

public sealed class GitCliClient : IGitClient
{
    public async Task CloneAsync(
        string repositoryUrl,
        string targetDirectory,
        string? branch,
        CancellationToken stoppingToken)
    {
        Directory.CreateDirectory(targetDirectory);

        var args = branch is null
            ? $"clone --depth 1 {repositoryUrl} ."
            : $"clone --depth 1 --branch {branch} {repositoryUrl} .";

        var psi = new ProcessStartInfo
        {
            FileName = "git",
            Arguments = args,
            WorkingDirectory = targetDirectory,
            RedirectStandardError = true,
            RedirectStandardOutput = true
        };

        using var process = Process.Start(psi)
                            ?? throw new InvalidOperationException("Failed to start git process");

        await process.WaitForExitAsync(stoppingToken);

        if (process.ExitCode != 0)
        {
            var error = await process.StandardError.ReadToEndAsync(stoppingToken);
            throw new InvalidOperationException($"Git clone failed: {error}");
        }
    }
}