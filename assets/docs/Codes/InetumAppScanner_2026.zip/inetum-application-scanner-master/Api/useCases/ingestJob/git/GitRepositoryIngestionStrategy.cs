﻿using System;
using System.IO;
using System.IO.Compression;
using System.Threading;
using System.Threading.Tasks;
using Api.contracts.jobSources;
using Core.contracts;
using Core.models;
using Core.repositories;
using Core.services;

namespace Api.useCases.ingestJob.git;

public sealed class GitRepositoryIngestionStrategy : IJobIngestionStrategy
{
    private readonly IGitClient _git;
    private readonly IJobRepository _repository;
    private readonly IFileStorageService _storage;
    private readonly IJobWorkspace _workspace;

    public GitRepositoryIngestionStrategy(
        IGitClient git,
        IJobRepository repository,
        IFileStorageService storage,
        IJobWorkspace workspace)
    {
        _git = git;
        _repository = repository;
        _storage = storage;
        _workspace = workspace;
    }

    public bool CanHandle(JobSource source)
        => source is GitRepositorySource;

    public async Task<JobMessage> IngestAsync(JobSource source, CancellationToken stoppingToken)
    {
        var git = (GitRepositorySource)source;
        ValidateGitSource(git);

        var job = new Job();

        var workspaceRoot = _workspace.GetJobRoot(job.Id);
        var cloneDir = Path.Combine(workspaceRoot, "git");
        Directory.CreateDirectory(cloneDir);
        
        var srcDir = _workspace.GetSourceDirectory(job.Id);
        Directory.CreateDirectory(srcDir);
        
        await _git.CloneAsync(
            git.RepositoryUrl,
            cloneDir,
            git.Branch,
            stoppingToken);
        
        var zipPath = Path.Combine(srcDir, "input.zip");
        
        ZipFile.CreateFromDirectory(
            cloneDir,
            zipPath,
            CompressionLevel.Optimal,
            includeBaseDirectory: false);

        var blobPath = $"jobs/{job.Id}/src/input.zip";
        job.SetSourcePath(blobPath);

        await _repository.SaveAsync(job, stoppingToken);
        await _storage.UploadAsync(blobPath, zipPath, stoppingToken);

        File.Delete(zipPath);
        
        return new JobMessage(job.Id, blobPath);
    }

    private static void ValidateGitSource(GitRepositorySource git)
    {
        if (!Uri.TryCreate(git.RepositoryUrl, UriKind.Absolute, out _))
            throw new InvalidOperationException("Invalid git repository URL");
    }
}