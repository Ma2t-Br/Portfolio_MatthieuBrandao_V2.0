﻿using Api.contracts.jobSources;

namespace Api.useCases.ingestJob;

public sealed record IngestJobCommand(JobSource Source);