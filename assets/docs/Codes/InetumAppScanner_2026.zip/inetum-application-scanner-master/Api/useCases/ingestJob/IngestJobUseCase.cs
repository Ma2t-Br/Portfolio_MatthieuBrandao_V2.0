﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Core.contracts;

namespace Api.useCases.ingestJob;

public sealed class IngestJobUseCase : IUseCase<IngestJobCommand, JobMessage>
{
    private readonly IEnumerable<IJobIngestionStrategy> _strategies;

    public IngestJobUseCase(IEnumerable<IJobIngestionStrategy> strategies)
    {
        _strategies = strategies;
    }

    public Task<JobMessage> ExecuteAsync(
        IngestJobCommand command,
        CancellationToken ct)
    {
        var strategy = _strategies
            .FirstOrDefault(source => source.CanHandle(command.Source));

        if (strategy is null)
            throw new InvalidOperationException(
                $"No ingestion strategy for {command.Source.GetType().Name}");

        return strategy.IngestAsync(command.Source, ct);
    }
}