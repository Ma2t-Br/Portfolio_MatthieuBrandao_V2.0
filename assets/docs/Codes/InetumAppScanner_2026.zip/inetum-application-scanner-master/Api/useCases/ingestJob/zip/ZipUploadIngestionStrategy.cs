﻿using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Api.contracts.jobSources;
using Core.contracts;
using Core.models;
using Core.repositories;
using Core.services;

namespace Api.useCases.ingestJob.zip;

public sealed class ZipUploadIngestionStrategy : IJobIngestionStrategy
{
    private readonly IJobRepository _repository;
    private readonly IFileStorageService _storage;
    private readonly IJobWorkspace _workspace;

    public ZipUploadIngestionStrategy(
        IJobRepository repository,
        IFileStorageService storage,
        IJobWorkspace workspace)
    {
        _repository = repository;
        _storage = storage;
        _workspace = workspace;
    }

    public bool CanHandle(JobSource source)
        => source is ZipUploadSource;

    public async Task<JobMessage> IngestAsync(JobSource source, CancellationToken stoppingToken)
    {
        var zip = (ZipUploadSource)source;

        ZipValidator.Validate(zip);

        var job = new Job();

        var srcDir = _workspace.GetSourceDirectory(job.Id);
        Directory.CreateDirectory(srcDir);

        var zipPath = Path.Combine(srcDir, "input.zip");
        await using (var fs = File.Create(zipPath))
            await zip.Content.CopyToAsync(fs, stoppingToken);

        var blobPath = $"jobs/{job.Id}/src/input.zip";
        job.SetSourcePath(blobPath);

        await _repository.SaveAsync(job, stoppingToken);
        await _storage.UploadAsync(blobPath, zipPath, stoppingToken);

        File.Delete(zipPath);
        
        await _repository.SaveAsync(job, stoppingToken);
        return new JobMessage(job.Id, blobPath);
    }
}