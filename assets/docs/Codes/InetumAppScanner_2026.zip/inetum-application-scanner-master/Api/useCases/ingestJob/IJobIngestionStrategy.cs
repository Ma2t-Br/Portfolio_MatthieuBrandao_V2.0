﻿using System.Threading;
using System.Threading.Tasks;
using Api.contracts.jobSources;
using Core.contracts;

namespace Api.useCases.ingestJob;

public interface IJobIngestionStrategy
{
    bool CanHandle(JobSource source);
    Task<JobMessage> IngestAsync(JobSource source, CancellationToken stoppingToken);
}