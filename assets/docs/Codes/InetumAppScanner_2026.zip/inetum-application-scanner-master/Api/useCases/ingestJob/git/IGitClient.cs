﻿using System.Threading;
using System.Threading.Tasks;

namespace Api.useCases.ingestJob.git;

public interface IGitClient
{
    Task CloneAsync(
        string repositoryUrl,
        string targetDirectory,
        string? branch,
        CancellationToken stoppingToken);
}