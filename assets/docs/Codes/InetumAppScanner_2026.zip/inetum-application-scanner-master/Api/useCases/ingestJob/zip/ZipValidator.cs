﻿using System;
using Api.contracts.jobSources;

namespace Api.useCases.ingestJob.zip;

public static class ZipValidator
{
    public static void Validate(ZipUploadSource zip)
    {
        if (!zip.FileName.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Only .zip files allowed");

        switch (zip.Length)
        {
            case 0:
                throw new InvalidOperationException("Empty file");
            case > 500 * 1024 * 1024:
                throw new InvalidOperationException("File too large");
        }
    }
}