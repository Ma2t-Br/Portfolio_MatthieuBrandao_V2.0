﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Core.models;
using Core.repositories;

namespace Api.useCases.getAllJobs;

public sealed class GetAllJobsUseCase : IUseCase<GetAllJobsCommand, IEnumerable<Job>>
{
    private readonly IJobRepository _repository;

    public GetAllJobsUseCase(IJobRepository repository)
    {
        _repository = repository;
    }

    public Task<IEnumerable<Job>> ExecuteAsync(GetAllJobsCommand _, CancellationToken stoppingToken)
        => _repository.GetAllAsync(stoppingToken);
}