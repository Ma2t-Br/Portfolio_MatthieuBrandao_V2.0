﻿namespace Api.useCases.getAllJobs;

public sealed record GetAllJobsCommand;