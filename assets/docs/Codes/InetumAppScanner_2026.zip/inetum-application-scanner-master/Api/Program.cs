using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.RateLimiting;
using Api.factories;
using Api.factories.implementations.builders;
using Api.factories.implementations.factory;
using Api.security;
using Api.services;
using Api.useCases.enqueueJob;
using Api.useCases.getAllJobs;
using Api.useCases.getJob;
using Api.useCases.getReport;
using Api.useCases.ingestJob;
using Api.useCases.ingestJob.git;
using Api.useCases.ingestJob.zip;
using Core.broker;
using Core.broker.implementations;
using Core.configuration;
using Core.repositories;
using Core.repositories.implementations;
using Core.services;
using Core.services.implementations;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;

var builder = WebApplication.CreateBuilder(args);

builder.Services
    .AddOptions<RetryPolicy>()
    .Bind(builder.Configuration.GetSection("RetryPolicy"))
    .Validate(retryPolicy =>
    {
        retryPolicy.Validate();
        return true;
    });

builder.Services.AddSingleton(sp =>
    sp.GetRequiredService<
        Microsoft.Extensions.Options.IOptions<RetryPolicy>>().Value);

builder.Services
    .AddOptions<RateLimitPolicy>()
    .Bind(builder.Configuration.GetSection("RateLimit"))
    .Validate(rateLimit =>
    {
        rateLimit.Validate();
        return true;
    });

builder.Services.AddSingleton(sp =>
    sp.GetRequiredService<
        Microsoft.Extensions.Options.IOptions<RateLimitPolicy>>().Value);

builder.Services
    .AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
    });

builder.Services.AddHealthChecks();

builder.Services.AddSingleton<IConnectionFactory>(_ =>
    new ConnectionFactory
    {
        HostName = builder.Configuration["RabbitMQ:Host"],
        UserName = builder.Configuration["RabbitMQ:Username"],
        Password = builder.Configuration["RabbitMQ:Password"],
        DispatchConsumersAsync = true,
        AutomaticRecoveryEnabled = true,
        NetworkRecoveryInterval = TimeSpan.FromSeconds(10)
    });

builder.Services.AddSingleton<IConnection>(sp =>
{
    var logger = sp.GetRequiredService<ILoggerFactory>()
        .CreateLogger("RabbitMQ");

    var factory = sp.GetRequiredService<IConnectionFactory>();

    while (true)
    {
        try
        {
            logger.LogInformation("Attempting RabbitMQ connection...");
            var connection = factory.CreateConnection();
            logger.LogInformation("RabbitMQ connection established");
            return connection;
        }
        catch (Exception ex)
        {
            logger.LogWarning(
                ex,
                "RabbitMQ not ready. Retrying in 5 seconds...");
            Thread.Sleep(TimeSpan.FromSeconds(5));
        }
    }
});

builder.Services.AddSingleton<IJobQueue, RabbitMqJobQueue>();

builder.Services.Configure<MongoSettings>(builder.Configuration.GetSection("MongoDB"));
builder.Services.AddSingleton<IJobRepository, MongoJobRepository>();

builder.Services.AddSingleton<IJobDispatcher, JobDispatcher>();

builder.Services.Configure<AzureBlobSettings>(builder.Configuration.GetSection("AzureBlob"));
builder.Services.AddSingleton <IFileStorageService, BlobStorageService>();
builder.Services.AddSingleton<IJobWorkspace, JobWorkspace>();

builder.Services.AddSingleton<IJobResponseBuilder, CreatedJobResponseBuilder>();
builder.Services.AddSingleton<IJobResponseBuilder, EnqueuedJobResponseBuilder>();
builder.Services.AddSingleton<IJobResponseBuilder, RunningJobResponseBuilder>();
builder.Services.AddSingleton<IJobResponseBuilder, CompletedJobResponseBuilder>();
builder.Services.AddSingleton<IJobResponseBuilder, CanceledJobResponseBuilder>();
builder.Services.AddSingleton<IJobResponseBuilder, FailedJobResponseBuilder>();

builder.Services.AddSingleton<IJobResponseFactory, JobResponseFactory>();

builder.Services.AddSingleton<IGitClient, GitCliClient>();

builder.Services.AddSingleton<IJobIngestionStrategy, ZipUploadIngestionStrategy>();
builder.Services.AddSingleton<IJobIngestionStrategy, GitRepositoryIngestionStrategy>();

builder.Services.AddSingleton<IngestJobUseCase>();
builder.Services.AddSingleton<EnqueueJobUseCase>();
builder.Services.AddSingleton<GetJobUseCase>();
builder.Services.AddSingleton<GetAllJobsUseCase>();
builder.Services.AddSingleton<GetJobReportUseCase>();

builder.Services.AddSingleton<JobFacade>();

const int sizeLimit = 500 * 1024 * 1024;
builder.Services.Configure<FormOptions>(options =>
{
    options.MultipartBodyLengthLimit = sizeLimit;
});

builder.WebHost.ConfigureKestrel(options =>
{
    options.Limits.MaxRequestBodySize = sizeLimit;
});

const string rateLimiterName = "perIp";
builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;

    options.AddPolicy(rateLimiterName, context =>
    {
        var policy = context.RequestServices.GetRequiredService<RateLimitPolicy>();
        var ip = context.Connection.RemoteIpAddress?.ToString() ?? "unknown";

        return RateLimitPartition.GetFixedWindowLimiter(
            partitionKey: ip,
            factory: _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = policy.RequestsPerMinute,
                Window = policy.Window,
                QueueLimit = policy.Burst,
                QueueProcessingOrder = QueueProcessingOrder.OldestFirst
            });
    });
});
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(option =>
{
    option.EnableAnnotations();
    option.UseAllOfToExtendReferenceSchemas();
    option.UseOneOfForPolymorphism();
});

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy
            .AllowAnyOrigin()
            .AllowAnyHeader()
            .AllowAnyMethod()
    );
});

var app = builder.Build();

app.UseCors();
app.UseSwagger();
app.UseSwaggerUI();

app.MapControllers();

app.MapHealthChecks("/health");

app.Run();