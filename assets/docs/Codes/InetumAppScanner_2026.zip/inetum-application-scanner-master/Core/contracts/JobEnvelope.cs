﻿namespace Core.contracts;

public class JobEnvelope
{
    public JobMessage Message { get; init; } = null!;

    public int Attempt { get; set; } = 1;

    public ulong? DeliveryTag { get; set; }
}