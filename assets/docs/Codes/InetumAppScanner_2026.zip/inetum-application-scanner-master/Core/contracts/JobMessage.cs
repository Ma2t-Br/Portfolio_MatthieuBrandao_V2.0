﻿namespace Core.contracts;

public record JobMessage(
    string JobId,
    string SourcePath
);