using System;
using System.Collections.Generic;
using Core.models;

namespace Core.contracts;

public sealed class SourceCodeAuditResult
{
    public string JobId { get; }

    public DateTime GeneratedAt { get; }

    public int Count { get; }

    public IReadOnlyList<SourceCodeAudit> Audit { get; }

    public SourceCodeAuditResult(string jobId, DateTime generatedAt, int count, IReadOnlyList<SourceCodeAudit> audit)
    {
        JobId = jobId;
        GeneratedAt = generatedAt;
        Count = count;
        Audit = audit;
    }
}
