using System;
using System.Collections.Generic;
using Core.models;

namespace Core.contracts;

public sealed class DependencyVulnerabilitiesResult
{
    public string JobId { get; }

    public DateTime GeneratedAt { get; }

    public int Count { get; }

    public IReadOnlyList<DependencyVulnerability> Vulnerabilities { get; }

    public DependencyVulnerabilitiesResult(string jobId, DateTime generatedAt, int count, IReadOnlyList<DependencyVulnerability> vulnerabilities)
    {
        JobId = jobId;
        GeneratedAt = generatedAt;
        Count = count;
        Vulnerabilities = vulnerabilities;
    }
}
