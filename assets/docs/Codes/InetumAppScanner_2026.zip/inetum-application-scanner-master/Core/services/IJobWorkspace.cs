﻿namespace Core.services;

public interface IJobWorkspace
{
    string GetBaseDirectory();
    string GetJobRoot(string jobId);
    string GetSourceDirectory(string jobId);
    string GetOutputDirectory(string jobId);
}