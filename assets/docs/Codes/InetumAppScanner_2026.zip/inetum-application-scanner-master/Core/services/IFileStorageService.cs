﻿using System.Threading;
using System.Threading.Tasks;

namespace Core.services;

public interface IFileStorageService
{
    Task UploadAsync(string blobPath, string localPath, CancellationToken stoppingToken = default);
    Task DownloadAsync(string blobPath, string localPath, CancellationToken stoppingToken = default);
    Task<bool> ExistsAsync(string blobPath, CancellationToken stoppingToken = default);
}