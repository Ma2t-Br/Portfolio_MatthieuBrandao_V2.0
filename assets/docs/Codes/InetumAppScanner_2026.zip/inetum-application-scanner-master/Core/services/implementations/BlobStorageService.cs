﻿using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Core.configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Core.services.implementations;

public sealed class BlobStorageService : IFileStorageService
{
    private readonly BlobContainerClient _container;

    public BlobStorageService(IOptions<AzureBlobSettings> configuration)
    {
        _container = new BlobContainerClient(
            configuration.Value.ConnectionString,
            configuration.Value.ContainerName);

        _container.CreateIfNotExists();
    }

    public async Task UploadAsync(string blobPath, string localPath, CancellationToken stoppingToken = default)
    {
        var blob = _container.GetBlobClient(Normalize(blobPath));

        await using var stream = File.OpenRead(localPath);
        await blob.UploadAsync(stream, overwrite: true, cancellationToken: stoppingToken);
    }

    public async Task DownloadAsync(string blobPath, string localPath, CancellationToken stoppingToken = default)
    {
        var blob = _container.GetBlobClient(Normalize(blobPath));

        Directory.CreateDirectory(Path.GetDirectoryName(localPath)!);

        await using var stream = File.Create(localPath);
        await blob.DownloadToAsync(stream, stoppingToken);
    }

    public async Task<bool> ExistsAsync(string blobPath, CancellationToken stoppingToken = default)
    {
        var blob = _container.GetBlobClient(Normalize(blobPath));
        return await blob.ExistsAsync(stoppingToken);
    }

    private static string Normalize(string path)
        => path.Replace("\\", "/").TrimStart('/');
}