﻿using System.IO;

namespace Core.services.implementations;

public sealed class JobWorkspace : IJobWorkspace
{
    private readonly string _baseDir = Path.GetTempPath();

    public string GetBaseDirectory() 
        => _baseDir;
    
    public string GetJobRoot(string jobId)
        => Path.Combine(_baseDir, "jobs", jobId);

    public string GetSourceDirectory(string jobId)
        => Path.Combine(GetJobRoot(jobId), "src");

    public string GetOutputDirectory(string jobId)
        => Path.Combine(GetJobRoot(jobId), "output");
}