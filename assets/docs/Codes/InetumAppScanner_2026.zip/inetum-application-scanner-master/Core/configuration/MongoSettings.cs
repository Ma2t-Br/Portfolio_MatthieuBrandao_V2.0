﻿namespace Core.configuration;

public class MongoSettings
{
    public required string ConnectionString { get; init; }
    public required string Database { get; init; }
    public required string Collection { get; init; }
}