﻿namespace Core.configuration;

public class AzureBlobSettings
{
    public required string ConnectionString { get; init; }
    public required string ContainerName { get; init; }

    public required int SasTtlMinutes { get; init; }
} 