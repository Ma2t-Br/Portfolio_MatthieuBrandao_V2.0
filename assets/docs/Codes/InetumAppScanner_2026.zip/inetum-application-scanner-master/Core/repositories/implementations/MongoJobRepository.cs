﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Core.configuration;
using Core.contracts;
using Core.models;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace Core.repositories.implementations;

public class MongoJobRepository : IJobRepository
{
    private readonly IMongoCollection<Job> _collection;

    public MongoJobRepository(IOptions<MongoSettings> configuration)
    {
        var client = new MongoClient(configuration.Value.ConnectionString);
        var database = client.GetDatabase(configuration.Value.Database);
        _collection = database.GetCollection<Job>(configuration.Value.Collection);
    }

    public async Task SaveAsync(Job job, CancellationToken stoppingToken = default)
    {
        await _collection.ReplaceOneAsync(
            jobDocument => jobDocument.Id == job.Id,
            job,
            new ReplaceOptions { IsUpsert = true },
            stoppingToken
        );
    }

    public async Task<Job?> GetAsync(string jobId, CancellationToken stoppingToken = default)
    {
        var job = await _collection
            .Find(jobDocument => jobDocument.Id == jobId)
            .FirstOrDefaultAsync(stoppingToken);

        return job;
    }

    public async Task<IEnumerable<Job>> GetAllAsync(CancellationToken stoppingToken = default)
    {
        return await _collection
            .Find(job => true)
            .ToListAsync(stoppingToken);
    }
}