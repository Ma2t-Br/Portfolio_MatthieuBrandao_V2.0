﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Core.repositories;

using models;

public interface IJobRepository
{
    Task SaveAsync(Job job, CancellationToken stoppingToken = default);
    Task<Job?> GetAsync(string jobId, CancellationToken stoppingToken = default);
    Task<IEnumerable<Job>> GetAllAsync(CancellationToken stoppingToken = default);
}