﻿using System;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Core.models;

public class Job
{
    [BsonId]
    [BsonRepresentation(BsonType.String)]
    public string Id { get; init; } = Guid.NewGuid().ToString();

    public string? SourcePath { get; private set; }
    public int CurrentStepIndex { get; private set; }

    public JobStatus Status { get; private set; } = JobStatus.Created;

    public DateTime CreatedAt { get; init; } = DateTime.UtcNow;
    
    public DateTime? EnqueuedAt { get; private set; } 
    public DateTime? StartedAt { get; private set; }
    public DateTime? CompletedAt { get; private set; }
    public DateTime? CanceledAt { get; private set; }
    public DateTime? FailedAt { get; private set; }

    public string? Error { get; private set; }

    public void SetSourcePath(string path) => SourcePath = path;

    public void MarkQueued()
    {
        EnsureState(JobStatus.Created);
        Status = JobStatus.Queued;
        
        EnqueuedAt ??= DateTime.UtcNow;
    }

    public void MarkRunning()
    {
        if (Status is not (JobStatus.Queued or JobStatus.Retrying))
            throw InvalidTransition("Running");

        Status = JobStatus.Running;

        StartedAt ??= DateTime.UtcNow;
    }

    public void MarkRetry()
    {
        EnsureState(JobStatus.Running);
        Status = JobStatus.Retrying;
    }

    public void MarkCompleted()
    {
        EnsureState(JobStatus.Running);
        Status = JobStatus.Completed;
        
        CompletedAt ??= DateTime.UtcNow;
    }

    public void MarkCanceled()
    {
        EnsureState(JobStatus.Running);
        Status = JobStatus.Canceled;
        
        CanceledAt ??= DateTime.UtcNow;
    }

    public void MarkFailed(string error)
    {
        EnsureState(JobStatus.Running);
        Status = JobStatus.Failed;
        
        Error = error;
        FailedAt ??= DateTime.UtcNow;
    }

    public void MarkStepCompleted(int stepIndex)
    {
        EnsureState(JobStatus.Running);
        CurrentStepIndex = stepIndex + 1;
    }

    private void EnsureState(JobStatus expected)
    {
        if (Status != expected)
            throw InvalidTransition(expected.ToString());
    }

    private InvalidOperationException InvalidTransition(string target) =>
        new($"Invalid job state transition: {Status} → {target}");
}