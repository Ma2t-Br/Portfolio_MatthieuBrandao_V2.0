namespace Core.models;

using System;
using System.Collections.Generic;

public sealed class SourceCodeAudit
{
    public string ClassName { get; }
    public string VulnerabilityType { get; }
    public bool IssueFound { get; }
    public int RiskScore { get; }
    public string DetailedAnalysis { get; }
    public string Remediation { get; }
    public IReadOnlyList<AffectedFile> AffectedFiles { get; }

    public SourceCodeAudit(
        string className,
        string vulnerabilityType,
        bool issueFound,
        int riskScore,
        string detailedAnalysis,
        string remediation,
        IReadOnlyList<AffectedFile>? affectedFiles = null)
    {
        ClassName = className;
        VulnerabilityType = vulnerabilityType;
        IssueFound = issueFound;
        RiskScore = riskScore;
        DetailedAnalysis = detailedAnalysis;
        Remediation = remediation;
        AffectedFiles = affectedFiles ?? Array.Empty<AffectedFile>();
    }
}

public sealed class AffectedFile
{
    public string FilePath { get; }
    public int? StartLine { get; }
    public int? EndLine { get; }
    public string? CodeSnippet { get; }

    public AffectedFile(string filePath, int? startLine, int? endLine, string? codeSnippet)
    {
        FilePath = filePath;
        StartLine = startLine;
        EndLine = endLine;
        CodeSnippet = codeSnippet;
    }
}
