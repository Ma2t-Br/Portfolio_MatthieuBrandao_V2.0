﻿namespace Core.models;

public enum JobStatus
{
    Created,
    Queued,
    Running,
    Retrying,
    Completed,
    Canceled,
    Failed
}