﻿using Core.contracts;

namespace Core.broker;

using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

public interface IJobQueue
{
    Task PublishAsync(
        string queue,
        JobEnvelope envelope,
        CancellationToken stoppingToken = default
    );

    IAsyncEnumerable<JobEnvelope> ConsumeAsync(
        string queue,
        CancellationToken stoppingToken = default
    );
    
    Task AcknowledgeAsync(
        JobEnvelope envelope,
        CancellationToken stoppingToken = default
    );
    
    Task RetryAsync(
        JobEnvelope envelope,
        CancellationToken stoppingToken = default
    );

    Task PublishToDlqAsync(
        JobEnvelope envelope,
        string reason,
        CancellationToken stoppingToken = default
    );
}