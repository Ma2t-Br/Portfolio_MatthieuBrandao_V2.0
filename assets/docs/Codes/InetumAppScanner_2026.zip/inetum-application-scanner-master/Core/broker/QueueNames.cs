﻿namespace Core.broker;

public static class QueueNames
{
    public const string Jobs = "jobs";
    public const string Retry = "jobs.retry";
    public const string DeadLetter = "jobs.dlq";
}