﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Core.contracts;
using Core.models;
using Core.repositories;

namespace Core.broker.implementations;

public sealed class JobDispatcher : IJobDispatcher
{
    private readonly IJobRepository _jobRepository;
    private readonly IJobQueue _queue;

    public JobDispatcher(
        IJobRepository jobRepository,
        IJobQueue queue)
    {
        _jobRepository = jobRepository;
        _queue = queue;
    }

    public async Task<Job> DispatchAsync(JobMessage message, CancellationToken stoppingToken = default)
    {
        var job = await _jobRepository.GetAsync(message.JobId, stoppingToken)
                  ?? throw new InvalidOperationException("Job not found");

        if (job.Status != JobStatus.Created)
            throw new InvalidOperationException(
                $"Job {job.Id} cannot be dispatched from state {job.Status}");

        job.MarkQueued();
        await _jobRepository.SaveAsync(job, stoppingToken);

        await _queue.PublishAsync(
            QueueNames.Jobs,
            new JobEnvelope
            {
                Message = message,
                Attempt = 1
            },
            stoppingToken);
        
        return job;
    }
}