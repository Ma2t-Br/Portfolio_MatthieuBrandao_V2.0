﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using Core.contracts;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace Core.broker.implementations;

public class RabbitMqJobQueue : IJobQueue, IDisposable
{
    private const string DeathHeader = "x-death";
    private const string CountKey = "count";
    private const string FailureReasonHeader = "failure-reason";

    private readonly IModel _channel;

    public RabbitMqJobQueue(
        IConnection connection,
        RetryPolicy retryPolicy)
    {
        _channel = connection.CreateModel();
        DeclareQueues(retryPolicy);
    }

    // ---------------------------------------------------------------------
    // QUEUE TOPOLOGY
    // ---------------------------------------------------------------------

    private void DeclareQueues(RetryPolicy retryPolicy)
    {
        // Dead Letter Queue (explicit publish ONLY)
        _channel.QueueDeclare(
            queue: QueueNames.DeadLetter,
            durable: true,
            exclusive: false,
            autoDelete: false
        );

        // Retry queue (TTL → Jobs)
        _channel.QueueDeclare(
            queue: QueueNames.Retry,
            durable: true,
            exclusive: false,
            autoDelete: false,
            arguments: new Dictionary<string, object>
            {
                ["x-message-ttl"] = (int)retryPolicy.Delay.TotalMilliseconds,
                ["x-dead-letter-exchange"] = "",
                ["x-dead-letter-routing-key"] = QueueNames.Jobs
            }
        );

        // Main Jobs queue (DLX → Retry ONLY)
        _channel.QueueDeclare(
            queue: QueueNames.Jobs,
            durable: true,
            exclusive: false,
            autoDelete: false,
            arguments: new Dictionary<string, object>
            {
                ["x-dead-letter-exchange"] = "",
                ["x-dead-letter-routing-key"] = QueueNames.Retry
            }
        );
    }

    // ---------------------------------------------------------------------
    // PUBLISH
    // ---------------------------------------------------------------------

    public Task PublishAsync(string queue, JobEnvelope envelope, CancellationToken stoppingToken = default)
    {
        if (stoppingToken.IsCancellationRequested)
            return Task.CompletedTask;
        
        var body = Encoding.UTF8.GetBytes(
            JsonSerializer.Serialize(envelope)
        );

        var props = _channel.CreateBasicProperties();
        props.Persistent = true;

        _channel.BasicPublish(
            exchange: "",
            routingKey: queue,
            basicProperties: props,
            body: body
        );

        return Task.CompletedTask;
    }

    // ---------------------------------------------------------------------
    // CONSUME
    // ---------------------------------------------------------------------

    public async IAsyncEnumerable<JobEnvelope> ConsumeAsync(
        string queue,
        [EnumeratorCancellation] CancellationToken stoppingToken = default)
    {
        var buffer = Channel.CreateUnbounded<JobEnvelope>();

        var consumer = new AsyncEventingBasicConsumer(_channel);

        consumer.Received += async (_, args) =>
        {
            try
            {
                var json = Encoding.UTF8.GetString(args.Body.ToArray());
                var envelope = JsonSerializer.Deserialize<JobEnvelope>(json)!;

                envelope.Attempt = ReadAttemptFromXDeath(args.BasicProperties.Headers);
                envelope.DeliveryTag = args.DeliveryTag;

                await buffer.Writer.WriteAsync(envelope, stoppingToken);
            }
            catch
            {
                _channel.BasicReject(args.DeliveryTag, requeue: false);
            }
        };

        _channel.BasicConsume(
            queue: queue,
            autoAck: false,
            consumer: consumer
        );

        await foreach (var item in buffer.Reader.ReadAllAsync(stoppingToken))
        {
            yield return item;
        }
    }

    // ---------------------------------------------------------------------
    // ACK / RETRY / DLQ
    // ---------------------------------------------------------------------

    public Task AcknowledgeAsync(
        JobEnvelope envelope,
        CancellationToken stoppingToken = default)
    {
        if (stoppingToken.IsCancellationRequested)
            return Task.CompletedTask;

        if (envelope.DeliveryTag.HasValue)
        {
            _channel.BasicAck(envelope.DeliveryTag.Value, multiple: false);
        }

        return Task.CompletedTask;
    }

    /// <summary>
    /// Failure → Retry queue (via DLX)
    /// </summary>
    public Task RetryAsync(
        JobEnvelope envelope,
        CancellationToken stoppingToken = default)
    {
        if (stoppingToken.IsCancellationRequested)
            return Task.CompletedTask;

        if (envelope.DeliveryTag.HasValue)
        {
            _channel.BasicNack(
                envelope.DeliveryTag.Value,
                multiple: false,
                requeue: false
            );
        }

        return Task.CompletedTask;
    }

    /// <summary>
    /// Final failure → DLQ (explicit publish)
    /// </summary>
    public Task PublishToDlqAsync(
        JobEnvelope envelope,
        string reason,
        CancellationToken stoppingToken = default)
    {
        if (stoppingToken.IsCancellationRequested)
            return Task.CompletedTask;

        var body = Encoding.UTF8.GetBytes(
            JsonSerializer.Serialize(envelope)
        );

        var props = _channel.CreateBasicProperties();
        props.Persistent = true;
        props.Headers = new Dictionary<string, object>
        {
            [FailureReasonHeader] = reason
        };

        _channel.BasicPublish(
            exchange: "",
            routingKey: QueueNames.DeadLetter,
            basicProperties: props,
            body: body
        );

        if (envelope.DeliveryTag.HasValue)
        {
            _channel.BasicAck(envelope.DeliveryTag.Value, multiple: false);
        }

        return Task.CompletedTask;
    }

    // ---------------------------------------------------------------------
    // x-death PARSING
    // ---------------------------------------------------------------------

    private int ReadAttemptFromXDeath(IDictionary<string, object>? headers)
    {
        if (headers == null)
            return 0;

        if (!headers.TryGetValue(DeathHeader, out var xDeathObj))
            return 0;

        if (xDeathObj is not IList<object> deaths)
            return 0;

        foreach (var deathEntry in deaths)
        {
            if (deathEntry is not IDictionary<string, object> death)
                continue;

            if (death.TryGetValue(CountKey, out var count))
            {
                return count switch
                {
                    byte b => b,
                    short s => s,
                    int i => i,
                    long l => (int)l,
                    _ => 0
                };
            }
        }

        return 0;
    }

    // ---------------------------------------------------------------------
    // DISPOSE
    // ---------------------------------------------------------------------

    public void Dispose()
    {
        _channel.Close();
        _channel.Dispose();
    }
}