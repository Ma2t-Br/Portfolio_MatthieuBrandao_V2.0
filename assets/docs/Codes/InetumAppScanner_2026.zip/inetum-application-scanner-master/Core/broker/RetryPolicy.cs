﻿namespace Core.broker;

using System;

public sealed class RetryPolicy
{
    public int MaxAttempts { get; init; } = 3;

    public int DelaySeconds { get; init; } = 5;

    public TimeSpan Delay => TimeSpan.FromSeconds(DelaySeconds);

    public void Validate()
    {
        if (MaxAttempts < 1)
            throw new InvalidOperationException(
                "RetryPolicy.MaxAttempts must be >= 1");

        if (DelaySeconds < 1)
            throw new InvalidOperationException(
                "RetryPolicy.DelaySeconds must be >= 1");
    }
}