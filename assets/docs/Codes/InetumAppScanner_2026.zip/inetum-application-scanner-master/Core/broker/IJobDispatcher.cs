﻿using System.Threading;
using Core.models;

namespace Core.broker;

using System.Threading.Tasks;
using contracts;

public interface IJobDispatcher
{
    Task<Job> DispatchAsync(JobMessage message, CancellationToken cancellationToken);
}