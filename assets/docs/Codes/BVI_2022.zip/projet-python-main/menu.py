"""---------------------------------------------------------------------------------------------------------------------
Projet Python (Semestre 1) : Système de recommandation de livres

Auteurs : Matthieu BRANDAO, Alexandre BAUDIN, Anthony CAO

/ menu.py : Programme secondaire; en charge d'afficher le menu principal, de récupérer
            les entrées et de les renvoyer à main.py
---------------------------------------------------------------------------------------------------------------------"""


from function import HORIZONTAL_LINE, PrintInfo, ChoiceInput


def menu(functionality_index: int = None) -> tuple[int, int]:
    """
    Fonction du menu.

    Retourne comme indice d'opération -1 si ladite opération est un retour au menu prinipal.

    :param functionality_index: L'indice de la fonctionnalité/partie du programme.
    :return: Un tuple : l'indice de la partie du programme, l'indice de l'opération (ou -1)
    """

    infolist = [
        ["Gestion du profil des lecteurs", "Gestion du dépôt de livres", "Recommandations de livres"],
        ["Ajouter un lecteur", "Afficher un lecteur", "Modifier un lecteur", "Supprimer un lecteur",
         "Retour"],
        ["Afficher la liste des livres dans le dépôt", "Ajouter un livre au dépôt",
         "Modifier le titre d’un livre dans le dépôt", "Supprimer un livre du dépôt", "Retour"],
        ["Noter un livre", "Suggérer des livres", "Retour"]]

    if functionality_index is None:
        functionality_index = ChoiceInput(inf=1, sup=len(PrintInfo(infolist[0])),
                                          message_input="À quelle fonctionnalité voulez-vous accéder ? Numéro :")
        print(HORIZONTAL_LINE)

    operation = ChoiceInput(inf=1, sup=len(PrintInfo(infolist[functionality_index])),
                            message_input="Quelle opération voulez-vous effectuer ? Numéro :")

    if operation == len(infolist[functionality_index]):
        operation = -1
    return functionality_index, operation
