
                                           L1 - Programmation en Python

------------------------------------------------------------------------------------------------------------------------
                         Projet Python (Semestre 1) : Système de recommandation de livres
------------------------------------------------------------------------------------------------------------------------

Réalisé par :   Alexandre BAUDIN
                Matthieu BRANDAO
                Anthony CAO

-------------------------------------

Liste des programmes :
    - main.py
        "Est utilisé au démarrage. Permet de faire appel, après
         la saisie des options dans les menus, aux fichiers et
         fonctions concernées."
    - menu.py
        "Est utilisé après l'appel de main. Permet d'afficher
         les menus et de récupérer les saisies pour les renvoyer
         à main."
    - function.py
        "Est utilisé par tous les programmes. Répertorie l'ensemble
         des fonctions utiles."
    - profile.py
        "Est utilisé lors d'actions sur les profiles. Répertorie
         l'ensemble des actions possible sur les profils."
    - depot.py
        "Est utilisé lors d'actions sur le dépôt de livres. Répertorie
         l'ensemble des actions possible sur le dépôt.""
    - recommendations.py
        "Est utilisé pour les actions de notation et de recommandations de livres."

Instructions nécessaires à l'exécution :
    (IMPORTANT !!!) En utilisant Python 3.10 minimum,
    - Lancer le programme main.py.
    - Suivre les instructions dans la console.
        - Si au moment de la saisie est demandé un "numéro" ou "indice" :
            → Entrer le nombre correspondant à la saisie voulue
        - Sinon :
            → Entrer une chaine de caractères

Chemins précis pour chaque action :
    ([a:b] : un entier entre a et b tous deux inclus
    *Nom* : une chaine de caractères correspondant à Nom)

    - Profil
        - Ajouter un lecteur : 1 / 1 / *PseudonymeDuLecteur* / [1:3] / [1:3] / [1:7] / [1:10] / [*NumérosDesLivresLus*]
        - Afficher un lecteur : 1 / 2 / *PseudonymeDuLecteur*
        - Modifier un lecteur : 1 / 3 / *PseudonymeDuLecteur* / [1:5]
        - Supprimer un lecteur : 1 / 4 / *PseudonymeDuLecteur*
    - Dépôt
        - Afficher la liste du dépôt : 2 / 1
        - Ajouter un livre au dépôt : 2 / 2 / *TitreDuNouveauLivre*
        - Modifier le titre d'un livre dans le dépôt : 2 / 3 / *TitreDuLivre* / *NouveauTitreDuLivre*
        - Supprimer un livre du dépôt : 2 / 4 / *TitreDuLivre*
    - Recommandations
        - Noter un livre : 3 / 1 / *PseudonymeDuLecteur* / [*NuméroDuLivreÀNoter*] / [1:5]
        - Suggérer des livres : 3 / 2 / *PseudonymeDuLecteur*
