"""---------------------------------------------------------------------------------------------------------------------
Projet Python (Semestre 1) : Système de recommandation de livres

Auteurs : Matthieu BRANDAO, Alexandre BAUDIN, Anthony CAO

/ profile.py : Programme secondaire ; En charge de répertorier les fonctions utiles pour les fonctionnalités
                en rapport avec la gestion de profils.
---------------------------------------------------------------------------------------------------------------------"""


from function import *

__all__ = [
    'addNewReader',
    'printReader',
    'modifyReader',
    'removeReader',
]  # On évite d'exporter _CARA_PRINTS et _readBooksLine

_CARA_PRINTS: list[list[str]] = [
    ["Homme", "Femme", "Autre"],
    ["A moins de 18 ans", "A entre 18 et 25 ans", "A plus de 25 ans"],
    ["Science-fiction", "Biographie", "Horreur", "Romance", "Fable", "Histoire", "Comédie"]
]


def _readBooksLine(pseudo: str) -> list[str]:
    """
    Fonction interne d'addNewReader() et de modifyReader().

    Obtient une liste des indices de livres données par l'utilisateur.

    :param pseudo: Nom de l'utilisateur
    :return: La ligne à écrire sous forme de liste (à concacténer).
    """

    with open("BdD/books.txt", 'r', encoding='utf-8') as books:  # Remplissage des livres lus
        booklist = FileList(books.read())

    booksnb = ChoiceInput(inf=0, sup=len(PrintInfo(booklist)),
                          message_input="Combien de livres avez-vous lu ? Nombre :")  # demande du nombre de livres

    writebooks = []
    for i in range(booksnb):  # Remplissage des données
        bookinput = ChoiceInput(inf=1, sup=len(booklist), message_input=f"Numéro du livre ({i + 1}/{booksnb}) :")
        while bookinput in writebooks:
            print("Livre déjà entré, veuillez en choisir un autre.", end=" ")
            bookinput = ChoiceInput(1, len(booklist), message_input=f"Numéro du livre ({i + 1}/{booksnb}) :")

        writebooks = sorted(ConvertValues(iterable=writebooks + [bookinput], convert_type="int"))
    print(f"Livres entrés : {', '.join(ConvertValues(iterable=writebooks, convert_type='str'))}")

    return [pseudo] + ConvertValues(iterable=writebooks, convert_type="str")


def addNewReader() -> None:
    """
    Ajoute un nouveau lecteur.

    :return: Rien, car la fonction n'a pas été prévue pour être réutilisée en dehors du fichier principal.
    """

    message_outputs = ["Entrez votre genre:", "Entrez votre tranche d'âge:",
                       "Entrez votre style de lecture:"]

    with open("BdD/readers.txt", "r+", encoding='utf-8') as readers:  # r+ est le mode read + update
        # cela permet de lire le fichier et d'écrire à la fin

        pseudo = ConditionalInput(file_iterable=FileDict(filecontent=readers.read()),
                                  input_type="pseudo", newinput=True)

        profileinfos = [pseudo]
        for index, cara_element in enumerate(_CARA_PRINTS):
            profileinfos += [str(ChoiceInput(inf=1, sup=len(PrintInfo(cara_element)),
                                             message_input=message_outputs[index]))]
            print(HORIZONTAL_LINE)

        # ajout du lecteur dans readers et booksread
        readers.write(f"\n{','.join(profileinfos)}")
    with open("BdD/booksread.txt", "a", encoding='utf-8') as booksread:
        booksread.write("\n" + ",".join(_readBooksLine(pseudo)))

    return print(f'Votre profil a été créé. Bienvenue, "{pseudo}" !')


def printReader(name: str = None) -> tuple[str, list[str]]:
    """
    Affiche les informations d'un lecteur.

    :param name: Pseudonyme du lecteur, demandé si non présent.
    :return: Un tuple : le pseudonyme, une liste de ses caractéristiques sous forme d'indices (en str).
    """

    with open("BdD/readers.txt", "r", encoding='utf-8') as r, \
            open("BdD/booksread.txt", "r", encoding='utf-8') as br, \
            open("BdD/books.txt", "r", encoding='utf-8') as b:
        rdict, brdict, blist = FileDict(filecontent=r.read()), FileDict(filecontent=br.read()), FileList(b.read())

    if name is None or name not in rdict:  # Demande d'entrer un nom si aucun n'est donné
        name = ConditionalInput(file_iterable=rdict, input_type="pseudo", newinput=False)
    readbooks = ConvertValues(iterable=brdict[name], convert_type="int")  # readbooks correspond aux livres lus
    r_cara = rdict[name]  # Récupère les informations personnelles du lecteur
    print("""Le lecteur "{pseudo}" :
- Est de genre {infos[0]} ;
- {infos[1]} ;
- Aime lire des livres de {infos[2]} ;
""".format(pseudo=name, infos=[_CARA_PRINTS[i][int(r_cara[i]) - 1] for i in range(3)]))
    print("A lu : ")
    if len(readbooks) != 0:
        print("\n".join([f"- {blist[bookindex - 1]}" for bookindex in sorted(readbooks)]))
    else:
        print("rien pour l'instant...")

    print("Notes :\n" + "\n".join(
        [f"{blist[i]} - {note}/5" for i, note in enumerate(FetchNotationMatrix()[name]) if note != 0]
    ))  # affichage selon les notes de name

    return name, r_cara  # Retourne les informations personnelles du lecteur, name: pseudo du lecteur,
    # r_cara: liste des caractéristiques du lecteur, exemple :
    # la ligne correspondant au lecteur est "Xavier,1,2,3", name = "Xavier", r_cara = ["1", "2", "3"]


def modifyReader() -> None:
    """
    Modifie un lecteur.

    :return: Rien, car la fonction n'a pas été prévue pour être réutilisée en dehors du fichier principal.
    """

    def rewriteFile(to_write: list, key: str, file: str) -> None:
        """
        Supprime une ligne d'un fichier à l'aide d'une clé et la remplace par une autre ligne
        à l'aide de son 1er élément.

        :param to_write: Liste contenant les informations à modifier
        :param key: Clé permettant de retrouver la valeur à remplacer
        :param file: Fichier à modifier
        :return: Rien, car c'est une fonction interne et une écriture, cela ne récupère pas de valeur
        """

        with open(file, 'r', encoding='utf-8') as readfile:
            file_dict = FileDict(filecontent=readfile.read())

        del file_dict[key]  # suppression de l'entrée
        file_dict[to_write[0]] = to_write[1:]  # ajout des informations modifiées
        with open(file, "w") as newfile:
            newfile.write(JoinWriteFileDict(file_dict))  # réécriture du fichier
        return

    cara_list: list[str] = ["Nom", "Genre", "Âge", "Style de lecture", "Livres lus"]

    readerkey, readerinfos = printReader()  # Récupère les informations personnelles du lecteur
    print(HORIZONTAL_LINE)

    element_index_to_modify = ChoiceInput(inf=1, sup=len(PrintInfo(cara_list)),
                                          message_input="Quelle information voulez-vous modifier ? Numéro :")
    # Récupère l'information à modifier sous forme d'indice

    if element_index_to_modify == 1:  # Si l'information est le pseudonyme
        with open("BdD/readers.txt", 'r', encoding='utf-8') as readersfile, \
                open("BdD/booksread.txt", 'r', encoding='utf-8') as brfile:
            readerscontent = readersfile.read()
            name = ConditionalInput(file_iterable=FileDict(filecontent=readerscontent),
                                    input_type="pseudo", newinput=True)
            written_files = {"readers": [name] + readerinfos, "booksread": [name] + FileDict(brfile.read())[readerkey]}

        notation_matrix = FetchNotationMatrix()  # modification de la clé dans la matrice de notation
        notation_matrix[name] = notation_matrix[readerkey]
        del notation_matrix[readerkey]
        UpdateNotationMatrix(notation_matrix)

    elif element_index_to_modify == len(cara_list):  # Si l'information est la liste des livres lus
        written_files = {"booksread": _readBooksLine(pseudo=readerkey)}

    else:  # Modifie l'information personnelle sélectionnée
        element_index_to_modify -= 2
        # element_index_to_modify -> 1: pseudo, 2-...: infos
        # vers 0-...: infos

        readerinfos[element_index_to_modify] = str(ChoiceInput(
            inf=1, sup=len(PrintInfo(_CARA_PRINTS[element_index_to_modify])),
            message_input=f"Entrer la nouvelle valeur pour votre {cara_list[1:][element_index_to_modify]} :")
        )
        written_files = {"readers": [readerkey] + readerinfos}

    for filename, writeline in written_files.items():
        rewriteFile(to_write=writeline, key=readerkey, file=f"BdD/{filename}.txt")

    return print("Votre profil a été modifié !")


def removeReader() -> None:
    """
    Supprime un lecteur.

    :return: Rien, car la fonction n'a pas été prévue pour être réutilisée en dehors du fichier principal.
    """

    with open("BdD/readers.txt", 'r', encoding='utf-8') as r, open("BdD/booksread.txt", 'r', encoding='utf-8') as br:
        readersdict = FileDict(filecontent=r.read())
        brdict = FileDict(filecontent=br.read())
    pseudo = ConditionalInput(file_iterable=readersdict, input_type="pseudo", newinput=False)

    del readersdict[pseudo]  # suppressions
    del brdict[pseudo]

    with open("BdD/readers.txt", "w", encoding='utf-8') as rw, open("BdD/booksread.txt", "w", encoding='utf-8') as brw:
        rw.write(JoinWriteFileDict(filedict=readersdict))
        brw.write(JoinWriteFileDict(filedict=brdict))

    return print(f'Le profil de "{pseudo}" a été supprimé !')
