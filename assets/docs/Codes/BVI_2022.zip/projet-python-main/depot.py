"""---------------------------------------------------------------------------------------------------------------------
Projet Python (Semestre 1) : Système de recommandation de livres

Auteurs : Matthieu BRANDAO, Alexandre BAUDIN, Anthony CAO

/ depot.py : Programme secondaire ; En charge de répertorier les fonctions utiles pour les fonctionnalités
                en rapport avec la gestion du dépot de livres.
---------------------------------------------------------------------------------------------------------------------"""


from function import *


def printBookList() -> list[str]:
    """
    Affiche tous les titres des livres du dépôt.

    :return: Une liste du titre des livres.
    """

    with open("BdD/books.txt", 'r', encoding='utf-8') as b:
        return PrintInfo(FileList(b.read()))


def addNewBook() -> None:
    """
    Ajoute un nouveau livre.

    :return: Rien, car la fonction n'a pas été prévue pour être réutilisée en dehors du fichier principal.
    """

    with open("BdD/books.txt", "r+", encoding='utf-8') as b:
        # fichier à la fois de type read : le contenu initial peut être lu (sans les nouvelles écritures)
        # et de caractéristique update : les opérations d'écriture écrivent à la fin du fichier (comme append)
        writtentitle = ConditionalInput(file_iterable=FileList(b.read()), input_type="book", newinput=True)
        b.write("\n" + writtentitle)

    return print("Votre livre a été ajouté au dépôt !")


def modifyBook() -> None:
    """
    Modifie le titre d'un livre déjà présent dans le dépôt.

    :return: Rien, car la fonction n'a pas été prévue pour être réutilisée en dehors du fichier principal.
    """

    bookslist = printBookList()
    titleindex = ChoiceInput(inf=1, sup=len(bookslist),
                             message_input="Quel livre voulez-vous modifier ? Numéro :") - 1  # bookslist débute à 0
    print(HORIZONTAL_LINE)

    booktitle = bookslist[titleindex]  # ancien titre
    bookslist[titleindex] = ConditionalInput(file_iterable=bookslist, input_type="book", newinput=True)
    with open("BdD/books.txt", 'w', encoding='utf-8') as booksfile:
        booksfile.write("\n".join(bookslist))

    return print(f'Anciennement {booktitle},\nle nouveau titre du livre est "{bookslist[titleindex]}" !')


def removeBook() -> None:
    """
    Supprime un livre du dépôt.

    :return: Rien, car la fonction n'a pas été prévue pour être réutilisée en dehors du fichier principal.
    """

    bookslist = printBookList()
    bookindex_to_remove = ChoiceInput(inf=1, sup=len(bookslist),
                                      message_input="Quel livre voulez-vous retirer ? Numéro :")
    # La liste affichée commence par 1 (non pas par 0, ce qui est le cas dans les BdD) !

    bookslist.remove(bookslist[bookindex_to_remove - 1])

    # Il faut aussi adapter les indices des livres lus :
    # retirer l'indice du livre supprimé dans chaque ligne (si présent)
    # et réduire ceux plus grands que l'indice dudit livre
    with open("BdD/booksread.txt", 'r', encoding='utf-8') as br:
        content = FileDict(br.read())
    for pseudo, infos in content.items():
        if str(bookindex_to_remove) in infos:
            infos.remove(str(bookindex_to_remove))  # suppression de l'indice du livre supprimé
        for i, number in enumerate(infos):
            int_number = int(number)
            if bookindex_to_remove < int_number:  # si l'indice est plus grand que celui supprimé
                infos[i] = str(int_number - 1)

    with open("BdD/books.txt", "w", encoding='utf-8') as bfile, open("BdD/booksread.txt", 'w', encoding='utf-8') as brw:
        bfile.write("\n".join(bookslist))
        brw.write(JoinWriteFileDict(filedict=content))

    notation_matrix = FetchNotationMatrix()  # suppression des notes du livre supprimé
    for listrates in notation_matrix.values():
        del listrates[bookindex_to_remove - 1]
    UpdateNotationMatrix(notation_matrix)

    return print("Le livre a été supprimé !")
