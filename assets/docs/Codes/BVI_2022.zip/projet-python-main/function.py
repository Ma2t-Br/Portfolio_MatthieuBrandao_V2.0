"""---------------------------------------------------------------------------------------------------------------------
Projet Python (Semestre 1) : Système de recommandation de livres

Auteurs : Matthieu BRANDAO, Alexandre BAUDIN, Anthony CAO

/ function.py : Programme secondaire ; En charge de répertorier les fonctions utiles aux programmes.
---------------------------------------------------------------------------------------------------------------------"""


import os

HORIZONTAL_LINE = "\n" + "_" * 30 + "\n"
INLINE_SEPERATOR = ","


def removeFilesBlankLines() -> None:
    """
    Récupère tous les fichiers du dossier BdD et y supprime toutes les lignes vides.

    :return: Rien, car cela n'a pas pour objectif de récupérer de valeur, mais de modifier des fichiers.
    """

    with os.scandir('./BdD') as folder:
        files_name = [entry.path for entry in folder if entry.is_file() and entry.name.lower().endswith('.txt')]
        # si l'entrée est un fichier et que son nom finit par .txt

    for filename in files_name:
        with open(filename, 'r', encoding='utf-8') as f:
            content = f.read()
        if "" in content:  # on ne réécrit pas le fichier si non nécessaire
            content = [line for line in content.split("\n") if line != ""]
            with open(filename, 'w', encoding='utf-8') as fwrite:
                fwrite.write("\n".join(content))
    return


def ConvertValues(iterable: list[int | str] | dict[str, list[int | str]], convert_type: str) \
        -> list[int | str] | dict[str, list[int | str]]:
    """
    Convertit les valeurs d'un itérable en str ou en int.

    :param iterable: L'itérable initial à convertir.
    :param convert_type: Le type en lequel les valeurs seront converties ("int" ou "str")
    :return: L'itérable converti.
    """

    if convert_type not in ["int", "str"]:  # dans le cas où le type mentionné n'est pas supporté
        raise ValueError("The convert_type argument value is not 'int' or 'str'")
    if isinstance(iterable, list):
        if convert_type == "str":
            return [str(el) for el in iterable]
        else:  # convert_type vers int
            return [int(el) for el in iterable]

    temp_iterable = [(key, val) for key, val in iterable.items()]
    if convert_type == "str":
        return {key: [str(el) for el in value_list] for key, value_list in temp_iterable}
    return {key: [int(el) for el in value_list] for key, value_list in temp_iterable}


def SafeIntInput(message: str, error_message: str = "Entrée invalide.") -> int:
    """
    Retourne un entier à l'aide d'une demande sécurisée.

    :param message: Message affiché pour chaque demande
    :param error_message: Affiché lorsqu'une erreur de conversion apparait
    :return: L'entier.
    """

    try:
        return int(input(f"{message} "))  # espace après l'affichage du message
    except ValueError:  # est exécuté lorsque l'input ne peut pas être converti en un entier
        print(error_message, end=" ")
        return SafeIntInput(message, error_message)


def ChoiceInput(inf: int, sup: int, message_input: str) -> int:
    """
    Obtient un entier entre deux bornes.

    :param inf: Borne inférieure, entrée redemandée si celle-ci est plus petite qu'elle
    :param sup: Borne supérieure, entrée redemandée si plus grande
    :param message_input: Message affiché à chaque demandée de réponse à l'utilisateur
    :return: Le choix de l'utilisateur sous forme d'entier.
    """

    choice = SafeIntInput(message=message_input)
    while inf > choice or choice > sup:
        print("Entrée invalide.", end=" ")
        choice = SafeIntInput(message=message_input)
    return choice


def SafeifyStr(string: str, filtered: list[str] = None) -> str:
    """
    Supprime tous les caractères dangereux d'un word.

    :param string: Le word à filtrer, non modifié (par défaut "\\n" et ",")
    :param filtered: Une liste des caractères à supprimer.
    :return: Le mot filtré.
    """

    if filtered is None:
        filtered = ['\\n', ',']
    for sep in filtered:
        string: str = "".join(string.split(sep))
    return string


def PrintInfo(printlist: list) -> list:
    """
    Affiche une liste de :
    1- {printlist[0]}
    2- {printlist[1]}
    ...

    :param printlist: La liste utilisée pour afficher l'ensemble des informations.
    :return: printlist elle-même (ce qui a été mis en argument).
    """

    print("\n".join(
        [f"{i + 1}- {choix}" for i, choix in enumerate(printlist)])
          + "\n")
    return printlist


def FileList(filecontent: str) -> list[str]:
    """
    Retourne une liste à partir du contenu d'un fichier lu.

    :param filecontent: Contenu du fichier. Attention, pas le fichier en lui-même !
    :return: Une liste de str.
    """

    return filecontent.split("\n")


def FileDict(filecontent: str, inlineseparator: str = INLINE_SEPERATOR) -> dict[str, list[str]]:
    """
    Crée un dictionnaire {1re occurrence: le reste} à partir du contenu d'un fichier.

    :param filecontent: Contenu du fichier.
    :param inlineseparator: Le séparateur de chaque ligne (par défaut la constante).
    :return: Le dictionnaire, ayant pour clés la 1re occurrence de chaque ligne et pour valeurs le reste de chacun.
    """

    temp_dict = {el[0]: el[1:] for el in [line.split(inlineseparator) for line in filecontent.split("\n")]}
    for key, el in temp_dict.items():
        if el == [""]:
            temp_dict[key] = []
    return temp_dict


def JoinWriteFileDict(filedict: dict[str, list[str]], inlinejoin: str = INLINE_SEPERATOR) -> str:
    """
    Crée un str à partir d'un dict, prêt à l'écriture sur un fichier.

    Cela écrit aussi les retours à la ligne entre chaque ligne.

    :param filedict: Le dict, de préférence obtenu par la fonction FileDict.
    :param inlinejoin: Str de concacténation, placé entre chaque élément dans chacune des lignes.
    :return: Le str.
    """

    return "\n".join([f'{reader}{inlinejoin.join([""] + infos)}' for reader, infos in filedict.items()])


def WordIndex(word: str, file_iterable: list[str] | dict[str]) -> int | str:
    """
    Retourne la clé de la 1re occurrence d'un mot d'une liste ou d'un dict.

    L'absence du mot dans l'itérable est prise en compte et retournera -1.

    :param word: Le mot recherché.
    :param file_iterable: Non modifié (obtenue de préférence par la fonction FileList ou FileDict)
    :return: La clé (int pour une liste, str pour un dict) ; -1 si elle n'est pas trouvée
    """

    if isinstance(file_iterable, list):
        for i, line in enumerate(file_iterable):
            if word == line:
                return i  # indice correspondant
    elif isinstance(file_iterable, dict):
        for line in file_iterable:
            if word == line:
                return line  # clé correspondante
    return -1  # élément non retrouvé ou type d'instance non prise en charge


def ConditionalInput(file_iterable: list[str] | dict[str, list], input_type: str, newinput: bool = False) -> str:
    """
    Obtient une entrée (non vide) existante ou nouvelle de pseudonyme/livre

    :param file_iterable: Non modifiée, de préférence obtenue par FileList().
    :param input_type: Type d'entrée : "pseudo" ou "book".
    :param newinput: Ne retourne qu'une entrée nouvelle.
    :return: L'entrée, après avoir tenu compte des conditions.
    """

    prints = filtered = None
    if input_type == "pseudo":
        prints, filtered = ["Pseudonyme", "pseudo"], None
    elif input_type == "book":
        filtered = ['\\n']
        if not newinput:
            prints = ["Numéro de livre", "numéro"]
        else:
            prints = ["Titre de livre", "titre"]

    testedinput: str = SafeifyStr(input(f"{prints[0]} : "), filtered)
    conditions: list[bool, bool] = []
    if testedinput != "":
        wordindex = WordIndex(testedinput, file_iterable)
        conditions = [newinput and wordindex != -1, not newinput and not (wordindex != -1)]
        # [nouvel_input dans file_iterable ?, input_existant non retrouvé dans file_iterable ?]

    if testedinput == "" or True in conditions:
        if testedinput == "":
            print(f"Le {prints[1]} ne peut pas être vide.", end=" ")
        elif conditions[0]:  # nouvel_input dans file_iterable
            print(f'Le {prints[1]} "{testedinput}" existe déjà.', end=" ")
        else:
            print(f"""Le {prints[1]} "{testedinput}" n'est pas enregistré.""", end=" ")
        return ConditionalInput(file_iterable, input_type, newinput)
    print(f'{prints[0]} entré : "{testedinput}"', HORIZONTAL_LINE)
    return testedinput


def UpdateNotationMatrix(new_notation_matrix: dict[str, list[int]]) -> dict[str, list[int]]:
    """
    Permet d'écrire la matrice dans le fichier.

    :param new_notation_matrix: La nouvelle matrice de notation.
    :return: La nouvelle valeur de NotationMatrix.
    """

    with open("BdD/notation_matrix.txt", 'w', encoding='utf-8') as file:
        file.write(JoinWriteFileDict(ConvertValues(iterable=new_notation_matrix, convert_type="str"), inlinejoin=", "))
        # les valeurs de la matrice doivent être de type str
    return new_notation_matrix


def FetchNotationMatrix() -> dict[str, list[int]]:
    """
    Fonction permettant de récupérer la matrice de notation à partir du fichier.

    :return: Un dictionnaire associant 'pseudo' et liste des notes.
    """

    with open("BdD/notation_matrix.txt", 'r', encoding='utf-8') as matrix_file:
        content = matrix_file.read()
    return ConvertValues(iterable=FileDict(filecontent=content, inlineseparator=", "), convert_type="int")
