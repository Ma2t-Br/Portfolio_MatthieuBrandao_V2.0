"""---------------------------------------------------------------------------------------------------------------------
Projet Python (Semestre 1) : Système de recommandation de livres

Auteurs : Matthieu BRANDAO, Alexandre BAUDIN, Anthony CAO

/ recommendations.py : Programme secondaire ; En charge de répertorier les fonctions utiles pour les fonctionnalités
                        en rapport avec les recommandations.
---------------------------------------------------------------------------------------------------------------------"""


import time

from function import *

__all__ = [
    'rateBook',
    'recommendBooks',
    'fixNotationMatrix',
]  # On n'exporte pas les fonctions internes (qui commencent par un "_")


def fixNotationMatrix(readersdict: dict[str, list[str]] = None, bookslist: list[str] = None) -> dict[str, list[int]]:
    """
    Corrige les potentielles incohérences du fichier de la matrice de notation.

    Plus précisément, ces incohérences sont :
    l'absence du fichier,
    leurs absences des lecteurs dans la matrice ou leurs présences factices
    (lorsque les lecteurs sont dans la matrice, mais ne sont plus enregistrés) ;
    ainsi que le nombre de notes pour chaque ligne par rapport au nombre de livres.

    Cela supprime aussi les lignes vides de chaque fichier de la BdD.

    :param readersdict: Dict issu de readers.txt si possible
    :param bookslist: Liste issue de books.txt si possible
    :return: La matrice de notation.
    """

    removeFilesBlankLines()  # la suppression des lignes vides est nécessaire
    # pour éviter des erreurs lors des corrections de la matrice

    if readersdict is None:
        with open("BdD/readers.txt", 'r', encoding='utf-8') as readers:
            readersdict = FileDict(readers.read())  # il faut éviter de lire un fichier plusieurs fois
    if bookslist is None:
        with open("BdD/books.txt", 'r', encoding='utf-8') as books:
            bookslist = FileList(books.read())

    try:
        notation_matrix = FetchNotationMatrix()  # le fichier peut ne pas exister, cela retournera alors une erreur
        notationset, readersset = set(notation_matrix), set(readersdict)
        # cela permet de mieux comparer les listes

        for excess in notationset - readersset:  # lecteurs en trop
            del notation_matrix[excess]

        booknb = len(bookslist)
        for pseudo, ratelist in notation_matrix.items():
            difference = booknb - len(ratelist)
            if difference > 0:  # il manque des nombres
                notation_matrix[pseudo] += [0] * difference
            elif difference < 0:  # il y a excès
                notation_matrix[pseudo] = ratelist[:difference]

        for lacking in readersset - notationset:  # manquants
            notation_matrix[lacking] = [0] * booknb

        UpdateNotationMatrix(notation_matrix)
    except FileNotFoundError:  # le fichier n'a pas été trouvé, c'est-à-dire qu'il n'existe pas
        UpdateNotationMatrix({pseudo: [0 for _ in bookslist] for pseudo in readersdict})
        notation_matrix = FetchNotationMatrix()
        # la matrice de notation est créée de façon idéale
        # il ne sera alors pas nécessaire de vérifier la cohérence de la matrice par rapport aux éléments de la BdD

    return notation_matrix


def _initSimilarityMatrix() -> dict[str, dict[str, float]]:
    """
    Fonction interne permettant d'initialiser la matrice de similarité.

    :return: La matrice de similarité.
    """

    with open("BdD/readers.txt", 'r', encoding='utf-8') as rfile:
        rdict = FileDict(rfile.read())
    return {pseudo: {compared_user: 0 for compared_user in rdict} for pseudo in rdict}


SimilarityMatrix = _initSimilarityMatrix()


def _cosineSimilarity(first_line: list[int], second_line: list[int]) -> float:
    """
    Calcule la similarité cosinus pour deux lignes.
    
    :param first_line: 1re ligne, interchangable avec la 2de
    :param second_line: 2de ligne, interchangable
    :return: Le résultat du calcul
    """

    if first_line == second_line:  # ce sont les mêmes lignes
        return 1

    sum_num = sum_square1 = sum_square2 = 0
    for i, note1 in enumerate(first_line):
        sum_num += note1 * second_line[i]
        sum_square1 += note1 ** 2
        sum_square2 += second_line[i] ** 2

    if sum_square1 * sum_square2 == 0:
        return 0  # cela ne fonctionne pas pour les lignes vides
    return sum_num / ((sum_square1 ** 0.5) * (sum_square2 ** 0.5))


def _calculateSimilarityMatrix(notation_matrix: dict[str, list[int]]) -> dict[str, int]:
    """
    Met à jour la matrice de similarité et donne le temps de calcul de la matrice de similarité.

    :return: Le temps de calcul de la matrice sous forme de dict (minutes, secondes, millisecondes et microsecondes).
    """

    global SimilarityMatrix

    start_time = time.perf_counter_ns()

    SimilarityMatrix = _initSimilarityMatrix()  # réinitialisation
    for line in notation_matrix.items():
        pseudo, bookratings = line

        for line2 in notation_matrix.items():
            pseudo2, bookratings2 = line2

            SimilarityMatrix[pseudo][pseudo2] = _cosineSimilarity(bookratings, bookratings2)
    delta_time = (time.perf_counter_ns() - start_time) // 1000  # pas assez précis pour calculer les nanosecondes

    microseconds = delta_time % 1000
    milliseconds = delta_time // 1000 % 1000
    seconds = delta_time // 1000 ** 2 % 60
    minutes = delta_time // 1000 ** 2 * 60

    return {"minutes": minutes, "seconds": seconds, "milliseconds": milliseconds, "microseconds": microseconds}


def rateBook(notation_matrix: dict[str, list[int]], pseudo: str = None, book_index: int = None) -> None:
    """
    Un lecteur note un livre lu.

    :param notation_matrix: La matrice de notation, de préférence la plus à jour possible.
    :param pseudo: Le pseudonyme du lecteur, demandé si non présent.
    :param book_index: L'indice du livre à noter (indice minimal : 0), demandé si non présent.
    :return: Rien, la continuation du programme signifie que la fonction s'est correctement exécutée.
    """

    # on lit plusieurs fichiers en même temps
    with open("BdD/readers.txt", 'r', encoding='utf-8') as rfile, \
            open("BdD/books.txt", 'r', encoding='utf-8') as bfile, \
            open("BdD/booksread.txt", 'r', encoding='utf-8') as brfile:
        readersfiledict, brfiledict = FileDict(filecontent=rfile.read()), FileDict(filecontent=brfile.read())
        booklist = FileList(bfile.read())

    if pseudo is None or pseudo not in readersfiledict:
        pseudo = ConditionalInput(readersfiledict, input_type="pseudo", newinput=False)
    user_booksread = brfiledict[pseudo]

    if len(user_booksread) == 0:
        return print("Vous n'avez pas encore lu de livre !")

    if book_index is None or str(book_index + 1) not in user_booksread:  # on demande l'indice du livre lu à noter
        print("\n".join([f"{i + 1}- {title}" for i, title in enumerate(booklist) if str(i + 1) in user_booksread]))
        # 1- titre ; 2- 2me titre ; ...

        book_index = SafeIntInput("Quel livre lu souhaitez-vous noter ? Indice :") - 1
        # on garde en mémoire l'indice qui a pour valeur minimale 0 (pas 1 !)
        while str(book_index + 1) not in user_booksread:
            print("Vous n'avez pas lu ce livre.", end=" ")
            book_index = SafeIntInput("Indice d'un autre livre lu :") - 1

    note = ChoiceInput(1, 5, message_input="Entre 1 et 5, quelle est votre appréciation de ce livre ?")
    notation_matrix[pseudo][book_index] = note
    UpdateNotationMatrix(notation_matrix)
    return print(f"Le livre '{booklist[book_index]}' a bien été noté !")


def recommendBooks(notation_matrix: dict[str, list[int]]) -> None:
    """Recommande des livres.

    Cela propose un livre à un utilisateur selon les livres lus
    par son plus proche lecteur, mais pas par ledit utilisateur.

    La fonction propose aussi de noter le livre après l'avoir choisi.

    :return: Rien, car la fonction n'a pas été prévue pour être réutilisée en dehors du fichier principal.
    """

    def mostSimilar(reader_dict: dict[str, float]) -> tuple[str, float]:
        """
        Obtient l'utilisateur le plus similaire au lecteur.

        :param reader_dict: La ligne du lecteur de la matrice de similarité.
        :return: Tuple : lecteur, taux de similarité
        """

        max_simi, similar_reader = 0, ""
        for reader in reader_dict:
            if max_simi < reader_dict[reader] < 1:  # on veut la similarité max hors 1 (= soi-même)
                max_simi, similar_reader = reader_dict[reader], reader
        return similar_reader, max_simi

    with open("BdD/booksread.txt", 'r', encoding='utf-8') as brfile, \
            open("BdD/books.txt", 'r', encoding='utf-8') as booksfile:
        brdict, bookslist = FileDict(filecontent=brfile.read()), FileList(booksfile.read())

    pseudo = ConditionalInput(brdict, input_type="pseudo", newinput=False)
    print("Matrice de similarité calculée en {0[minutes]} min {0[seconds]} s {0[milliseconds]} ms {0[microseconds]} μs".
          format(_calculateSimilarityMatrix(notation_matrix)))  # update de la matrice de similarité

    similar, max_similarity = mostSimilar(SimilarityMatrix[pseudo])

    if max_similarity == 0:  # si le lecteur n'a encore rien noté
        print("Un de vos livres doit être noté avant que vous soyez recommandé.")
        ratenow_choice = bool(
            ChoiceInput(inf=0, sup=1,
                        message_input="""Voulez-vous en noter un maintenant ? 0 ou 1 :
1 --> Oui, sans tarder
0 --> Pas maintenant
"""))
        if ratenow_choice:
            return rateBook(notation_matrix, pseudo)
        return print("D'accord ; n'hésitez pas à le faire quand vous voulez !")

    reco_booklist = ConvertValues(
        iterable=sorted(ConvertValues(brdict[similar], convert_type="int")),
        convert_type="str")  # triage de la liste dans l'ordre
    recommended = [i for i in reco_booklist if i not in brdict[pseudo]]  # tous livres du lecteur recommandé non lus
    print("\n".join(
        [""] + ["{0[0]}- {0[1]}".format([i, bookslist[int(i) - 1]])
                for i in recommended]
    ))

    index_choice = SafeIntInput(message="Saisir l'indice d'un livre recommandé que vous n'avez pas encore lu :")
    while str(index_choice) not in recommended:
        print("Indice incorrect.", end=" ")
        index_choice = SafeIntInput(message="Saisir un autre indice de livre :")

    brdict[pseudo] += [str(index_choice)]
    with open("BdD/booksread.txt", 'w', encoding='utf-8') as brwrite:
        brwrite.write(JoinWriteFileDict(filedict=brdict))

    index_choice -= 1  # cela représente maintenant l'indice dans la liste
    print(f"Livre ajouté : {bookslist[index_choice]}")
    ratenow_choice = bool(
        ChoiceInput(inf=0, sup=1,
                    message_input="""Voulez-vous noter le livre maintenant ? 0 ou 1 :
1 --> Oui, sans tarder
0 --> Pas maintenant
"""))
    if not ratenow_choice:
        return print("D'accord. N'oubliez pas de noter le livre dès que vous aurez fini de le lire !")
    print(HORIZONTAL_LINE)
    return rateBook(notation_matrix, pseudo, book_index=index_choice)
