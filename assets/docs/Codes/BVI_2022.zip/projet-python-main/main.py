"""---------------------------------------------------------------------------------------------------------------------
Projet Python (Semestre 1) : Système de recommandation de livres

Auteurs : Matthieu BRANDAO, Alexandre BAUDIN, Anthony CAO

/ main.py : Programme principal ; en charge de faire l'appel aux autres fichiers pour chaque fonctionnalité.
---------------------------------------------------------------------------------------------------------------------"""


from menu import *
from profile import *
from recommendations import *
from depot import *


def main() -> None:
    """
    Redirection des fonctions selon les entrées.

    :return: La fonction elle-même.
    """

    notation_matrix = fixNotationMatrix()  # adapte la matrice selon les lecteurs réellement présents et le nb de livres
    # et supprime les lignes vides de chaque fichier
    # Supplante : addNewReader, removeReader, addNewBook
    # Ne prend PAS en charge : modifyReader, removeBook

    print(HORIZONTAL_LINE)
    functionality, finalchoice = menu()
    if finalchoice != -1:  # si on ne retourne pas sur le menu principal
        if functionality == 1:  # partie lecteurs
            if finalchoice == 1:
                addNewReader()
            elif finalchoice == 2:
                printReader()
            elif finalchoice == 3:
                modifyReader()
            else:
                removeReader()

        elif functionality == 2:  # partie dépôt
            if finalchoice == 1:
                printBookList()
            elif finalchoice == 2:
                addNewBook()
            elif finalchoice == 3:
                modifyBook()
            else:
                removeBook()

        else:  # partie recommendations
            if finalchoice == 1:
                rateBook(notation_matrix)
            else:
                recommendBooks(notation_matrix)

    return main()


if __name__ == "__main__":
    main()
